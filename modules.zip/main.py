import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os
import json
import requests
import urllib3
import threading
import os
import json
import time
import flet as ft
import sqlite3
import pandas as pd
from html.parser import HTMLParser # Standart kütüphane, kurulum gerektirmez!

# --- MODÜL IMPORTLARI ---
from modules.mizan_analiz.ui import MizanFrame
from modules.defter_ozellikleri.ui import LedgerPropsFrame
from modules.bakiye_analiz.ui import BalanceAnalizFrame
from modules.grafik_denetim.ui import ChartAuditFrame
from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
from modules.veri_yonetimi.ui import VeriYonetimiFrame
from modules.mali_tablolar.ui import FinancialReportsView
from modules.degiskenler_tablosu.ui import DegiskenlerTablosuFrame
from modules.denetim_analiz.ui import DenetimFrame
import modules.denetim_analiz.ui as audit_ui
from modules.hesaplama_havuzu.ui import HesaplamaHavuzuFrame
from modules.kullanici_profil.ui import ProfilFrame
from modules.istatistik_paneli.ui import StatisticsPanel
from modules.talep_oneri.ui import  TalepFrame
from modules.pivot_table.ui import PivotTableFrame
from modules.pivot_table.tablolar import TablolarUI
from modules.pivot_table.degisimanalizi import DegisimAnaliziUI
from modules.fatura_analiz.ui import FaturaAnalizFrame
from modules.fatura_analiz.ui_iade_listesi import IadeListesiFrame
from modules.fatura_analiz.ui_karsit import KarsitParametreFrame



# SSL Sertifika uyarısını gizle
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Sunucu Adresi (Senin Render adresin)
SERVER_URL = "https://ghostserver-rgyz.onrender.com"
# --- DRAG & DROP KÜTÜPHANESİ ---
try:
    from tkinterdnd2 import TkinterDnD
except ImportError:
    print("tkinterdnd2 bulunamadı, sürükle-bırak devre dışı.")
    class TkinterDnD:
        class Tk(tk.Tk): pass
if getattr(sys, 'frozen', False):
    application_path = os.path.dirname(sys.executable)
else:
    application_path = os.path.dirname(os.path.abspath(__file__))

sys.path.append(application_path)

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# --- AYARLAR VE VERİTABANI ---
from config import *
from utils.session_db import get_last_session, save_session

# --- DİĞER MODÜLLER ---
try: from modules.defter_yukle.ui import YeniDefterYukleFrame
except ImportError: YeniDefterYukleFrame = None

try: from modules.arsiv_yukle.ui import ArsivdenYukleFrame
except ImportError: ArsivdenYukleFrame = None

try: from modules.mukellef_karti.ui import MukellefBilgiKartiUI
except ImportError: MukellefBilgiKartiUI = None

try: from modules.fatura_yukle.ui_yukle import FaturaYukleFrame
except ImportError: FaturaYukleFrame = None

try: from modules.fatura_yukle.ui_liste import TumFaturalarFrame
except ImportError: TumFaturalarFrame = None

try: from modules.menu_yonetimi.ui import MenuYonetimFrame
except ImportError: MenuYonetimFrame = None

try: from modules.yevmiye_analiz.ui import YevmiyeAnalizFrame
except ImportError: YevmiyeAnalizFrame = None



def turkce_kucuk_yap(metin):
    """Metinlerdeki Türkçe karakterleri bozmadan küçük harfe çevirir."""
    if not isinstance(metin, str):
        return ""
    
    # Sıkıntılı büyük harfleri manuel olarak küçük karşılıklarıyla değiştiriyoruz
    harfler = {
        "I": "ı",
        "İ": "i",
        "Ş": "ş",
        "Ç": "ç",
        "Ğ": "ğ",
        "Ö": "ö",
        "Ü": "ü"
    }
    
    for buyuk, kucuk in harfler.items():
        metin = metin.replace(buyuk, kucuk)
        
    return metin.lower()

class SlidingNotePanel(tk.Frame):
    def __init__(self, parent, main_app, start_width=1150): 
        super().__init__(parent, bg="#cccccc", highlightthickness=2, highlightbackground="#34495e")
        self.main_app = main_app
        self.parent = parent
        self.start_width = start_width
        self.is_open = False
        self.animating = False
        self.current_x = start_width  
        self.current_note = None
        self.active_filter = "ALL"
        self.summary_data = []

        self.panel_vkn = "---"
        self.panel_unvan = "Seçili Mükellef Yok"
        self.panel_yil = "---"

        self.place(relx=1.0, x=self.start_width, y=0, relheight=1.0, width=self.start_width, anchor="ne")
        self.setup_ui()
        
        # --- YENİ EKLENEN: DIŞARIYA TIKLAMA KONTROLÜ (GLOBAL LİSTENER) ---
        self.main_app.bind_all("<Button-1>", self.check_click_outside, "+")

    def check_click_outside(self, event):
        """Ekranda bir yere tıklandığında bunun panelin dışında olup olmadığını kontrol eder."""
        if not self.is_open or self.animating:
            return
            
        # Eğer sağdaki turuncu açma/kapama butonuna tıklandıysa, bu işi toggle() halledecektir.
        btn = getattr(self.main_app, 'btn_floating_notes', None)
        if event.widget == btn:
            return
            
        try:
            widget = event.widget
            if isinstance(widget, str):
                widget = self.nametowidget(widget)
                
            # Eğer tıklanan yer farklı bir pencere ise (Örn: Combobox'ın açılır menüsü veya uyarı messagebox'ı) görmezden gel
            if widget.winfo_toplevel() != self.winfo_toplevel():
                return
                
            # Tıklanan nesneden yukarıya doğru hiyerarşiyi (master) tara. Eğer 'self' (bu panel) bulunursa, panelin İÇİNE tıklanmıştır.
            while widget:
                if widget == self:
                    return # Panelin içine tıklandı, kapatma
                widget = widget.master
                
            # Döngü bitti ve panel bulunamadıysa demek ki dışarıya tıklandı. Direk kapat.
            self.animate_out()
        except Exception:
            pass

    def setup_ui(self):
        info_header = tk.Frame(self, bg="#f8f9fa", pady=10, bd=1, relief="ridge")
        info_header.pack(fill=tk.X, padx=10, pady=(10, 0))
        
        btn_close = tk.Button(info_header, text="▶ PANELI KAPAT", bg="#e74c3c", fg="white", font=("Arial", 10, "bold"), bd=0, cursor="hand2", command=self.toggle)
        btn_close.pack(side=tk.LEFT, padx=15)

        self.lbl_title = tk.Label(info_header, text="🏢 Seçili Mükellef Yok", font=("Segoe UI", 14, "bold"), bg="#f8f9fa", fg="#2c3e50")
        self.lbl_title.pack()
        
        self.lbl_subtitle = tk.Label(info_header, text="🆔 VKN: ---    |    📅 Dönem: ---", font=("Segoe UI", 11), bg="#f8f9fa", fg="#7f8c8d")
        self.lbl_subtitle.pack()

        style = ttk.Style()
        style.configure("Panel.TNotebook", background="#cccccc", borderwidth=0)
        style.configure("Panel.TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=[15, 8])
        style.map("Panel.TNotebook.Tab", background=[("selected", "#34495e")], foreground=[("selected", "white")])
        
        self.notebook = ttk.Notebook(self, style="Panel.TNotebook")
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.tab_mevcut = tk.Frame(self.notebook, bg="#cccccc")
        self.notebook.add(self.tab_mevcut, text="📂 1. Mevcut Mükellef Detayları")
        self.setup_mevcut_tab()

        self.tab_tum = tk.Frame(self.notebook, bg="#cccccc")
        self.notebook.add(self.tab_tum, text="📊 2. Tüm Mükellef Kartları")
        self.setup_tum_tab()




    def setup_mevcut_tab(self):
        top_frame = tk.Frame(self.tab_mevcut, bg="#FFFFFF", height=45)
        top_frame.pack(fill=tk.X, pady=(10,0), padx=10)
        
        self.btn_ongoing = tk.Button(top_frame, text="DEVAM EDEN NOTLAR", bg="#ED7D31", fg="white", font=("Arial", 11, "bold"), relief="flat", padx=20, pady=8, command=lambda: self.load_mevcut_data("ONGOING"))
        self.btn_ongoing.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))
        
        self.btn_completed = tk.Button(top_frame, text="TAMAMLANANLAR", bg="#4472C4", fg="white", font=("Arial", 11, "bold"), relief="flat", padx=20, pady=8, command=lambda: self.load_mevcut_data("COMPLETED"))
        self.btn_completed.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        
        self.btn_all = tk.Button(top_frame, text="TÜM NOTLAR", bg="#C00000", fg="white", font=("Arial", 11, "bold"), relief="flat", padx=20, pady=8, command=lambda: self.load_mevcut_data("ALL"))
        self.btn_all.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2, 0))

        # --- GÜNCELLENEN KISIM: BUTON BAĞLANTISI ---
        self.btn_export = tk.Button(top_frame, text="📥 PDF RAPORLA", bg="#8e44ad", fg="white", font=("Arial", 11, "bold"), relief="flat", padx=20, pady=8, command=self.export_current_report)
        self.btn_export.pack(side=tk.RIGHT, fill=tk.X, padx=(20, 0))
        # -------------------------------------------

        search_frame = tk.Frame(self.tab_mevcut, bg="#cccccc", pady=5)
        search_frame.pack(fill=tk.X, padx=10)
        tk.Label(search_frame, text="🔍 Tabloda Kelime Ara:", bg="#cccccc", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT)
        self.search_note_var = tk.StringVar()
        self.search_note_var.trace("w", lambda *args: self.load_mevcut_data(self.active_filter))
        tk.Entry(search_frame, textvariable=self.search_note_var, font=("Segoe UI", 10), width=30).pack(side=tk.LEFT, padx=5)

        main_pane = tk.PanedWindow(self.tab_mevcut, orient=tk.HORIZONTAL, bg="#cccccc", sashwidth=5)
        main_pane.pack(fill=tk.BOTH, expand=True, padx=10, pady=(5, 10))

        self.left_frame = tk.Frame(main_pane, bg="white")
        main_pane.add(self.left_frame, width=750)

        cols = ("ID", "Risk", "Kaynak", "Ref", "Hesap Kodu", "Hesap Adı", "Açıklama", "Eklenme", "Tamamlanma")
        self.tree = ttk.Treeview(self.left_frame, columns=cols, show="headings", selectmode="browse")
        
        self.tree.column("ID", width=0, stretch=False)
        self.tree.column("Risk", width=70, anchor="center")
        self.tree.column("Kaynak", width=100, anchor="center")
        self.tree.column("Ref", width=80, anchor="center")
        self.tree.column("Hesap Kodu", width=80, anchor="w")
        self.tree.column("Hesap Adı", width=120, anchor="w")
        self.tree.column("Açıklama", width=200, anchor="w")
        self.tree.column("Eklenme", width=110, anchor="center")
        self.tree.column("Tamamlanma", width=110, anchor="center")
        for c in cols: self.tree.heading(c, text=c)

        sb = ttk.Scrollbar(self.left_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Double-1>", self.on_double_click) 
        
        self.tree.tag_configure("R_HIGH", background="#ffadad")
        self.tree.tag_configure("R_MID", background="#ffd6a5")
        self.tree.tag_configure("R_LOW", background="#caffbf")
        self.tree.tag_configure("R_DONE", background="#e0e0e0", foreground="#555")

        self.right_frame = tk.Frame(main_pane, bg="white", bd=1, relief="solid")
        main_pane.add(self.right_frame)

        tk.Label(self.right_frame, text="DETAY VE DÜZENLEME", bg="white", font=("Arial", 12, "bold")).pack(pady=10)

        tk.Label(self.right_frame, text="RİSK DURUMU SEÇİNİZ", bg="#5B9BD5", fg="white", font=("Arial", 10, "bold"), pady=5).pack(fill=tk.X, padx=10, pady=(5, 0))
        self.cmb_risk = ttk.Combobox(self.right_frame, values=["Yüksek", "Orta", "Düşük"], state="readonly", font=("Arial", 11))
        self.cmb_risk.pack(fill=tk.X, padx=10, pady=(0, 10))
        self.cmb_risk.set("Düşük")

        tk.Label(self.right_frame, text="RİSK AÇIKLAMASI", bg="#5B9BD5", fg="white", font=("Arial", 10, "bold"), pady=5).pack(fill=tk.X, padx=10, pady=(5, 0))
        self.txt_desc = tk.Text(self.right_frame, height=6, bg="#DDEBF7", font=("Arial", 10), bd=0)
        self.txt_desc.pack(fill=tk.X, padx=10, pady=(0, 10))

        tk.Label(self.right_frame, text="YAPILACAK İŞLEMLER", bg="#5B9BD5", fg="white", font=("Arial", 10, "bold"), pady=5).pack(fill=tk.X, padx=10, pady=(5, 0))
        self.txt_action = tk.Text(self.right_frame, height=6, bg="#DDEBF7", font=("Arial", 10), bd=0)
        self.txt_action.pack(fill=tk.X, padx=10, pady=(0, 10))

        btn_box = tk.Frame(self.right_frame, bg="white")
        btn_box.pack(fill=tk.X, padx=10, pady=20)
        
        self.btn_save = tk.Button(btn_box, text="💾 KAYDET (GÜNCELLE)", bg="#7f8c8d", fg="white", font=("Arial", 9, "bold"), height=2, command=self.save_current_note)
        self.btn_save.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)

        self.btn_complete = tk.Button(btn_box, text="✓ GÖREVİ TAMAMLA", bg="#27ae60", fg="white", font=("Arial", 9, "bold"), height=2, command=self.complete_task)
        self.btn_complete.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)
        
        tk.Button(self.right_frame, text="➕ YENİ GENEL NOT EKLE", bg="#34495e", fg="white", font=("Arial", 9, "bold"), pady=5, command=self.clear_form_for_new).pack(fill=tk.X, padx=10, side=tk.BOTTOM, pady=(0, 10))
        tk.Label(self.right_frame, text="KAYNAĞA GİTMEK İÇİN SATIRA ÇİFT TIKLAYIN.", bg="#fff3cd", fg="black", font=("Arial", 9, "bold"), pady=5).pack(side=tk.BOTTOM, fill=tk.X)



    def setup_tum_tab(self):
        search_frame = tk.Frame(self.tab_tum, bg="#34495e", pady=10, padx=15)
        search_frame.pack(fill=tk.X)
        
        tk.Label(search_frame, text="🔍 Mükellef Ara (Unvan/VKN):", bg="#34495e", fg="white", font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT, padx=(0, 10))
        self.search_card_var = tk.StringVar()
        self.search_card_var.trace("w", self.render_cards)
        tk.Entry(search_frame, textvariable=self.search_card_var, font=("Segoe UI", 10), width=30).pack(side=tk.LEFT)

        # --- YENİ EKLENEN: TÜM MÜKELLEFLER İÇİN TOPLU PDF BUTONU ---
        self.btn_export_all = tk.Button(search_frame, text="📥 TÜMÜNÜ PDF RAPORLA", bg="#8e44ad", fg="white", font=("Arial", 10, "bold"), relief="flat", padx=15, pady=4, command=self.export_all_report)
        self.btn_export_all.pack(side=tk.RIGHT, padx=(10, 0))

        canvas_bg = "#ecf0f1"
        self.cards_canvas = tk.Canvas(self.tab_tum, bg=canvas_bg, highlightthickness=0)
        self.cards_scroll = ttk.Scrollbar(self.tab_tum, orient="vertical", command=self.cards_canvas.yview)
        self.cards_inner = tk.Frame(self.cards_canvas, bg=canvas_bg)
        
        self.cards_canvas.configure(yscrollcommand=self.cards_scroll.set)
        self.cards_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.cards_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.cards_canvas_window = self.cards_canvas.create_window((0,0), window=self.cards_inner, anchor="nw")
        
        self.cards_inner.bind("<Configure>", lambda e: self.cards_canvas.configure(scrollregion=self.cards_canvas.bbox("all")))
        self.cards_canvas.bind("<Configure>", lambda e: self.cards_canvas.itemconfig(self.cards_canvas_window, width=e.width))

    def refresh_header(self):
        self.lbl_title.config(text=f"🏢 {self.panel_unvan}")
        self.lbl_subtitle.config(text=f"🆔 VKN: {self.panel_vkn}    |    📅 Dönem: {self.panel_yil}")

    def load_mevcut_data(self, filter_type):
        self.active_filter = filter_type
        self.refresh_header()
        
        for i in self.tree.get_children(): self.tree.delete(i)
        if self.panel_vkn in ["---", "000", ""]: return
        
        search_term = self.search_note_var.get().lower()
        filter_map = {"ONGOING": "ONGOING", "COMPLETED": "COMPLETED", "ALL": "ALL"}
        mapped_filter = filter_map.get(filter_type, "ALL")

        try:
            from modules.not_yonetimi.db import get_notes_by_filter
            data = get_notes_by_filter(self.panel_vkn, status_filter=mapped_filter)
            
            for n in data:
                desc = str(n.get('description', ''))
                risk = n.get('risk_level', '')
                status = str(n.get('status', ''))
                hesap_kodu = str(n.get('hesap_kodu', '-'))
                hesap_adi = str(n.get('hesap_adi', '-'))
                kaynak = str(n.get('table_source', '-'))
                ref = str(n.get('row_ref', '-'))
                
                if search_term and not any(search_term in x.lower() for x in [desc, risk, status, hesap_kodu, hesap_adi, kaynak]):
                    continue

                tag = "R_LOW"
                if status == "Tamamlandı": tag = "R_DONE"
                elif risk == "Yüksek": tag = "R_HIGH"
                elif risk == "Orta": tag = "R_MID"
                
                desc_short = desc.replace("\n", " ")
                created = str(n.get('created_at', ''))[:16]
                completed = str(n.get('completed_at', ''))[:16] if n.get('completed_at') else "-"
                
                vals = (n['id'], risk, kaynak, ref, hesap_kodu, hesap_adi, desc_short, created, completed)
                self.tree.insert("", "end", values=vals, tags=(tag,))
        except Exception as e: print("Mevcut veri hatası:", e)

    def on_select(self, event):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0])['values']
        
        status = "Tamamlandı" if vals[8] != "-" else "Devam"
        self.current_note = {"id": vals[0], "status": status, "table_source": vals[2], "row_ref": vals[3]} 
        
        self.cmb_risk.set(vals[1])
        try:
            from modules.not_yonetimi.db import get_single_note
            full_note = get_single_note(self.panel_vkn, vals[2], vals[3])
            
            self.txt_desc.delete("1.0", tk.END)
            self.txt_action.delete("1.0", tk.END)
            
            if full_note:
                self.txt_desc.insert("1.0", full_note.get('description', ''))
                self.txt_action.insert("1.0", full_note.get('action_plan', ''))
            else:
                self.txt_desc.insert("1.0", str(vals[6]))
        except: pass


    def on_double_click(self, event):
        if not self.current_note: return
        sistem_vkn = getattr(self.main_app, 'vkn', '---')
        
        # Seçili mükellef ile paneldeki mükellef aynı mı kontrolü
        if sistem_vkn != self.panel_vkn:
            from tkinter import messagebox
            messagebox.showwarning(
                "Mükellef Uyuşmazlığı", 
                f"Bu detaya gidebilmek için '{self.panel_unvan}' firmasını sol üst arama menüsünden ana defter olarak yüklemelisiniz.\n\n"
                f"Şu anki aktif yüklü mükellef VKN: {sistem_vkn}"
            )
            return

        target_ref = str(self.current_note['row_ref'])
        
        # Eğer tıklanan satır bir "GENEL_NOT" ise uyar, değilse KESİNLİKLE fiş detayını aç.
        if target_ref == "GENEL_NOT":
            from tkinter import messagebox
            messagebox.showinfo("Bilgi", "Bu bir genel nottur, herhangi bir yevmiye fişine bağlı değildir.")
            return

        # KAYNAK NE OLURSA OLSUN (Mizan, Denetim, Yevmiye vb.) DOĞRUDAN FİŞ DETAY POPUP'INI AÇ
        self.open_fis_detail_popup(target_ref)


    def clear_form_for_new(self):
        self.current_note = None
        self.cmb_risk.set("Düşük")
        self.txt_desc.delete("1.0", tk.END)
        self.txt_action.delete("1.0", tk.END)

    def save_current_note(self):
        if self.panel_vkn in ["---", "000", ""]: return
        try:
            from modules.not_yonetimi.db import upsert_note, get_single_note
            if self.current_note:
                full_data = get_single_note(self.panel_vkn, self.current_note['table_source'], self.current_note['row_ref']) or {}
            else:
                full_data = {"vkn": self.panel_vkn, "unvan": self.panel_unvan, "table_source": "DASHBOARD_HIZLI_NOT", "row_ref": "GENEL_NOT", "status": "Devam", "hesap_kodu": "-", "hesap_adi": "-", "borc": "0", "alacak": "0"}
            
            full_data['unvan'] = self.panel_unvan
            full_data['risk_level'] = self.cmb_risk.get()
            full_data['description'] = self.txt_desc.get("1.0", "end-1c").strip()
            full_data['action_plan'] = self.txt_action.get("1.0", "end-1c").strip()
            
            upsert_note(full_data)
            self.load_mevcut_data(self.active_filter)
            self.fetch_all_cards_data() 
            from tkinter import messagebox
            messagebox.showinfo("Başarılı", "Not güncellendi/kaydedildi.")
        except Exception as e: 
            from tkinter import messagebox
            messagebox.showerror("Hata", str(e))

    def complete_task(self):
        if not self.current_note: return
        from tkinter import messagebox
        if messagebox.askyesno("Onay", "Görevi tamamlandı işaretlemek istiyor musunuz?"):
            try:
                from modules.not_yonetimi.db import update_status
                update_status(self.current_note['id'], "Tamamlandı")
                self.load_mevcut_data(self.active_filter)
                self.fetch_all_cards_data()
                self.clear_form_for_new()
            except: pass



    def export_current_report(self):
        import webbrowser
        import tempfile
        import os
        from datetime import datetime
        from tkinter import messagebox
        
        if self.panel_vkn in ["---", "000", ""]:
            messagebox.showwarning("Uyarı", "Lütfen raporlanacak mükellefi seçin veya 'Tüm Mükellef Kartları' sekmesinden toplu rapor alın.")
            return

        try:
            from modules.not_yonetimi.db import get_notes_by_filter
            notes = get_notes_by_filter(self.panel_vkn, status_filter="ALL")
            
            if not notes:
                messagebox.showinfo("Bilgi", "Bu mükellefe ait raporlanacak bir not bulunamadı.")
                return

            grouped_by_status = {"Devam Eden İşlemler": {}, "Tamamlanan İşlemler": {}}
            devam_count = 0
            tamam_count = 0

            for n in notes:
                status = str(n.get('status', 'Devam'))
                src = str(n.get('table_source', 'GENEL')).upper()
                
                if status == "Tamamlandı":
                    main_key = "Tamamlanan İşlemler"
                    tamam_count += 1
                else:
                    main_key = "Devam Eden İşlemler"
                    devam_count += 1
                    
                if src not in grouped_by_status[main_key]:
                    grouped_by_status[main_key][src] = []
                grouped_by_status[main_key][src].append(n)

            now_str = datetime.now().strftime("%d.%m.%Y %H:%M")
            html_content = f"""
            <!DOCTYPE html>
            <html lang="tr">
            <head>
                <meta charset="UTF-8">
                <title>{self.panel_unvan} - Risk Raporu</title>
                <style>
                    body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f4f6f9; color: #333; padding: 30px; line-height: 1.6; }}
                    .report-header {{ text-align: center; background: #2c3e50; color: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }}
                    .report-header h1 {{ margin: 0; font-size: 24px; }}
                    .report-header p {{ margin: 5px 0 0 0; font-size: 14px; color: #bdc3c7; }}
                    .main-group-title {{ background: #2980b9; color: white; padding: 12px 15px; font-size: 16px; font-weight: bold; margin-top: 30px; margin-bottom: 15px; border-radius: 6px; text-transform: uppercase; }}
                    .main-group-title.tamamlandi {{ background: #27ae60; }}
                    .group-container {{ margin-bottom: 25px; background: white; border-radius: 6px; overflow: hidden; border: 1px solid #e1e8ed; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }}
                    .group-title {{ background: #34495e; color: white; padding: 10px 15px; font-size: 14px; font-weight: bold; margin: 0; }}
                    table {{ width: 100%; border-collapse: collapse; }}
                    th {{ background: #ecf0f1; color: #7f8c8d; padding: 10px 12px; text-align: left; font-size: 12px; text-transform: uppercase; }}
                    td {{ padding: 10px 12px; border-top: 1px solid #ecf0f1; font-size: 13px; }}
                    .row-Yüksek {{ background-color: #ffeaa7; }}
                    .row-Yüksek td.risk-col {{ color: #d35400; font-weight: bold; }}
                    .row-Orta {{ background-color: #fdf2e9; }}
                    .row-Orta td.risk-col {{ color: #e67e22; font-weight: bold; }}
                    .row-Düşük {{ background-color: #e8f8f5; }}
                    .row-Düşük td.risk-col {{ color: #16a085; font-weight: bold; }}
                    .status-Tamamlandı {{ text-decoration: line-through; color: #95a5a6; background-color: #f9f9f9; }}
                    .status-badge {{ display: inline-block; padding: 2px 6px; border-radius: 10px; font-size: 11px; font-weight: bold; }}
                    .badge-Devam {{ background: #3498db; color: white; }}
                    .badge-Tamamlandı {{ background: #27ae60; color: white; }}
                    @media print {{ body {{ background: white; padding: 0; }} .btn-print {{ display: none; }} }}
                    .btn-print {{ display: block; width: 250px; margin: 0 auto 20px auto; text-align: center; background: #e74c3c; color: white; padding: 10px; text-decoration: none; border-radius: 5px; font-weight: bold; cursor: pointer; }}
                </style>
            </head>
            <body>
                <div class="btn-print" onclick="window.print()">🖨️ PDF OLARAK KAYDET / YAZDIR</div>
                <div class="report-header">
                    <h1>{self.panel_unvan}</h1>
                    <p>Mali Denetim Risk Raporu | VKN: {self.panel_vkn} | Dönem: {self.panel_yil} | Çıktı Tarihi: {now_str}</p>
                    <p style="margin-top: 10px; font-weight: bold; color: white;">Toplam: {devam_count} Devam Eden, {tamam_count} Tamamlanan Not</p>
                </div>
            """

            for main_status, modules in grouped_by_status.items():
                if not modules: continue 
                title_class = "main-group-title tamamlandi" if main_status == "Tamamlanan İşlemler" else "main-group-title"
                icon = "✅" if main_status == "Tamamlanan İşlemler" else "⏳"
                html_content += f'<div class="{title_class}">{icon} {main_status}</div>'

                for group_name, items in modules.items():
                    html_content += f"""
                    <div class="group-container">
                        <div class="group-title">📂 Kaynak: {group_name} ({len(items)} Kayıt)</div>
                        <table>
                            <thead>
                                <tr><th>Ref/Belge No</th><th>Hesap Kodu</th><th>Risk</th><th>Açıklama</th><th>Aksiyon Planı</th><th>Durum</th></tr>
                            </thead>
                            <tbody>
                    """
                    for item in items:
                        risk = item.get('risk_level', 'Düşük')
                        status = item.get('status', 'Devam')
                        row_class = f"row-{risk}" if status != 'Tamamlandı' else "status-Tamamlandı"
                        html_content += f"""
                                <tr class="{row_class}">
                                    <td><b>{item.get('row_ref', '-')}</b></td>
                                    <td>{item.get('hesap_kodu', '-')}</td>
                                    <td class="risk-col">{risk}</td>
                                    <td>{item.get('description', '-')}</td>
                                    <td>{item.get('action_plan', '-')}</td>
                                    <td><span class="status-badge badge-{status}">{status}</span></td>
                                </tr>
                        """
                    html_content += "</tbody></table></div>"

            html_content += "</body></html>"
            fd, path = tempfile.mkstemp(suffix=".html", prefix="Mellef_Risk_Raporu_")
            with os.fdopen(fd, 'w', encoding='utf-8') as f: f.write(html_content)
            webbrowser.open('file://' + os.path.realpath(path))
        except Exception as e:
            messagebox.showerror("Hata", str(e))


    def export_all_report(self):
        import webbrowser
        import tempfile
        import os
        from datetime import datetime
        from tkinter import messagebox
        
        try:
            from modules.not_yonetimi.db import get_notes_by_filter
            
            if not self.summary_data:
                self.fetch_all_cards_data()
            
            if not self.summary_data:
                messagebox.showinfo("Bilgi", "Sistem genelinde kayıtlı herhangi bir mükellef notu bulunamadı.")
                return
            
            now_str = datetime.now().strftime("%d.%m.%Y %H:%M")
            total_devam_count = 0
            total_tamam_count = 0
            
            html_content = f"""
            <!DOCTYPE html>
            <html lang="tr">
            <head>
                <meta charset="UTF-8">
                <title>Tüm Mükellefler Konsolide Risk Raporu</title>
                <style>
                    body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f4f6f9; color: #333; padding: 30px; line-height: 1.6; }}
                    .report-header {{ text-align: center; background: #2c3e50; color: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }}
                    .report-header h1 {{ margin: 0; font-size: 24px; }}
                    .report-header p {{ margin: 5px 0 0 0; font-size: 14px; color: #bdc3c7; }}
                    .taxpayer-section {{ background: #ffffff; border-radius: 8px; padding: 20px; margin-bottom: 35px; box-shadow: 0 4px 10px rgba(0,0,0,0.04); border-left: 5px solid #8e44ad; page-break-inside: avoid; }}
                    .taxpayer-title {{ color: #2c3e50; font-size: 18px; font-weight: bold; border-bottom: 2px solid #ecf0f1; padding-bottom: 8px; margin-bottom: 15px; text-transform: uppercase; }}
                    .main-group-title {{ background: #2980b9; color: white; padding: 6px 12px; font-size: 14px; font-weight: bold; margin-top: 15px; margin-bottom: 10px; border-radius: 4px; text-transform: uppercase; }}
                    .main-group-title.tamamlandi {{ background: #27ae60; }}
                    .group-container {{ margin-bottom: 15px; background: white; border-radius: 4px; overflow: hidden; border: 1px solid #e1e8ed; }}
                    .group-title {{ background: #34495e; color: white; padding: 8px 12px; font-size: 12px; font-weight: bold; margin: 0; }}
                    table {{ width: 100%; border-collapse: collapse; }}
                    th {{ background: #ecf0f1; color: #7f8c8d; padding: 8px 10px; text-align: left; font-size: 11px; text-transform: uppercase; }}
                    td {{ padding: 8px 10px; border-top: 1px solid #ecf0f1; font-size: 12px; }}
                    .row-Yüksek {{ background-color: #ffeaa7; }}
                    .row-Yüksek td.risk-col {{ color: #d35400; font-weight: bold; }}
                    .row-Orta {{ background-color: #fdf2e9; }}
                    .row-Orta td.risk-col {{ color: #e67e22; font-weight: bold; }}
                    .row-Düşük {{ background-color: #e8f8f5; }}
                    .row-Düşük td.risk-col {{ color: #16a085; font-weight: bold; }}
                    .status-Tamamlandı {{ text-decoration: line-through; color: #95a5a6; background-color: #f9f9f9; }}
                    .status-badge {{ display: inline-block; padding: 2px 5px; border-radius: 8px; font-size: 10px; font-weight: bold; }}
                    .badge-Devam {{ background: #3498db; color: white; }}
                    .badge-Tamamlandı {{ background: #27ae60; color: white; }}
                    @media print {{ body {{ background: white; padding: 0; }} .taxpayer-section {{ box-shadow: none; page-break-inside: avoid; }} .btn-print {{ display: none; }} }}
                    .btn-print {{ display: block; width: 250px; margin: 0 auto 20px auto; text-align: center; background: #e74c3c; color: white; padding: 10px; text-decoration: none; border-radius: 5px; font-weight: bold; cursor: pointer; }}
                </style>
            </head>
            <body>
                <div class="btn-print" onclick="window.print()">🖨️ PDF OLARAK KAYDET / YAZDIR</div>
                <div class="report-header">
                    <h1>TÜM MÜKELLEFLER KONSOLİDE RİSK RAPORU</h1>
                    <p>Sistem Genelindeki Tüm Firmalara Ait Notlar Listesi | Çıktı Tarihi: {now_str}</p>
                </div>
            """

            has_any_data = False
            for item in self.summary_data:
                unvan, vkn, _, _, _, _ = item
                notes = get_notes_by_filter(vkn, status_filter="ALL")
                if not notes: continue
                
                has_any_data = True
                html_content += f'<div class="taxpayer-section">'
                html_content += f'<div class="taxpayer-title">🏢 {unvan} (VKN: {vkn})</div>'

                grouped = {"Devam Eden İşlemler": {}, "Tamamlanan İşlemler": {}}
                for n in notes:
                    status = str(n.get('status', 'Devam'))
                    src = str(n.get('table_source', 'GENEL')).upper()
                    m_key = "Tamamlanan İşlemler" if status == "Tamamlandı" else "Devam Eden İşlemler"
                    if status == "Tamamlandı": total_tamam_count += 1
                    else: total_devam_count += 1
                        
                    if src not in grouped[m_key]: grouped[m_key][src] = []
                    grouped[m_key][src].append(n)

                for main_status, modules in grouped.items():
                    if not modules: continue
                    t_class = "main-group-title tamamlandi" if main_status == "Tamamlanan İşlemler" else "main-group-title"
                    html_content += f'<div class="{t_class}">{"✅" if main_status == "Tamamlanan İşlemler" else "⏳"} {main_status}</div>'

                    for g_name, items in modules.items():
                        html_content += f"""
                        <div class="group-container">
                            <div class="group-title">📂 Kaynak: {g_name} ({len(items)} Kayıt)</div>
                            <table>
                                <thead><tr><th>Ref No</th><th>Hesap Kodu</th><th>Risk</th><th>Açıklama</th><th>Aksiyon Planı</th><th>Durum</th></tr></thead>
                                <tbody>
                        """
                        for itm in items:
                            risk = itm.get('risk_level', 'Düşük')
                            stat = itm.get('status', 'Devam')
                            r_class = f"row-{risk}" if stat != 'Tamamlandı' else "status-Tamamlandı"
                            html_content += f"""
                                    <tr class="{r_class}">
                                        <td><b>{itm.get('row_ref', '-')}</b></td>
                                        <td>{itm.get('hesap_kodu', '-')}</td>
                                        <td class="risk-col">{risk}</td>
                                        <td>{itm.get('description', '-')}</td>
                                        <td>{itm.get('action_plan', '-')}</td>
                                        <td><span class="status-badge badge-{stat}">{stat}</span></td>
                                    </tr>
                            """
                        html_content += "</tbody></table></div>"
                html_content += '</div>'

            if not has_any_data:
                messagebox.showinfo("Bilgi", "Raporlanacak hiçbir not kaydı bulunamadı.")
                return

            html_content += f"""
                <div style="text-align:center; margin-top:20px; font-weight:bold; color:#2c3e50;">
                    Rapor Sonu - Genel Toplam: {total_devam_count} Devam Eden, {total_tamam_count} Tamamlanan Kayıt
                </div>
            </body></html>"""

            fd, path = tempfile.mkstemp(suffix=".html", prefix="Konsolide_Risk_Raporu_")
            with os.fdopen(fd, 'w', encoding='utf-8') as f: f.write(html_content)
            webbrowser.open('file://' + os.path.realpath(path))
        except Exception as e:
            messagebox.showerror("Hata", str(e))

    def fetch_all_cards_data(self):
        db_path = os.path.join(application_path, "notes.db")
        self.summary_data = []
        if os.path.exists(db_path):
            try:
                import sqlite3
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                query = """
                    SELECT 
                        IFNULL(unvan, 'Bilinmeyen Ünvan'), vkn, COUNT(*),
                        SUM(CASE WHEN risk_level='Yüksek' THEN 1 ELSE 0 END),
                        SUM(CASE WHEN status='Devam' THEN 1 ELSE 0 END),
                        SUM(CASE WHEN status='Tamamlandı' THEN 1 ELSE 0 END)
                    FROM risk_notes GROUP BY vkn, unvan ORDER BY COUNT(*) DESC
                """
                cursor.execute(query)
                self.summary_data = cursor.fetchall()
                conn.close()
            except Exception as e: print("DB Hatası:", e)
        self.render_cards()


    def render_cards(self, *args):
        for w in self.cards_inner.winfo_children(): w.destroy()
        search_term = self.search_card_var.get().lower()
        filtered = [item for item in self.summary_data if search_term in item[0].lower() or search_term in str(item[1])]

        color_palette = [("#ED5565", "#DA4453"), ("#FC6E51", "#E9573F"), ("#FFCE54", "#FCBB42"), ("#A0D468", "#8CC152"), ("#48CFAD", "#37BC9B"), ("#4FC1E9", "#3BAFDA")]

        # max_cols 3'ten 5'e çıkarılarak yan yana daha fazla kart sığdırıldı
        row, col, max_cols = 0, 0, 5 
        for idx, item in enumerate(filtered):
            unvan, vkn_no, t_total, t_high, t_pending, t_completed = item
            c_light, c_dark = color_palette[idx % len(color_palette)]

            # Kart çerçevesi ve padding alanları daraltıldı
            card = tk.Frame(self.cards_inner, bg="white", highlightthickness=1, highlightbackground="#bdc3c7", cursor="hand2")
            card.grid(row=row, column=col, padx=4, pady=4, sticky="nsew") # padx/pady 10'dan 4'e düşürüldü
            
            # Üst bilgi barı yüksekliği azaltıldı (35'ten 24'e)
            top_bar = tk.Frame(card, bg=c_light, height=24)
            top_bar.pack(fill=tk.X)
            top_bar.pack_propagate(False)
            tk.Label(top_bar, text=f"{t_total} Kayıt", bg=c_light, fg="white", font=("Segoe UI", 8, "bold")).pack(side=tk.LEFT, padx=5)

            # Uzun unvanlar için kırpma sınırı 30'dan 20'ye düşürüldü, font boyutu 10'dan 9'a indirildi
            short_unvan = unvan if len(unvan) < 20 else unvan[:17] + "..."
            tk.Label(card, text=short_unvan, bg="white", fg="#2c3e50", font=("Segoe UI", 9, "bold"), anchor="w").pack(fill=tk.X, padx=6, pady=(4, 0))
            tk.Label(card, text=f"VKN: {vkn_no}", bg="white", fg="#7f8c8d", font=("Consolas", 8), anchor="w").pack(fill=tk.X, padx=6)

            # İstatistik ikon alanı ve dikey boşlukları (pady) minimize edildi
            stats_frame = tk.Frame(card, bg="white")
            stats_frame.pack(fill=tk.X, padx=6, pady=4)
            tk.Label(stats_frame, text=f"⚠️ {t_high}", bg="white", fg="#c0392b" if t_high>0 else "gray", font=("Arial", 8, "bold")).pack(side=tk.LEFT, expand=True)
            tk.Label(stats_frame, text=f"⏳ {t_pending}", bg="white", fg="#e67e22" if t_pending>0 else "gray", font=("Arial", 8, "bold")).pack(side=tk.LEFT, expand=True)
            tk.Label(stats_frame, text=f"✅ {t_completed}", bg="white", fg="#27ae60" if t_completed>0 else "gray", font=("Arial", 8, "bold")).pack(side=tk.LEFT, expand=True)

            def bind_click(widget, u=unvan, v=vkn_no):
                widget.bind("<Button-1>", lambda e: self.open_taxpayer_details(u, v))
            for w in [card, top_bar, stats_frame] + card.winfo_children() + top_bar.winfo_children() + stats_frame.winfo_children():
                bind_click(w)

            col += 1
            if col >= max_cols: col, row = 0, row + 1

        for i in range(max_cols): self.cards_inner.columnconfigure(i, weight=1)

    def open_taxpayer_details(self, unvan, vkn):
        self.panel_vkn = vkn
        self.panel_unvan = unvan
        self.panel_yil = "---"
        
        self.refresh_header()
        self.notebook.select(self.tab_mevcut) 
        self.load_mevcut_data("ALL")
        self.clear_form_for_new()

    def toggle(self):
        if self.animating: return
        self.animating = True
        if not self.is_open:
            self.panel_vkn = getattr(self.main_app, 'vkn', '---')
            self.panel_unvan = getattr(self.main_app, 'unvan', 'Seçili Mükellef Yok')
            self.panel_yil = getattr(self.main_app, 'yil', '---')
            
            self.fetch_all_cards_data()
            self.load_mevcut_data("ALL")
            self.animate_in()
        else:
            self.animate_out()

    def animate_in(self):
        if self.current_x > 0:
            self.current_x -= 70
            if self.current_x < 0: self.current_x = 0
            self.place(x=self.current_x)
            self.after(10, self.animate_in)
        else:
            self.is_open = True
            self.animating = False


    def fetch_fis_details(self, fis_no):
        import os
        import pandas as pd
        
        try:
            from config import get_mukellefler_dir
            base_dir = get_mukellefler_dir()
        except ImportError:
            return []

        target_folder = None
        if os.path.exists(base_dir):
            for f in os.listdir(base_dir):
                if f.endswith(f"-{self.panel_vkn}"):
                    target_folder = os.path.join(base_dir, f)
                    break
                    
        if not target_folder: return []
        
        # Yıl kontrolü (Tüm mükellefler sekmesinden açılırsa yıl "---" gelir)
        aktif_yil = str(self.panel_yil)
        if aktif_yil == "---":
            aktif_yil = getattr(self.main_app, 'yil', '---')
            
        if aktif_yil == "---":
            # Klasör içindeki yılları tara (Örn: 2023, 2024), en güncelini al
            yillar = [d for d in os.listdir(target_folder) if d.isdigit()]
            if yillar:
                aktif_yil = sorted(yillar, reverse=True)[0]
            else:
                return []
        
        parquet_path = os.path.join(target_folder, str(aktif_yil), f"{aktif_yil}_FULL.parquet")
        if not os.path.exists(parquet_path): return []
        
        try:
            df = pd.read_parquet(parquet_path)
            col_name = "YevmiyeNo" if "YevmiyeNo" in df.columns else ("Yevmiye No" if "Yevmiye No" in df.columns else None)
            if not col_name: return []
            
            fis_df = df[df[col_name].astype(str).str.strip() == str(fis_no).strip()]
            return fis_df.to_dict('records')
        except Exception as e:
            print(f"Fiş detay okuma hatası: {e}")
            return []

    def fetch_invoice_from_db(self, fatura_no):
        """E-Fatura arşivinden belge numarasına göre faturayı çeker."""
        import sqlite3
        import pandas as pd
        import os
        try:
            from config import get_mukellefler_dir
            base_dir = get_mukellefler_dir()
        except ImportError:
            return None

        try:
            vkn = self.panel_vkn
            yil = self.panel_yil
            if yil == "---":
                yil = getattr(self.main_app, 'yil', '---')
            
            target_folder = None
            if os.path.exists(base_dir):
                for f in os.listdir(base_dir):
                    if f.endswith(f"-{vkn}") and os.path.isdir(os.path.join(base_dir, f)):
                        target_folder = os.path.join(base_dir, f)
                        break
            
            if not target_folder: return None

            db_path = os.path.join(target_folder, str(yil), f"fatura_data_{yil}.db")
            if not os.path.exists(db_path): return None

            conn = sqlite3.connect(db_path)
            c = conn.cursor()
            c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
            res = c.fetchone()
            if not res:
                conn.close()
                return None
            
            tbl_name = res[0]
            df_limit1 = pd.read_sql(f"SELECT * FROM {tbl_name} LIMIT 1", conn)
            col_name = "NO_FATURA" if "NO_FATURA" in df_limit1.columns else "FATURA_NO"
            
            query = f"SELECT * FROM {tbl_name} WHERE {col_name} = ?"
            df = pd.read_sql(query, conn, params=(fatura_no,))
            conn.close()
            
            return df
        except Exception as e:
            print(f"Fatura DB Sorgu Hatası: {e}")
            return None



    def open_fis_detail_popup(self, fis_no):
        from tkinter import filedialog, messagebox
        import pandas as pd

        if hasattr(self, '_fis_popup') and self._fis_popup.winfo_exists():
            self._fis_popup.destroy()

        items = self.fetch_fis_details(fis_no)
        if not items:
            messagebox.showinfo("Bilgi", "Fiş detayı bulunamadı veya veritabanında okunamadı.")
            return

        popup = tk.Toplevel(self)
        self._fis_popup = popup
        
        popup.title(f"Fiş İnceleme - No: {fis_no}")
        popup.geometry("1300x650")
        popup.configure(bg="white")
        
        # --- Uİ.PY GİBİ MODERN BAŞLIK TASARIMI ---
        HEADER_BG = "#1B2559" 
        TEXT_WHITE = "white"
        
        date_str = str(items[0].get('KayitTarihi', items[0].get('Tarih', '-'))) if items else "-"
        if len(date_str) > 10: date_str = date_str[:10]
        
        header_frame = tk.Frame(popup, bg=HEADER_BG, height=60)
        header_frame.pack(fill="x")
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text=f"FİŞ NO: {fis_no}", bg=HEADER_BG, fg=TEXT_WHITE, font=("DM Sans", 16, "bold")).pack(side="left", padx=20)
        tk.Label(header_frame, text=f"TARİH: {date_str}", bg=HEADER_BG, fg=TEXT_WHITE, font=("DM Sans", 14, "bold")).pack(side="right", padx=20)

        toolbar_frame = tk.Frame(popup, bg="#ecf0f1", height=40)
        toolbar_frame.pack(fill="x")
        toolbar_frame.pack_propagate(False)

        def _export_excel():
            if not items: return
            try:
                df_exp = pd.DataFrame(items)
                path = filedialog.asksaveasfilename(parent=popup, defaultextension=".xlsx", filetypes=[("Excel Dosyası", "*.xlsx")], title=f"Fiş_{fis_no}_Detay")
                if path:
                    df_exp.to_excel(path, index=False)
                    messagebox.showinfo("Başarılı", "Excel dosyası kaydedildi.", parent=popup)
            except Exception as e:
                messagebox.showerror("Hata", str(e), parent=popup)

        tk.Button(toolbar_frame, text="📥 Excel İndir", bg="#27ae60", fg="white", font=("DM Sans", 9, "bold"), relief="flat", padx=10, command=_export_excel).pack(side="right", padx=10, pady=5)
        tk.Label(toolbar_frame, text="💡 İpucu: Belge görüntülemek veya satır kopyalamak için tabloya sağ tıklayınız.", bg="#ecf0f1", fg="#7f8c8d", font=("DM Sans", 9, "bold")).pack(side="left", padx=20)

        # --- YENİ SÜTUNLAR: MUAVİN EKLENDİ ---
        cols = ("HesapKodu", "HesapAdı", "MuavinKodu", "MuavinAdı", "BelgeNo", "FisAciklama", "DetayAciklama", "Borc", "Alacak")
        tree_frame = tk.Frame(popup, bg="white")
        tree_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        style = ttk.Style()
        style.configure("FisDetay.Treeview", rowheight=30, font=('DM Sans', 10), borderwidth=0)
        style.configure("FisDetay.Treeview.Heading", font=('DM Sans', 10, 'bold'), background="#1B2559", foreground="white")
        
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", style="FisDetay.Treeview", selectmode="extended")
        
        ysb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        
        tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        
        tree_frame.rowconfigure(0, weight=1); tree_frame.columnconfigure(0, weight=1)

        tree.heading("HesapKodu", text="Hesap Kodu");      tree.column("HesapKodu", width=90, anchor="w")
        tree.heading("HesapAdı", text="Hesap Adı");        tree.column("HesapAdı", width=160, anchor="w")
        tree.heading("MuavinKodu", text="Muavin Kodu");    tree.column("MuavinKodu", width=90, anchor="w")
        tree.heading("MuavinAdı", text="Muavin Adı");      tree.column("MuavinAdı", width=160, anchor="w")
        tree.heading("BelgeNo", text="Belge No");          tree.column("BelgeNo", width=90, anchor="center")
        tree.heading("FisAciklama", text="Fiş Açıklama");  tree.column("FisAciklama", width=180, anchor="w")
        tree.heading("DetayAciklama", text="Detay Açıklama"); tree.column("DetayAciklama", width=180, anchor="w")
        tree.heading("Borc", text="Borç");                 tree.column("Borc", width=100, anchor="e")
        tree.heading("Alacak", text="Alacak");             tree.column("Alacak", width=100, anchor="e")
        
        tree.tag_configure('odd', background='#F8F9FC')
        tree.tag_configure('even', background='white')

        # =========================================================
        # --- SAĞ TIK MENÜSÜ VE BELGE GÖSTER FONKSİYONU ---
        context_menu = tk.Menu(tree, tearoff=0, font=("DM Sans", 10))
        
        def _copy_selection():
            selection = tree.selection()
            if not selection: return
            res = ""
            for item in selection:
                vals = tree.item(item)['values']
                res += "\t".join([str(v) for v in vals]) + "\n"
            popup.clipboard_clear()
            popup.clipboard_append(res)
            
        def _show_invoice_document():
            sel = tree.selection()
            if not sel: return
            vals = tree.item(sel[0])['values']
            belge_no = str(vals[4]).strip() # BelgeNo indexi 4 oldu (Muavinlerden dolayı)

            if belge_no.endswith('.0'): belge_no = belge_no[:-2]

            if not belge_no or belge_no in ["-", "", "None", "0", "nan", "."]:
                messagebox.showwarning("Uyarı", "Geçerli bir Belge Numarası yok.", parent=popup)
                return

            df_fatura = self.fetch_invoice_from_db(belge_no)
            if df_fatura is not None and not df_fatura.empty:
                try:
                    from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
                    target_master = self.main_app.winfo_toplevel()
                    FaturaGoruntulePopup(target_master, df_fatura)
                except Exception as e:
                    messagebox.showerror("Hata", f"Görüntüleyici açılırken hata:\n{e}", parent=popup)
            else:
                messagebox.showinfo("Bulunamadı", f"'{belge_no}' numaralı belge E-Fatura arşivinde bulunamadı.", parent=popup)

        context_menu.add_command(label="📋 Seçili Satırları Kopyala", command=_copy_selection)
        context_menu.add_separator()
        context_menu.add_command(label="🔎 Belge Göster (E-Fatura)", command=_show_invoice_document)

        def _on_right_click(event):
            item = tree.identify_row(event.y)
            if item:
                tree.selection_set(item)
                context_menu.post(event.x_root, event.y_root)
            
        tree.bind("<Button-3>", _on_right_click)
        # =========================================================

        total_borc, total_alacak = 0.0, 0.0
        
        for i, it in enumerate(items):
            try: b = float(it.get('Borc', it.get('Borç', 0)))
            except: b = 0.0
            try: a = float(it.get('Alacak', 0))
            except: a = 0.0
            
            total_borc += b; total_alacak += a
            
            fmt_borc = f"{b:,.2f}"
            fmt_alacak = f"{a:,.2f}"
            
            # Verilerin Parquet'ten güvenle alınması
            hk = it.get('HesapKodu', it.get('Hesap Kodu', ''))
            ha = it.get('HesapAdi', it.get('Hesap Adı', ''))
            mk = it.get('MuavinKodu', it.get('Muavin Kodu', ''))
            ma = it.get('MuavinAdi', it.get('Muavin Adı', ''))
            bn = it.get('BelgeNo', it.get('Belge No', ''))
            fa = it.get('FisAciklamasi', it.get('Fiş Açıklama', ''))
            da = it.get('DetayAciklama', '')
            
            vals = (hk, ha, mk, ma, bn, fa, da, fmt_borc, fmt_alacak)
            tag = 'odd' if i % 2 == 0 else 'even'
            tree.insert("", "end", values=vals, tags=(tag,))
            
        footer_frame = tk.Frame(popup, bg="#f8f9fa", height=50, bd=1, relief="solid")
        footer_frame.pack(fill="x", side="bottom")
        
        diff = abs(total_borc - total_alacak)
        is_balanced = diff < 0.01
        
        status_text = "✅ FİŞ DENGEDE" if is_balanced else f"⚠️ BAKİYE FARKI: {diff:,.2f}"
        status_fg = "green" if is_balanced else "red"
        
        t_borc_fmt = f"{total_borc:,.2f}"
        t_alacak_fmt = f"{total_alacak:,.2f}"
        
        tk.Label(footer_frame, text=f"TOPLAM BORÇ: {t_borc_fmt}", fg="#c0392b", bg="#f8f9fa", font=("DM Sans", 11, "bold")).pack(side="left", padx=20, pady=15)
        tk.Label(footer_frame, text=f"TOPLAM ALACAK: {t_alacak_fmt}", fg="#27ae60", bg="#f8f9fa", font=("DM Sans", 11, "bold")).pack(side="left", padx=20, pady=15)
        tk.Label(footer_frame, text=status_text, fg=status_fg, bg="#f8f9fa", font=("DM Sans", 12, "bold")).pack(side="right", padx=30, pady=10)

    def animate_out(self):
        self.current_x = self.start_width
        self.place(x=self.current_x)
        self.is_open = False
        self.animating = False


class SimpleTkHTMLParser(HTMLParser):
    """HTML etiketlerini okuyup Tkinter Text widget'ı etiketlerine çeviren dahili sınıf"""
    def __init__(self, text_widget):
        super().__init__()
        self.text_widget = text_widget
        self.tags = []

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)
        if tag in ('br', 'p', 'h1', 'h2', 'ul'):
            self.text_widget.insert(tk.END, "\n")
        elif tag == 'li':
            self.text_widget.insert(tk.END, "\n  • ")

    def handle_endtag(self, tag):
        if tag in self.tags:
            self.tags.remove(tag)
        if tag in ('p', 'h1', 'h2', 'div'):
            self.text_widget.insert(tk.END, "\n")

    def handle_data(self, data):
        # Gereksiz boşlukları/satır atlamalarını temizle
        if data.strip() or data == ' ':
            active_tags = tuple(self.tags)
            self.text_widget.insert(tk.END, data, active_tags)
# =============================================================================
# =============================================================================
# YENİ EKLENECEK SINIF: X Butonlu Notebook
# =============================================================================
class ClosableNotebook(ttk.Notebook):
    """X butonu ile kapatılabilen sekmeler içeren Notebook sınıfı"""
    __initialized = False

    def __init__(self, *args, **kwargs):
        if not self.__initialized:
            self.__initialize_custom_style()
            ClosableNotebook.__initialized = True

        kwargs["style"] = "Closable.TNotebook"
        super().__init__(*args, **kwargs)
        
        self.bind("<ButtonPress-1>", self.on_close_press, "+")
        self.bind("<ButtonRelease-1>", self.on_close_release, "+")

    def __initialize_custom_style(self):
        style = ttk.Style()
        
        # 1. Resimlerin Oluşturulması (kapat.ico dosyasından)
        icon_path = os.path.join(application_path, "kapat.ico")
        
        try:
            from PIL import Image, ImageTk
            # İkonu aç ve sekmeye uygun boyuta (örn. 12x12) küçült/ayarla
            img = Image.open(icon_path).resize((12, 12), Image.Resampling.LANCZOS)
            
            # Referansları 'self' içinde tutuyoruz ki Garbage Collector silmesin
            self.img_close = ImageTk.PhotoImage(img)
            self.img_closeactive = ImageTk.PhotoImage(img)    # Üzerine gelince
            self.img_closepressed = ImageTk.PhotoImage(img)   # Tıklanınca
            
        except Exception as e:
            print(f"Kapatma ikonu (kapat.ico) yüklenirken hata oluştu: {e}")
            # Hata durumunda eski Base64 veya boş bir placeholder kullanılabilir
            self.img_close = tk.PhotoImage(width=12, height=12)
            self.img_closeactive = tk.PhotoImage(width=12, height=12)
            self.img_closepressed = tk.PhotoImage(width=12, height=12)

        # 2. Elementin Oluşturulması
        try:
            # Resim referanslarımızı style.element_create içine veriyoruz
            style.element_create("close", "image", self.img_close,
                                ("active", "pressed", "!disabled", self.img_closepressed),
                                ("active", "!disabled", self.img_closeactive), border=8, sticky='')
        except tk.TclError:
            pass # Zaten oluşturulmuşsa geç

        # 3. Layout (Düzen) Ayarı
        style.layout("Closable.TNotebook", [("ClosableNotebook.client", {"sticky": "nswe"})])
        
        style.layout("Closable.TNotebook.Tab", [
            ("ClosableNotebook.tab", {
                "sticky": "nswe",
                "children": [
                    ("ClosableNotebook.padding", {
                        "side": "top",
                        "sticky": "nswe",
                        "children": [
                            ("ClosableNotebook.focus", {
                                "side": "top",
                                "sticky": "nswe",
                                "children": [
                                    ("ClosableNotebook.label", {"side": "left", "sticky": ""}),
                                    ("ClosableNotebook.close", {"side": "left", "sticky": ""}),
                                ]
                            })
                        ]
                    })
                ]
            })
        ])
        
        # 4. Renk Ayarları
        TAB_BAR_BG = "#EAECEE"
        TAB_BG = "#7F8C8D"
        TAB_ACTIVE_BG = "#ED7D31"
        TAB_FG = "white"

        style.configure("Closable.TNotebook", background=TAB_BAR_BG, tabposition='nw', borderwidth=0)
        style.configure("Closable.TNotebook.Tab", background=TAB_BG, foreground=TAB_FG, padding=[10, 4], font=("Segoe UI", 10, "bold"), borderwidth=0)
        style.map("Closable.TNotebook.Tab", background=[("selected", TAB_ACTIVE_BG), ("active", "#D35400")], foreground=[("selected", "white")], expand=[("selected", [0, 0, 0, 0])])

    def on_close_press(self, event):
        """Tıklanan yerin 'close' butonu olup olmadığını kontrol et"""
        element = self.identify(event.x, event.y)
        if "close" in element:
            index = self.index(f"@{event.x},{event.y}")
            self.state(['pressed'])
            self._active = index

    def on_close_release(self, event):
        """Bırakıldığında kapatma işlemini yap"""
        if not self.instate(['pressed']):
            return

        element =  self.identify(event.x, event.y)
        index = self.index(f"@{event.x},{event.y}")

        if "close" in element and self._active == index:
            # Dashboard (0. index) kapatılmasın istiyorsanız:
            if index == 0:
                # self.bell() # Uyarı sesi
                self.state(['!pressed'])
                self._active = None
                return
            
            # MainApp içindeki kapatma fonksiyonunu çağıracağız
            # event.widget -> notebook objesi
            # event.widget.master.master... -> MainApp'e ulaşmamız lazım veya event generate edebiliriz.
            # Ancak en kolayı MainApp'in close_tab_by_index metodunu çağırmaktır.
            
            # Bu widget MainApp'in içinde self.notebook olarak duruyor.
            # self.master -> tab_container, self.master.master -> body, self.master.master.master -> MainApp
            main_app = self.winfo_toplevel() 
            if hasattr(main_app, 'close_tab_by_index'):
                main_app.close_tab_by_index(index)
            else:
                self.forget(index)
                
        self.state(['!pressed'])
        self._active = None



class PlaceholderFrame(tk.Frame):
    def __init__(self, master, title="YAPIM AŞAMASINDA"):
        super().__init__(master, bg=CLR_BODY_BG)
        tk.Label(self, text=f"🚧 {title}", font=('Segoe UI', 20, 'bold'), 
                 bg=CLR_BODY_BG, fg="#95a5a6").pack(expand=True)
        tk.Label(self, text="Bu modül henüz aktif edilmedi.", 
                 bg=CLR_BODY_BG, fg="gray").pack(pady=(0, 50))


class CollapsibleMenu(tk.Frame):
    instances = []
    def __init__(self, master, title, icon, is_open=False, is_sidebar_collapsed_callback=None, **kwargs):
        super().__init__(master, bg=CLR_SIDEBAR_BG)
        self.master = master
        self.title = title
        self.icon = icon
        self.is_open = is_open
        self.is_sidebar_collapsed_callback = is_sidebar_collapsed_callback
        
        self.sub_items_data = [] 
        self.item_widgets = [] # YENİ: Filtreleme için buton referanslarını tutar
        self.flyout_window = None 
        self._hide_job = None 

        CollapsibleMenu.instances.append(self)
        
        # ... (Renk ve Header oluşturma kodlarınız aynı kalıyor) ...
        is_risk_header = "RİSK ANALİZİ" in self.title.upper()
        self.header_bg = "#D8362B" if is_risk_header else CLR_SIDEBAR_BG
        self.header_fg = "white" if is_risk_header else CLR_SIDEBAR_FG
        self.header_hover = "#D35400" if is_risk_header else CLR_HOVER_BG_SUB

        self.header = tk.Frame(self, bg=self.header_bg, cursor="hand2")
        self.header.pack(fill=tk.X)
        
        self.lbl_icon = tk.Label(self.header, text=self.icon, bg=self.header_bg, fg=self.header_fg, font=("Segoe UI Symbol", 12), width=3)
        self.lbl_icon.pack(side=tk.LEFT, padx=(5, 0), pady=10)
        
        self.lbl_title = tk.Label(self.header, text=self.title, bg=self.header_bg, fg=self.header_fg, font=("Segoe UI", 10, "bold"), anchor="w")
        self.lbl_title.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        self.lbl_arrow = tk.Label(self.header, text=ICON_ARROW_DOWN if is_open else ICON_ARROW_RIGHT, bg=self.header_bg, fg=self.header_fg, font=("Segoe UI Symbol", 9))
        self.lbl_arrow.pack(side=tk.RIGHT, padx=10)
        
        for w in [self.header, self.lbl_icon, self.lbl_title, self.lbl_arrow]:
            w.bind("<Button-1>", self.toggle)
            w.bind("<Enter>", self.on_header_enter)
            w.bind("<Leave>", self.on_header_leave)

        self.content = tk.Frame(self, bg=CLR_SUBMENU_BG)
        if self.is_open: self.content.pack(fill=tk.X)

    def add_item(self, text, command):
        self.sub_items_data.append({"text": text, "command": command})

        is_risk_item = "RİSK ANALİZİ" in text.upper()
        item_bg = "#E97D35" if is_risk_item else CLR_SUBMENU_BG
        item_fg = "white" if is_risk_item else CLR_SIDEBAR_FG
        item_hover = "#D35400" if is_risk_item else CLR_HOVER_BG_SUB

        btn_frame = tk.Frame(self.content, bg=item_bg, cursor="hand2")
        btn_frame.pack(fill=tk.X, pady=1)
        
        lbl_dot = tk.Label(btn_frame, text="•", bg=item_bg, fg="white" if is_risk_item else "#bdc3c7", font=("Arial", 12))
        lbl_dot.pack(side=tk.LEFT, padx=(25, 5))
        
        lbl_text = tk.Label(btn_frame, text=text, bg=item_bg, fg=item_fg, font=("Segoe UI", 9, "bold" if is_risk_item else "normal"), anchor="w")
        lbl_text.pack(side=tk.LEFT, fill=tk.X, expand=True, pady=6)
        
        # YENİ: Filtrede gizleyip gösterebilmek için frame referansını hafızaya al
        self.item_widgets.append({"frame": btn_frame, "text": text})
        
        def on_hover(e):
            btn_frame.config(bg=item_hover)
            lbl_text.config(bg=item_hover, fg="white")
            lbl_dot.config(bg=item_hover)
        def on_leave(e):
            btn_frame.config(bg=item_bg)
            lbl_text.config(bg=item_bg, fg=item_fg)
            lbl_dot.config(bg=item_bg)
            
        for w in [btn_frame, lbl_dot, lbl_text]:
            w.bind("<Button-1>", lambda e: command())
            w.bind("<Enter>", on_hover)
            w.bind("<Leave>", on_leave)

    # --- YENİ EKLENEN METOT ---
    def apply_filter(self, search_text):
        """Arama kutusuna yazılan metne göre alt menüleri filtreler."""
        # YENİ: Türkçe karakter destekli küçültme
        search_text = turkce_kucuk_yap(search_text).strip()
        match_count = 0
        
        # YENİ: Türkçe karakter destekli küçültme
        title_match = search_text in turkce_kucuk_yap(self.title)

        for item in self.item_widgets:
            # YENİ: Türkçe karakter destekli küçültme
            if search_text in turkce_kucuk_yap(item["text"]) or title_match:
                item["frame"].pack(fill=tk.X, pady=1)
                match_count += 1
            else:
                item["frame"].pack_forget()

        if match_count > 0 or title_match:
            self.header.pack(fill=tk.X)
            if search_text:
                self.expand() 
            else:
                self.collapse() 
            return True
        else:
            self.header.pack_forget()
            self.content.pack_forget()
            return False
    
    # ... (Sınıfın toggle, expand, collapse gibi diğer eski kodları aynı şekilde aşağıya devam eder) ...

    def toggle(self, event=None):
        if self.is_sidebar_collapsed_callback and self.is_sidebar_collapsed_callback():
            if self.flyout_window:
                self.destroy_flyout()
            main_app = self.winfo_toplevel()
            if hasattr(main_app, 'toggle_sidebar'):
                main_app.toggle_sidebar()
            for menu in CollapsibleMenu.instances:
                if menu != self and menu.is_open: 
                    menu.collapse()
            self.expand()
            return 

        if not self.is_open:
            for menu in CollapsibleMenu.instances:
                if menu != self and menu.is_open: menu.collapse()
                
        if self.is_open: 
            self.collapse()
        else: 
            self.expand()

    def collapse(self):
        self.content.pack_forget()
        self.lbl_arrow.config(text=ICON_ARROW_RIGHT)
        self.is_open = False

    def expand(self):
        self.content.pack(fill=tk.X)
        self.lbl_arrow.config(text=ICON_ARROW_DOWN)
        self.is_open = True

    def set_collapsed_mode(self, collapsed):
        if collapsed:
            self.lbl_title.pack_forget()
            self.lbl_arrow.pack_forget()
            self.content.pack_forget() 
        else:
            self.lbl_icon.pack(side=tk.LEFT, padx=(5, 0), pady=10)
            self.lbl_title.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
            self.lbl_arrow.pack(side=tk.RIGHT, padx=10)
            if self.is_open: self.content.pack(fill=tk.X)
    
    def on_header_enter(self, e):
        if self._hide_job:
            self.after_cancel(self._hide_job)
            self._hide_job = None

        self.header.config(bg=self.header_hover)
        self.lbl_icon.config(bg=self.header_hover)
        self.lbl_title.config(bg=self.header_hover)
        self.lbl_arrow.config(bg=self.header_hover)
        
    def on_header_leave(self, e):
        self.header.config(bg=self.header_bg)
        self.lbl_icon.config(bg=self.header_bg)
        self.lbl_title.config(bg=self.header_bg)
        self.lbl_arrow.config(bg=self.header_bg)
        
        if self.flyout_window:
            self._hide_job = self.after(5000, self.destroy_flyout)

    def show_flyout(self):
        for menu in CollapsibleMenu.instances:
            if menu != self and menu.flyout_window:
                menu.destroy_flyout()

        if self.flyout_window:
            if self._hide_job: self.after_cancel(self._hide_job)
            return

        root_x = self.winfo_rootx()
        root_y = self.winfo_rooty()
        menu_width = self.winfo_width()
        
        pos_x = root_x + menu_width - 2
        pos_y = root_y

        self.flyout_window = tk.Toplevel(self)
        self.flyout_window.wm_overrideredirect(True)
        self.flyout_window.configure(bg=CLR_SIDEBAR_BG, bd=1, relief="raised")
        self.flyout_window.geometry(f"+{pos_x}+{pos_y}") 
        
        self.flyout_window.lift()

        title_lbl = tk.Label(self.flyout_window, text=f"  {self.title}  ", bg="#2c3e50", fg="white", font=("Segoe UI", 10, "bold"), pady=8, anchor="w")
        title_lbl.pack(fill="x")

        for item in self.sub_items_data:
            f = tk.Frame(self.flyout_window, bg=CLR_SUBMENU_BG, cursor="hand2")
            f.pack(fill="x", pady=0)
            l = tk.Label(f, text=f"  {item['text']}  ", bg=CLR_SUBMENU_BG, fg="white", font=("Segoe UI", 9), anchor="w", pady=8, padx=10)
            l.pack(fill="x")
            
            def enter(e, frm=f, lbl=l):
                frm.config(bg=CLR_HOVER_BG_SUB)
                lbl.config(bg=CLR_HOVER_BG_SUB)
            def leave(e, frm=f, lbl=l):
                frm.config(bg=CLR_SUBMENU_BG)
                lbl.config(bg=CLR_SUBMENU_BG)
            
            for w in [f, l]:
                w.bind("<Enter>", enter)
                w.bind("<Leave>", leave)
                w.bind("<Button-1>", lambda e, cmd=item['command']: [cmd(), self.destroy_flyout()])

        self.flyout_window.bind("<Enter>", self.cancel_hide)
        self.flyout_window.bind("<Leave>", self.schedule_hide)

    def cancel_hide(self, e):
        if self._hide_job:
            self.after_cancel(self._hide_job)
            self._hide_job = None

    def schedule_hide(self, e):
        self._hide_job = self.after(500, self.destroy_flyout)

    def destroy_flyout(self):
        if self.flyout_window:
            self.flyout_window.destroy()
            self.flyout_window = None





class MainApp(TkinterDnD.Tk):
    def __init__(self):
        super().__init__()
        self.title("Mali Analiz ve Denetim Sistemi PRO")
        self.geometry("1400x900")
        
        # --- DEĞİŞEN/EKLENEN KISIM ---
        # "zoomed" durumunu pencere tam oluştuktan biraz sonra veriyoruz
        # Bu, Windows'ta taskbar bug'ını önlemeye yardımcı olur.
        self.after(100, lambda: self.state("zoomed"))
        
        self.configure(bg=CLR_BODY_BG)
        
        # Pencereyi görev çubuğundan tıklandığında veya odaklandığında
        # zorla en öne (top) getirmek için <FocusIn> veya <Map> eventini kullanıyoruz.
        self.bind("<Map>", self.on_window_map)
        # -----------------------------
        
        self.sidebar_expanded = True
        # ... (kodun geri kalanı aynı şekilde devam ediyor) ...
        self.sidebar_width = 280
        self.collapsed_width = 60
        self.menu_groups = []
        
        self.unvan = "Seçili Mükellef Yok"
        self.vkn = "---"
        self.yil = "---"    
        
        self.opened_tabs = {} 
        self.form_map = {
            "YeniDefterYukleFrame": YeniDefterYukleFrame,
            "ArsivdenYukleFrame": ArsivdenYukleFrame,
            "MukellefBilgiKartiUI": MukellefBilgiKartiUI,
            "FaturaYukleFrame": FaturaYukleFrame,
            "TumFaturalarFrame": TumFaturalarFrame,
            "MenuYonetimFrame": MenuYonetimFrame,
            "YevmiyeAnalizFrame": YevmiyeAnalizFrame,
            "LedgerPropsFrame": LedgerPropsFrame,
            "BalanceAnalizFrame": BalanceAnalizFrame,
            "FinancialReportsView": FinancialReportsView,
            "ChartAuditFrame": ChartAuditFrame,
            "FaturaGoruntulePopup": FaturaGoruntulePopup,
            "VeriYonetimiFrame": VeriYonetimiFrame,
            "DegiskenlerTablosuFrame": DegiskenlerTablosuFrame,
            "DenetimFrame": DenetimFrame,
            "HesaplamaHavuzuFrame": HesaplamaHavuzuFrame,
            "ProfilFrame": ProfilFrame,
            "StatisticsPanel": StatisticsPanel,
            "TalepFormu": TalepFrame, 
            "PivotTableFrame": PivotTableFrame,
            "FaturaAnalizEngine": FaturaAnalizFrame,
            "IadeListesiFrame": IadeListesiFrame,
            "TablolarUI": TablolarUI,
            "DegisimAnaliziUI": DegisimAnaliziUI,
            "KarsitIncelemeEngine": KarsitParametreFrame,   
            "MizanFrame": MizanFrame
        }

        self.setup_ui()
        self.load_last_session()
        self.start_keep_alive()
        self.start_startup_sync()
# --- YENİ EKLENEN: KISAYOL TUŞLARI ---
        # Ctrl+w veya Ctrl+W basıldığında aktif sekmeyi kapat
        self.bind("<Control-w>", self.close_current_tab)
        self.bind("<Control-W>", self.close_current_tab)
# 2. Ctrl + N: Yeni Defter Yükle (Modül Aç)
        # open_module fonksiyonunu çağırıyoruz:
        # Parametreler: ("SınıfAdı", PopupMı?, "Görünen Başlık")
        self.bind("<Control-n>", lambda event: self.open_module("YeniDefterYukleFrame", False, "Yeni Defter Yükle"))
        self.bind("<Control-o>", lambda event: self.open_module("ArsivdenYukleFrame", False, "Arşiv Yükle"))
        self.bind("<Control-7>", lambda event: self.open_module("MenuYonetimFrame", False, "Menu"))
    # --- YENİ EKLENEN FONKSİYON ---


    def start_keep_alive(self):
        """
        Program açık kaldığı sürece her 1 dakikada bir sunucuya heartbeat atar.
        Hem Render uyku moduna geçmez hem de kullanıcı 'online' görünür.
        """
        def pinger():
            while True:
                try:
                    time.sleep(60) # 60 saniyede bir tetikle
                    
                    # Kullanıcı id'sini (token) session/config içinden alıyoruz
                    # (Giriş yaparken bu token'ı bir değişkene veya config dosyasına yazmalısınız)
                    # Örnek olarak çevre değişkeninden veya bir utils fonksiyonundan alabilirsiniz:
                    token = os.environ.get("CURRENT_USER_TOKEN", "") 
                    
                    if token:
                        requests.post(f"{SERVER_URL}/api/heartbeat", json={"token": token}, timeout=10, verify=False)
                    else:
                        requests.get(SERVER_URL, timeout=10, verify=False) # Sadece sunucuyu dürt
                        
                except Exception as e:
                    pass

        t = threading.Thread(target=pinger, daemon=True)
        t.start()


    def start_startup_sync(self):
        """
        Program açılışında 'ProfilEngine' aracılığıyla yerel verileri
        sunucuya gönderir (senkronize eder).
        """
        def sync_worker():
            try:
                # Engine'i burada import ediyoruz ki açılış hızını etkilemesin
                from modules.kullanici_profil.engine import ProfilEngine
                engine = ProfilEngine()
                if hasattr(engine, 'sync_data_to_web'):
                    # Sessizce (silent) senkronize et
                    engine.sync_data_to_web()
            except Exception as e:
                print(f"Startup Sync Error: {e}")

        # UI donmasın diye arka planda (Thread) çalıştır
        threading.Thread(target=sync_worker, daemon=True).start()


    def on_window_map(self, event):
        """Pencere simge durumundan küçültülüp (minimize) tekrar açıldığında
           veya görev çubuğundan tıklandığında pencereyi en öne getirir."""
        # Sadece ana pencere (MainApp) için çalışsın, içindeki diğer widgetlar için değil
        if event.widget == self:
            self.lift() # Pencereyi diğer pencerelerin üstüne kaldırır
            self.focus_force() # Klavye ve fare odağını zorla bu pencereye alır


    def setup_ui(self):
        # 1. TOP BAR
        self.top_bar = tk.Frame(self, bg=CLR_TOP_BAR_BG, height=60)
        self.top_bar.pack(side=tk.TOP, fill=tk.X)
        self.top_bar.pack_propagate(False)
        
        # Logo ve Oturum Bilgisi
        # --- LOGO VE OTURUM BİLGİSİ GÜNCELLEMESİ ---
        icon_path = os.path.join(application_path, "icon.png")
        
        try:
            from PIL import Image, ImageTk
            img = Image.open(icon_path)
            
            hedef_yukseklik = 32 
            oran = hedef_yukseklik / float(img.size[1])
            hedef_genislik = int(float(img.size[0]) * float(oran))
            
            img = img.resize((hedef_genislik, hedef_yukseklik), Image.Resampling.LANCZOS)
            self.logo_icon = ImageTk.PhotoImage(img)
            
        except ImportError:
            print("Pillow kütüphanesi bulunamadı. Lütfen terminale 'pip install Pillow' yazarak yükleyin.")
            self.logo_icon = tk.PhotoImage(file=icon_path)
        except Exception as e:
            print(f"İkon yüklenirken hata oluştu: {e}")
            self.logo_icon = None

        # 1. PARÇA: İkon ve "e-DENETİM " yazısı (Beyaz)
        tk.Label(
            self.top_bar, 
            text="e-DENETİM", # Sonunda bilerek bir boşluk bıraktık
            image=self.logo_icon, 
            compound=tk.LEFT, 
            padx=10, 
            bg=CLR_TOP_BAR_BG, 
            fg="white", 
            font=("Segoe UI", 16, "bold")
        ).pack(side=tk.LEFT, padx=(20, 0)) # Sağ taraftan boşluk bırakmadık ki PRO yazısı bitişik dursun

        # 2. PARÇA: Sadece "PRO" yazısı (Turuncu)
        tk.Label(
            self.top_bar, 
            text="PRO", 
            bg=CLR_TOP_BAR_BG, 
            fg="#E97D35", # Uygulamanızın temasına uygun turuncu renk
            font=("Segoe UI", 16, "bold")
        ).pack(side=tk.LEFT)
        # -------------------------------------------
        self.lbl_session = tk.Label(self.top_bar, text="", bg=CLR_TOP_BAR_BG, fg="#ecf0f1", font=("Consolas", 11))
        self.lbl_session.pack(side=tk.LEFT, padx=30)
        
        # ÇIKIŞ BUTONU
        btn_exit = tk.Button(self.top_bar, text="ÇIKIŞ", command=self.on_closing, bg="#c0392b", fg="white", bd=0, padx=15)
        btn_exit.pack(side=tk.RIGHT, padx=20, pady=10)
        # --- YENİ EKLENEN: YENİLE BUTONU ---
        btn_refresh = tk.Button(self.top_bar, text="🔄 YENİLE", command=self.refresh_app, bg="#3498db", fg="white", bd=0, padx=15, cursor="hand2", font=("Segoe UI", 10, "bold"))
        btn_refresh.pack(side=tk.RIGHT, padx=10, pady=10)
        # -----------------------------------
        # KREDİ GÖSTERGESİ
        initial_credit = audit_ui.CURRENT_USER_CREDITS
        
        self.lbl_credits = tk.Label(
            self.top_bar, 
            text=f"💰 Bakiye: {initial_credit}", 
            bg=CLR_TOP_BAR_BG, 
            fg="#f1c40f", 
            font=("Segoe UI", 11, "bold")
        )
        self.lbl_credits.pack(side=tk.RIGHT, padx=15, pady=10)
        
        if self.lbl_credits not in audit_ui.CREDIT_LABEL_LIST:
            audit_ui.CREDIT_LABEL_LIST.append(self.lbl_credits)

        # 2. ANA GÖVDE
        self.body = tk.Frame(self, bg=CLR_BODY_BG)
        self.body.pack(fill=tk.BOTH, expand=True)

        # 3. SIDEBAR
        self.sidebar_frame = tk.Frame(self.body, bg=CLR_SIDEBAR_BG, width=self.sidebar_width)
        self.sidebar_frame.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar_frame.pack_propagate(False)

        # ... (setup_ui içindeki mevcut kodlar)
        self.toggle_frame = tk.Frame(self.sidebar_frame, bg=CLR_SIDEBAR_BG, height=50)
        self.toggle_frame.pack(fill=tk.X)
        self.btn_toggle = tk.Button(self.toggle_frame, text=ICON_MENU_TOGGLE, command=self.toggle_sidebar, 
                                    bg=CLR_SIDEBAR_BG, fg="white", bd=0, font=("Arial", 14), cursor="hand2")
        self.btn_toggle.pack(side=tk.RIGHT, padx=10, pady=10)
        self.lbl_menu_title = tk.Label(self.toggle_frame, text="MENÜ", bg=CLR_SIDEBAR_BG, fg="gray", font=("Segoe UI", 10, "bold"))
        self.lbl_menu_title.pack(side=tk.LEFT, padx=15)

        # ==============================================================
        # --- YENİ: MENÜ ARAMA ÇUBUĞU (TOGGLE ALTINA) ---
        self.menu_search_frame = tk.Frame(self.sidebar_frame, bg=CLR_SIDEBAR_BG)
        self.menu_search_frame.pack(fill=tk.X, pady=(0, 10))
        
        search_inner = tk.Frame(self.menu_search_frame, bg="#34495e")
        search_inner.pack(fill=tk.X, padx=15)
        
        tk.Label(search_inner, text="🔍", bg="#34495e", fg="gray").pack(side=tk.LEFT, padx=5)
        
        self.menu_search_var = tk.StringVar()
        self.menu_search_var.trace("w", self.on_menu_search) # Yazı değiştikçe filtreyi tetikler
        
        self.entry_menu_search = tk.Entry(
            search_inner, 
            textvariable=self.menu_search_var, 
            bg="#34495e", fg="white", font=("Segoe UI", 9), 
            insertbackground="white", bd=0
        )
        self.entry_menu_search.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=5)
        # ==============================================================

        # ... (Mevcut bottom_user_frame ve canvas tanımlamalarınız aynen devam eder)

        # --- YENİ: HOŞGELDİN YAZISINI MENÜNÜN EN ALTINA YAPIŞTIRMA ---
        self.bottom_user_frame = tk.Frame(self.sidebar_frame, bg=CLR_SIDEBAR_BG, height=60)
        self.bottom_user_frame.pack(side=tk.BOTTOM, fill=tk.X)
        
        try: user = os.getlogin()
        except: user = os.environ.get('USERNAME', 'Kullanıcı')
        
        # Sadece ikona tıklama (bind) ve el imleci (cursor="hand2") eklendi
        self.lbl_welcome_icon = tk.Label(self.bottom_user_frame, text="👤", bg=CLR_SIDEBAR_BG, fg="#E97D35", font=("Segoe UI Symbol", 14), cursor="hand2")
        self.lbl_welcome_icon.pack(side=tk.LEFT, padx=(15, 5), pady=15)
        self.lbl_welcome_icon.bind("<Button-1>", lambda e: self.open_module("ProfilFrame", False, "Kullanıcı Profili"))
        
        self.lbl_welcome_text = tk.Label(self.bottom_user_frame, text=f"Hoş Geldin, {user}", bg=CLR_SIDEBAR_BG, fg="white", font=("Segoe UI", 10, "bold"))
        self.lbl_welcome_text.pack(side=tk.LEFT, pady=15)
        # -------------------------------------------------------------
        # -------------------------------------------------------------

        self.canvas = tk.Canvas(self.sidebar_frame, bg=CLR_SIDEBAR_BG, highlightthickness=0)
        # ... (kod devam eder)
        self.scroll_inner = tk.Frame(self.canvas, bg=CLR_SIDEBAR_BG)
        self.scrollbar = ttk.Scrollbar(self.sidebar_frame, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.canvas_window = self.canvas.create_window((0,0), window=self.scroll_inner, anchor="nw", width=self.sidebar_width)
        self.scroll_inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        # 4. NOTEBOOK - TASARIM
        style = ttk.Style()
        try: style.theme_use('clam')
        except: pass
        
        TAB_BAR_BG = "#EAECEE"
        TAB_BG = "#7F8C8D"
        TAB_ACTIVE_BG = "#ED7D31"
        TAB_FG = "white"
        
        style.configure("Custom.TNotebook", background=TAB_BAR_BG, tabposition='nw', borderwidth=0)
        style.configure("Custom.TNotebook.Tab", background=TAB_BG, foreground=TAB_FG, padding=[15, 6], font=("Segoe UI", 10, "bold"), borderwidth=0, focuscolor=style.configure(".")["background"])
        style.map("Custom.TNotebook.Tab", background=[("selected", TAB_ACTIVE_BG), ("active", "#D35400")], foreground=[("selected", "white")], expand=[("selected", [0, 0, 0, 0])])

        self.tab_container = tk.Frame(self.body, bg=TAB_BAR_BG)
        self.tab_container.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=0, pady=0)

        self.notebook = ClosableNotebook(self.tab_container)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        self.notebook.bind("<Button-3>", self.on_tab_right_click) 
        self.notebook.bind("<Button-2>", self.on_tab_middle_click) 

        self.create_menus()
        self.show_dashboard()

    def create_menus(self):
        CollapsibleMenu.instances = []
        
        # --- ANA SAYFA (DASHBOARD) BUTONU ---
        self.btn_dash = tk.Frame(self.scroll_inner, bg=CLR_ACCENT, height=40, cursor="hand2")
        self.btn_dash.pack(fill=tk.X, pady=(15, 2))
        
        self.lbl_dash_icon = tk.Label(self.btn_dash, text=ICON_DASHBOARD, bg=CLR_ACCENT, fg="white", font=("Segoe UI Symbol", 12))
        self.lbl_dash_icon.pack(side=tk.LEFT, padx=(10, 0), pady=10)
        
        self.lbl_dash_text = tk.Label(self.btn_dash, text="ANA SAYFA", bg=CLR_ACCENT, fg="white", font=("Segoe UI", 10, "bold"))
        self.lbl_dash_text.pack(side=tk.LEFT, padx=10)
        
        for w in [self.btn_dash, self.lbl_dash_icon, self.lbl_dash_text]:
            w.bind("<Button-1>", lambda e: self.show_dashboard())
        # ---------------------------------------

        # --- 3. DİNAMİK MENÜLERİN YÜKLENMESİ ---
        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "menu_config.json")
        menu_structure = []
        if os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    menu_structure = json.load(f)
            except:
                pass
        
            try:
                with open(config_path, "w", encoding="utf-8") as f:
                    json.dump(menu_structure, f, ensure_ascii=False, indent=4)
            except:
                pass

        for group in menu_structure:
            menu = CollapsibleMenu(
                self.scroll_inner, 
                group["title"], 
                group.get("icon", "•"),
                is_sidebar_collapsed_callback=lambda: not self.sidebar_expanded
            )
            menu.pack(fill=tk.X, pady=(1, 0))
            self.menu_groups.append(menu)
            for item in group["items"]:
                text = item.get("title", "Adsız") if isinstance(item, dict) else item[0]
                target = item.get("target", "Placeholder") if isinstance(item, dict) else item[1]
                is_popup = item.get("popup", False) if isinstance(item, dict) else item[2]
                
                html_icerik = item.get("html_content", "") if isinstance(item, dict) else ""
                
                cmd = lambda t=target, p=is_popup, lbl=text, hc=html_icerik: self.open_module(t, p, lbl, hc)
                menu.add_item(text, cmd)

    def on_menu_search(self, *args):
        """Menü arama çubuğuna yazı yazıldıkça çalışan filtre fonksiyonu"""
        search_text = self.menu_search_var.get()
        
        # 1. ADIM: Dağınıklığı ve boşlukları önlemek için tüm menüleri ekrandan kaldır
        for menu in self.menu_groups:
            menu.pack_forget()
            
        # 2. ADIM: Sadece filtreden geçen (True dönen) menüleri ORİJİNAL SIRASIYLA tekrar ekrana yerleştir
        for menu in self.menu_groups:
            if hasattr(menu, 'apply_filter'):
                is_visible = menu.apply_filter(search_text)
                if is_visible:
                    # Menüyü tekrar eklerken standart boşluğunu (pady) koruyarak ekle
                    menu.pack(fill=tk.X, pady=(1, 0))


    def toggle_sidebar(self):
        target = self.collapsed_width if self.sidebar_expanded else self.sidebar_width
        
        if self.sidebar_expanded:
            # Kapatırken Bileşenleri Gizle
            self.lbl_menu_title.pack_forget()
            self.lbl_dash_text.pack_forget()
            self.lbl_welcome_text.pack_forget() 
            self.menu_search_frame.pack_forget() # YENİ: Arama çubuğunu gizle
            
            for group in self.menu_groups: 
                group.set_collapsed_mode(True)
        else:
            # Açarken Bileşenleri Geri Getir
            self.lbl_menu_title.pack(side=tk.LEFT, padx=15)
            self.lbl_dash_text.pack(side=tk.LEFT, padx=10)
            self.lbl_welcome_text.pack(side=tk.LEFT, pady=15) 
            
            # YENİ: Arama çubuğunu yerine (canvas'ın üstüne) geri koy.
            # (pack() metoduna before eklemek ekranın diziliş sırasının bozulmasını önler)
            self.menu_search_frame.pack(fill=tk.X, pady=(0, 10), before=self.canvas)
            
            for group in self.menu_groups: 
                group.set_collapsed_mode(False)

        self.sidebar_frame.config(width=target)
        self.canvas.itemconfig(self.canvas_window, width=target)
        self.sidebar_expanded = not self.sidebar_expanded
        
        if not self.sidebar_expanded: 
            self.scrollbar.pack_forget()
        else: 
            self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.body.update_idletasks()
    
    
    # Fonksiyon tanımına varsayılan değerli html_content eklendi
    def open_module(self, class_name, is_popup, title, html_content=""):
        # --- Sidebar Otomatik Kapanma ---
        if self.sidebar_expanded and not is_popup:
            self.toggle_sidebar()
        
        # ===== YENİ EKLENEN: DİNAMİK HTML YAKALAYICI =====
        # Eğer Menü Yönetimi'nden hedef olarak 'OzelHTML' yazıldıysa dinamik pencereyi aç
        if class_name == "OzelHTML":
            self.show_html_popup(title, html_content)
            return
        # =================================================

        critical_modules = ["YeniDefterYukleFrame", "ArsivdenYukleFrame"]
        # ... (fonksiyonun kalanı eskisi gibi devam eder) ...
       
        
        if class_name in critical_modules and not is_popup:
            other_tabs = [t for t in self.opened_tabs.keys() if t != "Dashboard"]
            if other_tabs:
                confirm = messagebox.askyesno("Sekmeler Kapatılacak", f"'{title}' işlemini yapabilmek için diğer açık sekmelerin kapatılması gerekiyor.\nDevam etmek istiyor musunuz?")
                if confirm: self.close_all_tabs()
                else: return

        FormClass = self.form_map.get(class_name)
        if is_popup and FormClass:
            win = tk.Toplevel(self)
            win.title(title); win.geometry("1100x700"); win.configure(bg=CLR_BODY_BG)
            try: FormClass(win).pack(fill=tk.BOTH, expand=True)
            except Exception as e: tk.Label(win, text=f"Hata: {e}").pack()
            return

        if class_name in self.opened_tabs:
            self.notebook.select(self.opened_tabs[class_name])
            return

        display_title = title 

        if not FormClass:
            frame = PlaceholderFrame(self.notebook, title)
            self.notebook.add(frame, text=display_title)
            self.notebook.select(frame)
            self.opened_tabs[class_name] = frame 
            return

        try:
            frame = FormClass(self.notebook)
            self.notebook.add(frame, text=display_title)
            self.notebook.select(frame)
            self.opened_tabs[class_name] = frame
        except Exception as e:
            err_frame = PlaceholderFrame(self.notebook, f"HATA: {e}")
            self.notebook.add(err_frame, text=f"Hata: {title}")
            self.notebook.select(err_frame)


    def show_dashboard(self):
        if "Dashboard" in self.opened_tabs:
            self.notebook.select(self.opened_tabs["Dashboard"])
            return

        # Modülden yeni DashboardFrame'i çağırıyoruz
        from modules.dashboard.ui import DashboardFrame
        dash_frame = DashboardFrame(self.notebook, main_app=self, application_path=application_path)
        
        # Global Notlar Paneli ve Butonu eskisi gibi MainApp üzerinde kalıyor
        if not hasattr(self, 'sliding_panel') or not self.sliding_panel.winfo_exists():
            self.sliding_panel = SlidingNotePanel(self.tab_container, self)

        if not hasattr(self, 'btn_floating_notes') or not self.btn_floating_notes.winfo_exists():
            self.btn_floating_notes = tk.Button(
                self.tab_container, text="📝\n\nN\nO\nT\nL\nA\nR", font=("Segoe UI", 9, "bold"),
                bg="#E97D35", fg="white", bd=0, cursor="hand2", width=3, pady=20, relief="flat",
                command=self.sliding_panel.toggle
            )
            self.btn_floating_notes.place(relx=1.0, rely=0.35, anchor="ne", x=-2)
            
        self.btn_floating_notes.lift()
        self.sliding_panel.lift()

        if self.notebook.tabs(): 
            self.notebook.insert(0, dash_frame, text="🏠 Dashboard")
        else: 
            self.notebook.add(dash_frame, text="🏠 Dashboard")
        
        self.notebook.select(dash_frame)
        self.opened_tabs["Dashboard"] = dash_frame

    def on_tab_middle_click(self, event):
        try:
            index = self.notebook.index(f"@{event.x},{event.y}")
            self.close_tab_by_index(index)
        except: pass

    def on_tab_right_click(self, event):
        try:
            menu = tk.Menu(self, tearoff=0)
            clicked_index = self.notebook.index(f"@{event.x},{event.y}")
            if clicked_index != 0:
                menu.add_command(label="Bu Sekmeyi Kapat", command=lambda: self.close_tab_by_index(clicked_index))
            menu.add_separator()
            menu.add_command(label="Tüm Sekmeleri Kapat", command=self.close_all_tabs)
            menu.post(event.x_root, event.y_root)
        except: pass

    def close_all_tabs(self):
        count = self.notebook.index("end")
        for i in range(count - 1, 0, -1):
            self.close_tab_by_index(i)
    def close_current_tab(self, event=None):
        """Ctrl + W ile çağrılan, aktif sekmeyi kapatma fonksiyonu"""
        try:
            # Notebook'ta şu an seçili olan sekmenin indeksini al
            current_index = self.notebook.index("current")
            
            # Eğer 0. indeks (Dashboard) ise kapatma
            if current_index == 0:
                # İsterseniz uyarı sesi verebilirsiniz: self.bell()
                return

            # Mevcut kapatma mantığını kullan
            self.close_tab_by_index(current_index)
            
        except tk.TclError:
            # Eğer hiç sekme yoksa veya hata oluşursa sessizce geç
            pass
        
    def close_tab_by_index(self, index):
        if index == 0: return 
        tab_widget_name = self.notebook.tabs()[index]
        widget_obj = self.notebook.nametowidget(tab_widget_name)
        key_to_remove = None
        for key, val in self.opened_tabs.items():
            if val == widget_obj:
                key_to_remove = key; break
        if key_to_remove: del self.opened_tabs[key_to_remove]
        self.notebook.forget(index)
    def refresh_app(self):
        """Uygulama genelindeki oturum ve dashboard verilerini yeniler."""
        # 1. Oturum bilgisini (VKN, Unvan vb.) arka planda tekrar çek ve üst barı güncelle
        self.load_last_session()
        
        # 2. Dashboard sekmesini bul, sil ve taze verilerle (yeni not/risk sayılarıyla) yeniden oluştur
        if "Dashboard" in self.opened_tabs:
            dash_widget = self.opened_tabs["Dashboard"]
            
            # Eski widget'ı Notebook'tan kaldır ve sil
            try:
                self.notebook.forget(dash_widget)
            except:
                pass
            dash_widget.destroy()
            del self.opened_tabs["Dashboard"]
            
            # Dashboard'u tekrar yükle (yeni istatistikler tablodan çekilecek)
            self.show_dashboard()
    def load_last_session(self):
        session = get_last_session()
        if session: self.update_header_info(session['unvan'], session['vkn'], session['yil'])

    def update_header_info(self, unvan, vkn, yil):
        self.unvan = unvan; self.vkn = vkn; self.yil = yil
        info = f"🏢 Mükellef: {self.unvan}  |  🆔 VKN: {self.vkn}  |  📅 Dönem: {self.yil}"
        self.lbl_session.config(text=info)
        save_session(unvan, vkn, yil)

    def on_closing(self):
        # Kapanırken sunucuya offline bilgisi yolla
        token = os.environ.get("CURRENT_USER_TOKEN", "")
        if token:
            try:
                requests.post(f"{SERVER_URL}/api/logout", json={"token": token}, timeout=2)
            except: pass
            
        save_session(self.unvan, self.vkn, self.yil)
        self.destroy()






    def show_html_popup(self, title, html_content):
        """Basit HTML içerikleri ek bir kütüphane kurmadan Text widget ile gösterir."""
        win = tk.Toplevel(self)
        win.title(title)
        win.geometry("815x690") # Biraz daha büyük açılması için boyutları artırdık
        win.configure(bg=CLR_BODY_BG)
        # Pencereyi her zaman en üstte tutmak istersen alttaki satırı açabilirsin:
        # win.attributes("-topmost", True) 

        # --- ÜST BAŞLIK ALANI ---
        header = tk.Label(win, text=f"ℹ️ {title}", font=("Segoe UI", 14, "bold"), bg=CLR_BODY_BG, fg=CLR_ACCENT)
        header.pack(pady=10, padx=20, anchor="w")

        # --- METİN VE SCROLLBAR İÇİN ÇERÇEVE ---
        txt_frame = tk.Frame(win, bg=CLR_BODY_BG)
        txt_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 10))

        # 1. SCROLLBAR OLUŞTURMA
        scrollbar = ttk.Scrollbar(txt_frame, orient="vertical")
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        text_area = tk.Text(txt_frame, wrap="word", bg="white", fg="#2c3e50", font=("Segoe UI", 11), 
                            bd=1, relief="solid", padx=15, pady=15, yscrollcommand=scrollbar.set)
        text_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=text_area.yview)

        # --- KONTROL BUTONU ALANI (OYNAT/DURDUR) ---
        ctrl_frame = tk.Frame(win, bg=CLR_BODY_BG)
        ctrl_frame.pack(fill=tk.X, padx=20, pady=(0, 15))

        # Otomatik kaydırma durumunu tutan sözlük (closure yapısı için)
        scroll_state = {"active": True}

        def toggle_scroll():
            # Eğer sayfanın en altına gelindiyse ve tekrar basıldıysa başa sar
            if text_area.yview()[1] >= 0.999 and not scroll_state["active"]:
                text_area.yview_moveto(0)
                
            scroll_state["active"] = not scroll_state["active"]
            btn_scroll.config(text="⏸️ Kaydırmayı Durdur" if scroll_state["active"] else "▶️ Otomatik Kaydır")
            if scroll_state["active"]:
                do_auto_scroll()

        btn_scroll = tk.Button(ctrl_frame, text="⏸️ Kaydırmayı Durdur", command=toggle_scroll,
                               bg="#ecf0f1", fg="#2c3e50", bd=1, font=("Segoe UI", 9, "bold"), cursor="hand2", padx=10)
        btn_scroll.pack(side=tk.RIGHT)

        # --- HTML STİLLERİ ---
        text_area.tag_configure('b', font=("Segoe UI", 11, "bold"))
        text_area.tag_configure('strong', font=("Segoe UI", 11, "bold"))
        text_area.tag_configure('i', font=("Segoe UI", 11, "italic"))
        text_area.tag_configure('h1', font=("Segoe UI", 16, "bold"), spacing3=15, foreground="#2980b9", justify="center")
        text_area.tag_configure('h2', font=("Segoe UI", 14, "bold"), spacing3=10, foreground="#34495e")
        text_area.tag_configure('p', spacing1=5, spacing3=10)
        text_area.tag_configure('li', spacing1=4)

        # HTML'i ayrıştırıp ekrana bas
        parser = SimpleTkHTMLParser(text_area)
        parser.feed(html_content)

        # Kullanıcı değiştiremesin diye salt-okunur yap
        text_area.config(state="disabled")

        # --- 2. OTOMATİK KAYDIRMA FONKSİYONU ---
        def do_auto_scroll():
            if not win.winfo_exists(): return  # Pencere kapatıldıysa döngüyü durdur
            if not scroll_state["active"]: return  # Duraklatıldıysa döngüyü durdur

            # Scroll en alta ulaştı mı kontrol et (0.999 hassasiyeti)
            if text_area.yview()[1] >= 0.999:
                scroll_state["active"] = False
                btn_scroll.config(text="🔄 Başa Dön ve Yeniden Oynat")
                return

            # Her tetiklenmede 1 piksel aşağı kaydır (Akıcı görünüm için)
            text_area.yview_scroll(1, "pixels")
            
            # 50 milisaniyede bir kendini tekrar et (Hızı buradan ayarlayabilirsin, sayı küçüldükçe hızlanır)
            win.after(40, do_auto_scroll)

        # Yazı ekrana yüklendikten 1.5 saniye sonra kaydırmayı başlat
        win.after(1500, do_auto_scroll)

if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support() # Windows için kritik satı
    app = MainApp()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()