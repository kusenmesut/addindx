import sqlite3
import os
from config import get_base_dir

TABLE_NAME = "last_sessions"

def get_session_db_path():
    return os.path.join(get_base_dir(), "sessions.db")

def init_db():
    db_path = get_session_db_path()
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(f"CREATE TABLE IF NOT EXISTS {TABLE_NAME} (id INTEGER PRIMARY KEY AUTOINCREMENT, unvan TEXT, vkn TEXT, yil TEXT, last_opened TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
    conn.commit()
    conn.close()

def save_session(unvan, vkn, yil):
    try:
        init_db()
        conn = sqlite3.connect(get_session_db_path())
        cursor = conn.cursor()
        cursor.execute(f"SELECT id FROM {TABLE_NAME} WHERE vkn = ? AND yil = ?", (vkn, yil))
        existing = cursor.fetchone()
        if existing:
            cursor.execute(f"UPDATE {TABLE_NAME} SET unvan = ?, last_opened = CURRENT_TIMESTAMP WHERE id = ?", (unvan, existing[0]))
        else:
            cursor.execute(f"INSERT INTO {TABLE_NAME} (unvan, vkn, yil) VALUES (?, ?, ?)", (unvan, vkn, yil))
        conn.commit()
        conn.close()
    except: pass

def get_last_session():
    try:
        if not os.path.exists(get_session_db_path()): return None
        conn = sqlite3.connect(get_session_db_path())
        cursor = conn.cursor()
        cursor.execute(f"SELECT unvan, vkn, yil FROM {TABLE_NAME} ORDER BY last_opened DESC LIMIT 1")
        result = cursor.fetchone()
        conn.close()
        if result: return {'unvan': result[0], 'vkn': result[1], 'yil': result[2]}
    except: pass
    return None
