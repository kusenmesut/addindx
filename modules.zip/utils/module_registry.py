# Sistemdeki tüm formları buraya import et
from modules.defter_yukle.ui import YeniDefterYukleFrame
from modules.arsiv_yukle.ui import ArsivdenYukleFrame
from modules.istatistik_paneli.ui import StatisticsPanel
from modules.mukellef_karti.ui import MukellefBilgiKartiUI
from modules.fatura_yukle.ui_yukle import FaturaYukleFrame
from modules.fatura_yukle.ui_liste import TumFaturalarFrame
from modules.menu_yonetimi.ui import MenuYonetimFrame 
from modules.defter_ozellikleri.ui import LedgerPropsFrame
from modules.mizan_analiz.ui import MizanFrame
from modules.bakiye_analiz.ui import BalanceAnalizFrame
from modules.mali_tablolar.ui import FinancialReportEngine
from modules.mali_tablolar.grafik_ui import PowerBIBoard
from modules.grafik_denetim.ui import ChartAuditFrame
from modules.talep_oneri.engine import TalepEngine
from modules.veri_yonetimi.ui import VeriYonetimiFrame
from modules.denetim_analiz.ui import DenetimFrame
from modules.degiskenler_tablosu.ui import DegiskenlerTablosuFrame
from modules.hesaplama_havuzu.ui import HesaplamaHavuzuFrame
from modules.kullanici_profil.ui import ProfilFrame
from modules.talep_oneri.ui import  TalepFrame
from modules.pivot_table.ui import PivotTableFrame
from modules.pivot_table.tablolar import TablolarUI
from modules.fatura_analiz.ui import FaturaAnalizFrame
from modules.fatura_analiz.ui_iade_listesi import IadeListesiFrame
from modules.pivot_table.degisimanalizi import DegisimAnaliziUI
from modules.fatura_analiz.ui_karsit import KarsitParametreFrame
from modules.fatura_yukle.faturanaliz_ui import FaturaAnalizFrame
from modules.pivot_table.tablodashboard import TabloDashboard
from modules.yevmiye_analiz.yevmiyeanaliz_ui import YevmiyeManuelDenetimUI

# String Adı -> Sınıf Eşleştirmesi
FORM_MAP = {
    "YeniDefterYukleFrame": {"class": YeniDefterYukleFrame, "desc": "Yeni Defter Yükleme Ekranı"},
    "ArsivdenYukleFrame": {"class": ArsivdenYukleFrame, "desc": "Arşivden Defter Yükleme"},
    "MukellefBilgiKartiUI": {"class": MukellefBilgiKartiUI, "desc": "Mükellef Bilgi Kartı"},
    "FaturaYukleFrame": {"class": FaturaYukleFrame, "desc": "Fatura Yükleme Sihirbazı"},
    "TumFaturalarFrame": {"class": TumFaturalarFrame, "desc": "Tüm Faturalar Listesi"},
    "MenuYonetimFrame": {"class": MenuYonetimFrame, "desc": "⚙️ Menü Tasarımcısı"},
    "MizanFrame": {"class": MizanFrame, "desc": "⚙️ Denem"},
    "LedgerPropsFrame": {"class": LedgerPropsFrame, "desc": "⚙️ Denaaem"},
    "BalanceAnalizFrame": {"class": BalanceAnalizFrame, "desc": "⚙️ Denaaem"},
    "FinancialReportsView": {"class": FinancialReportEngine, "desc": "⚙️ Denaaem"},
    "ChartAuditFrame": {"class": ChartAuditFrame, "desc": "⚙️ Denaaem"},
    "PowerBIBoard": {"class": PowerBIBoard, "desc": "⚙️ Denaaem"},
    "VeriYonetimiFrame": {"class": VeriYonetimiFrame, "desc": "⚙️ Denaaem"},
    "DenetimFrame": {"class": DenetimFrame, "desc": "⚙️ Denaaem"},
    "DegiskenlerTablosuFrame": {"class": DegiskenlerTablosuFrame, "desc": "⚙️ DegiskenlerTablosuFrame"},
    "HesaplamaHavuzuFrame": {"class": HesaplamaHavuzuFrame, "desc": "Hesaplama Havuzu"}, 
    "ProfilFrame": {"class": ProfilFrame, "desc": "Kullanıcı Profil Yönetimi"},
    "StatisticsPanel": {"class": StatisticsPanel, "desc": "İstatistik Paneli"},
    "TalepFormu": {"class": TalepFrame, "desc": "Talep ve Öneri Sistemi"},  
    "PivotTableFrame": {"class": PivotTableFrame, "desc": "Pivot"},
    "FaturaAnalizFrame": {"class": FaturaAnalizFrame, "desc": "fATURAaNALİZ"},
    "IadeListesiFrame": {"class": IadeListesiFrame, "desc": "Iadeanaliz"},
    "TablolarUI": {"class": TablolarUI, "desc": "Tablolar"},
    "DegisimAnaliziUI": {"class": DegisimAnaliziUI, "desc": "DegisimAnaliziUI"},
    "KarsitIncelemeEngine": {"class": KarsitParametreFrame, "desc": "KarsitIncelemeEngine"},
    "FaturaAnalizFrame": {"class": FaturaAnalizFrame, "desc": "FaturaAnalizFrame"},
    "TabloDashboard": {"class": TabloDashboard, "desc": "TabloDashboard"},
    "YevmiyeManuelDenetimUI": {"class": YevmiyeManuelDenetimUI, "desc": "YevmiyeManuelDenetimUI"},

    "Placeholder": {"class": None, "desc": "Boş / Yapım Aşamasında"}
}

def get_form_class(name):
    # Eğer isim boşsa veya None ise None dön
    if not name: return None
    return FORM_MAP.get(name, {}).get("class", None)

def get_available_forms():
    return list(FORM_MAP.keys())