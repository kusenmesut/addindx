import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinterdnd2 import DND_FILES
import os
import json
import time
import socket
from config import CLR_BODY_BG, CLR_ACCENT, CLR_DROP_BG, CLR_DROP_FG, CLR_BTN_BG, CLR_BTN_FG, get_mukellefler_dir
from .engine import klasor_tara_ve_analiz_et, eksik_ay_kontrolu, islem_yap_ve_kaydet
from users import CloudLicenseManager
import pandas as pd
import glob
from datetime import datetime


# --- MODERN UI RENK PALETİ ---
M_CLR_BG = "#ffffff"          
M_CLR_HEADER = "#f8f9fa"      
M_CLR_TXT_HEAD = "#2c3e50"    
M_CLR_TXT_BODY = "#34495e"    
M_CLR_BTN_PRIMARY = "#2980b9" 
M_CLR_BTN_HOVER = "#3498db"   
M_CLR_BTN_SEC = "#ecf0f1"     
M_CLR_BTN_SEC_TXT = "#7f8c8d" 
M_FONT_TITLE = ("Segoe UI", 12, "bold")
M_FONT_MSG = ("Segoe UI", 11)
M_FONT_SUB = ("Segoe UI", 9)


class IkiAlanliBirlestirmeDialog(tk.Toplevel):
    def __init__(self, parent, dosyalar):
        super().__init__(parent)
        self.attributes('-topmost', True)
        self.overrideredirect(True)
        self.configure(highlightthickness=2, highlightbackground="#8e44ad")
        self.result = None
        
        w, h = 850, 480
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
            self.geometry(f"{w}x{h}+{x}+{y}")
        except:
            self.geometry(f"{w}x{h}")

        # --- HEADER ---
        frm_header = tk.Frame(self, bg="#8e44ad", height=50)
        frm_header.pack(fill=tk.X)
        tk.Label(frm_header, text="PARÇALI DEFTER BİRLEŞTİRME", 
                 bg="#8e44ad", fg="white", font=("Segoe UI", 12, "bold")).pack(pady=10)

        # --- BİLGİ ALANI ---
        frm_info = tk.Frame(self, bg="#ffffff", padx=20, pady=10)
        frm_info.pack(fill=tk.X)
        tk.Label(frm_info, text="1. Soldaki listeden birleştirmek istediğiniz dosyaları sağ tarafa sürükleyin.\n2. Sağ taraftaki listede dosyaları yukarı/aşağı sürükleyerek 'Ezme Önceliğini' belirleyin (Üstteki ezer).", 
                 bg="#ffffff", fg="#2c3e50", font=("Segoe UI", 10), justify="center").pack()

        # --- İKİ ALANLI ANA GÖVDE ---
        frm_main = tk.Frame(self, bg="#ffffff")
        frm_main.pack(fill=tk.BOTH, expand=True, padx=20, pady=5)

        # SOL ALAN (KAYNAK)
        frm_left = tk.Frame(frm_main, bg="#ffffff")
        frm_left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        tk.Label(frm_left, text="📁 Mevcut Dosyalar", bg="#ffffff", font=("Segoe UI", 10, "bold"), fg="#34495e").pack(pady=5)
        
        self.tree_kaynak = ttk.Treeview(frm_left, columns=("Dosya", "Tarih"), show="headings", selectmode="browse")
        self.tree_kaynak.heading("Dosya", text="Dosya Adı")
        self.tree_kaynak.heading("Tarih", text="Tarih")
        self.tree_kaynak.column("Dosya", width=180)
        self.tree_kaynak.column("Tarih", width=120, anchor="center")
        self.tree_kaynak.pack(fill=tk.BOTH, expand=True)

        # SAĞ ALAN (HEDEF / BİRLEŞECEKLER)
        frm_right = tk.Frame(frm_main, bg="#ffffff")
        frm_right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))
        tk.Label(frm_right, text="🎯 Birleştirilecekler (Öncelikli)", bg="#ffffff", fg="#c0392b", font=("Segoe UI", 10, "bold")).pack(pady=5)
        
        self.tree_hedef = ttk.Treeview(frm_right, columns=("Dosya", "Tarih"), show="headings", selectmode="browse")
        self.tree_hedef.heading("Dosya", text="Dosya Adı")
        self.tree_hedef.heading("Tarih", text="Tarih")
        self.tree_hedef.column("Dosya", width=180)
        self.tree_hedef.column("Tarih", width=120, anchor="center")
        self.tree_hedef.pack(fill=tk.BOTH, expand=True)

        # Kaynak listesini doldur
        for dosya in dosyalar:
            self.tree_kaynak.insert("", "end", values=(dosya['ad'], dosya['tarih']), iid=dosya['path'])

        # Sürükle Bırak Olayları
        self.tree_kaynak.bind("<ButtonPress-1>", self.on_drag_start)
        self.tree_hedef.bind("<ButtonPress-1>", self.on_drag_start)
        self.tree_kaynak.bind("<ButtonRelease-1>", self.on_drag_release)
        self.tree_hedef.bind("<ButtonRelease-1>", self.on_drag_release)

        self.drag_data = {"item": None, "source_tree": None}

        # --- BUTONLAR ---
        frm_btn = tk.Frame(self, bg="#ffffff", height=60)
        frm_btn.pack(fill=tk.X, pady=10)
        tk.Button(frm_btn, text="BİRLEŞTİRMEYİ BAŞLAT", bg="#27ae60", fg="white", 
                  font=("Segoe UI", 10, "bold"), padx=20, pady=8, cursor="hand2", command=self.on_submit).pack(side=tk.RIGHT, padx=20)
        tk.Button(frm_btn, text="İPTAL", bg="#c0392b", fg="white", 
                  font=("Segoe UI", 10, "bold"), padx=20, pady=8, cursor="hand2", command=self.on_cancel).pack(side=tk.LEFT, padx=20)
        self.grab_set()

    def on_drag_start(self, event):
        tree = event.widget
        item = tree.identify_row(event.y)
        if item:
            self.drag_data["item"] = item
            self.drag_data["source_tree"] = tree

    def on_drag_release(self, event):
        if not self.drag_data["item"]: return
        
        x, y = event.x_root, event.y_root
        target_tree = None
        
        # Hangi alanın (sol veya sağ) üzerine bırakıldığını tespit et
        kx, ky = self.tree_kaynak.winfo_rootx(), self.tree_kaynak.winfo_rooty()
        kw, kh = self.tree_kaynak.winfo_width(), self.tree_kaynak.winfo_height()
        hx, hy = self.tree_hedef.winfo_rootx(), self.tree_hedef.winfo_rooty()
        hw, hh = self.tree_hedef.winfo_width(), self.tree_hedef.winfo_height()
        
        if kx <= x <= kx + kw and ky <= y <= ky + kh: target_tree = self.tree_kaynak
        elif hx <= x <= hx + hw and hy <= y <= hy + hh: target_tree = self.tree_hedef
            
        source_tree = self.drag_data["source_tree"]
        item = self.drag_data["item"]
        
        if target_tree:
            rel_y = y - target_tree.winfo_rooty()
            target_item = target_tree.identify_row(rel_y)
            idx = target_tree.index(target_item) if target_item else "end"
            
            if source_tree == target_tree:
                target_tree.move(item, "", idx) # Aynı liste içinde yer değiştir
            else:
                values = source_tree.item(item, "values") # Diğer listeye taşı
                target_tree.insert("", idx, iid=item, values=values)
                source_tree.delete(item)

        self.drag_data = {"item": None, "source_tree": None}

    def on_submit(self):
        sirali_yollar = list(self.tree_hedef.get_children())
        if len(sirali_yollar) < 2:
            messagebox.showwarning("Uyarı", "Birleştirme işlemi için sağ taraftaki alana en az 2 dosya sürüklemelisiniz!", parent=self)
            return
        self.result = sirali_yollar
        self.destroy()

    def on_cancel(self):
        self.result = None
        self.destroy()

class ModernDialog(tk.Toplevel):
    """Görseldeki tasarıma uygun, butonları GARANTİ GÖSTEREN dialog penceresi."""
    def __init__(self, parent, title, icon_char="?"):
        super().__init__(parent, bg=M_CLR_BG)
        self.result = None
        self.attributes('-topmost', True)
        self.overrideredirect(True) 
        self.configure(highlightthickness=1, highlightbackground="#bdc3c7")
        
        w, h = 480, 320 
        
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except:
            x, y = 300, 300
        self.geometry(f"{w}x{h}+{x}+{y}")
        
        # --- 1. HEADER ---
        self.header = tk.Frame(self, bg=M_CLR_HEADER, height=40)
        self.header.pack(side=tk.TOP, fill=tk.X)
        self.header.pack_propagate(False) 
        
        lbl_title = tk.Label(self.header, text=title, bg=M_CLR_HEADER, fg="#95a5a6", font=("Segoe UI", 10))
        lbl_title.pack(side=tk.LEFT, padx=15)
        
        btn_close = tk.Button(self.header, text="✕", bg=M_CLR_HEADER, fg="#95a5a6", bd=0, 
                              font=("Arial", 12), cursor="hand2", command=self.on_cancel)
        btn_close.pack(side=tk.RIGHT, padx=5, fill=tk.Y)
        
        self.header.bind("<Button-1>", self.start_move)
        self.header.bind("<B1-Motion>", self.do_move)
        lbl_title.bind("<Button-1>", self.start_move)

        tk.Frame(self, bg="#ecf0f1", height=2).pack(side=tk.TOP, fill=tk.X)

        # --- 2. BUTON ALANI ---
        self.btn_frame = tk.Frame(self, bg=M_CLR_BG, height=70)
        self.btn_frame.pack(side=tk.BOTTOM, fill=tk.X)
        self.btn_frame.pack_propagate(False) 

        # --- 3. İÇERİK ALANI ---
        self.content_frame = tk.Frame(self, bg=M_CLR_BG)
        self.content_frame.pack(side=tk.TOP, expand=True, fill=tk.BOTH, padx=20, pady=10)
        
        self.lbl_icon = tk.Label(self.content_frame, text=icon_char, bg=M_CLR_BG, fg="#3498db", font=("Segoe UI", 40))
        self.lbl_icon.pack(pady=(10, 5))

        self.grab_set()

    def start_move(self, event):
        self.x = event.x
        self.y = event.y

    def do_move(self, event):
        x = self.winfo_x() + (event.x - self.x)
        y = self.winfo_y() + (event.y - self.y)
        self.geometry(f"+{x}+{y}")

    def add_message(self, main_msg, sub_msg=""):
        if sub_msg:
            lbl_sub = tk.Label(self.content_frame, text=sub_msg, bg=M_CLR_BG, fg="#7f8c8d", 
                     font=("Segoe UI", 11, "bold"), wraplength=460, justify="center")
            lbl_sub.pack(side=tk.BOTTOM, pady=(15, 0), fill=tk.X)
            tk.Frame(self.content_frame, bg="#ecf0f1", height=1).pack(side=tk.BOTTOM, fill=tk.X, pady=5)
        
        lbl_main = tk.Label(self.content_frame, text=main_msg, bg=M_CLR_BG, fg=M_CLR_TXT_HEAD, 
                 font=("Segoe UI", 12), wraplength=460, justify="center")
        lbl_main.pack(side=tk.TOP, pady=(5, 5), expand=True)
        self.geometry("500x380")

    def add_buttons(self, ok_text="TAMAM", cancel_text="İPTAL", show_cancel=True):
        spacer = tk.Frame(self.btn_frame, bg=M_CLR_BG, width=20)
        spacer.pack(side=tk.RIGHT)
        btn_ok = tk.Button(self.btn_frame, text=ok_text, bg=M_CLR_BTN_PRIMARY, fg="white", 
                           font=("Segoe UI", 10, "bold"), relief="flat", padx=20, pady=5, cursor="hand2",
                           command=self.on_ok)
        btn_ok.pack(side=tk.RIGHT, padx=5, pady=15) 
        if show_cancel:
            btn_cancel = tk.Button(self.btn_frame, text=cancel_text, bg=M_CLR_BTN_SEC, fg=M_CLR_TXT_BODY, 
                                   font=("Segoe UI", 10, "bold"), relief="flat", padx=20, pady=5, cursor="hand2",
                                   command=self.on_cancel)
            btn_cancel.pack(side=tk.RIGHT, padx=5, pady=15)

    def on_ok(self): self.result = True; self.destroy()
    def on_cancel(self): self.result = False; self.destroy()



class MukellefSecimDialog(tk.Toplevel):
    def __init__(self, parent, excel_unvan, tum_mukellefler, onerilen_mukellef=None):
        super().__init__(parent, bg=M_CLR_BG)
        self.attributes('-topmost', True)
        self.result = None
        self.excel_unvan = excel_unvan
        self.overrideredirect(True)
        self.configure(highlightthickness=2, highlightbackground="#e74c3c" if onerilen_mukellef else "#3498db")
        
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        w = max(700, min(900, int(sw * 0.6)))
        h = max(500, min(650, int(sh * 0.6)))
        
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except: 
            x = (sw // 2) - (w // 2)
            y = (sh // 2) - (h // 2)
            
        self.geometry(f"{w}x{h}+{x}+{y}")

        header_color = "#e74c3c" if onerilen_mukellef else "#2980b9"
        frm_header = tk.Frame(self, bg=header_color, height=50)
        frm_header.pack(fill=tk.X)
        tk.Label(frm_header, text="MÜKELLEF EŞLEŞTİRME", bg=header_color, fg="white", font=("Segoe UI", 12, "bold")).pack(pady=10)

        frm_btn = tk.Frame(self, bg=M_CLR_BG, height=60)
        frm_btn.pack(fill=tk.X, pady=(15, 5), side=tk.TOP) 
        
        tk.Button(frm_btn, text="✨ YENİ OLUŞTUR", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), padx=15, pady=8, cursor="hand2", command=self.on_new).pack(side=tk.LEFT, padx=(20, 10))
        tk.Button(frm_btn, text="SEÇİLİ OLANA KAYDET", bg="#2980b9", fg="white", font=("Segoe UI", 10, "bold"), padx=20, pady=8, cursor="hand2", command=self.on_select).pack(side=tk.LEFT, padx=10)
        tk.Button(frm_btn, text="❌ İPTAL ET", bg="#c0392b", fg="white", font=("Segoe UI", 10, "bold"), padx=15, pady=8, cursor="hand2", command=self.on_cancel).pack(side=tk.RIGHT, padx=20)

        frm_info = tk.Frame(self, bg=M_CLR_BG, padx=20, pady=5)
        frm_info.pack(fill=tk.X)
        tk.Label(frm_info, text=f"Dosyadaki Unvan: {excel_unvan}", bg="#ecf0f1", fg="#2c3e50", font=("Segoe UI", 11, "bold"), pady=5).pack(fill=tk.X, pady=5)
        
        msg = "Aşağıdaki listeden kayıt yapılacak mükellefi seçiniz."
        if onerilen_mukellef: msg = "⚠️ SİSTEM BİR EŞLEŞME BULDU! (Kırmızı işaretli)"
        tk.Label(frm_info, text=msg, bg=M_CLR_BG, fg="#e74c3c" if onerilen_mukellef else "#7f8c8d", font=("Segoe UI", 10)).pack(pady=5)

        frm_list = tk.Frame(self, bg=M_CLR_BG, padx=20) 
        frm_list.pack(fill=tk.BOTH, expand=True, pady=(5, 20)) 
        
        self.tree = ttk.Treeview(frm_list, columns=("Unvan", "VKN"), show="headings")
        self.tree.heading("Unvan", text="Unvan"); self.tree.column("Unvan", width=int(w*0.7))
        self.tree.heading("VKN", text="VKN"); self.tree.column("VKN", width=int(w*0.2), anchor="center")
        
        vsb = ttk.Scrollbar(frm_list, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True); vsb.pack(side=tk.RIGHT, fill=tk.Y)

        style = ttk.Style()
        style.map("Treeview", background=[("selected", "#3498db")])
        self.tree.tag_configure("onerilen", background="#e74c3c", foreground="white")

        target_item = None
        for muk in tum_mukellefler:
            tag = "onerilen" if onerilen_mukellef and muk['vkn'] == onerilen_mukellef['vkn'] else ""
            item_id = self.tree.insert("", "end", values=(muk['unvan'], muk['vkn']), tags=(tag,))
            if tag == "onerilen": target_item = item_id

        if target_item: self.tree.selection_set(target_item); self.tree.see(target_item)
        self.grab_set()

    def on_select(self):
        sel = self.tree.selection()
        if not sel: return messagebox.showwarning("Uyarı", "Seçim yapmadınız!")
        val = self.tree.item(sel[0])['values']
        self.result = {'action': 'existing', 'unvan': val[0], 'vkn': str(val[1])}
        self.destroy()

    def on_new(self):
        yeni_bilgiler = modern_ask_unvan_vkn(self, varsayilan_unvan=self.excel_unvan)
        if yeni_bilgiler:
            self.result = {'action': 'new', 'unvan': yeni_bilgiler['unvan'], 'vkn': yeni_bilgiler['vkn']}
            self.destroy()

    def on_cancel(self):
        self.result = None 
        self.destroy()


class LoadingDialog(tk.Toplevel):
    def __init__(self, parent, title="Lütfen Bekleyin"):
        super().__init__(parent)
        self.attributes('-topmost', True)
        self.overrideredirect(True) 
        
        w, h = 450, 220 
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        except:
            x, y = 300, 300
        self.geometry(f"{w}x{h}+{x}+{y}")
        
        C_TEAL   = "#00c0a3"  
        C_GREY   = "#c1bbb2"  
        C_ORANGE = "#ff7800"  
        C_WHITE  = "#ffffff"  
        
        self.main_frame = tk.Frame(self, bg=C_WHITE, highlightthickness=1, highlightbackground="#ecf0f1")
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        self.canvas_top = tk.Canvas(self.main_frame, bg=C_TEAL, height=90, highlightthickness=0)
        self.canvas_top.pack(fill=tk.X, side=tk.TOP)
        self.canvas_top.create_line(0, 82, 2000, 82, fill=C_WHITE, width=2, dash=(6, 3))
        
        self.lbl_title = tk.Label(self.canvas_top, text="⏳ " + title.upper(), bg=C_TEAL, fg=C_WHITE, font=("Segoe UI", 14, "bold"))
        self.canvas_top.create_window(w//2, 40, window=self.lbl_title)

        self.frame_w1 = tk.Frame(self.main_frame, bg=C_WHITE, height=35)
        self.frame_w1.pack(fill=tk.X)
        self.frame_w1.pack_propagate(False)
        
        self.progress = ttk.Progressbar(self.frame_w1, orient="horizontal", mode="determinate")
        self.progress.pack(fill=tk.X, padx=25, pady=8)

        tk.Frame(self.main_frame, bg=C_GREY, height=8).pack(fill=tk.X)
        tk.Frame(self.main_frame, bg=C_WHITE, height=6).pack(fill=tk.X)

        self.frame_orange = tk.Frame(self.main_frame, bg=C_ORANGE, height=45)
        self.frame_orange.pack(fill=tk.X)
        self.frame_orange.pack_propagate(False)
        
        self.lbl_file = tk.Label(self.frame_orange, text="Veriler hazırlanıyor...", bg=C_ORANGE, fg=C_WHITE, font=("Segoe UI", 10, "bold"))
        self.lbl_file.pack(pady=12)

        self.frame_w2 = tk.Frame(self.main_frame, bg=C_WHITE)
        self.frame_w2.pack(fill=tk.BOTH, expand=True)
        
        self.lbl_status = tk.Label(self.frame_w2, text="Sistem başlatılıyor...", bg=C_WHITE, fg="#7f8c8d", font=("Segoe UI", 9))
        self.lbl_status.pack(pady=5)
        
        self.is_cancelled = False 
        
        self.btn_cancel = tk.Button(self.frame_w2, text="İŞLEMİ İPTAL ET", bg="#e74c3c", fg="white", 
                                    font=("Segoe UI", 8, "bold"), relief="flat", cursor="hand2", 
                                    command=self.cancel_process)
        self.btn_cancel.pack(side=tk.RIGHT, padx=15, pady=5)
        self.grab_set()

    def cancel_process(self):
        self.is_cancelled = True
        self.lbl_status.config(text="İşlem durduruluyor, lütfen bekleyin...")
        self.btn_cancel.config(state=tk.DISABLED, text="DURDURULUYOR...")
        self.grab_set()

    def update_progress(self, msg, i, total, fname):
        if fname:
            short_fname = fname if len(fname) < 40 else "..." + fname[-37:]
            self.lbl_file.config(text=f"İşlenen: {short_fname}")
            
        self.lbl_status.config(text=f"{msg} ({i} / {total})")
        
        if total > 0:
            self.progress['value'] = (i / total) * 100
            
        self.update_idletasks()

def modern_ask_yes_no(parent, title, message, sub_message="", ok_text="EVET", cancel_text="HAYIR"):
    dialog = ModernDialog(parent, title, icon_char="?")
    dialog.add_message(message, sub_message)
    dialog.add_buttons(ok_text, cancel_text, show_cancel=True)
    parent.wait_window(dialog)
    return dialog.result

def modern_ask_unvan_vkn(parent, varsayilan_unvan=""):
    dialog = ModernDialog(parent, "Yeni Mükellef Tanımlama", icon_char="📝")
    w = 520; h = 480
    try:
        x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
        y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        dialog.geometry(f"{w}x{h}+{x}+{y}")
    except: 
        dialog.geometry(f"{w}x{h}")

    lbl_main = tk.Label(dialog.content_frame, text="Lütfen yeni mükellef bilgilerini tanımlayın:", bg=M_CLR_BG, fg=M_CLR_TXT_HEAD, font=("Segoe UI", 12, "bold"))
    lbl_main.pack(side=tk.TOP, pady=(10, 20))

    frm_unvan = tk.Frame(dialog.content_frame, bg=M_CLR_BG)
    frm_unvan.pack(fill=tk.X, padx=20, pady=10)
    tk.Label(frm_unvan, text="Unvan:", bg=M_CLR_BG, fg="#2c3e50", font=("Segoe UI", 10, "bold"), width=10, anchor="w").pack(side=tk.LEFT)
    sv_unvan = tk.StringVar(value=varsayilan_unvan)
    ent_unvan = tk.Entry(frm_unvan, textvariable=sv_unvan, font=("Segoe UI", 11), bd=1, relief="solid", bg="white")
    ent_unvan.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=6)

    frm_vkn = tk.Frame(dialog.content_frame, bg=M_CLR_BG)
    frm_vkn.pack(fill=tk.X, padx=20, pady=10)
    tk.Label(frm_vkn, text="VKN/TCKN:", bg=M_CLR_BG, fg="#2c3e50", font=("Segoe UI", 10, "bold"), width=10, anchor="w").pack(side=tk.LEFT)
    sv_vkn = tk.StringVar()
    ent_vkn = tk.Entry(frm_vkn, textvariable=sv_vkn, font=("Segoe UI", 11), bd=1, relief="solid", bg="white")
    ent_vkn.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=6)

    def on_submit():
        unv = sv_unvan.get().strip()
        vkn = sv_vkn.get().strip()
        
        if not unv:
            ent_unvan.config(bg="#fab1a0")
            return
        else: ent_unvan.config(bg="white")
            
        if not vkn.isdigit() or len(vkn) not in [10, 11]:
            ent_vkn.config(bg="#fab1a0")
            messagebox.showwarning("Hata", "VKN/TCKN 10 veya 11 haneli sadece rakamlardan oluşmalıdır!", parent=dialog)
            return
        else: ent_vkn.config(bg="white")

        dialog.result = {'unvan': unv, 'vkn': vkn}
        dialog.destroy()

    for widget in dialog.btn_frame.winfo_children(): widget.destroy()
    tk.Frame(dialog.btn_frame, bg=M_CLR_BG, width=20).pack(side=tk.RIGHT)

    btn_ok = tk.Button(dialog.btn_frame, text="KAYDET", bg=M_CLR_BTN_PRIMARY, fg="white", font=("Segoe UI", 10, "bold"), relief="flat", padx=30, pady=10, cursor="hand2", command=on_submit)
    btn_ok.pack(side=tk.RIGHT, padx=5, pady=15)
    btn_cancel = tk.Button(dialog.btn_frame, text="İPTAL", bg=M_CLR_BTN_SEC, fg=M_CLR_TXT_BODY, font=("Segoe UI", 10, "bold"), relief="flat", padx=20, pady=10, cursor="hand2", command=dialog.on_cancel)
    btn_cancel.pack(side=tk.RIGHT, padx=5, pady=15)

    ent_unvan.focus_set()
    parent.wait_window(dialog)
    return dialog.result

def modern_ask_string(parent, title, message, sub_message=""):
    dialog = ModernDialog(parent, title, icon_char="✏️")
    w = 520; h = 450
    try:
        x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
        y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        dialog.geometry(f"{w}x{h}+{x}+{y}")
    except: dialog.geometry(f"{w}x{h}")

    lbl_main = tk.Label(dialog.content_frame, text=message, bg=M_CLR_BG, fg=M_CLR_TXT_HEAD, 
                        font=("Segoe UI", 12, "bold"), wraplength=480, justify="center")
    lbl_main.pack(side=tk.TOP, pady=(10, 10))
    
    if sub_message:
        lbl_sub = tk.Label(dialog.content_frame, text=sub_message, bg=M_CLR_BG, fg="#7f8c8d", 
                           font=("Segoe UI", 10), wraplength=480, justify="center")
        lbl_sub.pack(side=tk.TOP, pady=(0, 20))

    sv = tk.StringVar()
    entry = tk.Entry(dialog.content_frame, textvariable=sv, font=("Segoe UI", 13), 
                     bd=1, relief="solid", width=40, bg="white", fg="#2d3436")
    entry.pack(side=tk.TOP, ipady=8, pady=5); entry.focus_set()
    tk.Frame(dialog.content_frame, bg=M_CLR_BTN_PRIMARY, height=2, width=360).pack(side=tk.TOP, pady=(0, 20))

    def on_submit():
        if sv.get().strip(): dialog.result = sv.get().strip(); dialog.destroy()
        else: entry.config(bg="#fab1a0"); entry.focus_set()

    for widget in dialog.btn_frame.winfo_children(): widget.destroy()
    tk.Frame(dialog.btn_frame, bg=M_CLR_BG, width=20).pack(side=tk.RIGHT)

    btn_ok = tk.Button(dialog.btn_frame, text="KAYDET", bg=M_CLR_BTN_PRIMARY, fg="white", 
                       font=("Segoe UI", 10, "bold"), relief="flat", padx=30, pady=10, cursor="hand2", command=on_submit)
    btn_ok.pack(side=tk.RIGHT, padx=5, pady=15)
    btn_cancel = tk.Button(dialog.btn_frame, text="İPTAL", bg=M_CLR_BTN_SEC, fg=M_CLR_TXT_BODY, 
                           font=("Segoe UI", 10, "bold"), relief="flat", padx=20, pady=10, cursor="hand2", command=dialog.on_cancel)
    btn_cancel.pack(side=tk.RIGHT, padx=5, pady=15)
    
    parent.wait_window(dialog)
    return dialog.result

# --- YENİ EKLENEN: FORMAT SORDURMA PENCERESİ ---
def modern_ask_format(parent, title, message, sub_message, format_list):
    dialog = ModernDialog(parent, title, icon_char="⚙️")
    w, h = 520, 420
    try:
        x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (w // 2)
        y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (h // 2)
        dialog.geometry(f"{w}x{h}+{x}+{y}")
    except: 
        dialog.geometry(f"{w}x{h}")

    lbl_main = tk.Label(dialog.content_frame, text=message, bg=M_CLR_BG, fg=M_CLR_TXT_HEAD, font=("Segoe UI", 11, "bold"), wraplength=480)
    lbl_main.pack(side=tk.TOP, pady=(10, 5))
    lbl_sub = tk.Label(dialog.content_frame, text=sub_message, bg=M_CLR_BG, fg="#7f8c8d", font=("Segoe UI", 10), wraplength=480)
    lbl_sub.pack(side=tk.TOP, pady=(0, 15))

    sv_format = tk.StringVar()
    cb_format = ttk.Combobox(dialog.content_frame, textvariable=sv_format, values=format_list, font=("Segoe UI", 12), state="readonly")
    cb_format.pack(side=tk.TOP, pady=10, ipady=5, fill=tk.X, padx=60)
    if format_list: cb_format.current(0) 

    def on_submit():
        secim = sv_format.get()
        if secim: dialog.result = secim; dialog.destroy()
        else: messagebox.showwarning("Uyarı", "Lütfen bir format seçiniz!", parent=dialog)

    def on_skip():
        dialog.result = None
        dialog.destroy()

    for widget in dialog.btn_frame.winfo_children(): widget.destroy()
    tk.Frame(dialog.btn_frame, bg=M_CLR_BG, width=20).pack(side=tk.RIGHT)
    
    btn_ok = tk.Button(dialog.btn_frame, text="SEÇ VE YÜKLE", bg=M_CLR_BTN_PRIMARY, fg="white", font=("Segoe UI", 10, "bold"), relief="flat", padx=20, pady=8, cursor="hand2", command=on_submit)
    btn_ok.pack(side=tk.RIGHT, padx=5, pady=15)
    
    btn_cancel = tk.Button(dialog.btn_frame, text="ATLA", bg=M_CLR_BTN_SEC, fg=M_CLR_TXT_BODY, font=("Segoe UI", 10, "bold"), relief="flat", padx=20, pady=8, cursor="hand2", command=on_skip)
    btn_cancel.pack(side=tk.RIGHT, padx=5, pady=15)

    parent.wait_window(dialog)
    return dialog.result

def modern_show_info(parent, title, message, sub_message=""):
    dialog = ModernDialog(parent, title, icon_char="!")
    dialog.lbl_icon.config(fg="#12d463")
    dialog.add_message(message, sub_message)
    dialog.add_buttons(ok_text="TAMAM", show_cancel=False)
    parent.wait_window(dialog)

def modern_show_error(parent, title, message):
    dialog = ModernDialog(parent, title, icon_char="❌")
    dialog.lbl_icon.config(fg="#c0392b")
    dialog.add_message(message)
    dialog.add_buttons(ok_text="KAPAT", show_cancel=False)
    parent.wait_window(dialog)

try:
    from modules.kullanici_profil.engine import ProfilEngine
except ImportError:
    ProfilEngine = None

def check_internet_connection(host="8.8.8.8", port=53, timeout=1):
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
        return True
    except socket.error:
        return False

class YeniDefterYukleFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.master = master
        self.dosya_listesi = []
        self.detected_months = [] 
        self.last_net_check_time = 0
        self.setup_ui()

    def setup_ui(self):
        tk.Label(self, text="📁 YENİ DEFTER YÜKLEME SİHİRBAZI", 
                 font=("Segoe UI", 16, "bold"), bg=CLR_BODY_BG, fg="#2d3436").pack(pady=(20, 15))
        
        self.drop_canvas = tk.Canvas(self, bg=CLR_DROP_BG, height=280, highlightthickness=0, cursor="hand2")
        self.drop_canvas.pack(fill=tk.X, padx=60, pady=10)
        self.drop_canvas.bind("<Configure>", self.draw_drop_zone)
        try:
            self.drop_canvas.drop_target_register(DND_FILES)
            self.drop_canvas.dnd_bind('<<Drop>>', self.on_drop)
        except Exception as e: print(f"DnD Hatası: {e}")

        self.lbl_path = tk.Label(self, text="Henüz bir seçim yapılmadı.", bg=CLR_BODY_BG, fg="#636e72", font=("Segoe UI", 10, "italic"))
        self.lbl_path.pack(pady=(10, 5))

        self.info_frame = tk.Frame(self, bg=CLR_BODY_BG)
        self.info_frame.pack(fill=tk.X, padx=60, pady=10)

        self.progress = ttk.Progressbar(self.info_frame, orient="horizontal", mode="determinate")
        self.progress.pack(fill=tk.X, pady=(0, 10))

        self.btn_start = tk.Button(self.info_frame, text="İŞLEMİ BAŞLAT", command=self.start_process, 
                                   state=tk.DISABLED, bg="#b2bec3", fg="white", 
                                   font=("Segoe UI", 12, "bold"), pady=12, bd=0, cursor="hand2")
        self.btn_start.pack(fill=tk.X)

        # --- YENİ BİRLEŞTİR BUTONU BURADA ---
        tk.Frame(self.info_frame, bg=CLR_BODY_BG, height=15).pack(fill=tk.X)

        self.btn_birlestir = tk.Button(self.info_frame, text="🔄 SİSTEMDEKİ PARÇALI DEFTERLERİ BİRLEŞTİR", 
                                       bg="#8e44ad", fg="white", font=("Segoe UI", 11, "bold"), 
                                       pady=10, bd=0, cursor="hand2",
                                       command=self.aktif_defter_birlestir_tetikle)
        self.btn_birlestir.pack(fill=tk.X)




    def draw_drop_zone(self, event=None):
        w = self.drop_canvas.winfo_width()
        h = self.drop_canvas.winfo_height()
        self.drop_canvas.delete("all")
        self.drop_canvas.create_rectangle(10, 10, w-10, h-10, outline="white", width=2, dash=(10, 10))
        cx = w / 2
        self.drop_canvas.create_text(cx, 70, text="☁", fill="white", font=("Arial", 60))
        self.drop_canvas.create_text(cx, 80, text="⬆", fill=CLR_DROP_BG, font=("Arial", 24, "bold"))
        self.drop_canvas.create_text(cx, 140, text="Dosya veya Klasör Sürükle & Bırak", fill="white", font=("Segoe UI", 16, "bold"))
        self.drop_canvas.create_text(cx, 175, text="VEYA AŞAĞIDAN SEÇİN", fill="#dfe6e9", font=("Segoe UI", 10))
        
        if not hasattr(self, 'btn_browse_folder_widget'):
            self.btn_browse_folder_widget = tk.Button(self.drop_canvas, text="📁 Klasör Seç", command=self.browse_folder,
                                               bg=CLR_BTN_BG, fg=CLR_BTN_FG, font=("Segoe UI", 10, "bold"),
                                               relief="flat", padx=15, pady=5, cursor="hand2")
        self.drop_canvas.create_window(cx - 70, 230, window=self.btn_browse_folder_widget)

        if not hasattr(self, 'btn_browse_file_widget'):
            self.btn_browse_file_widget = tk.Button(self.drop_canvas, text="📄 Dosya Seç", command=self.browse_file,
                                               bg="#e17055", fg="white", font=("Segoe UI", 10, "bold"),
                                               relief="flat", padx=15, pady=5, cursor="hand2")
        self.drop_canvas.create_window(cx + 70, 230, window=self.btn_browse_file_widget)

    def on_drop(self, event):
        try:
            paths = self.tk.splitlist(event.data)
        except AttributeError:
            paths = self.master.tk.splitlist(event.data)
            
        if paths:
            self.after(250, lambda: self.check_and_ask_user(paths))

    def browse_folder(self):
        yol = filedialog.askdirectory()
        if yol: 
            self.after(250, lambda: self.check_and_ask_user([yol]))

    def browse_file(self):
        dosyalar = filedialog.askopenfilenames(title="Dosya Seç", filetypes=[("Excel & XML", "*.xlsx *.xls *.xml"), ("Tüm Dosyalar", "*.*")])
        if dosyalar: 
            self.after(250, lambda: self.check_and_ask_user(dosyalar))

    def check_and_ask_user(self, yollar):
        if isinstance(yollar, str): 
            yollar = [yollar]
            
        files, months = klasor_tara_ve_analiz_et(yollar)
        
        if not files:
            messagebox.showerror("Hata", "Seçilen konumda uygun formatta (ör: -y- uzantılı) geçerli dosya bulunamadı.")
            return
            
        eksikler = eksik_ay_kontrolu(months)
        
        if len(yollar) == 1:
            display_path_name = os.path.basename(yollar[0])
            folder_label = "📄 Seçim"
        else:
            display_path_name = f"{len(yollar)} Adet Farklı Dosya/Klasör"
            folder_label = "📚 Çoklu Seçim"

        files_count_str = f"{len(files)} adet geçerli dosya"
        months_count_str = f"{len(months)} adet"
        
        self.detected_months = months 
        msg_extra = f"\n⚠️ Eksik Aylar: {', '.join(eksikler)}" if eksikler else ""
        msg_main = "Yükleme işlemini başlatmak istiyor musunuz?"
        msg_sub = f"{folder_label}: {display_path_name}\n📄 İşlenecek Dosya: {files_count_str}\n📅 Dönem: {months_count_str}{msg_extra}\n\nDevam etmek için onaylayın."
        
        if modern_ask_yes_no(self.master, "Onay", msg_main, msg_sub, ok_text="YÜKLEMEYİ BAŞLAT"):
            self.dosya_listesi = files
            self.lbl_path.config(text=f"✅ {display_path_name}", fg=CLR_BTN_FG)
            self.btn_start.config(state=tk.NORMAL, bg=CLR_ACCENT)

    def get_sistemdeki_vknler(self):
        mevcut_vknler = set()
        root_dir = get_mukellefler_dir()
        if not os.path.exists(root_dir): return mevcut_vknler
        
        for folder in os.listdir(root_dir):
            if os.path.isdir(os.path.join(root_dir, folder)) and "-" in folder:
                parts = folder.rsplit("-", 1)
                if len(parts) == 2:
                    vkn = parts[1].strip()
                    mevcut_vknler.add(vkn)
        return mevcut_vknler

    def start_process(self):
        if not check_internet_connection():
            modern_show_error(self.master, "Bağlantı Hatası", "İnternet bağlantısı algılanamadı.")
            return

        try:
            import modules.denetim_analiz.ui as audit_ui
            token = audit_ui.CURRENT_USER_TOKEN
        except ImportError: token = None
        
        if not token:
            modern_show_error(self.master, "Oturum Hatası", "Oturum süresi dolmuş veya giriş yapılmamış.")
            return

        is_dev_env = False 
        sistemdeki_eski_vknler = self.get_sistemdeki_vknler()

        self.btn_start.config(state=tk.DISABLED, text="İŞLENİYOR...")
        self.update_idletasks()
        self.last_net_check_time = time.time()
        
        processed_vkn_container = {'vkn': None, 'yil': None}

        def ui_callback(unvan, vkn, aktif_yil):
            processed_vkn_container['vkn'] = str(vkn)
            processed_vkn_container['yil'] = str(aktif_yil) 
            try:
                root = self.winfo_toplevel()
                root.vkn = str(vkn); root.unvan = str(unvan); root.yil = str(aktif_yil)
                if hasattr(root, 'update_header_info'): root.update_header_info(unvan, vkn, aktif_yil)
            except: pass

        def progress_cb(msg, i, total, fname):
            if hasattr(self, 'loading_popup') and self.loading_popup.winfo_exists():
                if self.loading_popup.is_cancelled:
                    raise InterruptedError("Kullanıcı işlemi iptal etti.")
                self.loading_popup.update_progress(msg, i, total, fname)
                
            if total > 0: self.progress['value'] = (i / total) * 100
            self.update_idletasks()
            
            if time.time() - self.last_net_check_time > 5:
                self.last_net_check_time = time.time()
                if not check_internet_connection(timeout=1.5): raise ConnectionError("NET_LOST")

        def engine_ui_bridge(dialog_type, **kwargs):
            if hasattr(self, 'loading_popup') and self.loading_popup.winfo_exists():
                self.loading_popup.attributes('-topmost', False)

            sonuc = None
            if dialog_type == "ask_string":
                sonuc = modern_ask_string(self.master, title=kwargs.get('title'), message=kwargs.get('message'), sub_message=kwargs.get('sub_message'))
            elif dialog_type == "ask_yes_no":
                sonuc = modern_ask_yes_no(self.master, title=kwargs.get('title'), message=kwargs.get('message'), sub_message=kwargs.get('sub_message'), ok_text=kwargs.get('ok_text', 'EVET'), cancel_text=kwargs.get('cancel_text', 'HAYIR'))
            elif dialog_type == "select_taxpayer":
                dialog = MukellefSecimDialog(self.master, excel_unvan=kwargs.get('excel_unvan'), tum_mukellefler=kwargs.get('all_taxpayers'), onerilen_mukellef=kwargs.get('suggested_match'))
                self.master.wait_window(dialog)
                sonuc = dialog.result
            # --- YENİ EKLENEN KÖPRÜ BAĞLANTISI ---
            elif dialog_type == "ask_format":
                sonuc = modern_ask_format(self.master, title=kwargs.get('title'), message=kwargs.get('message'), sub_message=kwargs.get('sub_message'), format_list=kwargs.get('format_list'))

            if hasattr(self, 'loading_popup') and self.loading_popup.winfo_exists():
                self.loading_popup.attributes('-topmost', True)

            return sonuc

        def kredi_on_kontrol(islem_vkn):
            if is_dev_env: return True, ""
            if str(islem_vkn) in sistemdeki_eski_vknler: return True, ""
            
            if not check_internet_connection(timeout=3):
                return False, "İnternet koptuğu için bakiye kontrol edilemedi."
            
            try:
                mevcut_bakiye = int(CloudLicenseManager.get_wallet_balance(token))
                try:
                    islem_maliyeti = int(CloudLicenseManager.get_action_cost(token, "Defter Yukle"))
                except AttributeError:
                    islem_maliyeti = 1 
                
                if mevcut_bakiye < islem_maliyeti:
                    return False, f"⚠️ YETERSİZ BAKİYE!\n\nMevcut Krediniz: {mevcut_bakiye}\nGereken Kredi: {islem_maliyeti}\n\nİşleme devam etmek için lütfen kredi yükleyiniz."

                if hasattr(self, 'loading_popup') and self.loading_popup.winfo_exists():
                    self.loading_popup.attributes('-topmost', False) 
                    
                msg = "Bu bir YENİ MÜKELLEF kaydıdır."
                sub_msg = f"Kayıt tamamlandığında bakiyenizden {islem_maliyeti} Kredi düşülecektir.\n\nMevcut Bakiyeniz: {mevcut_bakiye}\n\nOnaylıyor musunuz?"
                
                onay = modern_ask_yes_no(self.master, "Kredi Onayı", msg, sub_message=sub_msg, ok_text="ONAYLA VE DEVAM ET", cancel_text="İPTAL")
                
                if hasattr(self, 'loading_popup') and self.loading_popup.winfo_exists():
                    self.loading_popup.attributes('-topmost', True)

                if onay: return True, "Kredi uyarısı onaylandı."
                else: return False, "İşlem iptal edildi (Kredi düşülmedi)."

            except Exception as e:
                return False, f"Bakiye doğrulama hatası: {str(e)}"

        self.loading_popup = LoadingDialog(self.master, "Dosyalar İşleniyor")

        try:
            success, msg = islem_yap_ve_kaydet(
                self.dosya_listesi, 
                progress_cb, 
                ui_callback, 
                ui_dialog_callback=engine_ui_bridge,
                kredi_kontrol_cb=kredi_on_kontrol
            )
            
            self.btn_start.config(state=tk.NORMAL, text="YÜKLEME İŞLEMİNE BAŞLA")
            
            if hasattr(self, 'loading_popup') and self.loading_popup.winfo_exists():
                self.loading_popup.destroy()
                
            if success:
                credit_status_msg = "ℹ️ İşlem tamamlandı."
                will_deduct = not is_dev_env
                
                islenen_vkn = processed_vkn_container.get('vkn')
                islenen_yil = processed_vkn_container.get('yil')
                
                self.otomatik_mizan_ve_tablo_olustur(islenen_vkn, islenen_yil)
                
                if will_deduct and islenen_vkn:
                    if islenen_vkn in sistemdeki_eski_vknler:
                        will_deduct = False
                        credit_status_msg = "ℹ️ Mevcut mükellef dosyası güncellendiği için kredi DÜŞÜLMEDİ."
                    else:
                        will_deduct = True
                
                if will_deduct:
                    try:
                        if not check_internet_connection(timeout=3): 
                            credit_status_msg = "⚠️ İşlem başarılı ancak internet koptuğu için kredi düşülemedi."
                        else:
                            result = CloudLicenseManager.confirm_transaction(token, "Defter Yukle", "group")
                            if result:
                                credit_status_msg = " YENİ MÜKELLEF KAYDI: İşlem ücreti kredinizden DÜŞÜLDÜ."
                                if ProfilEngine:
                                    try:
                                        eng = ProfilEngine()
                                        dusulen = int(result.get('deducted', 1)) if isinstance(result, dict) else 1
                                        eng.kredi_islem_kaydet("Defter Yükleme (Yeni)", dusulen)
                                    except: pass
                                if hasattr(audit_ui, 'refresh_ui_credits_global'): 
                                    audit_ui.refresh_ui_credits_global()
                            else:
                                credit_status_msg = "⚠️ İşlem başarılı ancak bakiye yetersiz olduğu için kredi düşülemedi."
                    except Exception as e:
                        credit_status_msg = f"⚠️ Kredi hatası: {str(e)}"

                elif is_dev_env:
                    credit_status_msg = "ℹ️ Geliştirici ortamı (Kredi Düşülmedi)."
                
                islenen_vkn = processed_vkn_container.get('vkn')
                islenen_yil = processed_vkn_container.get('yil')

                if not islenen_yil:
                    import utils.session_db
                    session = utils.session_db.get_last_session()
                    if session:
                        islenen_yil = session.get('year', session.get('yil'))

                self.otomatik_mizan_ve_tablo_olustur(islenen_vkn, islenen_yil)
                
                modern_show_info(self.master, "İşlem Başarılı", "Veriler diske kaydedildi.", sub_message=credit_status_msg)
                
                def finish_sequence():
                    main_app = self.winfo_toplevel()
                    if hasattr(main_app, 'refresh_app'):
                        main_app.refresh_app()
                    elif hasattr(main_app, 'show_dashboard'):
                        main_app.show_dashboard()
                        
                    if hasattr(main_app, 'notebook'):
                        try:
                            my_index = main_app.notebook.index(self)
                            main_app.close_tab_by_index(my_index)
                        except Exception as e:
                            print(f"Sekme kapatma hatasi: {e}")

                self.after(500, finish_sequence)
                
            else:
                modern_show_error(self.master, "İşlem Durduruldu", msg)

        except InterruptedError as e:
            self.btn_start.config(state=tk.NORMAL, text="YÜKLEME İŞLEMİNE BAŞLA")
            if hasattr(self, 'loading_popup') and self.loading_popup.winfo_exists():
                self.loading_popup.destroy()
            modern_show_info(self.master, "İşlem Durduruldu", "Yükleme işlemi kullanıcı tarafından iptal edildi.")

        except ConnectionError:
            self.btn_start.config(state=tk.NORMAL, text="BAĞLANTI KOPTU")
            if hasattr(self, 'loading_popup') and self.loading_popup.winfo_exists():
                self.loading_popup.destroy()
            modern_show_error(self.master, "Bağlantı Hatası", "İşlem sırasında internet bağlantısı koptu.")
        
        except Exception as e:
            self.btn_start.config(state=tk.NORMAL, text="KRİTİK HATA")
            import traceback
            traceback.print_exc()
            if hasattr(self, 'loading_popup') and self.loading_popup.winfo_exists():
                self.loading_popup.destroy()
            modern_show_error(self.master, "Sistem Hatası", f"Beklenmeyen bir hata oluştu:\n{str(e)}")

    def aktif_defter_birlestir_tetikle(self):
        # 1. Aktif Mükellef ve Yıl bilgilerini al 
        try:
            import utils.session_db
            session = utils.session_db.get_last_session()
            aktif_vkn = session.get('vkn')
            aktif_yil = session.get('year') or session.get('yil')
        except:
            aktif_vkn = getattr(self, 'current_vkn', None)
            aktif_yil = getattr(self, 'current_year', None)

        if not aktif_vkn or not aktif_yil:
            modern_show_error(self, "Hata", "Aktif bir mükellef ve yıl seçili değil.")
            return

        # 2. Mükellefin klasör yolunu bul
        from config import get_mukellefler_dir
        base_dir = get_mukellefler_dir()
        hedef_klasor = None
        
        for f in os.listdir(base_dir):
            if str(f).strip().endswith(f"-{str(aktif_vkn).strip()}"):
                hedef_klasor = os.path.join(base_dir, f, str(aktif_yil))
                break

        if not hedef_klasor or not os.path.exists(hedef_klasor):
            modern_show_error(self, "Hata", f"{aktif_yil} yılına ait veri klasörü bulunamadı.")
            return

        # 3. Klasördeki parquet dosyalarını topla
        parquet_dosyalari = glob.glob(os.path.join(hedef_klasor, "*.parquet"))
        
        if len(parquet_dosyalari) < 2:
            modern_show_info(self, "Bilgi", "Birleştirilecek yeterli dosya yok. En az 2 adet parçalı defter (parquet) bulunmalıdır.")
            return

        # 4. Dosyaları UI'ın istediği formata çevir
        dosya_listesi = []
        for yol in parquet_dosyalari:
            dosya_adi = os.path.basename(yol)
            olusturulma_zamani = os.path.getctime(yol)
            tarih_str = datetime.fromtimestamp(olusturulma_zamani).strftime('%d.%m.%Y %H:%M')
            
            dosya_listesi.append({
                'ad': dosya_adi,
                'path': yol,
                'tarih': tarih_str
            })

        # 5. İki Alanlı Sürükle Bırak Dialogunu Aç
        dialog = IkiAlanliBirlestirmeDialog(self.winfo_toplevel(), dosya_listesi)
        self.wait_window(dialog)

        # 6. Kullanıcı sıralamayı onayladıysa işlemi başlat
        if dialog.result:
            sirali_yollar = dialog.result
            
            # STANDART ANA DEFTER İSMİ BELİRLEME (Versiyonlamanın doğru çalışması için)
            hedef_dosya_adi = f"{aktif_yil}_FULL.parquet"
            tam_hedef_yol = os.path.join(hedef_klasor, hedef_dosya_adi)

            islem_secimi = modern_ask_yes_no(
                self.winfo_toplevel(),
                title="Kayıt Yöntemi",
                message="Birleştirme işlemi tamamlandıktan sonra nasıl kaydedilsin?",
                sub_message="Mevcut ana dosyanın üzerine yazabilir veya yeni bir versiyon olarak kaydedebilirsiniz.",
                ok_text="YENİ VERSİYON OLUŞTUR (Tavsiye)",
                cancel_text="ESKİ PARÇALARI SİL VE ÜZERİNE YAZ"
            )

            # Kullanıcı "YENİ VERSİYON" seçerse
            if islem_secimi is True: 
                from modules.defter_yukle.engine import dosya_versiyonla
                # Ana defterin sonuna _V2, _V3 ekleyerek yolu günceller
                tam_hedef_yol = dosya_versiyonla(tam_hedef_yol)

            # 7. Motoru Çalıştır
            from modules.defter_yukle.engine import oncelikli_defter_birlestir
            basarili_mi, mesaj = oncelikli_defter_birlestir(sirali_yollar, tam_hedef_yol)

            if basarili_mi:
                # Kullanıcı "Eskileri Sil ve Üzerine Yaz" dediyse eski parçaları temizle
                if islem_secimi is False:
                    for eski_dosya in sirali_yollar:
                        if eski_dosya != tam_hedef_yol and os.path.exists(eski_dosya):
                            try:
                                os.remove(eski_dosya)
                            except: pass

                # --- YENİ EKLENEN: AKTİF DEFTERİ GÜNCELLEME ---
                # Yeni oluşan dosyayı sistemde "Aktif Defter" olarak ayarla
                try:
                    import utils.session_db
                    session = utils.session_db.get_last_session()
                    if session:
                        session['aktif_dosya_yolu'] = tam_hedef_yol
                        # Uygulamanızın yapısına göre session kaydetme fonksiyonunu çağırıyoruz
                        if hasattr(utils.session_db, 'save_session'):
                            utils.session_db.save_session(session)
                        elif hasattr(utils.session_db, 'update_session'):
                            utils.session_db.update_session(session)
                except Exception as e:
                    print(f"Session güncellenirken uyarı: {e}")

                # Ana penceredeki (Dashboard) aktif dosya değişkenini de güncelle
                ana_uygulama = self.winfo_toplevel()
                if hasattr(ana_uygulama, 'aktif_dosya_yolu'):
                    ana_uygulama.aktif_dosya_yolu = tam_hedef_yol

                modern_show_info(self, "Başarılı", "Defterler başarıyla birleştirildi ve Aktif Defter olarak ayarlandı.", sub_message=f"Oluşan Dosya: {os.path.basename(tam_hedef_yol)}")
                
                # Mizan ve tabloları yeni veritabanına göre sessizce güncelle
                self.otomatik_mizan_ve_tablo_olustur(aktif_vkn, aktif_yil)
                
                # UI (Arayüz) Yenileme İşlemleri
                if hasattr(self, 'refresh_data'):
                    self.refresh_data()
                    
                # Tüm sekmelerin ve dashboard'un yeni dosyayı görmesi için ana uygulamayı yenile
                if hasattr(ana_uygulama, 'refresh_app'):
                    ana_uygulama.refresh_app()
                elif hasattr(ana_uygulama, 'show_dashboard'):
                    ana_uygulama.show_dashboard()
                
            else:
                modern_show_error(self, "Hata", mesaj)


                
    def otomatik_mizan_ve_tablo_olustur(self, vkn, yil):
        if not vkn or not yil or str(yil) == "0":
            modern_show_error(self.master, "Otomatik İşlem İptal Edildi", f"Mizan ve Tablolar oluşturulamadı!\nGeçerli bir Yıl veya VKN bulunamadı.\nAlgılanan VKN: {vkn}\nAlgılanan Yıl: {yil}")
            return
            
        print(f"Arka plan işlemleri başlatılıyor: Mizan ve Mali Tablolar ({vkn} - {yil})...")
        import utils.session_db
        from config import get_mukellefler_dir
        
        hedef_klasor = None
        base_dir = get_mukellefler_dir()
        for f in os.listdir(base_dir):
            if str(f).strip().endswith(f"-{str(vkn).strip()}"):
                hedef_klasor = os.path.join(base_dir, f, str(yil))
                break
                
        en_yeni_parquet = None
        if hedef_klasor and os.path.exists(hedef_klasor):
            parquet_dosyalari = [os.path.join(hedef_klasor, p) for p in os.listdir(hedef_klasor) if p.endswith('.parquet')]
            if parquet_dosyalari:
                en_yeni_parquet = max(parquet_dosyalari, key=os.path.getmtime)
        
        print(f"[BILGI] Otomatik Mizan icin secilen dosya: {en_yeni_parquet}")
        orijinal_session_fonksiyonu = utils.session_db.get_last_session
        
        sahte_oturum = lambda: {
            "vkn": str(vkn), 
            "year": str(yil), 
            "yil": str(yil),
            "aktif_dosya_yolu": en_yeni_parquet
        }
        
        try:
            utils.session_db.get_last_session = sahte_oturum
            try:
                import modules.mizan_analiz.engine as mizan_modulu
                if hasattr(mizan_modulu, 'get_last_session'):
                    mizan_modulu.get_last_session = sahte_oturum
            except ImportError: pass

            try:
                from modules.mizan_analiz.engine import MizanEngine
                mizan_motoru = MizanEngine(ozel_dosya_yolu=en_yeni_parquet, vkn=vkn, yil=yil)
                if hasattr(mizan_motoru, 'current_vkn'): mizan_motoru.current_vkn = str(vkn)
                if hasattr(mizan_motoru, 'current_year'): mizan_motoru.current_year = str(yil)

                basarili_mi, msg = mizan_motoru.save_to_sqlite()
                if basarili_mi:
                    print(f"[BASARILI] Mizan veritabanina basariyla yazildi: {msg}")
                else:
                    modern_show_error(self.master, "Mizan Kayıt Hatası", f"Mizan oluşturuldu ancak veritabanına kaydedilemedi:\n{msg}")
            except Exception as e:
                import traceback
                hata_detayi = traceback.format_exc()
                print(hata_detayi) 
                modern_show_error(self.master, "Mizan Kritik Hata", f"Mizan oluşturulurken motor çöktü:\n{str(e)}")

            try:
                from modules.mali_tablolar.engine import FinancialReportEngine
                import modules.mali_tablolar.engine as mali_modulu
                if hasattr(mali_modulu, 'get_last_session'):
                    mali_modulu.get_last_session = sahte_oturum

                try:
                    mali_motor = FinancialReportEngine(aktif_dosya_yolu=en_yeni_parquet, vkn=str(vkn), yil=str(yil), parent=None)
                except TypeError:
                    mali_motor = FinancialReportEngine(parent=None)
                    mali_motor.aktif_dosya_yolu = en_yeni_parquet
                    mali_motor.ozel_dosya_yolu = en_yeni_parquet 
                    mali_motor.vkn = str(vkn)
                    mali_motor.yil = str(yil)

                print(f"[BILGI] Mali Tablo Motoru çalıştırılıyor. Hedef Dosya: {en_yeni_parquet}")
                mali_motor.calculate_matrix("Bilanço", "Yıllık", force_update=True)
                mali_motor.calculate_matrix("Gelir Tablosu", "Yıllık", force_update=True)
                print("[BASARILI] Mali Tablolar güncel veri ile financial_reports.db'ye kaydedildi.")
                
            except Exception as e:
                modern_show_error(self.master, "Mali Tablo Hatası", f"Mali tablolar oluşturulurken hata yaşandı:\n{str(e)}")
                
        finally:
            utils.session_db.get_last_session = orijinal_session_fonksiyonu
            try:
                if hasattr(mizan_modulu, 'get_last_session'): mizan_modulu.get_last_session = orijinal_session_fonksiyonu
                if hasattr(mali_modulu, 'get_last_session'): mali_modulu.get_last_session = orijinal_session_fonksiyonu
            except: pass