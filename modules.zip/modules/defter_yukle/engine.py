import os
import re
import json
import glob
import pandas as pd
from config import get_mukellefler_dir
import zipfile
import tempfile
import uuid

# --- 1. MODÜL İMPORTLARI ---
from modules.defter_yukle.parser import zip_veya_xml_oku
from modules.excel_loader.engine import excel_dosya_islee

# --- JSON AYAR DOSYASI AYARLARI ---
FORMAT_AYAR_DOSYASI = "format_isimleri.json"

def format_ayarlarini_getir():
    """JSON dosyasından kullanıcının tanımladığı isimleri ve sistem karşılıklarını getirir."""
    varsayilan_ayarlar = {
        
    }
    
    if os.path.exists(FORMAT_AYAR_DOSYASI):
        try:
            with open(FORMAT_AYAR_DOSYASI, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"Format ayarları okunamadı, varsayılanlar yükleniyor: {e}")
            
    # Eğer dosya yoksa varsayılanları kaydet ve döndür
    try:
        with open(FORMAT_AYAR_DOSYASI, "w", encoding="utf-8") as f:
            json.dump(varsayilan_ayarlar, f, ensure_ascii=False, indent=4)
    except: pass
    
    return varsayilan_ayarlar

def format_ayarlarini_kaydet(yeni_ayarlar):
    """Kullanıcının yaptığı değişiklikleri JSON dosyasına kaydeder."""
    with open(FORMAT_AYAR_DOSYASI, "w", encoding="utf-8") as f:
        json.dump(yeni_ayarlar, f, ensure_ascii=False, indent=4)

# --- YARDIMCI FONKSİYONLAR ---

def tum_mukellefleri_getir():
    """Sistemdeki tüm mükellefleri listeler."""
    root_dir = get_mukellefler_dir()
    liste = []
    if not os.path.exists(root_dir): return []

    for folder in os.listdir(root_dir):
        full_path = os.path.join(root_dir, folder)
        if os.path.isdir(full_path) and "-" in folder:
            parts = folder.rsplit('-', 1)
            if len(parts) == 2:
                unvan = parts[0].strip()
                vkn = parts[1].strip()
                liste.append({'unvan': unvan, 'vkn': vkn, 'path': full_path})
    return liste

def akilli_eslesme_bul(excel_unvan, mukellef_listesi):
    """Unvan benzerliği üzerinden eşleşme arar."""
    if not excel_unvan: return None
    excel_unvan_lower = excel_unvan.replace('İ','i').lower().strip()
    if ":" in excel_unvan_lower:
        excel_unvan_lower = excel_unvan_lower.split(":", 1)[-1].strip()
        
    kelimeler = excel_unvan_lower.split()
    
    for muk in mukellef_listesi:
        db_unvan = muk['unvan'].replace('İ','i').lower().strip()
        if excel_unvan_lower == db_unvan:
            return muk

    for i in range(min(3, len(kelimeler))):
        aranacak_kelime = kelimeler[i]
        if len(aranacak_kelime) < 3: continue
        for muk in mukellef_listesi:
            db_unvan = muk['unvan'].replace('İ','i').lower()
            if aranacak_kelime in db_unvan:
                return muk
    return None

def klasor_tara_ve_analiz_et(hedef_yollar):
    """Tüm Senaryoları Çözen Zırhlı Tarayıcı (ZIP -> Klasör -> Klasör sorununu çözer)"""
    dosyalar = []
    aylar = set()
    
    valid_exts = {'.zip', '.xml', '.xlsx', '.xls', '.csv'}
    gib_gecersiz_ekler = {'-k-', '-b-'} 
    
    if isinstance(hedef_yollar, str):
        taranacak_yollar = [hedef_yollar]
    else:
        taranacak_yollar = list(hedef_yollar) 
        
    temp_extract_dir = os.path.join(tempfile.gettempdir(), "MADS_Gecici_Zip_Cozucu")
    os.makedirs(temp_extract_dir, exist_ok=True)
    
    def donem_tespit_et(dosya_adi):
        match = re.search(r"202[0-9][-_]?[0-1][0-9]", dosya_adi)
        if match:
            raw = match.group(0).replace("_", "-")
            if len(raw) == 6: raw = f"{raw[:4]}-{raw[4:]}"
            return raw
        return "Bilinmiyor"

    while taranacak_yollar:
        aktif_yol = taranacak_yollar.pop(0) 
        
        if os.path.isfile(aktif_yol):
            file_list = [(os.path.dirname(aktif_yol), [], [os.path.basename(aktif_yol)])]
        else:
            file_list = os.walk(aktif_yol) 
            
        for kok, _, files in file_list:
            for f in files:
                file_lower = f.lower()
                tam_yol = os.path.join(kok, f)

                if not any(file_lower.endswith(ext) for ext in valid_exts):
                    continue

                if file_lower.endswith('.zip'):
                    try:
                        benzersiz_id = str(uuid.uuid4())[:8]
                        hedef_klasor = os.path.join(temp_extract_dir, f"{os.path.splitext(f)[0]}_{benzersiz_id}")
                        os.makedirs(hedef_klasor, exist_ok=True)
                        
                        with zipfile.ZipFile(tam_yol, 'r') as z:
                            z.extractall(hedef_klasor)
                        
                        taranacak_yollar.append(hedef_klasor)
                        continue 
                    except zipfile.BadZipFile:
                        continue 

                is_excel = file_lower.endswith(('.xlsx', '.xls', '.csv'))
                if not is_excel:
                    if not ("-y-" in file_lower or "yevmiye" in file_lower):
                        continue 
                    if any(gecersiz in file_lower for gecersiz in gib_gecersiz_ekler):
                        continue 

                donem = donem_tespit_et(f)
                if donem != "Bilinmiyor":
                    aylar.add(donem)
                    
                dosyalar.append({
                    "path": tam_yol,
                    "ad": f,
                    "donem": donem
                })

    temiz_dosyalar = []
    gorulen_isimler = set()
    for d in dosyalar:
        if d['ad'] not in gorulen_isimler:
            gorulen_isimler.add(d['ad'])
            temiz_dosyalar.append(d)

    return temiz_dosyalar, sorted(list(aylar))

def eksik_ay_kontrolu(bulunan_aylar):
    if not bulunan_aylar: return []
    try:
        yillar = set(d.split('-')[0] for d in bulunan_aylar if '-' in d)
        eksikler = []
        for yil in yillar:
            for i in range(1, 13):
                ay_str = f"{yil}-{i:02d}"
                if ay_str not in bulunan_aylar: eksikler.append(ay_str)
        return eksikler
    except: return []

def dosya_versiyonla(hedef_yol):
    if not os.path.exists(hedef_yol): return hedef_yol
    base, ext = os.path.splitext(hedef_yol)
    match = re.search(r"_V(\d+)$", base)
    if match:
        version_num = int(match.group(1)) + 1
        base_without_version = base[:match.start()]
        yeni_ad = f"{base_without_version}_V{version_num}{ext}"
    else:
        yeni_ad = f"{base}_V2{ext}"
    return dosya_versiyonla(yeni_ad)

def istatistik_kaydet(root_path, istatistik_data):
    json_path = os.path.join(root_path, "yukleme_istatistikleri.json")
    mevcut_veri = []
    if os.path.exists(json_path):
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                mevcut_veri = json.load(f)
        except: pass
    mevcut_veri.append(istatistik_data)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(mevcut_veri, f, ensure_ascii=False, indent=4)


# --- ANA İŞLEM FONKSİYONU ---

def islem_yap_ve_kaydet(dosya_listesi, callback_progress, root_ui_update, ui_dialog_callback=None, forced_format=None, kredi_kontrol_cb=None):
    normalized_list = []
    for d in dosya_listesi:
        if isinstance(d, str):
            normalized_list.append({'path': d, 'ad': os.path.basename(d)})
        else:
            normalized_list.append(d)
    dosya_listesi = normalized_list
    
    all_data = []
    hatalar = []  
    meta_info = {"vkn": "0000000000", "unvan": "Bilinmeyen"}
    tum_mukellefler = tum_mukellefleri_getir()
    
    # --- FORMATLARI JSON DOSYASINDAN DİNAMİK OLARAK ÇEKİYORUZ ---
    format_sozlugu = format_ayarlarini_getir()
    MEVCUT_FORMATLAR = list(format_sozlugu.keys()) # Ekranda görünecek özel isimler listesi

    for i, dosya in enumerate(dosya_listesi):
        callback_progress("Okunuyor...", i, len(dosya_listesi), dosya['ad'])
        path = dosya['path']
        is_excel = path.lower().endswith(('.xlsx', '.xls', '.csv'))
        
        if is_excel:
            # 1. AŞAMA: Otomatik Tanımayı Dene
            try:
                if excel_dosya_islee:
                    veri, meta, ek_bilgi, msg = excel_dosya_islee(path, forced_format=forced_format)
                else:
                    veri, meta, ek_bilgi, msg = [], {}, {}, "SİSTEM HATASI: excel_loader modülü bulunamadı!"
            except Exception as e:
                veri, meta, ek_bilgi, msg = [], {}, {}, f"Sistem Hatası: {str(e)}"
            
            # 2. AŞAMA: Otomatik Okunamazsa MANUEL FORMAT SOR (SÜREKLİ DÖNGÜ)
            if not forced_format and ui_dialog_callback:
                while not veri:
                    kisa_msg = msg[:150] + "... (devamı gizlendi)" if msg and len(msg) > 150 else msg
                    
                    # Kullanıcıya JSON'dan gelen süslü/özel isimler gösterilir
                    secilen_gorunen_isim = ui_dialog_callback(
                        "ask_format", 
                        title="Okuma Hatası / Format Seçin",
                        message=f"'{dosya['ad']}' dosyasından veri alınamadı.",
                        sub_message=f"Hata: {kisa_msg}\n\nLütfen listeden defter formatını seçin:",
                        format_list=MEVCUT_FORMATLAR
                    )
                    
                    if not secilen_gorunen_isim:
                        break # Kullanıcı ATLA dedi, döngüyü kır
                        
                    callback_progress(f"Deneniyor: {secilen_gorunen_isim}", i, len(dosya_listesi), dosya['ad'])
                    
                    # KRİTİK ÇEVİRİ NOKTASI: Seçilen özel ismin sistem kodunu JSON sözlüğünden buluyoruz
                    # Örn: "Zirve Müşavir" -> "ZIRVE"
                    secilen_gercek_format = format_sozlugu.get(secilen_gorunen_isim, "STANDART")
                    
                    try:
                        if excel_dosya_islee:
                            veri, meta, ek_bilgi, msg = excel_dosya_islee(path, forced_format=secilen_gercek_format)
                        else:
                            veri, meta, ek_bilgi, msg = [], {}, {}, "SİSTEM HATASI: excel_loader modülü arızalı!"
                    except Exception as e:
                        veri, meta, ek_bilgi, msg = [], {}, {}, f"Motor Hatası ({secilen_gorunen_isim}): {str(e)}"
        else:
            try:
                veri, meta, ek_bilgi, msg = zip_veya_xml_oku(path)
            except Exception as e:
                veri, meta, ek_bilgi, msg = [], {}, {}, f"XML Okuma Hatası: {str(e)}"
        
        if not veri: 
            print(f"[{dosya['ad']}] İŞLENEMEDİ: {msg}")
            hatalar.append(f"• {dosya['ad']}:\n  {msg}")
            continue

        current_vkn = meta.get('vkn', '0000000000')
        current_unvan = meta.get('unvan', 'Bilinmeyen')

        if not is_excel:
            if current_vkn and len(current_vkn) >= 10:
                eslesen = next((m for m in tum_mukellefler if m['vkn'] == current_vkn), None)
                if eslesen:
                    meta['unvan'] = eslesen['unvan']
                    meta_info['unvan'] = eslesen['unvan']
                    meta_info['vkn'] = current_vkn
                    for row in veri: row['VKN'] = current_vkn
                    all_data.extend(veri)
                    continue

        if is_excel:
            if ui_dialog_callback:
                onerilen = akilli_eslesme_bul(current_unvan, tum_mukellefler)
                cevap = ui_dialog_callback("select_taxpayer", excel_unvan=current_unvan, all_taxpayers=tum_mukellefler, suggested_match=onerilen)
                
                if cevap:
                    if cevap['action'] == 'existing':
                        current_vkn = cevap['vkn']
                        current_unvan = cevap['unvan']
                    elif cevap['action'] == 'new':
                        vkn_giris = cevap.get('vkn', '').strip()
                        temp_unvan = cevap.get('unvan', current_unvan).strip()
                        if not vkn_giris: return False, "SİSTEM HATASI: VKN boş!"
                        vkn_cakisan = next((m for m in tum_mukellefler if m['vkn'] == vkn_giris), None)
                        if vkn_cakisan:
                            devam = ui_dialog_callback("ask_yes_no", title="MEVCUT KAYIT", message=f"Mevcut: {vkn_cakisan['unvan']}", sub_message="Üzerine yazılsın mı?", ok_text="KAYDET", cancel_text="İPTAL")
                            if devam: current_vkn = vkn_cakisan['vkn']; current_unvan = vkn_cakisan['unvan']
                            else: return False, "İptal edildi."
                        else: current_vkn = vkn_giris; current_unvan = temp_unvan
                else: return False, "Seçim iptal edildi."

        meta['vkn'] = current_vkn
        meta_info['vkn'] = current_vkn
        if meta_info['unvan'] == "Bilinmeyen": meta_info['unvan'] = current_unvan
        for row in veri: row['VKN'] = current_vkn
        all_data.extend(veri)

    if not all_data: 
        hata_mesaji = "İşlenen dosyalardan veri okunamadı veya işlem iptal edildi.\n\nKarşılaşılan Hatalar:\n"
        hata_mesaji += "\n".join(hatalar[:5])
        return False, hata_mesaji

    df = pd.DataFrame(all_data)
    
    if 'KayitTarihi' in df.columns:
        df['KayitTarihi'] = df['KayitTarihi'].astype(str).str.strip()
        df['KayitTarihi'] = pd.to_datetime(df['KayitTarihi'], format='%d.%m.%Y', errors='coerce') \
            .fillna(pd.to_datetime(df['KayitTarihi'], format='%Y-%m-%d', errors='coerce')) \
            .fillna(pd.to_datetime(df['KayitTarihi'], format='%d/%m/%Y', errors='coerce')) \
            .fillna(pd.to_datetime(df['KayitTarihi'], dayfirst=True, errors='coerce'))
        df['KayitTarihi'] = df['KayitTarihi'].ffill()
        df['KayitTarihi'] = df['KayitTarihi'].fillna(pd.to_datetime('1900-01-01'))
    
    raw_unvan = meta_info['unvan']
    if ":" in raw_unvan: raw_unvan = raw_unvan.split(':', 1)[1]
    
    temiz_unvan = "".join([c for c in raw_unvan if c.isalnum() or c in (' ', '.', '-', '_')]).strip()
    while "  " in temiz_unvan: temiz_unvan = temiz_unvan.replace("  ", " ")
    if not temiz_unvan: temiz_unvan = "BILINMEYEN_MUKELLEF"

    klasor_adi = f"{temiz_unvan}-{meta_info['vkn']}"
    root_path = os.path.join(get_mukellefler_dir(), klasor_adi)
    
    kaydedilecek_dosyalar = []
    
    try: 
        if 'KayitTarihi' in df.columns:
            yillar = df['KayitTarihi'].dt.year.dropna().unique()
        else:
            yillar = []
    except: yillar = []
    
    processed_years = []
    cevap_cakisma = None

    for yil in yillar:
        yil = int(yil)
        processed_years.append(yil)
        
        yil_path = os.path.join(root_path, str(yil))
        full_path = os.path.join(yil_path, f"{yil}_FULL.parquet")
        
        if os.path.exists(full_path):
            if ui_dialog_callback and cevap_cakisma is None:
                cevap_cakisma = ui_dialog_callback(
                    "ask_yes_no",
                    title="⚠️ Mükellef Kaydı Bulundu",
                    message=f"{yil} yılına ait veri dosyası zaten mevcut.",
                    sub_message="Üzerine yazmak mı yoksa yeni versiyon oluşturmak mı istersiniz?",
                    ok_text="ÜZERİNE YAZ",
                    cancel_text="YENİ VERSİYON"
                )
            
            if cevap_cakisma is True:
                final_path = full_path
            else:
                final_path = dosya_versiyonla(full_path)
        else:
            final_path = full_path
            
        df_yil = df[df['KayitTarihi'].dt.year == yil]
        kaydedilecek_dosyalar.append((df_yil, final_path, yil_path))

    kredi_durum_mesaji = ""
    if kredi_kontrol_cb:
        callback_progress("Kredi bakiyesi doğrulanıyor...", len(dosya_listesi), len(dosya_listesi), "Ödeme Onayı")
        onay, mesaj = kredi_kontrol_cb(meta_info['vkn'])
        if not onay:
            return False, f"Kayıt İşlemi Durduruldu:\n{mesaj}"
        kredi_durum_mesaji = f"\n\nℹ️ {mesaj}"

    try:
        if not os.path.exists(root_path): os.makedirs(root_path)
    except OSError as e:
        return False, f"Klasör oluşturulamadı: {str(e)}\nPath: {root_path}"

    toplam_satir = len(df)
    try:
        if 'KayitTarihi' in df.columns and not df['KayitTarihi'].isnull().all():
            unique_months = df['KayitTarihi'].dt.to_period('M').unique()
            kac_ay = len(unique_months)
            aylar_listesi = [str(m) for m in unique_months]
        else:
            kac_ay = 0
            aylar_listesi = []
    except:
        kac_ay, aylar_listesi = 0, []
    
    istatistik_kaydet(root_path, {
        "islem_tarihi": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
        "toplam_satir": toplam_satir,
        "ay_sayisi": kac_ay,
        "aylar": aylar_listesi,
        "dosyalar": [d['ad'] for d in dosya_listesi]
    })

    for df_yil, dosya_yolu, yil_path in kaydedilecek_dosyalar:
        if not os.path.exists(yil_path): os.makedirs(yil_path)
        df_yil.to_parquet(dosya_yolu, index=False)

    if root_ui_update:
        root_ui_update(temiz_unvan, meta_info['vkn'], max(processed_years) if processed_years else 0)

    return True, f"İşlem Tamamlandı.\nUnvan: {temiz_unvan}\nVKN: {meta_info['vkn']}{kredi_durum_mesaji}"