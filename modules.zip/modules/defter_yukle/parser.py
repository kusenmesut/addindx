import xml.etree.ElementTree as ET
import zipfile
import io
import os

# GIB Standart Namespaces
NS = {
    'gl-cor': 'http://www.xbrl.org/int/gl/cor/2006-10-25',
    'gl-bus': 'http://www.xbrl.org/int/gl/bus/2006-10-25',
    'gl-muc': 'http://www.xbrl.org/int/gl/muc/2006-10-25',
    'xbrl': 'http://www.xbrl.org/2003/instance',
    'xbrli': 'http://www.xbrl.org/2003/instance' 
}

def guvenli_veri_al(element, tag_path, ns, tip="str"):
    """
    XML elementinden veriyi güvenli ve hassas çeker.
    """
    try:
        bulunan = element.find(tag_path, ns)
        if bulunan is not None and bulunan.text:
            value = bulunan.text.strip()
            
            if tip == "float":
                try:
                    # Görünmez karakterleri temizle
                    value = value.replace(" ", "").replace("\xa0", "")
                    
                    # Sayı Formatı Algılama
                    # Senaryo 1: 1.250,50 (TR - Binlik nokta, Ondalık virgül)
                    if "," in value and "." in value:
                        if value.rfind(".") < value.rfind(","): 
                            value = value.replace('.', '').replace(',', '.')
                        # Senaryo 2: 1,250.50 (US - Binlik virgül, Ondalık nokta)
                        else:
                            value = value.replace(",", "")
                    
                    # Senaryo 3: 1250,50 (Sadece virgül -> Ondalık)
                    elif "," in value:
                        value = value.replace(",", ".")
                    
                    # Senaryo 4: 1250.50 (Standart) -> Dokunma
                    
                    return round(float(value), 2)
                except:
                    return 0.0
            
            return value
        return 0.0 if tip == "float" else ""
    except:
        return 0.0 if tip == "float" else ""

def parse_single_xml(content_bytes, dosya_adi):
    liste = []
    vkn = "0000000000"
    unvan = "BILINMEYEN"
    
    mukellef_meta = {
        "vkn": vkn, "unvan": unvan, 
        "telefon": "", "fax": "", "email": "", 
        "adres_cadde": "", "adres_ek": "", "adres_sehir": "", "adres_postakodu": "",
        "muh_ad_soyad": "", "yil_baslangic": "", "vergi_dairesi": ""
    }
    
    try:
        tree = ET.parse(io.BytesIO(content_bytes))
        root = tree.getroot()
        
        # 1. VKN ve UNVAN
        entity_id = root.find('.//xbrli:identifier', NS)
        if entity_id is None: entity_id = root.find('.//xbrl:identifier', NS)
        if entity_id is not None and entity_id.text: vkn = entity_id.text.strip()
        mukellef_meta['vkn'] = vkn
        
        unvan_tags = ['.//gl-bus:organizationName', './/gl-bus:organizationIdentifier', './/gl-bus:businessName']
        for tag in unvan_tags:
            bulunan_unvan = root.find(tag, NS)
            if bulunan_unvan is not None and bulunan_unvan.text:
                unvan = bulunan_unvan.text.strip()
                break
        mukellef_meta['unvan'] = unvan
        if unvan == "BILINMEYEN" and vkn != "0000000000": mukellef_meta['unvan'] = f"Mükellef ({vkn})"
            
        # 2. İLETİŞİM (Opsiyonel alanlar)
        entity_info = root.find('.//gl-cor:entityInformation', NS)
        if entity_info:
            mukellef_meta['yil_baslangic'] = guvenli_veri_al(entity_info, './/gl-bus:fiscalYearStart', NS)

        # 3. YEVMİYE FİŞLERİ
        entries = root.findall('.//gl-cor:entryHeader', NS)
        for fis in entries:
            yevmiye_no = guvenli_veri_al(fis, 'gl-cor:entryNumberCounter', NS)
            fis_aciklama = guvenli_veri_al(fis, 'gl-cor:entryComment', NS)
            genel_tarih = guvenli_veri_al(fis, './/gl-cor:postingDate', NS) 
            
            detaylar = fis.findall('gl-cor:entryDetail', NS)
            for satir in detaylar:
                tutar = guvenli_veri_al(satir, 'gl-cor:amount', NS, "float")
                
                # [GÜNCELLEME] Satır Numarasını Al (Benzersizlik için şart)
                satir_no = guvenli_veri_al(satir, 'gl-cor:lineNumber', NS)
                if not satir_no: satir_no = guvenli_veri_al(satir, 'gl-cor:lineNumberCounter', NS)

                # [GÜNCELLEME] Borç/Alacak Yönü (Case Insensitive)
                raw_yon = guvenli_veri_al(satir, 'gl-cor:debitCreditCode', NS)
                yon = raw_yon.upper().strip() 
                
                if yon == 'D':
                    borc = tutar
                    alacak = 0.0
                elif yon == 'C':
                    borc = 0.0
                    alacak = tutar
                else:
                    # Kod okunamadıysa bile tutarı bir yere atalım ki fark oluşmasın (Genelde Borç varsayılır ama loglanmalı)
                    # Şimdilik 0 bırakıyoruz ama burası kritik.
                    borc = 0.0
                    alacak = 0.0

                satir_tarihi = guvenli_veri_al(satir, './/gl-cor:postingDate', NS)
                if not satir_tarihi: satir_tarihi = genel_tarih

                liste.append({
                    "VKN": vkn, "Unvan": unvan, 
                    "YevmiyeNo": int(yevmiye_no) if yevmiye_no.isdigit() else 0,
                    "SatirNo": satir_no,  # <-- YENİ ALAN
                    "KayitTarihi": satir_tarihi, 
                    "BelgeNo": guvenli_veri_al(satir, './/gl-cor:documentNumber', NS), 
                    "FisAciklamasi": fis_aciklama, 
                    "DetayAciklama": guvenli_veri_al(satir, './/gl-cor:detailComment', NS), 
                    "HesapKodu": guvenli_veri_al(satir, './/gl-cor:accountMainID', NS), 
                    "HesapAdi": guvenli_veri_al(satir, './/gl-cor:accountMainDescription', NS), 
                    "MuavinKodu": guvenli_veri_al(satir, './/gl-cor:accountSubID', NS), 
                    "MuavinAdi": guvenli_veri_al(satir, './/gl-cor:accountSubDescription', NS), 
                    "Borc": borc, 
                    "Alacak": alacak, 
                    "KaynakDosya": dosya_adi
                })
                
    except Exception as e:
        print(f"XML Parse Hatası ({dosya_adi}): {e}")
        return [], None, None, None

    return liste, vkn, unvan, mukellef_meta

def zip_veya_xml_oku(dosya_yolu):
    ham_veri = []
    meta = {"vkn": None, "unvan": None}
    mukellef_bilgi = {}
    try:
        if dosya_yolu.lower().endswith('.zip'):
            with zipfile.ZipFile(dosya_yolu, 'r') as z:
                for filename in z.namelist():
                    if filename.lower().endswith('.xml'):
                        with z.open(filename) as f:
                            data, vkn, unvan, meta_data = parse_single_xml(f.read(), filename)
                            if data:
                                ham_veri.extend(data)
                                if vkn: meta["vkn"] = vkn
                                if unvan: meta["unvan"] = unvan
                                if meta_data: mukellef_bilgi = meta_data 
        elif dosya_yolu.lower().endswith('.xml'):
             with open(dosya_yolu, 'rb') as f:
                data, vkn, unvan, meta_data = parse_single_xml(f.read(), os.path.basename(dosya_yolu))
                if data:
                    ham_veri.extend(data)
                    if vkn: meta["vkn"] = vkn
                    if unvan: meta["unvan"] = unvan
                    if meta_data: mukellef_bilgi = meta_data
    except Exception as e:
        return [], meta, None, str(e)
    return ham_veri, meta, mukellef_bilgi, "OK"