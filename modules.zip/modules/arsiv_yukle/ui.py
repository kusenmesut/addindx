import tkinter as tk
from tkinter import ttk, messagebox
import os
import pandas as pd  # Pandas'ı veriye hızlıca bakmak için ekledik
from config import CLR_BODY_BG, CLR_ACCENT
from .engine import (
    arsivdeki_mukellefleri_getir, mukellef_yillarini_getir, 
    yil_dosyalarini_getir, parquet_yukle
)

# --- GÖRSEL AYARLAR ---
CLR_CARD_BG = "#4472C4"  
CLR_STEP_BG = "#ED7D31"  
CLR_TEXT_W = "#FFFFFF"   

class ArsivdenYukleFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.master = master
        self.secili_mukellef = None
        self.secili_yil = None
        self.yillik_dosyalar = [] 
        self.secili_dosya_yolu = None
        
        self.setup_ui()
        self.verileri_doldur()

    def setup_ui(self):
        tk.Label(self, text="📂 ARŞİVDEN YÜKLEME SİHİRBAZI", 
                 font=("Segoe UI", 16, "bold"), bg=CLR_BODY_BG, fg="#2c3e50").pack(pady=(20, 20))
        
        self.card_frame = tk.Frame(self, bg=CLR_CARD_BG, padx=20, pady=30)
        self.card_frame.pack(pady=10, padx=50, fill=tk.Y)

        # --- ADIM 1: MÜKELLEF ---
        self.frm_step1 = self.create_step_frame(self.card_frame, "1. Mükellef Seçiniz")
        self.cmb_mukellef = ttk.Combobox(self.frm_step1, font=("Segoe UI", 11), state="readonly", width=40)
        self.cmb_mukellef.pack(pady=10, padx=10)
        self.cmb_mukellef.bind('<<ComboboxSelected>>', self.on_mukellef_select)

        # --- ADIM 2: YIL ---
        self.frm_step2 = self.create_step_frame(self.card_frame, "2. Dönem (Yıl) Seçiniz")
        self.cmb_yil = ttk.Combobox(self.frm_step2, font=("Segoe UI", 11), state="readonly", width=40)
        self.cmb_yil.pack(pady=10, padx=10)
        self.cmb_yil.bind('<<ComboboxSelected>>', self.on_yil_select)
        
        # --- ADIM 3: ÇOK SÜTUNLU TABLO (TREEVIEW) ---
        self.frm_step3 = self.create_step_frame(self.card_frame, "3. Yüklenecek Versiyonu Seçiniz")
        
        # Tabloyu tutacak beyaz bir çerçeve
        self.tree_frame = tk.Frame(self.frm_step3, bg="white")
        self.tree_frame.pack(pady=10, padx=10, fill=tk.X)
        
        # Treeview (Tablo) Tanımlaması
        self.tree_versiyon = ttk.Treeview(self.tree_frame, columns=("Dosya", "Donem", "Satir"), show="headings", height=4, selectmode="browse")
        
        # Sütun Başlıkları
        self.tree_versiyon.heading("Dosya", text="Versiyon / Dosya Adı")
        self.tree_versiyon.heading("Donem", text="İçerik")
        self.tree_versiyon.heading("Satir", text="Kayıt Sayısı")
        
        # Sütun Genişlikleri ve Hizalamalar
        self.tree_versiyon.column("Dosya", width=220, anchor="w")
        self.tree_versiyon.column("Donem", width=100, anchor="center")
        self.tree_versiyon.column("Satir", width=100, anchor="e")
        
        # Kaydırma Çubuğu (Ne olur ne olmaz, 4'ten fazla versiyon olursa diye)
        self.scrollbar = ttk.Scrollbar(self.tree_frame, orient=tk.VERTICAL, command=self.tree_versiyon.yview)
        self.tree_versiyon.configure(yscrollcommand=self.scrollbar.set)
        
        self.tree_versiyon.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Tablodan seçim yapıldığında tetiklenecek olay
        self.tree_versiyon.bind('<<TreeviewSelect>>', self.on_versiyon_select)

        # --- BİLGİ VE YÜKLE BUTONU ---
        self.lbl_bilgi = tk.Label(self.card_frame, text="", bg=CLR_CARD_BG, fg="white", font=("Consolas", 10))
        self.lbl_bilgi.pack(pady=(20, 5))

        self.btn_yukle = tk.Button(self.card_frame, text="⚡ SEÇİLİ VERSİYONU YÜKLE", 
                                   command=self.yukle_click, 
                                   bg="white", fg=CLR_CARD_BG, font=("Segoe UI", 12, "bold"), 
                                   pady=10, padx=30, bd=0, cursor="hand2")
        
        self.frm_step1.pack(fill=tk.X, pady=10)
        self.frm_step2.pack_forget()
        self.frm_step3.pack_forget()

    def create_step_frame(self, parent, title):
        frame = tk.Frame(parent, bg=CLR_STEP_BG, bd=2, relief="flat")
        lbl = tk.Label(frame, text=title, bg=CLR_STEP_BG, fg="white", font=("Segoe UI", 12, "bold"), anchor="center")
        lbl.pack(fill=tk.X, pady=(5, 0))
        return frame

    def verileri_doldur(self):
        mukellefler = arsivdeki_mukellefleri_getir()
        self.cmb_mukellef['values'] = mukellefler
        if not mukellefler:
            self.lbl_bilgi.config(text="Arşiv klasörü boş!")

    def on_mukellef_select(self, event):
        self.secili_mukellef = self.cmb_mukellef.get()
        self.frm_step2.pack_forget()
        self.frm_step3.pack_forget()
        self.btn_yukle.pack_forget()
        self.cmb_yil.set('')
        
        yillar = mukellef_yillarini_getir(self.secili_mukellef)
        self.cmb_yil['values'] = yillar
        if yillar:
            self.frm_step2.pack(fill=tk.X, pady=10)
            self.lbl_bilgi.config(text="Lütfen yüklemek istediğiniz yılı seçiniz...")
        else:
            self.lbl_bilgi.config(text="Bu mükellefe ait yıl bulunamadı.")

    def on_yil_select(self, event):
        self.secili_yil = self.cmb_yil.get()
        self.frm_step3.pack_forget()
        self.btn_yukle.pack_forget()
        self.secili_dosya_yolu = None
        
        # Tablonun içini eski verilerden temizle
        for item in self.tree_versiyon.get_children():
            self.tree_versiyon.delete(item)
            
        tum_dosyalar = yil_dosyalarini_getir(self.secili_mukellef, self.secili_yil)
        self.yillik_dosyalar = [d for d in tum_dosyalar if "YILLIK" in d['tip'] or "FULL" in d['ad']]
        
        if self.yillik_dosyalar:
            self.frm_step3.pack(fill=tk.X, pady=10)
            self.lbl_bilgi.config(text=" Dosya içerikleri analiz ediliyor...", fg="#f1c40f")
            self.update_idletasks() 
            
            # --- 1. ARAYÜZ OKUMASI İÇİN BYPASS'I GEÇİCİ OLARAK DURDUR ---
            import os
            os.environ['EDENETIM_ARAYUZ_TABLO_OKUMA'] = "1"
            
            for d in self.yillik_dosyalar:
                try:
                    temp_df = pd.read_parquet(d['yol'], columns=['KayitTarihi']).dropna()
                    
                    if not pd.api.types.is_datetime64_any_dtype(temp_df['KayitTarihi']):
                        temp_df['KayitTarihi'] = pd.to_datetime(temp_df['KayitTarihi'], errors='coerce')
                        temp_df = temp_df.dropna(subset=['KayitTarihi'])

                    gecerli_tarihler = temp_df[temp_df['KayitTarihi'].dt.year == int(self.secili_yil)]
                    aylik_dagilim = gecerli_tarihler['KayitTarihi'].dt.month.value_counts()
                    
                    print(f"[BILGI] [{d['ad']}] Ay Dagilimi: {aylik_dagilim.to_dict()}")
                    
                    gercek_aylar = aylik_dagilim[aylik_dagilim > 5].index.tolist()
                    aylar_listesi = sorted(gercek_aylar)
                    ay_sayisi = len(aylar_listesi)
                    satir_sayisi = len(temp_df)
                    
                    if ay_sayisi > 0:
                        aylar_str = ",".join(map(str, aylar_listesi))
                        if len(aylar_str) > 15:
                            aylar_str = aylar_str[:12] + "..."
                        donem_str = f"{ay_sayisi} Ay ({aylar_str})"
                    else:
                        donem_str = "0 Ay"
                        
                except ValueError:
                    print(f"[UYARI] [{d['ad']}] Dosyasinda 'KayitTarihi' sutunu bulunamadi!")
                    try:
                        tam_df = pd.read_parquet(d['yol'])
                        satir_sayisi = len(tam_df)
                        donem_str = "Tarih Sutunu Yok"
                    except:
                        donem_str = "Hata"
                        satir_sayisi = 0
                        
                except Exception as e:
                    print(f"[HATA] [{d['ad']}] Istatistik okuma hatasi: {e}")
                    donem_str = "Format Hatasi"
                    satir_sayisi = 0
                
                self.tree_versiyon.insert("", tk.END, iid=d['yol'], values=(d['ad'], donem_str, f"{satir_sayisi:,}"))

            # --- 2. BYPASS KORUMASINI GERİ AÇ ---
            os.environ['EDENETIM_ARAYUZ_TABLO_OKUMA'] = "0"

            self.lbl_bilgi.config(text="Lütfen listeden yüklemek istediğiniz versiyonu seçiniz.", fg="white")
            
            cocuklar = self.tree_versiyon.get_children()
            if len(cocuklar) == 1:
                self.tree_versiyon.selection_set(cocuklar[0])
                self.on_versiyon_select(None)
                
        else:
             self.lbl_bilgi.config(text=f"{self.secili_yil} yılına ait veri dosyası bulunamadı.")

    def on_versiyon_select(self, event):
        secili_itemler = self.tree_versiyon.selection()
        if not secili_itemler: 
            return
            
        # Tabloya satır eklerken 'iid' parametresine dosya yolunu atamıştık, direkt çekiyoruz
        self.secili_dosya_yolu = secili_itemler[0] 
        
        # Seçilen satırın sadece 1. sütununu (Dosya adını) bilgi mesajı için alıyoruz
        dosya_adi = self.tree_versiyon.item(self.secili_dosya_yolu, 'values')[0]
        
        self.lbl_bilgi.config(text=f"Yüklenmeye hazır: {dosya_adi}", fg="white")
        self.btn_yukle.pack(pady=20, fill=tk.X)




    def yukle_click(self):
        if not self.secili_dosya_yolu:
            messagebox.showwarning("Uyarı", "Lütfen yüklenecek versiyonu seçiniz!")
            return
            
        self.btn_yukle.config(text=" VERİLER YÜKLENİYOR...", state=tk.DISABLED, bg="#f39c12")
        self.update_idletasks()
        
                
        hedef_yol = str(self.secili_dosya_yolu)
        os.environ['EDENETIM_AKTIF_DOSYA'] = hedef_yol
        print(f"\n ARAYÜZ SEÇİMİ: Kullanıcı {os.path.basename(hedef_yol)} dosyasını seçti.")
        
        if not hasattr(pd, '_orijinal_read_parquet'):
            pd._orijinal_read_parquet = pd.read_parquet
            
        def _korsan_read_parquet(path, *args, **kwargs):
            # --- YENİ EKLENEN ŞART ---
            # Eğer arayüz kendi tablosunu çizmek için dosyayı istiyorsa, araya girme, gerçek dosyayı ver!
            if os.environ.get('EDENETIM_ARAYUZ_TABLO_OKUMA') == "1":
                return pd._orijinal_read_parquet(path, *args, **kwargs)

            aktif_arsiv = os.environ.get('EDENETIM_AKTIF_DOSYA')
            if isinstance(path, str) and path.endswith(".parquet") and aktif_arsiv:
                if os.path.exists(aktif_arsiv):
                    istenen = os.path.basename(path)
                    aktif = os.path.basename(aktif_arsiv)
                    # Sadece Dashboard ve Modüller istediğinde sahte dosyayı ver
                    if "FULL" in istenen and istenen != aktif:
                        print(f" YÖNLENDİRME: Motor {istenen} dosyasını istedi, ancak ona {aktif} verildi!")
                        return pd._orijinal_read_parquet(aktif_arsiv, *args, **kwargs)
            return pd._orijinal_read_parquet(path, *args, **kwargs)
            
        pd.read_parquet = _korsan_read_parquet

        df, msg = parquet_yukle(self.secili_dosya_yolu)
            
        if df is not None:
            try:
                parts = self.secili_mukellef.rsplit('-', 1)
                vkn = parts[1] if len(parts) > 1 and parts[1].isdigit() else "0000000000"
                unvan = parts[0] if len(parts) > 1 else self.secili_mukellef
                yil = str(self.secili_yil)

                main_app = self.winfo_toplevel()
                main_app.df = df  
                main_app.aktif_dosya_yolu = hedef_yol 

                try:
                    from modules.mizan_analiz.engine import MizanEngine
                    from modules.mali_tablolar.engine import FinancialReportEngine
                    
                    print(f" Motorlar çalıştırılıyor...")
                    mizan_motoru = MizanEngine()
                    mizan_motoru.save_to_sqlite()
                    
                    mali_motor = FinancialReportEngine(parent=None)
                    mali_motor.calculate_matrix("Bilanco", "Yillik", force_update=True)
                    mali_motor.calculate_matrix("Gelir Tablosu", "Yillik", force_update=True)
                    
                except Exception as ex:
                    print(f"[HATA] Hesaplama Motoru Hatasi: {ex}")

                if hasattr(main_app, 'update_header_info'):
                    main_app.update_header_info(unvan, vkn, yil)
                
                self.btn_yukle.config(text=" VERİ YÜKLENDİ", bg="#27ae60", fg="white")
                
                def finish_sequence():
                    # 1. Önce Dashboard verilerini tazelemesi için refresh_app çağırıyoruz
                    if hasattr(main_app, 'refresh_app'):
                        main_app.refresh_app()
                    elif hasattr(main_app, 'show_dashboard'):
                        main_app.show_dashboard()
                    
                    # 2. Ardından bu "Arşivden Yükle" sekmesini otomatik kapatıyoruz
                    if hasattr(main_app, 'notebook'):
                        try:
                            # Mevcut sekmenin (self) notebook üzerindeki sırasını buluyoruz
                            my_index = main_app.notebook.index(self)
                            # Mainapp içindeki kapatma fonksiyonunu tetikliyoruz
                            main_app.close_tab_by_index(my_index)
                        except Exception as e:
                            print(f"Sekme kapatma hatasi: {e}")

                # İşlemlerin görsel olarak bittiği anlaşılsın diye 1 saniye sonra çalıştır
                self.after(1000, finish_sequence)

            except Exception as e:
                print(f"[HATA] UI Guncelleme Hatasi: {e}")
                self.btn_yukle.config(text="HATA OLUŞTU", bg="#e74c3c", fg="white")
        else:
            messagebox.showerror("Hata", f"Dosya okunamadi: {msg}")
            self.btn_yukle.config(text=" SEÇİLİ VERSİYONU YÜKLE", state=tk.NORMAL, bg="white")




            