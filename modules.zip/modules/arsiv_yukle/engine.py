import os
import pandas as pd
from config import get_mukellefler_dir

def arsivdeki_mukellefleri_getir():
    """MUKELLEFLER klasöründeki alt klasörleri (Mükellefleri) listeler"""
    kok = get_mukellefler_dir()
    try:
        # Sadece klasörleri listele ve sırala
        return sorted([f for f in os.listdir(kok) if os.path.isdir(os.path.join(kok, f))])
    except:
        return []

def mukellef_yillarini_getir(mukellef_klasoru):
    """Seçilen mükellefin yıllarını listeler"""
    yol = os.path.join(get_mukellefler_dir(), mukellef_klasoru)
    try:
        # Sadece sayısal isimli klasörleri (yılları) al
        return sorted([f for f in os.listdir(yol) if f.isdigit() and os.path.isdir(os.path.join(yol, f))], reverse=True)
    except:
        return []

def yil_dosyalarini_getir(mukellef_klasoru, yil):
    """Seçilen yıl içindeki VE alt klasörlerindeki (Aylar) Parquet dosyalarını listeler"""
    yol = os.path.join(get_mukellefler_dir(), mukellef_klasoru, yil)
    dosyalar = []
    
    if not os.path.exists(yol):
        return []

    try:
        # 1. Ana dizindeki dosyalar (Genelde _FULL.parquet olanlar)
        for f in os.listdir(yol):
            tam_yol = os.path.join(yol, f)
            if os.path.isfile(tam_yol) and f.endswith(".parquet"):
                dosyalar.append({
                    "tip": "YILLIK (TÜM)", 
                    "ad": f, 
                    "yol": tam_yol
                })
        
        # 2. Alt Klasörlerdeki (Aylık) Dosyalar
        for klasor_adi in sorted(os.listdir(yol)):
            klasor_yolu = os.path.join(yol, klasor_adi)
            
            # Eğer bu bir klasörse (Örn: "01", "02" veya "OCAK") içine gir
            if os.path.isdir(klasor_yolu) and klasor_adi != "FATURALAR": 
                for f in os.listdir(klasor_yolu):
                    if f.endswith(".parquet"):
                        dosyalar.append({
                            "tip": f"AYLIK ({klasor_adi})", 
                            "ad": f, 
                            "yol": os.path.join(klasor_yolu, f)
                        })
        
        return dosyalar
    except Exception as e:
        print(f"Dosya listeleme hatası: {e}")
        return []

def parquet_yukle(dosya_yolu):
    """Tek bir Parquet dosyasını okur ve DataFrame döndürür"""
    try:
        df = pd.read_parquet(dosya_yolu)
        return df, "OK"
    except Exception as e:
        return None, str(e)

def coklu_parquet_yukle(dosya_yollari):
    """Birden fazla parquet dosyasını okur ve birleştirerek tek bir DataFrame döndürür"""
    try:
        df_listesi = []
        for yol in dosya_yollari:
            gecici_df = pd.read_parquet(yol)
            df_listesi.append(gecici_df)
        
        if not df_listesi:
            return None, "Seçili dosya yok."
            
        # Tüm ay dataframe'lerini alt alta birleştir
        birlesik_df = pd.concat(df_listesi, ignore_index=True)
        return birlesik_df, "OK"
    except Exception as e:
        return None, f"Veri Birleştirme Hatası: {str(e)}"