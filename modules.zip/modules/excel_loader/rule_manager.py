import os
import json
import pandas as pd

# --- HAYAT KURTARAN KISIM ---
# Program ana dizinden de çalışsa, bu kod JSON dosyasını her zaman kendi bulunduğu
# excel_loader klasörünün içinde arar. "Dosya bulunamadı" hatasını kökünden çözer.
MEVCUT_KLASOR = os.path.dirname(os.path.abspath(__file__))
JSON_DOSYA_YOLU = os.path.join(MEVCUT_KLASOR, "fingerprints.json")
# ----------------------------

class FormatRuleManager:
    def __init__(self):
        self.rules = self.load_rules()

    def load_rules(self):
        """Parmak izi kurallarını JSON dosyasından yükler."""
        if not os.path.exists(JSON_DOSYA_YOLU):
            print(f"UYARI: Kural dosyası bulunamadı -> {JSON_DOSYA_YOLU}")
            return {}
        try:
            with open(JSON_DOSYA_YOLU, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"JSON Okuma Hatası: {e}")
            return {}

    def _check_condition(self, kaynak_metin, aranan_metin, kosul):
        """Metinleri karşılaştırır. Harf büyüklüğüne duyarsız (case-insensitive) arama yapar."""
        if pd.isna(kaynak_metin):
            kaynak_metin = ""
            
        # Karşılaştırma kolaylığı için ikisini de küçültelim
        k = str(kaynak_metin).lower().strip()
        a = str(aranan_metin).lower().strip()
        
        if kosul == "İÇERİR":
            return a in k
        elif kosul == "TAM EŞLEŞİR":
            return a == k
        elif kosul == "İÇERMEZ":
            return a not in k and a != ""
        return False

    def evaluate(self, df_head, sheet_names):
        """
        Gelen Excel'in ilk 25 satırını ve sayfa isimlerini tarayarak
        fingerprints.json içindeki kurallara göre puanlama yapar.
        En yüksek puanı alan formatı döndürür.
        """
        if not self.rules:
            return "STANDART", "Kural dosyası (fingerprints.json) bulunamadı veya boş olduğu için STANDART format atandı."

        scores = {}
        rapor = []

        # Tüm formatları ve kurallarını dön
        for format_adi, format_data in self.rules.items():
            fingerprints = format_data.get("fingerprints", [])
            if not fingerprints:
                continue

            format_score = 0
            for kural in fingerprints:
                hedef = kural.get("target")
                kosul = kural.get("operator")
                aranan = str(kural.get("value", "")).strip()
                puan = int(kural.get("score", 50))
                row_idx = kural.get("row")
                col_idx = kural.get("col")

                if not aranan: 
                    continue

                match_found = False

                try:
                    # 1. Sayfa Adı Kontrolü
                    if hedef == "Sayfa Adı":
                        for sheet in sheet_names:
                            if self._check_condition(sheet, aranan, kosul):
                                match_found = True
                                break

                    # 2. Kaçıncı Satır Kontrolü (O satırdaki tüm değerleri birleştirip içinde arar)
                    elif hedef == "Kaçıncı Satır" and row_idx is not None:
                        if row_idx < len(df_head):
                            satir_verisi = " ".join([str(x) for x in df_head.iloc[row_idx].values if pd.notna(x)])
                            if self._check_condition(satir_verisi, aranan, kosul):
                                match_found = True

                    # 3. Kaçıncı Sütun Kontrolü (O sütundaki tüm değerleri birleştirip içinde arar)
                    elif hedef == "Kaçıncı Sütun" and col_idx is not None:
                        if col_idx < len(df_head.columns):
                            sutun_verisi = " ".join([str(x) for x in df_head.iloc[:, col_idx].values if pd.notna(x)])
                            if self._check_condition(sutun_verisi, aranan, kosul):
                                match_found = True

                    # 4. Nokta Atışı Hücre Kontrolü (Kaçıncı Hücre / Birleştirilmiş Hücre)
                    elif hedef in ["Kaçıncı Hücre", "Birleştirilmiş Hücre"] and row_idx is not None and col_idx is not None:
                        if row_idx < len(df_head) and col_idx < len(df_head.columns):
                            hucre_verisi = str(df_head.iloc[row_idx, col_idx])
                            if self._check_condition(hucre_verisi, aranan, kosul):
                                match_found = True
                                
                    # 5. Genel İçerik (Defterdeki Son Satır vs. için gelen bloğu string olarak tarama)
                    elif hedef == "Defterdeki Son Satır":
                        text_blob = df_head.to_string()
                        if self._check_condition(text_blob, aranan, kosul):
                            match_found = True

                    # Kural Başarılıysa Puanı Ekle
                    if match_found:
                        format_score += puan
                        rapor.append(f"[+] {format_adi}: {hedef} -> '{aranan}' kuralı eşleşti. (+{puan} Puan)")

                except Exception as e:
                    rapor.append(f"[-] {format_adi} kuralı test edilirken hata oluştu: {str(e)}")

            # Eğer formata ait kurallardan puan toplandıysa listeye ekle
            if format_score > 0:
                scores[format_adi] = format_score

        # Puanlama Bitti, Kazananı Belirle
        if scores:
            en_iyi_format = max(scores, key=scores.get)
            rapor.insert(0, f"✅ DEDEKTİF SONUCU: En yüksek puanı {scores[en_iyi_format]} puan ile '{en_iyi_format}' formatı aldı.\n" + "-"*40)
            return en_iyi_format, "\n".join(rapor)

        # Hiçbir kural tutmadıysa
        return "STANDART", "Hiçbir format kuralı eşleşmedi. Dosya STANDART format olarak varsayıldı.\n" + "\n".join(rapor)