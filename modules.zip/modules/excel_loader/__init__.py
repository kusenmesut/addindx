# Bu dosya, klasörün bir paket olarak algılanmasını sağlar.
from .engine import excel_dosya_islee