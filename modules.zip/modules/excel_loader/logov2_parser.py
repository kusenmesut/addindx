import pandas as pd
import re
import warnings

# Gereksiz uyarıları kapat
warnings.filterwarnings("ignore")

def clean_amount(val):
    """Sayısal değerleri her türlü formattan (boşluklu, virgüllü, noktalı, parantezli) temizler."""
    if pd.isna(val) or str(val).strip() == "": return 0.0
    try:
        if isinstance(val, (int, float)): return float(val)
        val_str = str(val).strip().replace(" ", "")
        
        # Bilimsel gösterim kontrolü
        if "E" in val_str.upper() and "EUR" not in val_str.upper():
            try: return float(val_str)
            except: pass

        # Negatif parantez (1500) -> -1500
        if val_str.startswith("(") and val_str.endswith(")"):
            val_str = "-" + val_str[1:-1]
        
        # Sadece rakam, eksi, virgül ve noktayı bırak
        clean = re.sub(r"[^\d,\.-]", "", val_str)
        if not clean or clean in ["-", ".", ","]: return 0.0
        
        if clean.endswith("-"): clean = "-" + clean[:-1]
        
        # Nokta ve virgül ayrıştırması
        last_dot = clean.rfind(".")
        last_comma = clean.rfind(",")
        
        if last_comma != -1 and last_dot != -1:
            if last_comma > last_dot:
                clean = clean.replace(".", "").replace(",", ".")
            else:
                clean = clean.replace(",", "")
        elif last_comma != -1:
            if clean.count(",") == 1:
                parts = clean.split(",")
                if len(parts[1]) == 3 and len(parts[0]) <= 3:
                    clean = clean.replace(",", "")
                else:
                    clean = clean.replace(",", ".")
            else:
                clean = clean.replace(",", "")
        elif last_dot != -1:
            if clean.count(".") > 1:
                clean = clean.replace(".", "")
            else:
                parts = clean.split(".")
                if len(parts[1]) == 3:
                    clean = clean.replace(".", "")
                    
        return float(clean)
    except Exception as e:
        return 0.0

def clean_text(val):
    if pd.isna(val): return ""
    val = str(val).strip()
    if val.lower() == "nan": return ""
    return val

def extract_date(text):
    text = str(text).strip()
    match = re.search(r'(\d{2}[./-]\d{2}[./-]\d{4}|\d{4}[./-]\d{2}[./-]\d{2})', text)
    if match: return match.group(1)
    if len(text) >= 10 and re.match(r'\d{4}-\d{2}-\d{2}', text): return text[:10]
    return ""

def parse_yevmiye_excel(file_path):
    try:
        df = pd.read_excel(file_path, dtype=str, header=None)
        df = df.reindex(columns=range(11))
        
        all_data = []
        
        curr_tarih = ""
        curr_yevmiye_no = ""
        curr_hesap_kodu = ""
        curr_hesap_adi = ""
        curr_hesap_yonu = "" # YENİ: Ana hesabın yönü (BORC veya ALACAK)
        
        for idx, row in df.iterrows():
            col_a_raw = clean_text(row.iloc[0])
            col_b = clean_text(row.iloc[1])
            col_c = clean_text(row.iloc[2])
            col_d_raw = clean_text(row.iloc[3])
            col_e_raw = clean_text(row.iloc[4])
            col_h = clean_text(row.iloc[7])
            
            # 1.0 vb. pandas okuma kaymalarını düzelt
            col_a_num = re.sub(r'\.0$', '', col_a_raw)
            
            if "No." in col_a_raw or "Yevmiye" in col_a_raw: continue
            if not col_a_raw and not col_b: continue

            # --- a & b: Tarih ve Yevmiye No ---
            tarih_bulundu = extract_date(col_b)
            if tarih_bulundu and col_a_num.isdigit():
                curr_tarih = tarih_bulundu
                curr_yevmiye_no = col_a_num
                continue
                
            # --- c & d: ANA HESAP TESPİTİ VE YÖN BULMA (YENİ MANTIK) ---
            if len(col_a_num) == 3 and col_a_num.isdigit() and not extract_date(col_b):
                curr_hesap_kodu = col_a_num
                curr_hesap_adi = col_b
                
                # Yönü (Borç mu Alacak mı?) Ana Hesap satırının D ve E'sinden anla
                d_kontrol_ana = abs(clean_amount(col_d_raw))
                e_kontrol_ana = abs(clean_amount(col_e_raw))
                
                if d_kontrol_ana > 0 or col_d_raw.upper() in ["B", "1", "BORÇ", "BORC"]:
                    curr_hesap_yonu = "BORC"
                elif e_kontrol_ana > 0 or col_e_raw.upper() in ["A", "1", "ALACAK"]:
                    curr_hesap_yonu = "ALACAK"
                else:
                    curr_hesap_yonu = "" # Eğer ana hesapta yön belirteci yoksa boş bırak
                    
                continue
                
            # --- e'den k'ya: MUAVİN İŞLEMLERİ ---
            if len(col_a_num) > 3 and curr_hesap_kodu and col_a_num.startswith(curr_hesap_kodu):
                muavin_kodu = col_a_num
                muavin_adi = ""
                belge_no = ""
                detay_aciklama = ""
                
                if "/" in col_b:
                    parts = col_b.split("/", 1)
                    muavin_adi = parts[0].strip()
                    sag_taraf = parts[1].strip()
                    
                    if "," in sag_taraf:
                        alt_parts = sag_taraf.split(",", 1)
                        belge_no = alt_parts[0].strip()
                        detay_aciklama = alt_parts[1].strip()
                    else:
                        belge_no = sag_taraf 
                else:
                    muavin_adi = col_b
                    
                # --- TUTAR OKUMA (MUAVİNİN C SÜTUNU + ANA HESABIN YÖNÜ) ---
                c_tutari = abs(clean_amount(col_c))
                borc = 0.0
                alacak = 0.0
                
                # 1. Öncelik: Ana hesapta bulduğumuz yön (Senin yeni kuralın)
                if curr_hesap_yonu == "BORC":
                    borc = c_tutari
                elif curr_hesap_yonu == "ALACAK":
                    alacak = c_tutari
                else:
                    # 2. Öncelik (Güvenlik Ağı): Ana hesapta yön yazmıyorsa, satırın kendi D/E'sine bak
                    d_kontrol = abs(clean_amount(col_d_raw))
                    e_kontrol = abs(clean_amount(col_e_raw))
                    if d_kontrol > 0 or col_d_raw.upper() in ["B", "1"]:
                        borc = c_tutari if c_tutari > 0 else d_kontrol
                    elif e_kontrol > 0 or col_e_raw.upper() in ["A", "1"]:
                        alacak = c_tutari if c_tutari > 0 else e_kontrol
                    else:
                        borc = c_tutari # Çaresiz kalırsak borca yaz (genelde tutar vardır yön yoktur)
                        
                fis_aciklamasi = col_h
                
                islem_satiri = {
                    "YevmiyeNo": curr_yevmiye_no,
                    "KayitTarihi": curr_tarih,
                    "BelgeNo": belge_no,
                    "FisAciklamasi": fis_aciklamasi,
                    "DetayAciklama": detay_aciklama,
                    "HesapKodu": curr_hesap_kodu,
                    "HesapAdi": curr_hesap_adi,
                    "MuavinKodu": muavin_kodu,
                    "MuavinAdi": muavin_adi,
                    "Borc": borc,
                    "Alacak": alacak
                }
                all_data.append(islem_satiri)

        meta = {"unvan": "Unvan Tanımlayınız.", "vkn": "VKN Tanımlayınız."}
        ek_bilgi = {"status": "OK"}
        msg = f"Başarılı! Toplam {len(all_data)} satır yakalandı."
        
        return all_data, meta, ek_bilgi, msg

    except Exception as e:
        import traceback
        hata_mesaji = f"Hata: {str(e)}\n{traceback.format_exc()}"
        return [], {}, {}, hata_mesaji