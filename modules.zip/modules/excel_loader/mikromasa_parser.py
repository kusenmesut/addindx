import pandas as pd
import re
import warnings
import csv

# Gereksiz uyarıları kapat
warnings.filterwarnings("ignore")

def clean_amount(val):
    """Sayısal değerleri her türlü formattan temizler."""
    if pd.isna(val) or str(val).strip() == "": return 0.0
    try:
        val_str = str(val).strip().replace(" ", "")
        if val_str.startswith("(") and val_str.endswith(")"):
            val_str = "-" + val_str[1:-1]
            
        clean = re.sub(r"[^\d,\.-]", "", val_str)
        if not clean or clean in ["-", ".", ","]: return 0.0
        
        last_dot = clean.rfind(".")
        last_comma = clean.rfind(",")
        
        if last_comma != -1 and last_dot != -1:
            if last_comma > last_dot:
                clean = clean.replace(".", "").replace(",", ".")
            else:
                clean = clean.replace(",", "")
        elif last_comma != -1:
            if clean.count(",") == 1:
                parts = clean.split(",")
                if len(parts[1]) == 3 and len(parts[0]) <= 3:
                    clean = clean.replace(",", "")
                else:
                    clean = clean.replace(",", ".")
            else:
                clean = clean.replace(",", "")
        elif last_dot != -1:
            if clean.count(".") > 1:
                clean = clean.replace(".", "")
            else:
                parts = clean.split(".")
                if len(parts[1]) == 3:
                    clean = clean.replace(".", "")
                    
        return float(clean)
    except Exception:
        return 0.0

def clean_text(val):
    """Metin verilerini temizler ve görünmez karakterleri yok eder."""
    if pd.isna(val): return ""
    val = str(val).replace('\ufeff', '').replace('\u200b', '').strip()
    if val.lower() in ["nan", "nat", "none"]: return ""
    return val

def read_file_robust(file_path):
    """Excel ve CSV dosyalarını kodlama sorunu olmadan okur."""
    try:
        xl = pd.ExcelFile(file_path)
        sheet_name = xl.sheet_names[0]
        df = pd.read_excel(xl, sheet_name=sheet_name, header=None, dtype=str)
        return df, "MIKROMASA", "", "OK"
    except:
        pass

    encodings = ['utf-8', 'cp1254', 'latin-1', 'iso-8859-9']
    separators = [None, ';', '\t', ',']

    for enc in encodings:
        for sep in separators:
            try:
                temp_df = pd.read_csv(
                    file_path, sep=sep, encoding=enc, engine='python',
                    header=None, dtype=str, quotechar='"', quoting=csv.QUOTE_MINIMAL
                )
                if len(temp_df.columns) > 3:
                    return temp_df, "MIKROMASA", "", "OK"
            except:
                continue

    return None, "", "", "Dosya formatı okunamadı."

def parse_mikromasa_excel(file_path):
    try:
        # 1. DOSYA OKUMA
        df, sheet_unvan, sheet_donem, msg = read_file_robust(file_path)
        if df is None: return [], {}, {}, msg

        # A'dan I'ye kadar (9 sütun) indekslemede hata almamak için df'yi sabitliyoruz
        df = df.reindex(columns=range(10)) 
        
        all_data = []
        
        # --- STATE (DURUM) DEĞİŞKENLERİ ---
        curr_yevmiye_no = ""
        curr_kayit_tarihi = ""
        
        curr_hesap_kodu = ""
        curr_hesap_adi = ""
        curr_hesap_yonu = ""
        
        curr_detay_aciklama = "" # Yönerge i: İlk bulduğumuz Detay Açıklama (D sütunu)

        # 2. SATIR ITERASYONU
        for idx, row in df.iterrows():
            col_a = clean_text(row[0]) # Yevmiye No / Boş
            col_b = clean_text(row[1]) # Hesap Kodu ve Adı / Tarih
            col_c = clean_text(row[2]) # Açıklama (FisAciklamasi)
            col_d = clean_text(row[3]) # Belge Türü (DetayAciklama)
            col_e = clean_text(row[4]) # Belge No
            
            col_g = row[6] if len(row) > 6 else "0" # Detay Sütunu (Tutar)
            col_h = row[7] if len(row) > 7 else "0" # Borç Sütunu (Ana Hesap İçin Yön)
            col_i = row[8] if len(row) > 8 else "0" # Alacak Sütunu (Ana Hesap İçin Yön)
            
            # --- a ve c yönergesi: Tarih satırını bulma ve fiş aralığını belirleme ---
            date_match = re.search(r'[-]+\s*(\d{2}[./-]\d{2}[./-]\d{4})\s*[-]+', col_b)
            if date_match:
                # b yönergesi: KayitTarihi satırının A sütununda bulunan sayısal değer YevmiyeNo dur
                yevmiye_no_clean = re.sub(r'\.0$', '', col_a)
                if yevmiye_no_clean:
                    curr_yevmiye_no = yevmiye_no_clean
                    
                curr_kayit_tarihi = date_match.group(1).replace('/', '.').replace('-', '.')
                
                # Yeni bir yevmiye fişine geçildi, eski fişe ait alt verileri sıfırla
                curr_hesap_kodu = ""
                curr_hesap_adi = ""
                curr_hesap_yonu = ""
                curr_detay_aciklama = ""
                continue
            
            # Tarih ve Yevmiye set edilmemişse (dosya başındaki boşluklar vb.) işlemi atla
            if not curr_yevmiye_no or not curr_kayit_tarihi or not col_b:
                continue
            
            # --- HESAP ve MUAVİN AYRIŞTIRMASI ---
            # B sütununu ilk boşluktan ikiye bölerek kod ve ad kısmını ayır
            parts = col_b.split(' ', 1)
            if len(parts) >= 1:
                code_cand = parts[0].strip()
                name_cand = parts[1].strip() if len(parts) > 1 else ""
                
                # Değerin kod olup olmadığını anlamak için içindeki noktaları silip rakam mı diye bakıyoruz
                if code_cand.replace('.', '').isdigit():
                    
                    # --- d ve e yönergesi: HesapKodu ve HesapAdi (Ana Hesap Yakalama) ---
                    # Kod tam 3 haneliyse bu bir Ana Hesaptır
                    if len(code_cand) == 3 and code_cand.isdigit():
                        curr_hesap_kodu = code_cand
                        curr_hesap_adi = name_cand
                        
                        # Ana hesabın yönünü H (Borç) ve I (Alacak) sütunlarına bakarak belirle
                        val_h = abs(clean_amount(col_h))
                        val_i = abs(clean_amount(col_i))
                        
                        if val_h > 0: curr_hesap_yonu = "BORC"
                        elif val_i > 0: curr_hesap_yonu = "ALACAK"
                        else: curr_hesap_yonu = "BORC"
                        
                    # --- f ve g yönergesi: MuavinKodu ve MuavinAdi (Muavin Hesap Yakalama) ---
                    # Kod 3 haneden büyükse bu bir Muavin Hesaptır
                    elif len(code_cand) > 3 and curr_hesap_kodu:
                        muavin_kodu = code_cand
                        muavin_adi = name_cand
                        
                        # h yönergesi: MuavinKodu satırındaki C sütunu FisAciklamasi
                        fis_aciklamasi = col_c
                        
                        # i yönergesi: İlk bulduğun FisAciklamasi satırındaki D sütunu DetayAciklama
                        # Görseldeki gibi boş "Tanımsız" verileri geçip ilk dolu D sütununu yakala
                        if curr_detay_aciklama == "" and col_d != "" and col_d.upper() != "TANIMSIZ":
                            curr_detay_aciklama = col_d
                            
                        detay_aciklama = col_d if (col_d and col_d.upper() != "TANIMSIZ") else curr_detay_aciklama
                        
                        # j yönergesi: MuavinKodu satırındaki E sütunu BelgeNo'dur
                        belge_no = col_e
                        
                        # --- k ve L yönergeleri: Tutarı G'den (Detay) alıp Ana Hesabın yönüne atama ---
                        mua_tutar = abs(clean_amount(col_g))
                        
                        if curr_hesap_yonu == "BORC":
                            borc = mua_tutar
                            alacak = 0.0
                        else:
                            borc = 0.0
                            alacak = mua_tutar
                            
                        kayit = {
                            "YevmiyeNo": curr_yevmiye_no,
                            "KayitTarihi": curr_kayit_tarihi,
                            "BelgeNo": belge_no,
                            "FisAciklamasi": fis_aciklamasi,
                            "DetayAciklama": detay_aciklama,
                            "HesapKodu": curr_hesap_kodu,
                            "HesapAdi": curr_hesap_adi,
                            "MuavinKodu": muavin_kodu,
                            "MuavinAdi": muavin_adi,
                            "Borc": borc,
                            "Alacak": alacak
                        }
                        all_data.append(kayit)

        meta = {"unvan": sheet_unvan if sheet_unvan else "Mikromasa Formatı", "vkn": "-"}
        ek_bilgi = {"status": "OK"}
        msg = f"Başarılı! Toplam {len(all_data)} muavin satırı yakalandı."
        
        return all_data, meta, ek_bilgi, msg

    except Exception as e:
        import traceback
        return [], {}, {}, f"Hata: {str(e)}\n{traceback.format_exc()}"