import pandas as pd
import re
import warnings

warnings.filterwarnings("ignore")

class ErgnParser:
    def __init__(self, file_path):
        self.file_path = file_path
        self.parsed_items = []
        self.meta_unvan = "Bilinmiyor"

    def clean_amount(self, val):
        """Parasal değerleri temizler. (Örn: 1.051.298,28 -> 1051298.28)"""
        if pd.isna(val) or str(val).strip() == "": return 0.0
        val_str = str(val).strip().replace(" ", "").replace("\xa0", "")
        
        sign = 1.0
        if val_str.startswith('(') and val_str.endswith(')'):
            sign = -1.0
            val_str = val_str.replace('(', '').replace(')', '')
        
        val_str = re.sub(r"[^0-9,.-]", "", val_str)
        
        try:
            if "," in val_str and "." in val_str:
                if val_str.rfind(",") > val_str.rfind("."): 
                    val_str = val_str.replace(".", "").replace(",", ".")
                else: 
                    val_str = val_str.replace(",", "")
            elif "," in val_str:
                val_str = val_str.replace(",", ".")
            
            if not val_str: return 0.0
            return float(val_str) * sign
        except:
            return 0.0

    def clean_text(self, val):
        if pd.isna(val): return ""
        return str(val).replace("\xa0", " ").strip()

    def parse_date(self, text):
        if not text: return None
        match = re.search(r'(\d{2})[./-](\d{2})[./-](\d{4})|(\d{4})[./-](\d{2})[./-](\d{2})', str(text))
        if match:
            if match.group(1): 
                d, m, y = match.group(1), match.group(2), match.group(3)
                return f"{y}-{m}-{d}"
            elif match.group(4): 
                y, m, d = match.group(4), match.group(5), match.group(6)
                return f"{y}-{m}-{d}"
        return None

    def process(self):
        try:
            df = pd.read_excel(self.file_path, header=None, dtype=str)
            if len(df) > 0: self.meta_unvan = self.clean_text(df.iloc[0, 0])

            curr_yevmiye = 0
            curr_date = "1900-01-01"
            yevmiye_regex = re.compile(r"^[-'\s]*(\d+)[-'\s]*$")
            
            # --- Durum (State) Değişkenleri ---
            active_direction = None
            main_code = ""
            main_name = ""
            sub_code = ""
            sub_name = ""
            
            pending_item = None
            leaf_items = []

            # Mükerrerliği önleyen ve bloğu kapatan fonksiyon
            def flush_block():
                if leaf_items:
                    self.parsed_items.extend(leaf_items)
                elif pending_item and (pending_item["Borc"] + pending_item["Alacak"] > 0):
                    self.parsed_items.append(pending_item)
                
                leaf_items.clear()
                return None

            for idx, row in df.iterrows():
                def get_col(i): return self.clean_text(row[i]) if len(row) > i else ""
                def get_val(i): return self.clean_amount(row[i]) if len(row) > i else 0.0

                col_a = get_col(0)     # Hesap Kodu
                col_b = get_col(1)     # Açıklama
                col_c_val = get_val(2) # Detay Tutar (C Sütunu)
                col_d_val = get_val(3) # Borç (D Sütunu - Başlık Toplamı)
                col_e_val = get_val(4) # Alacak (E Sütunu - Başlık Toplamı)

                row_str = (col_a + col_b).upper().replace(" ", "")
                if any(x in row_str for x in ["TOPLAM", "YEKÜN", "NAKLİ", "DEVREDEN"]):
                    continue

                # --- 1. YEVMİYE NO VE TARİH TESPİTİ ---
                h_match = yevmiye_regex.search(col_a)
                if h_match and ("." in col_b or "/" in col_b or "---" in col_b or "MAHSUP" in col_b.upper()):
                    pending_item = flush_block() # Önceki fişi kapat
                    
                    curr_yevmiye = int(h_match.group(1))
                    f_date = self.parse_date(col_b)
                    if f_date: curr_date = f_date
                    
                    active_direction = None
                    main_code = ""
                    sub_code = ""
                    continue

                # --- 2. HESAP KODU (BAŞLIK) SATIRLARI ---
                if col_a:
                    clean_a = col_a.replace(".", "").strip()
                    pending_item = flush_block() # Yeni hesaba geçerken eskisini kapat

                    # 3 Haneli ise ANA HESAPTIR (Kebir)
                    if len(clean_a) == 3:
                        main_code = col_a
                        main_name = col_b
                        sub_code = col_a # Alt hesap gelmezse diye kendini muavin yap
                        sub_name = col_b
                        
                        # Yön Tayini
                        if col_d_val > 0: active_direction = "BORC"
                        elif col_e_val > 0: active_direction = "ALACAK"

                    # 3 Haneden uzunsa ALT HESAPTIR (Muavin)
                    elif len(clean_a) > 3:
                        sub_code = col_a
                        sub_name = col_b

                    # Detay satırı GELMEYEBİLİR (Örn: 500 Sermaye hesabı) ihtimaline karşı kendini "Aday" olarak hazırla
                    # C, D veya E sütununda veri varsa potansiyel tutar olarak alıyoruz
                    potansiyel_tutar = col_c_val if col_c_val > 0 else (col_d_val if col_d_val > 0 else col_e_val)
                    
                    if potansiyel_tutar > 0 and active_direction:
                        pending_item = {
                            "YevmiyeNo": curr_yevmiye,
                            "KayitTarihi": curr_date,
                            "HesapKodu": main_code if main_code else sub_code[:3],
                            "HesapAdi": main_name,
                            "MuavinKodu": sub_code,
                            "MuavinAdi": sub_name,
                            "FisAciklamasi": col_b,
                            "DetayAciklama": "",
                            "BelgeNo": "",
                            "Borc": potansiyel_tutar if active_direction == "BORC" else 0.0,
                            "Alacak": potansiyel_tutar if active_direction == "ALACAK" else 0.0,
                            "Kaynak": "Seher_Parser_V5_Final",
                            "VKN": "0000000000",
                            "Unvan": self.meta_unvan
                        }
                    continue

                # --- 3. DETAY (İŞLEM/LEAF) SATIRLARI ---
                # A sütunu BOŞ ve C sütununda (veya D/E kaymış) rakam varsa
                islem_tutari = col_c_val if col_c_val > 0 else (col_d_val if col_d_val > 0 else col_e_val)
                
                if not col_a and islem_tutari > 0 and active_direction:
                    # Belge No Çıkarımı: İlk kelime rakam/harf karışımıysa belge no kabul et
                    belge_no = ""
                    first_word = col_b.split()[0] if col_b else ""
                    if any(char.isdigit() for char in first_word):
                        belge_no = first_word
                    
                    item = {
                        "YevmiyeNo": curr_yevmiye,
                        "KayitTarihi": curr_date,
                        "HesapKodu": main_code if main_code else sub_code[:3],
                        "HesapAdi": main_name,
                        "MuavinKodu": sub_code,
                        "MuavinAdi": sub_name,
                        "FisAciklamasi": col_b,
                        "DetayAciklama": "",
                        "BelgeNo": belge_no,
                        "Borc": islem_tutari if active_direction == "BORC" else 0.0,
                        "Alacak": islem_tutari if active_direction == "ALACAK" else 0.0,
                        "Kaynak": "Seher_Parser_V5_Final",
                        "VKN": "0000000000",
                        "Unvan": self.meta_unvan
                    }
                    leaf_items.append(item)
                    continue
                
                # --- 4. EK AÇIKLAMA SATIRLARI (TUTARSIZ) ---
                if not col_a and islem_tutari == 0 and col_b:
                    if leaf_items:
                        leaf_items[-1]["DetayAciklama"] += " " + col_b
                    elif pending_item:
                        pending_item["DetayAciklama"] += " " + col_b

            # Excel sonu - Hafızada kalan son işlemi kaydet
            flush_block()

            if not self.parsed_items:
                return [], {"unvan": self.meta_unvan}, {}, "Format tanındı ancak veri çıkarılamadı (Parsing Kuralı Uymadı)."

            return self.parsed_items, {"unvan": self.meta_unvan, "vkn": "0000000000"}, {"tahmini_donem": curr_date[:4]}, "OK"

        except Exception as e:
            import traceback
            return [], {}, {}, f"Hata: {str(e)}\n{traceback.format_exc()}"

def parse_brg_excel(file_path):
    return ErgnParser(file_path).process()