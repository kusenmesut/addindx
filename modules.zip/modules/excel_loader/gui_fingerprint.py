import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
import sys
import pandas as pd

# --- AYARLAR ---
KLASOR = os.path.dirname(os.path.abspath(__file__))
JSON_YOLU = os.path.join(KLASOR, "fingerprints.json")

# --- TÜRKÇE KARAKTER DUYARLI BÜYÜTME ---
def tr_upper(text):
    if not text: return ""
    text = str(text)
    mapping = {'i': 'İ', 'ı': 'I', 'ğ': 'Ğ', 'ü': 'Ü', 'ş': 'Ş', 'ö': 'Ö', 'ç': 'Ç'}
    for k, v in mapping.items():
        text = text.replace(k, v)
    return text.upper()


# --- AYARLAR ---
KLASOR = os.path.dirname(os.path.abspath(__file__))
JSON_YOLU = os.path.join(KLASOR, "fingerprints.json")

# NOT: tr_upper fonksiyonu kaldırıldı. Artık ne yazarsan o kaydedilir.

class ParmakIziEditoru:
    def __init__(self, pencere):
        self.pencere = pencere
        self.pencere.title("Muhasebe Format & Parmak İzi Yöneticisi")
        self.pencere.geometry("1200x800")
        self.pencere.configure(bg="#f0f2f5")
        
        self.formatlar = {}
        self.secili_format = None

        self.stil_ayarla()
        
        # --- ANA PANEL ---
        self.ana_panel = tk.Frame(pencere, bg="#f0f2f5")
        self.ana_panel.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)

        # === SOL PANEL ===
        self.sol_frame = tk.Frame(self.ana_panel, bg="white", width=300, relief="solid", bd=1)
        self.sol_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 15))
        self.sol_frame.pack_propagate(False)

        tk.Label(self.sol_frame, text="FORMAT LİSTESİ", font=("Segoe UI", 12, "bold"), bg="#2c3e50", fg="white", pady=15).pack(fill=tk.X)
        
        self.liste_kutusu = tk.Listbox(self.sol_frame, font=("Segoe UI", 11), bd=0, highlightthickness=0, selectbackground="#3498db", selectforeground="white", activestyle="none")
        self.liste_kutusu.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.liste_kutusu.bind("<<ListboxSelect>>", self.format_secildi)

        tk.Label(self.sol_frame, text="* _parser.py dosyaları otomatik taranır.", bg="white", fg="#7f8c8d", font=("Segoe UI", 8)).pack(side=tk.BOTTOM, pady=10)

        # === SAĞ PANEL ===
        self.sag_frame = tk.Frame(self.ana_panel, bg="#f0f2f5")
        self.sag_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.header_frame = tk.Frame(self.sag_frame, bg="white", pady=15, padx=15, relief="flat")
        self.header_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(self.header_frame, text="Seçili Defter:", bg="white", font=("Segoe UI", 10, "bold"), fg="#7f8c8d").pack(side=tk.LEFT)
        self.lbl_secili = tk.Label(self.header_frame, text="-", bg="white", font=("Segoe UI", 12, "bold"), fg="#2c3e50")
        self.lbl_secili.pack(side=tk.LEFT, padx=10)

        # --- YENİ EKLENEN BUTON GRUBU (SAĞ ÜST) ---
        # Görünümü bozmamak için butonları bir çerçeveye alıyoruz
        btn_group = tk.Frame(self.header_frame, bg="white")
        btn_group.pack(side=tk.RIGHT, padx=10)

        # 1. YENİ BUTON: HAM VERİYİ GÖR
        tk.Button(btn_group, text="🔍 HAM VERİYİ GÖR", command=self.ham_veri_incele, bg="#17a2b8", fg="white", font=("Segoe UI", 10, "bold"), relief="flat", padx=15).pack(side=tk.LEFT, padx=5)

        # 2. MEVCUT BUTON: TEST ET
        tk.Button(btn_group, text="🧪 TAM PARSER TESTİ YAP", command=self.test_dosya_sec, bg="#8e44ad", fg="white", font=("Segoe UI", 10, "bold"), relief="flat", padx=15).pack(side=tk.LEFT, padx=5)

        tree_frame = tk.Frame(self.sag_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True)

        columns = ("hedef", "konum", "kosul", "deger", "puan")
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=15)
        
        self.tree.heading("hedef", text="Kontrol Tipi")
        self.tree.heading("konum", text="Konum")
        self.tree.heading("kosul", text="Koşul")
        self.tree.heading("deger", text="Aranan Değer")
        self.tree.heading("puan", text="Puan")
        
        self.tree.column("hedef", width=150); self.tree.column("konum", width=120)
        self.tree.column("kosul", width=100); self.tree.column("deger", width=250)
        self.tree.column("puan", width=60, anchor="center")
        
        self.tree.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)

        action_frame = tk.Frame(self.sag_frame, bg="#f0f2f5")
        action_frame.pack(fill=tk.X, pady=10)

        tk.Button(action_frame, text="+ YENİ KURAL", command=self.parmak_izi_ekle_dialog, bg="#2980b9", fg="white", font=("Segoe UI", 9, "bold"), relief="flat", padx=15, pady=10).pack(side=tk.LEFT)
        tk.Button(action_frame, text="✎ DÜZENLE", command=self.kural_duzenle_dialog, bg="#f39c12", fg="white", font=("Segoe UI", 9, "bold"), relief="flat", padx=15, pady=10).pack(side=tk.LEFT, padx=10)
        tk.Button(action_frame, text="- SİL", command=self.kural_sil, bg="#7f8c8d", fg="white", font=("Segoe UI", 9, "bold"), relief="flat", padx=15, pady=10).pack(side=tk.LEFT)
        tk.Button(action_frame, text="💾 KAYDET", command=self.kaydet, bg="#27ae60", fg="white", font=("Segoe UI", 9, "bold"), relief="flat", padx=30, pady=10).pack(side=tk.RIGHT)

        self.yukle()

    def stil_ayarla(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#ecf0f1", foreground="#2c3e50")
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=28)

    # --- YENİ EKLENEN FONKSİYON: HAM VERİ MÜFETTİŞİ ---
    def ham_veri_incele(self):
        """Dosyanın ilk 10 satırını Python'ın gözüyle gösterir."""
        dosya_yolu = filedialog.askopenfilename(title="İncelenecek Dosyayı Seç", filetypes=[("Excel", "*.xlsx;*.xls")])
        if not dosya_yolu: return
        
        try:
            # header=None İLE OKU (BAŞLIKSIZ)
            df = pd.read_excel(dosya_yolu, nrows=10, header=None)
            
            msg = "PYTHON BU DOSYAYI ŞÖYLE GÖRÜYOR:\n(Sol baştaki numara Satır Indexidir)\n\n"
            for index, row in df.iterrows():
                # Satırdaki boş olmayan verileri al
                dolu_veriler = [str(x) for x in row.values if str(x).lower() != 'nan']
                icerik = " | ".join(dolu_veriler)
                if not icerik: icerik = "(BOŞ SATIR)"
                msg += f"👉 SATIR {index}:  {icerik}\n"
            
            # Sonucu göster
            pencere = tk.Toplevel(self.pencere)
            pencere.title("Veri Müfettişi")
            pencere.geometry("800x600")
            txt = tk.Text(pencere, font=("Consolas", 10), padx=10, pady=10)
            txt.pack(fill=tk.BOTH, expand=True)
            txt.insert(tk.END, msg)
            
        except Exception as e:
            messagebox.showerror("Hata", str(e))

    def tutar_cevir(self, deger):
        if not deger: return 0.0
        if isinstance(deger, (int, float)): return float(deger)
        try:
            temiz = str(deger).replace('.', '').replace(',', '.')
            return float(temiz)
        except: return 0.0

    def sonuclari_goster(self, veri_listesi, dosya_adi, meta_bilgi):
        sonuc_penceresi = tk.Toplevel(self.pencere)
        sonuc_penceresi.title(f"Analiz Sonuçları - {dosya_adi}")
        sonuc_penceresi.geometry("1400x850")
        sonuc_penceresi.configure(bg="#f4f6f9")

        info_frame = tk.Frame(sonuc_penceresi, bg="white", pady=10, padx=10, relief="solid", bd=1)
        info_frame.pack(fill=tk.X, padx=10, pady=10)

        unvan = meta_bilgi.get('unvan', 'Bilinmiyor')
        vkn = meta_bilgi.get('vkn', 'Bilinmiyor')
        satir_sayisi = len(veri_listesi)

        tk.Label(info_frame, text=f"DOSYA: {dosya_adi}", font=("Segoe UI", 11, "bold"), bg="white", fg="#2c3e50").pack(side=tk.LEFT, padx=20)
        tk.Label(info_frame, text=f"VKN: {vkn}", font=("Segoe UI", 11, "bold"), bg="white", fg="#e67e22").pack(side=tk.LEFT, padx=20)
        tk.Label(info_frame, text=f"TOPLAM SATIR: {satir_sayisi}", font=("Segoe UI", 11, "bold"), bg="white", fg="#27ae60").pack(side=tk.LEFT, padx=20)

        table_frame = tk.Frame(sonuc_penceresi)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        columns = ("YevmiyeNo", "KayitTarihi", "BelgeNo", "FisAciklamasi", "DetayAciklama", 
                   "HesapKodu", "HesapAdi", "MuavinKodu", "MuavinAdi", "Borc", "Alacak", "KaynakDosya")
        
        tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        headers = {
            "YevmiyeNo": "Yevmiye No", "KayitTarihi": "Tarih", "BelgeNo": "Belge No",
            "FisAciklamasi": "Fiş Açıklama", "DetayAciklama": "Detay", "HesapKodu": "Hesap Kodu", 
            "HesapAdi": "Hesap Adı", "MuavinKodu": "Muavin Kodu", "MuavinAdi": "Muavin Adı",
            "Borc": "Borç", "Alacak": "Alacak", "KaynakDosya": "Dosya"
        }

        for col in columns:
            tree.heading(col, text=headers.get(col, col))
            if col in ["FisAciklamasi", "DetayAciklama", "HesapAdi", "MuavinAdi"]: tree.column(col, width=200)
            elif col in ["Borc", "Alacak"]: tree.column(col, width=100, anchor="e")
            else: tree.column(col, width=100, anchor="center")

        ysb = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(table_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        ysb.pack(side=tk.RIGHT, fill=tk.Y); xsb.pack(side=tk.BOTTOM, fill=tk.X)
        tree.pack(fill=tk.BOTH, expand=True)

        toplam_borc = 0.0; toplam_alacak = 0.0
        for row in veri_listesi:
            b = self.tutar_cevir(row.get("Borc", 0)); a = self.tutar_cevir(row.get("Alacak", 0))
            toplam_borc += b; toplam_alacak += a
            values = [row.get(col, "") for col in columns]
            tree.insert("", tk.END, values=values)

        fark = round(abs(toplam_borc - toplam_alacak), 2)
        is_denk = fark < 0.01
        bg_color = "#d4edda" if is_denk else "#f8d7da"
        fg_color = "#155724" if is_denk else "#721c24"
        durum_metni = "✅ MİZAN DENK" if is_denk else f"⚠️ FARKI VAR! ({fark:,.2f})"

        footer = tk.Frame(sonuc_penceresi, bg=bg_color, pady=15, padx=15, relief="groove", bd=2)
        footer.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(footer, text="BORÇ:", font=("Segoe UI", 12, "bold"), bg=bg_color).pack(side=tk.LEFT, padx=10)
        tk.Label(footer, text=f"{toplam_borc:,.2f}", font=("Consolas", 14, "bold"), bg=bg_color).pack(side=tk.LEFT)
        tk.Label(footer, text="|", font=("Segoe UI", 14), bg=bg_color, fg="#aaa").pack(side=tk.LEFT, padx=20)
        tk.Label(footer, text="ALACAK:", font=("Segoe UI", 12, "bold"), bg=bg_color).pack(side=tk.LEFT, padx=10)
        tk.Label(footer, text=f"{toplam_alacak:,.2f}", font=("Consolas", 14, "bold"), bg=bg_color).pack(side=tk.LEFT)
        tk.Label(footer, text=durum_metni, font=("Segoe UI", 12, "bold"), bg=bg_color, fg=fg_color).pack(side=tk.RIGHT, padx=20)

    # Sadece test_dosya_sec fonksiyonunu güncellemen yeterli, dosyanın geri kalanı aynı.
# Dosyanın en altındaki test_dosya_sec fonksiyonunu bununla değiştir:

    def test_dosya_sec(self):
        self.kaydet()
        try:
            sys.path.append(KLASOR)
            try: from engine import excel_dosya_islee
            except ImportError: from .engine import excel_dosya_islee
        except ImportError as e:
            messagebox.showerror("Hata", f"Engine Yüklenemedi: {e}")
            return

        dosya_yolu = filedialog.askopenfilename(title="Test Edilecek Dosya", filetypes=[("Excel/CSV", "*.xlsx;*.xls;*.csv")])
        if not dosya_yolu: return

        self.pencere.config(cursor="watch"); self.pencere.update()
        
        try:
            # Engine artık 4. parametre olarak detaylı mesaj dönüyor
            veri, meta, ek_bilgi, msg = excel_dosya_islee(dosya_yolu)
            self.pencere.config(cursor="")
            
            # Mesajı göster (Hata veya Başarı)
            if "STANDART" in msg or "Hata" in msg or "PARSER" in msg:
                # Detaylı rapor penceresi aç (Çünkü mesaj uzun olabilir)
                top = tk.Toplevel(self.pencere)
                top.title("Analiz Raporu")
                top.geometry("600x500")
                txt = tk.Text(top, font=("Consolas", 10), padx=10, pady=10)
                txt.pack(fill=tk.BOTH, expand=True)
                txt.insert(tk.END, msg)
            else:
                # Başarılı ise tabloyu aç
                if veri and len(veri) > 0: 
                    self.sonuclari_goster(veri, os.path.basename(dosya_yolu), meta)
                    messagebox.showinfo("Başarılı", f"İşlem Tamam!\n{msg}")
                else:
                    messagebox.showwarning("Veri Yok", f"Format tanındı ama veri çıkmadı.\n{msg}")

        except Exception as e:
            self.pencere.config(cursor="")
            import traceback
            messagebox.showerror("Hata", f"İşlem Hatası:\n{str(e)}\n\n{traceback.format_exc()}")

    def mevcut_parserlari_tara(self):
        if not os.path.exists(KLASOR): return
        for d in os.listdir(KLASOR):
            if d.endswith("_parser.py"):
                f = d.replace("_parser.py", "").upper()
                if f not in self.formatlar: self.formatlar[f] = {"fingerprints": []}

    def yukle(self):
        if os.path.exists(JSON_YOLU):
            try:
                with open(JSON_YOLU, 'r', encoding='utf-8') as f: self.formatlar = json.load(f)
            except: self.formatlar = {}
        self.mevcut_parserlari_tara(); self.liste_guncelle()

    def kaydet(self):
        try:
            with open(JSON_YOLU, 'w', encoding='utf-8') as f: json.dump(self.formatlar, f, indent=4, ensure_ascii=False)
        except Exception as e: messagebox.showerror("Hata", str(e))

    def liste_guncelle(self):
        self.liste_kutusu.delete(0, tk.END)
        for f in sorted(self.formatlar.keys()): self.liste_kutusu.insert(tk.END, f)

    def format_secildi(self, event=None):
        # Eğer farenin tıklamasıyla (event) geldiyse yeni seçimi al
        if event is not None:
            s = self.liste_kutusu.curselection()
            if not s: return
            self.secili_format = self.liste_kutusu.get(s[0])
            
        # Hafızada seçili bir format yoksa işlem yapma
        if not self.secili_format: return

        # Başlığı ve tabloyu güncelle
        self.lbl_secili.config(text=self.secili_format)
        self.tree.delete(*self.tree.get_children())
        
        # Seçili formata ait kuralları (fingerprints) ekrana bas
        for k in self.formatlar[self.secili_format].get("fingerprints", []):
            konum = f"Sat:{k.get('row','-')} / Süt:{k.get('col','-')}"
            self.tree.insert("", tk.END, values=(k['target'], konum, k['operator'], k['value'], k.get('score', 50)))

    def kural_sil(self):
        s = self.tree.selection()
        if s:
            try:
                # Tablodaki sırasını al
                idx = self.tree.index(s[0])
                # Arka plandaki listeden sil
                del self.formatlar[self.secili_format]["fingerprints"][idx]
                # Tabloyu zorla yenile
                self.format_secildi(None)
            except Exception as e:
                messagebox.showerror("Hata", f"Kural silinemedi: {e}")
            self.format_secildi(None)
    
    def open_rule_popup(self, mode="new", existing_data=None, index=None):
        p = tk.Toplevel(self.pencere)
        p.title("Kural Düzenle" if mode == "edit" else "Yeni Kural Ekle")
        p.geometry("500x650")
        p.configure(bg="white")
        p.grab_set()

        hedef_var = tk.StringVar(value="Kaçıncı Satır")
        kosul_var = tk.StringVar(value="İÇERİR")
        
        tk.Label(p, text="1. Nereyi Kontrol Edeceğiz?", font=("Segoe UI", 10, "bold"), bg="white", fg="#2980b9").pack(pady=(20, 5))
        hedef_combo = ttk.Combobox(p, textvariable=hedef_var, values=["Kaçıncı Satır", "Kaçıncı Sütun", "Kaçıncı Hücre", "Defterdeki Son Satır", "Birleştirilmiş Hücre", "Sayfa Adı", "Belirli Sütunda Ara"], state="readonly", width=40)
        hedef_combo.pack(pady=5)

        konum_frame = tk.Frame(p, bg="#f9f9f9", pady=10, borderwidth=1, relief="solid")
        konum_frame.pack(fill=tk.X, padx=30, pady=10)
        lbl_row = tk.Label(konum_frame, text="Satır No:", bg="#f9f9f9")
        ent_row = tk.Entry(konum_frame, width=10)
        lbl_col = tk.Label(konum_frame, text="Sütun No:", bg="#f9f9f9")
        ent_col = tk.Entry(konum_frame, width=10)

        def arayuz_guncelle(event=None):
            s = hedef_var.get()
            lbl_row.pack_forget()
            ent_row.pack_forget()
            lbl_col.pack_forget()
            ent_col.pack_forget()
            if s == "Kaçıncı Satır": 
                lbl_row.config(text="Satır No:")
                lbl_row.pack(side=tk.LEFT, padx=5)
                ent_row.pack(side=tk.LEFT)
            elif s in ["Kaçıncı Sütun", "Belirli Sütunda Ara"]: 
                lbl_col.config(text="Sütun No:")
                lbl_col.pack(side=tk.LEFT, padx=5)
                ent_col.pack(side=tk.LEFT)
            elif s in ["Kaçıncı Hücre", "Birleştirilmiş Hücre"]:
                lbl_row.config(text="Satır:")
                lbl_row.pack(side=tk.LEFT, padx=5)
                ent_row.pack(side=tk.LEFT)
                lbl_col.config(text="Sütun:")
                lbl_col.pack(side=tk.LEFT, padx=5)
                ent_col.pack(side=tk.LEFT)
                
        hedef_combo.bind("<<ComboboxSelected>>", arayuz_guncelle)

        tk.Label(p, text="2. Koşul Nedir?", font=("Segoe UI", 10, "bold"), bg="white", fg="#2980b9").pack(pady=5)
        ttk.Combobox(p, textvariable=kosul_var, values=["İÇERİR", "İÇERMEZ", "TAM EŞLEŞİR"], state="readonly", width=40).pack(pady=5)

        tk.Label(p, text="3. Aranan Değer / Metin:", font=("Segoe UI", 10, "bold"), bg="white", fg="#2980b9").pack(pady=5)
        ent_val = tk.Entry(p, width=40, font=("Segoe UI", 10))
        ent_val.pack(pady=5)

        tk.Label(p, text="4. Puan:", font=("Segoe UI", 10, "bold"), bg="white").pack(pady=(15, 5))
        ent_score = tk.Entry(p, width=10)
        ent_score.pack(pady=5)

        if mode == "edit" and existing_data:
            hedef_var.set(existing_data.get("target", ""))
            kosul_var.set(existing_data.get("operator", "İÇERİR"))
            ent_val.insert(0, existing_data.get("value", ""))
            ent_score.insert(0, str(existing_data.get("score", 50)))
            arayuz_guncelle()
            if existing_data.get("row") is not None: ent_row.insert(0, str(existing_data.get("row")))
            if existing_data.get("col") is not None: ent_col.insert(0, str(existing_data.get("col")))
        else:
            ent_score.insert(0, "50")
            arayuz_guncelle()

        def kaydet_kapat():
            try:
                kural = {
                    "target": hedef_var.get(),
                    "operator": kosul_var.get(),
                    "value": ent_val.get(),
                    "score": int(ent_score.get())
                }
                r = ent_row.get()
                c = ent_col.get()
                kural["row"] = int(r) if r.isdigit() else None
                kural["col"] = int(c) if c.isdigit() else None
                
                if mode == "new": 
                    self.formatlar[self.secili_format]["fingerprints"].append(kural)
                else: 
                    self.formatlar[self.secili_format]["fingerprints"][index] = kural
                self.format_secildi(None)
                p.destroy()
            except Exception as e: 
                messagebox.showerror("Hata", f"Girdi hatası: {e}")

        btn_text = "DÜZENLEMEYİ KAYDET" if mode == "edit" else "EKLE"
        bg_color = "#f39c12" if mode == "edit" else "#27ae60"
        tk.Button(p, text=btn_text, command=kaydet_kapat, bg=bg_color, fg="white", font=("Segoe UI", 11, "bold"), relief="flat", pady=10).pack(fill=tk.X, padx=30, pady=30)

    def parmak_izi_ekle_dialog(self):
        if not self.secili_format: 
            messagebox.showwarning("Uyarı", "Önce soldan bir format seçin.")
            return
        self.open_rule_popup(mode="new")

    def kural_duzenle_dialog(self):
        s = self.tree.selection()
        if not s: 
            messagebox.showwarning("Uyarı", "Seçim yapın.")
            return
        idx = self.tree.index(s[0])
        self.open_rule_popup(mode="edit", existing_data=self.formatlar[self.secili_format]["fingerprints"][idx], index=idx)


# --- SINIFIN (CLASS) DIŞINA ÇIKTIK ---

def sutunda_tam_eslesme_ara(df, sutun_indeksi, aranan_metin):
    """
    Belirtilen sütunda aranan metin ile 'tam eşleşen' bir hücre olup olmadığını kontrol eder.
    """
    try:
        if sutun_indeksi >= len(df.columns) or sutun_indeksi < 0:
            return False
            
        sutun_verileri = df.iloc[:, sutun_indeksi].astype(str).str.strip()
        hedef_metin = str(aranan_metin).strip()
        eslesme_var_mi = (sutun_verileri == hedef_metin).any()
        
        return bool(eslesme_var_mi)
        
    except Exception as e:
        print(f"Arama sırasında hata: {e}")
        return False

# --- DOSYANIN EN ALTI ---
if __name__ == "__main__":
    root = tk.Tk()
    app = ParmakIziEditoru(root)
    root.mainloop()