import pandas as pd
import re
import warnings

# Gereksiz uyarıları kapat
warnings.filterwarnings("ignore")

def clean_amount(val):
    """Sayısal değerleri her türlü formattan temizler."""
    if pd.isna(val) or str(val).strip() == "": return 0.0
    try:
        val_str = str(val).strip().replace(" ", "")
        if val_str.startswith("(") and val_str.endswith(")"):
            val_str = "-" + val_str[1:-1]
            
        clean = re.sub(r"[^\d,\.-]", "", val_str)
        if not clean or clean in ["-", ".", ","]: return 0.0
        
        last_dot = clean.rfind(".")
        last_comma = clean.rfind(",")
        
        if last_comma != -1 and last_dot != -1:
            if last_comma > last_dot:
                clean = clean.replace(".", "").replace(",", ".")
            else:
                clean = clean.replace(",", "")
        elif last_comma != -1:
            if clean.count(",") == 1:
                parts = clean.split(",")
                if len(parts[1]) == 3 and len(parts[0]) <= 3:
                    clean = clean.replace(",", "")
                else:
                    clean = clean.replace(",", ".")
            else:
                clean = clean.replace(",", "")
        elif last_dot != -1:
            if clean.count(".") > 1:
                clean = clean.replace(".", "")
            else:
                parts = clean.split(".")
                if len(parts[1]) == 3:
                    clean = clean.replace(".", "")
                    
        return float(clean)
    except Exception:
        return 0.0

def clean_text(val):
    """Metin verilerini temizler ve NaN değerlerini boş stringe çevirir."""
    if pd.isna(val): return ""
    val = str(val).strip()
    if val.lower() == "nan": return ""
    return val

def parse_diya_excel(file_path):
    try:
        # Excel dosyasını başlıklar olmadan okuyoruz
        df = pd.read_excel(file_path, header=None, dtype=str)
        df = df.reindex(columns=range(15)) 
        
        all_data = []
        
        curr_yevmiye_no = ""
        curr_kayit_tarihi = ""
        curr_hesap_kodu = ""
        curr_hesap_adi = ""
        curr_hesap_yonu = "" 
        
        for idx, row in df.iterrows():
            # SATIRIN TAMAMINI TARAMA (Adım 1 Mantığı)
            satir_hucreleri = [str(x).strip() for x in row if pd.notna(x)]
            
            if any("Mahsup Fişi" in hucre for hucre in satir_hucreleri):
                curr_yevmiye_no = ""
                curr_kayit_tarihi = ""
                
                for hucre in satir_hucreleri:
                    temiz_deger = hucre.replace(".0", "")
                    if temiz_deger.isdigit() and curr_yevmiye_no == "":
                        curr_yevmiye_no = temiz_deger
                        
                    match = re.search(r'\(?(\d{2}[./-]\d{2}[./-]\d{4})\)?', hucre)
                    if match and curr_kayit_tarihi == "":
                        curr_kayit_tarihi = match.group(1)
                continue
                
            # --- TABLO VERİLERİ (A=0, D=3, E=4, F=5, G=6, H=7, I=8) ---
            col_a = clean_text(row[0])
            col_d = clean_text(row[3])
            col_e = clean_text(row[4])
            col_f = clean_text(row[5])
            col_g = clean_text(row[6])
            col_h = clean_text(row[7])
            col_i = clean_text(row[8])
            
            if "NAKLİ YEKÜN" in col_e.upper() or "NAKLIYEKUN" in col_e.replace(" ", "").upper():
                continue
                
            # --- Kural d, e, k, l: Ana Hesap ---
            if re.match(r'^\d{3}$', col_d):
                curr_hesap_kodu = col_d
                curr_hesap_adi = col_e 
                
                h_val = abs(clean_amount(col_h))
                i_val = abs(clean_amount(col_i))
                
                if h_val > 0: curr_hesap_yonu = "BORC"
                elif i_val > 0: curr_hesap_yonu = "ALACAK"
                else: curr_hesap_yonu = "BORC" 
                continue
                
            # --- Kural f, g, h: Muavin Hesap ---
            if re.match(r'^\d{3}\.[\d\.]+$', col_d):
                muavin_kodu = col_d
                muavin_adi = col_e 
                fis_aciklamasi = col_f 
                
                # Varsayılan Belge No (Alt satırda Detay Açıklama çıkmazsa diye yedekte tutulur)
                belge_no_taslak = fis_aciklamasi
                if "," in belge_no_taslak: belge_no_taslak = belge_no_taslak.split(",")[0]
                elif "/" in belge_no_taslak: belge_no_taslak = belge_no_taslak.split("/")[0]
                
                tutar = abs(clean_amount(col_g))
                borc = tutar if curr_hesap_yonu == "BORC" else 0.0
                alacak = tutar if curr_hesap_yonu == "ALACAK" else 0.0
                
                kayit = {
                    "YevmiyeNo": curr_yevmiye_no,
                    "KayitTarihi": curr_kayit_tarihi,
                    "BelgeNo": belge_no_taslak.strip(),
                    "FisAciklamasi": fis_aciklamasi,
                    "DetayAciklama": "",
                    "HesapKodu": curr_hesap_kodu,
                    "HesapAdi": curr_hesap_adi,
                    "MuavinKodu": muavin_kodu,
                    "MuavinAdi": muavin_adi,
                    "Borc": borc,
                    "Alacak": alacak
                }
                all_data.append(kayit)
                continue
                
            # --- YENİ KURAL: Detay Açıklama ve Belge No Tespiti ---
            if col_d == "" and len(col_e) > 5 and curr_yevmiye_no != "":
                detay_metni = col_e
                
                # BelgeNo'yu DetayAciklama metninin solundaki ilk virgülle ayrılan kelimeden al
                hesaplanan_belge_no = ""
                if "," in detay_metni:
                    hesaplanan_belge_no = detay_metni.split(",")[0].strip()
                elif "/" in detay_metni:
                    hesaplanan_belge_no = detay_metni.split("/")[0].strip()
                else:
                    hesaplanan_belge_no = detay_metni.strip()

                # İlgili yevmiyeye dönüp değerleri ez
                for rec in reversed(all_data):
                    if rec["YevmiyeNo"] == curr_yevmiye_no:
                        if not rec["DetayAciklama"]:
                            rec["DetayAciklama"] = detay_metni
                            # Eğer virgülle ayrılan bir BelgeNo bulduysak, taslak olanı ez!
                            if hesaplanan_belge_no:
                                rec["BelgeNo"] = hesaplanan_belge_no
                    else:
                        break 
                        
        meta = {"unvan": "Diya Formatı", "vkn": "-"}
        ek_bilgi = {"status": "OK"}
        msg = f"Başarılı! Toplam {len(all_data)} muavin satırı yakalandı."
        
        return all_data, meta, ek_bilgi, msg

    except Exception as e:
        import traceback
        return [], {}, {}, f"Hata: {str(e)}\n{traceback.format_exc()}"