import pandas as pd
import re
import os
import logging

# --- 1. SÖZLÜK ENTEGRASYONU ---
try:
    from sozluk import THP_SOZLUK
except ImportError:
    try:
        from .sozluk import THP_SOZLUK
    except ImportError:
        THP_SOZLUK = {}

# Loglama ayarı
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ZirveParser:
    def __init__(self, file_path):
        self.file_path = file_path
        self.dosya_adi = os.path.basename(file_path)
        self.parsed_items = []
        self.local_account_map = {} 
        self.meta_unvan = "Bilinmeyen Firma"
        self.last_yevmiye_no = 0
        self.last_date = ""

    def clean_amount(self, val):
        if pd.isna(val) or str(val).strip() == "": return 0.0
        val_str = str(val).strip()
        sign = -1.0 if val_str.startswith('(') and val_str.endswith(')') else 1.0
        val_str = val_str.replace('(', '').replace(')', '').replace('-', '')
        if not val_str: return 0.0
        try:
            if "," in val_str and "." in val_str:
                if val_str.rfind(",") > val_str.rfind("."):
                    val_str = val_str.replace(".", "").replace(",", ".")
                else:
                    val_str = val_str.replace(",", "")
            elif "," in val_str:
                val_str = val_str.replace(",", ".")
            clean = re.sub(r"[^0-9.]", "", val_str)
            return float(clean) * sign
        except:
            return 0.0
    
    def get_account_name(self, code, fallback_name=""):
        code = str(code).strip()
        if code in self.local_account_map: return self.local_account_map[code]
        if code in THP_SOZLUK: return THP_SOZLUK[code]
        if fallback_name and len(fallback_name) > 1: return fallback_name
        return "BİLİNMİYOR"

    def preprocess_accounts(self, df):
        for _, row in df.iterrows():
            def safe(idx): return str(row.iloc[idx]).strip() if len(row) > idx else ""
            col_a, col_b = safe(0), safe(1)
            if col_a and col_a[0].isdigit():
                if col_b and col_b.lower() != 'nan': self.local_account_map[col_a] = col_b
            col_c, col_d = safe(2), safe(3)
            if col_c and col_c[0].isdigit():
                if col_d and col_d.lower() != 'nan': self.local_account_map[col_c] = col_d

    def parse_belge_no_from_desc(self, text):
        if not text: return ""
        match = re.search(r'\d{2}[./-]\d{2}[./-]\d{4}-([A-Za-z0-9]+)', text)
        if match: 
            return match.group(1).strip('- ')
        return ""


    def extract_metadata_from_block(self, block_rows):
        header_row = block_rows[0]
        
        yevmiye_no = None
        date_str = None
        
        # --- Dinamik Sütun ve Metin İşaretçisi (Text Marker) Taraması ---
        # Sabit bir sütuna bakmak yerine, başlık satırındaki dolu olan tüm hücreleri tarıyoruz.
        for item in header_row:
            if pd.isna(item):
                continue
                
            cell_text = str(item).strip()
            if not cell_text:
                continue

            # --- A. YevmiyeNo Tespiti ---
            if not yevmiye_no:
                no_match = re.search(r'Madde No\s*[:]\s*(\d+)', cell_text, re.IGNORECASE)
                if no_match: 
                    yevmiye_no = int(no_match.group(1))
                else:
                    nolu_match = re.search(r'(\d+)\s*Nolu', cell_text, re.IGNORECASE)
                    if nolu_match:
                        yevmiye_no = int(nolu_match.group(1))

            # --- B. KayitTarihi Tespiti ---
            if not date_str:
                # Metnin neresinde olursa olsun tarihi yakalar
                date_match = re.search(r'(\d{2})[./-](\d{2})[./-](\d{4})', cell_text)
                if date_match:
                    d, m, y = date_match.groups()
                    date_str = f"{d}.{m}.{y}" # İstenilen "01.01.2024" formatı

            # Eğer ikisini de bulduysak döngüyü erken bitirebiliriz
            if yevmiye_no and date_str:
                break

        # --- Yevmiye No: Fallback (Yedek) Mantığı ---
        if yevmiye_no:
            self.last_yevmiye_no = yevmiye_no # Bulunduysa hafızaya al
        else:
            yevmiye_no = self.last_yevmiye_no # Bulunamadıysa öncekini kullan

        # --- KayitTarihi: Fallback Mantığı ---
        if date_str:
            self.last_date = date_str
        else:
            date_str = self.last_date if self.last_date else "01.01.1900"
        
        # Fiş sonundaki detay açıklamasını alma (Dinamik son dolu hücre kontrolü eklenebilir ama mevcut yapı korunuyor)
        block_detay = ""
        if len(block_rows) > 0:
            last_row = block_rows[-1]
            if len(last_row) > 4:
                val = str(last_row.iloc[4]).strip()
                if val and val.lower() != 'nan': block_detay = val

        return yevmiye_no, date_str, block_detay


    # -------------------------------------------------------------------------
    # SENARYO 1: Mükerrer Kayıtları Önleyen Güncel Mantık
    # -------------------------------------------------------------------------
    def process_scenario_1(self, block_rows, meta):
        curr_yevmiye, curr_date, block_detay = meta
        
        active_hk, active_ha = "", ""
        active_mk, active_ma = "", ""
        is_borc = True 
        
        for i, row in enumerate(block_rows):
            if i == 0: continue 
            
            def safe_str(idx): return str(row.iloc[idx]).strip() if len(row) > idx and pd.notna(row.iloc[idx]) else ""
            def safe_float(idx): return self.clean_amount(row.iloc[idx]) if len(row) > idx else 0.0

            col_a = safe_str(0)
            col_b = safe_str(1)
            col_c = safe_str(2)
            col_d = safe_str(3)
            col_e = safe_str(4)
            if col_e.lower() == 'nan': col_e = ""
            val_f = safe_float(5)
            
            # 1. Ana Hesap ve Yön Güncellemesi (val_f == 0 kontrolü ile ana başlığı saptama)
            if col_a and len(col_a) == 3 and val_f == 0:
                active_hk, active_ha = col_a, col_b
                is_borc = True
                active_mk, active_ma = "", "" # Ana hesap değiştiğinde muavini sıfırla
            elif col_c and len(col_c) == 3 and val_f == 0:
                active_hk, active_ha = col_c, col_d
                is_borc = False
                active_mk, active_ma = "", ""
                
            # 2. Muavin Hesap Güncellemesi
            if col_a and len(col_a) > 3:
                active_mk, active_ma = col_a, col_b
                is_borc = True
            elif col_c and len(col_c) > 3:
                active_mk, active_ma = col_c, col_d
                is_borc = False
                
            # --- 3. KRİTİK FİLTRE ---
            # Hesap kodu sütunları (A ve C) BOŞ, fakat Tutar (F) DOLU ise bu asıl işlem satırıdır
            if val_f > 0 and not col_a and not col_c:
                fis_aciklamasi = col_e
                belge_no = self.parse_belge_no_from_desc(fis_aciklamasi)
                
                borc = val_f if is_borc else 0.0
                alacak = val_f if not is_borc else 0.0
                
                # EĞER MUAVİN YOKSA (Örn: 257 hesabı) ANA HESABI MUAVİN GİBİ KULLAN
                final_mk = active_mk if active_mk else active_hk
                final_ma = active_ma if active_ma else active_ha
                
                self.add_item(curr_yevmiye, curr_date, belge_no, fis_aciklamasi, block_detay, 
                              active_hk, active_ha, final_mk, final_ma, borc, alacak)

    # -------------------------------------------------------------------------
    # SENARYO 2: F Sütununda Tutar Olmayan Standart İşleyiş
    # -------------------------------------------------------------------------
    def process_scenario_2(self, block_rows, meta):
        curr_yevmiye, curr_date, block_detay = meta
        
        for i, row in enumerate(block_rows):
            if i == 0: continue
            def safe_str(idx): return str(row.iloc[idx]).strip() if len(row) > idx and pd.notna(row.iloc[idx]) else ""
            def safe_float(idx): return self.clean_amount(row.iloc[idx]) if len(row) > idx else 0.0
            
            col_a = safe_str(0)
            col_b = safe_str(1)
            col_c = safe_str(2)
            col_d = safe_str(3)
            col_e = safe_str(4) 
            if col_e.lower() == 'nan': col_e = ""
            
            val_g = safe_float(6) 
            val_h = safe_float(7) 

            belge_no = self.parse_belge_no_from_desc(col_e)

            if col_a and val_g > 0:
                hk, ha, mk, ma = "", "", "", ""
                if len(col_a) == 3:
                    hk, ha = col_a, col_b
                    mk, ma = col_a, col_b
                else:
                    mk, ma = col_a, col_b
                    hk = col_a[:3]
                    ha = self.get_account_name(hk)
                self.add_item(curr_yevmiye, curr_date, belge_no, col_e, block_detay, hk, ha, mk, ma, val_g, 0.0)
            
            if col_c and val_h > 0:
                hk, ha, mk, ma = "", "", "", ""
                if len(col_c) == 3:
                    hk, ha = col_c, col_d
                    mk, ma = col_c, col_d
                else:
                    mk, ma = col_c, col_d
                    hk = col_c[:3]
                    ha = self.get_account_name(hk)
                self.add_item(curr_yevmiye, curr_date, belge_no, col_e, block_detay, hk, ha, mk, ma, 0.0, val_h)

    def process_block(self, block_rows):
        if not block_rows: return
        meta = self.extract_metadata_from_block(block_rows)
        
        has_scenario_1 = False
        has_scenario_3 = False
        
        # Hangi senaryo olduğunu tespit edelim
        for r in block_rows[1:]:
            if len(r) > 5:
                val_f = self.clean_amount(r.iloc[5])
                if val_f > 0:
                    col_a = str(r.iloc[0]).strip() if pd.notna(r.iloc[0]) else ""
                    col_c = str(r.iloc[2]).strip() if pd.notna(r.iloc[2]) else ""
                    
                    # Eğer Tutar (F) dolu ama Hesap Kodu (A ve C) BOŞ ise -> Senaryo 1 KESİNLEŞİR
                    if not col_a and not col_c:
                        has_scenario_1 = True
                    # Eğer Tutar (F) dolu ve Hesap Kodu (A veya C) DOLU ise -> Senaryo 3 izleri
                    elif col_a or col_c:
                        has_scenario_3 = True

        # ÖNCELİK SIRASI: Önce Senaryo 1 (Açıklama satırı ayrı olan format) kontrol edilmeli!
        if has_scenario_1: 
            self.process_scenario_1(block_rows, meta)
        elif has_scenario_3:
            self.process_scenario_3(block_rows, meta)
        else: 
            self.process_scenario_2(block_rows, meta)


    def add_item(self, y_no, date, doc_no, desc, detail_desc, h_kodu, h_adi, m_kodu, m_adi, debit, credit):
        self.parsed_items.append({
            "YevmiyeNo": y_no, "KayitTarihi": date, "BelgeNo": doc_no, 
            "FisAciklamasi": desc, "DetayAciklama": detail_desc, 
            "HesapKodu": h_kodu, "HesapAdi": h_adi, 
            "MuavinKodu": m_kodu, "MuavinAdi": m_adi, 
            "Borc": debit, "Alacak": credit, 
            "Kaynak": "Zirve_Excel", "VKN": "0000000000", "Unvan": self.meta_unvan
        })

    def process(self):
        try:
            if self.file_path.lower().endswith('.csv'):
                df = pd.read_csv(self.file_path, sep=None, engine='python', header=None, dtype=str)
            else:
                df = pd.read_excel(self.file_path, header=None, dtype=str)

            try:
                val = df.iloc[1, 0]
                if pd.notna(val) and str(val).strip() != "":
                    raw_text = str(val).strip()
                    clean_unvan = re.sub(r'(?i)^Unvan\s*[:]\s*', '', raw_text)
                    self.meta_unvan = clean_unvan.strip()
            except Exception as e:
                logger.warning(f"Unvan bilgisi okunamadı: {e}")
                pass

            self.preprocess_accounts(df)
            current_block = []
            
            for _, row in df.iterrows():
                if "Madde No" in str(row.iloc[0]):
                    if current_block: self.process_block(current_block)
                    current_block = [row]
                elif current_block: 
                    current_block.append(row)
            
            if current_block: self.process_block(current_block)
            
            return self.parsed_items, {"vkn": "0000000000", "unvan": self.meta_unvan}, {}, "OK"
            
        except Exception as e:
            import traceback
            return [], {}, {}, f"Zirve Parser Hatası: {str(e)}\n{traceback.format_exc()}"


    # -------------------------------------------------------------------------
    # SENARYO 3: Muavin Kodu, Açıklama ve Tutarın (F Sütunu) Aynı Satırda Olduğu İşleyiş
    # -------------------------------------------------------------------------
    def process_scenario_3(self, block_rows, meta):
        curr_yevmiye, curr_date, block_detay = meta
        
        active_hk_borc, active_ha_borc = "", ""
        active_hk_alacak, active_ha_alacak = "", ""
        
        for i, row in enumerate(block_rows):
            if i == 0: continue 
            
            def safe_str(idx): return str(row.iloc[idx]).strip() if len(row) > idx and pd.notna(row.iloc[idx]) else ""
            def safe_float(idx): return self.clean_amount(row.iloc[idx]) if len(row) > idx else 0.0

            col_a = safe_str(0)
            col_b = safe_str(1)
            col_c = safe_str(2)
            col_d = safe_str(3)
            col_e = safe_str(4)
            if col_e.lower() == 'nan': col_e = ""
            val_f = safe_float(5)
            
            # 1. Ana Hesapları Hafızaya Al 
            # (Eğer tutar yoksa ve kod 3 haneliyse bu bir üst ana hesap başlığıdır)
            if col_a and len(col_a) == 3 and val_f == 0:
                active_hk_borc, active_ha_borc = col_a, col_b
            if col_c and len(col_c) == 3 and val_f == 0:
                active_hk_alacak, active_ha_alacak = col_c, col_d
                
            # 2. İşlem Satırlarını Yakala (F sütununda tutar mutlaka olmalı)
            if val_f > 0:
                belge_no = self.parse_belge_no_from_desc(col_e)
                
                # Borç Kaydı (A sütununda kod varsa)
                if col_a:
                    # Okunan kod mevcut ana hesapla başlıyorsa onu kullan, yoksa ilk 3 hanesinden ana hesabı türet
                    hk = active_hk_borc if (active_hk_borc and col_a.startswith(active_hk_borc)) else col_a[:3]
                    ha = active_ha_borc if (active_hk_borc and col_a.startswith(active_hk_borc)) else self.get_account_name(hk)
                    
                    self.add_item(curr_yevmiye, curr_date, belge_no, col_e, block_detay, 
                                  hk, ha, col_a, col_b, val_f, 0.0)
                                  
                # Alacak Kaydı (C sütununda kod varsa)
                elif col_c:
                    hk = active_hk_alacak if (active_hk_alacak and col_c.startswith(active_hk_alacak)) else col_c[:3]
                    ha = active_ha_alacak if (active_hk_alacak and col_c.startswith(active_hk_alacak)) else self.get_account_name(hk)
                    
                    self.add_item(curr_yevmiye, curr_date, belge_no, col_e, block_detay, 
                                  hk, ha, col_c, col_d, 0.0, val_f)
                    

def parse_zirve_excel(file_path):
    parser = ZirveParser(file_path)
    return parser.process()