import os
import json
import pandas as pd

# Profil klasörünün tam yolu
PROFILE_DIR = os.path.join(os.path.dirname(__file__), 'profiles')

def detect_format(df):
    """
    Verilen DataFrame'in sütun başlıklarına bakarak hangi profile uyduğunu bulur.
    """
    best_match = None
    max_score = 0
    
    # DataFrame sütunlarını temizle (küçük harf, boşluksuz)
    df_cols = [str(c).strip().lower() for c in df.columns]
    
    if not os.path.exists(PROFILE_DIR):
        return None, "Profil klasörü bulunamadı."

    # Tüm JSON profillerini tara
    for f in os.listdir(PROFILE_DIR):
        if not f.endswith('.json'): continue
        
        try:
            with open(os.path.join(PROFILE_DIR, f), 'r', encoding='utf-8') as file:
                profile = json.load(file)
                
            # Parmak izi kontrolü (Fingerprint Check)
            # Profildeki kritik sütunlar, bu dosyada var mı?
            fingerprint = profile.get('fingerprint', [])
            score = 0
            
            # Puanlama Sistemi
            for key_col in fingerprint:
                if key_col.lower() in df_cols:
                    score += 1
            
            # Eşleşme Oranı (Basit mantık: En çok sütunu tutan kazanır)
            if score > max_score and score >= len(fingerprint) * 0.5: # En az %50 eşleşme şart
                max_score = score
                best_match = profile
                
        except Exception as e:
            print(f"Profil okuma hatası ({f}): {e}")

    if best_match:
        return best_match, f"Format Algılandı: {best_match.get('name', 'Bilinmeyen')}"
    else:
        # Varsayılan profil (Standart) denemesi
        return None, "Uygun format profili bulunamadı."
