import pandas as pd
import numpy as np

def clean_currency(val):
    """TL formatındaki (1.000,50) veya (1,000.50) sayıları float'a çevirir."""
    if pd.isna(val) or val == '': return 0.0
    val = str(val).strip()
    
    # Zaten sayıysa dön
    if val.replace('.', '').replace(',', '').isdigit():
        return float(val)

    # İşaret kontrolü (Parantez içi negatiftir muhasebede)
    factor = -1 if val.startswith('(') and val.endswith(')') else 1
    val = val.replace('(', '').replace(')', '')

    try:
        if "," in val and "." in val:
            if val.find(".") < val.find(","): # 1.250,50 (TR)
                val = val.replace('.', '').replace(',', '.')
            else: # 1,250.50 (US)
                val = val.replace(',', '')
        elif "," in val: # 1250,50
            val = val.replace(",", ".")
        return float(val) * factor
    except:
        return 0.0

def normalize_data(df, profile, dosya_adi):
    """
    Ham DataFrame'i ve Profili alıp standart veri listesine çevirir.
    """
    liste = []
    mapping = profile.get('mapping', {})
    meta_defaults = profile.get('defaults', {})
    
    # 1. Sütun İsimlerini Haritala (Rename)
    # Excel sütun adlarını bizim standart adlara çevir
    # Örn: "Borç Tutarı" -> "Borc"
    
    # Önce tüm sütunları normalize et (boşlukları sil vb)
    df.columns = [str(c).strip() for c in df.columns]
    
    # Mapping işlemini tersten yapmamız lazım (Excel Col -> System Col)
    reverse_map = {}
    for excel_col, sys_col in mapping.items():
        # Excel sütunu dosyada var mı kontrol et
        if excel_col in df.columns:
            reverse_map[excel_col] = sys_col
            
    df.rename(columns=reverse_map, inplace=True)
    
    # 2. Kritik Sütun Kontrolü
    if 'Borc' not in df.columns: df['Borc'] = 0.0
    if 'Alacak' not in df.columns: df['Alacak'] = 0.0
    
    # 3. Veri Temizliği ve Tip Dönüşümü
    df['Borc'] = df['Borc'].apply(clean_currency)
    df['Alacak'] = df['Alacak'].apply(clean_currency)
    
    # Tarih İşlemleri
    if 'KayitTarihi' in df.columns:
        date_fmt = profile.get('date_format', None) # Profilde format varsa kullan
        df['KayitTarihi'] = pd.to_datetime(df['KayitTarihi'], format=date_fmt, errors='coerce')
        df['KayitTarihi'] = df['KayitTarihi'].dt.strftime('%Y-%m-%d')
        df['KayitTarihi'] = df['KayitTarihi'].fillna(method='ffill') # Boş tarihleri doldur
    else:
        df['KayitTarihi'] = "1900-01-01"

    if 'YevmiyeNo' in df.columns:
        df['YevmiyeNo'] = pd.to_numeric(df['YevmiyeNo'], errors='coerce').fillna(0)
        df['YevmiyeNo'] = df['YevmiyeNo'].replace(0, method='ffill') # Boş no'ları doldur

    # 4. Standart Sözlüğe Çevirme
    records = df.to_dict('records')
    vkn = meta_defaults.get('vkn', '0000000000')
    unvan = meta_defaults.get('unvan', 'EXCEL_YUKLEME')

    for row in records:
        b = row.get('Borc', 0.0)
        a = row.get('Alacak', 0.0)
        
        # Bakiye yoksa atla (Opsiyonel: Profil ayarına bağlanabilir)
        if b == 0 and a == 0: continue

        item = {
            "VKN": vkn, "Unvan": unvan,
            "YevmiyeNo": int(row.get('YevmiyeNo', 0)),
            "KayitTarihi": row.get('KayitTarihi'),
            "BelgeNo": str(row.get('BelgeNo', '')),
            "FisAciklamasi": str(row.get('FisAciklamasi', '')),
            "DetayAciklama": str(row.get('DetayAciklama', '')),
            "HesapKodu": str(row.get('HesapKodu', '')),
            "HesapAdi": str(row.get('HesapAdi', '')),
            "MuavinKodu": str(row.get('MuavinKodu', row.get('HesapKodu', ''))),
            "MuavinAdi": str(row.get('MuavinAdi', row.get('HesapAdi', ''))),
            "Borc": b,
            "Alacak": a,
            "KaynakDosya": dosya_adi
        }
        liste.append(item)
        
    return liste
