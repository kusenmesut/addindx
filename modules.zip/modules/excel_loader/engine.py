import pandas as pd
import os
import re
import sys
import traceback

# --- 1. IMPORT AYARLARI ---
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

# --- 2. MODÜLLERİ GÜVENLİ YÜKLE ---
try:
    from .detector import detect_format
    from .normalizer import normalize_data
    from .rule_manager import FormatRuleManager
except (ImportError, ValueError):
    try:
        from detector import detect_format
        from normalizer import normalize_data
        from rule_manager import FormatRuleManager
    except Exception as e:
        print(f"UYARI: Temel modüller yüklenemedi: {e}")
        FormatRuleManager = None
        detect_format = None
        normalize_data = None

# --- 3. PARSER IMPORTLARI (GELİŞMİŞ HATA YAKALAYICI İLE) ---
# YENİ: Artık hataları gizlemiyoruz, direkt ekrana yansıtıyoruz!
parser_errors = {}

def guvenli_import(module_name, func_name):
    try:
        module = __import__(f".{module_name}", globals(), locals(), [func_name], 1)
        return getattr(module, func_name)
    except Exception as e1:
        try:
            module = __import__(module_name, globals(), locals(), [func_name], 0)
            return getattr(module, func_name)
        except Exception as e2:
            parser_errors[module_name] = traceback.format_exc()
            return None

parse_ergn_excel = guvenli_import("ergn_parser", "parse_ergn_excel")
parse_brg_excel = guvenli_import("brg_parser", "parse_brg_excel")
parse_caniaserp_excel = guvenli_import("caniaserp_parser", "parse_caniaserp_excel")
parse_mikro_excel = guvenli_import("mikro_parser", "parse_mikro_excel")
parse_zirve_excel = guvenli_import("zirve_parser", "parse_zirve_excel")
parse_mikromasa_excel = guvenli_import("mikromasa_parser", "parse_mikromasa_excel")
parse_yevmiye_excel = guvenli_import("logov2_parser", "parse_yevmiye_excel")
parse_diya_excel = guvenli_import("diya_parser", "parse_diya_excel")

parse_luca_excel = guvenli_import("luca_parser", "parse_luca_excel")
if not parse_luca_excel:
    parse_luca_excel = guvenli_import("luca_parser", "parse_logo_excel")


# --- 4. YARDIMCI FONKSİYONLAR ---
def search_meta_in_content(df_head):
    try:
        text_blob = df_head.to_string(index=False, header=True)
        found_vkn = None
        match_vkn = re.search(r'\b[0-9]{10}\b', text_blob)
        if match_vkn: found_vkn = match_vkn.group(0)
        
        found_date = None
        match_date = re.search(r'\b(202[0-9])[-/.](0[1-9]|1[0-2])\b', text_blob)
        if match_date: found_date = f"{match_date.group(1)}-{match_date.group(2)}"
        return found_vkn, found_date
    except: return None, None

# --- 5. ANA MOTOR ---
def excel_dosya_islee(dosya_yolu, forced_format=None):
    meta = {"vkn": None, "unvan": "EXCEL_YUKLEME"}
    ek_bilgi = {}
    
    dosya_adi = os.path.basename(dosya_yolu)
    if dosya_adi.startswith("~$"):
        return [], meta, {}, "Geçici Excel dosyası (Lock File) atlandı."

    try:
        ext = os.path.splitext(dosya_yolu)[1].lower()
        read_engine = 'openpyxl' if ext == '.xlsx' else 'xlrd' if ext == '.xls' else None

        target_format = forced_format 
        dedektif_raporu = ""

        if not target_format and FormatRuleManager:
            try:
                if ext in ['.xls', '.xlsx']:
                    with pd.ExcelFile(dosya_yolu, engine=read_engine) as xls:
                        df_head = pd.read_excel(xls, sheet_name=0, nrows=25, header=None)     
                        detected_format, dedektif_raporu = FormatRuleManager().evaluate(df_head, xls.sheet_names)
                elif ext == '.csv':
                    df_head = pd.read_csv(dosya_yolu, nrows=25, header=None, engine='python')
                    detected_format, dedektif_raporu = FormatRuleManager().evaluate(df_head, ["CSV"])
                
                if detected_format != "STANDART":
                    target_format = detected_format

            except Exception as e:
                print(f"RuleManager Hatası: {e}")

        if not target_format: 
            target_format = "STANDART"
        
        parser_func = None
        parser_mod_name = ""
        
        if target_format == "BRG": parser_func = parse_brg_excel; parser_mod_name = "brg_parser"
        elif target_format == "MIKRO": parser_func = parse_mikro_excel; parser_mod_name = "mikro_parser"
        elif target_format == "MIKROMASA": parser_func = parse_mikromasa_excel; parser_mod_name = "mikromasa_parser"
        elif target_format == "ZIRVE": parser_func = parse_zirve_excel; parser_mod_name = "zirve_parser"
        elif target_format == "LOGOV2": parser_func = parse_yevmiye_excel; parser_mod_name = "logov2_parser"
        elif target_format == "DIYA": parser_func = parse_diya_excel; parser_mod_name = "diya_parser"
        elif target_format in ["LUCA", "LOGO"]: parser_func = parse_luca_excel; parser_mod_name = "luca_parser"
        elif target_format == "ERGN": parser_func = parse_ergn_excel; parser_mod_name = "ergn_parser"
        elif target_format == "CANIASERP": parser_func = parse_caniaserp_excel; parser_mod_name = "caniaserp_parser"

        # YENİ: EĞER PARSER FONKSİYONU NONE İSE GERÇEK HATAYI FIRLAT!
        if target_format != "STANDART" and parser_func is None:
             gercek_hata = parser_errors.get(parser_mod_name, "Dosya bulunamadı veya içe aktarma hatası.")
             return [], meta, {}, f"SİSTEM ÇÖKTÜ!\n'{parser_mod_name}.py' dosyası içindeki bir KOD HATASI yüzünden başlatılamıyor.\n\nKod Hatası Detayı:\n{gercek_hata}"

        if parser_func:
            try:
                return parser_func(dosya_yolu)
            except Exception as e:
                return [], meta, {}, f"Parser Çalışırken Hata Verdi:\n{str(e)}\n\n{traceback.format_exc()}"

        try:
            if ext == '.csv': df_std = pd.read_csv(dosya_yolu, sep=None, engine='python', nrows=40)
            else: df_std = pd.read_excel(dosya_yolu, nrows=40, engine=read_engine)
        except: return [], meta, {}, "Dosya okunamadı."

        vkn, date = search_meta_in_content(df_std)
        if vkn: meta['vkn'] = vkn
        if date: ek_bilgi['tahmini_donem'] = date

        if detect_format:
            profil, msg = detect_format(df_std)
            if profil:
                try:
                    skip = profil.get('data_start_row', 0)
                    if ext == '.csv': df_full = pd.read_csv(dosya_yolu, sep=None, engine='python', skiprows=skip)
                    else: df_full = pd.read_excel(dosya_yolu, skiprows=skip, engine=read_engine)
                    
                    veri = normalize_data(df_full, profil, dosya_adi)
                    if veri: return veri, meta, ek_bilgi, f"OK ({profil.get('name')})"
                except: pass

        return [], meta, {}, f"Format Tanınamadı (Standart).\n\nDedektif Raporu:\n{dedektif_raporu}"

    except Exception as e:
        return [], meta, {}, f"Genel Engine Hatası: {str(e)}\n{traceback.format_exc()}"