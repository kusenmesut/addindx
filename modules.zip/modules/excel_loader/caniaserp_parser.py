import pandas as pd
import re
import warnings

# Gereksiz uyarıları kapat
warnings.filterwarnings("ignore")

def clean_amount(val):
    """Sayısal değerleri her türlü formattan temizler."""
    if pd.isna(val) or str(val).strip() == "": return 0.0
    try:
        val_str = str(val).strip().replace(" ", "")
        if val_str.startswith("(") and val_str.endswith(")"):
            val_str = "-" + val_str[1:-1]
            
        clean = re.sub(r"[^\d,\.-]", "", val_str)
        if not clean or clean in ["-", ".", ","]: return 0.0
        
        last_dot = clean.rfind(".")
        last_comma = clean.rfind(",")
        
        if last_comma != -1 and last_dot != -1:
            if last_comma > last_dot:
                clean = clean.replace(".", "").replace(",", ".")
            else:
                clean = clean.replace(",", "")
        elif last_comma != -1:
            if clean.count(",") == 1:
                parts = clean.split(",")
                if len(parts[1]) == 3 and len(parts[0]) <= 3:
                    clean = clean.replace(",", "")
                else:
                    clean = clean.replace(",", ".")
            else:
                clean = clean.replace(",", "")
        elif last_dot != -1:
            if clean.count(".") > 1:
                clean = clean.replace(".", "")
            else:
                parts = clean.split(".")
                if len(parts[1]) == 3:
                    clean = clean.replace(".", "")
                    
        return float(clean)
    except Exception:
        return 0.0

def clean_text(val):
    """Metin verilerini temizler ve BOM/görünmez karakterleri yok eder."""
    if pd.isna(val): return ""
    val = str(val).replace('\ufeff', '').replace('\u200b', '').strip()
    if val.lower() in ["nan", "nat", "none"]: return ""
    return val

def extract_date(text):
    """Pandas'ın çevirdiği farklı tarih formatlarını da yakalayarak GG.AA.YYYY olarak döndürür."""
    text = str(text).strip()
    if not text or text.lower() in ["nan", "nat", "none"]:
        return ""
        
    match_iso = re.search(r'(\d{4})-(\d{2})-(\d{2})', text)
    if match_iso:
        return f"{match_iso.group(3)}.{match_iso.group(2)}.{match_iso.group(1)}"
        
    match_tr = re.search(r'(\d{2})[./-](\d{2})[./-](\d{4})', text)
    if match_tr: 
        return f"{match_tr.group(1)}.{match_tr.group(2)}.{match_tr.group(3)}"
        
    return ""

def parse_caniaserp_excel(file_path):
    try:
        try:
            df = pd.read_excel(file_path, header=None, dtype=str)
        except:
            df = pd.read_csv(file_path, header=None, dtype=str, sep=None, engine='python')
            
        df = df.reindex(columns=range(10)) 
        
        all_data = []
        blocks = []
        current_block = []
        
        # --- YENİ MİMARİ: "Belge Tipi" Çapasına Göre Bloklama ---
        for idx, row in df.iterrows():
            cols = [clean_text(x) for x in row]
            col_a_upper = cols[0].upper()
            
            # Tamamen boş olan veya sadece görünmez karakter içeren satırları yok say
            joined_text = "".join(cols[:7])
            is_empty = not bool(re.search(r'[a-zA-Z0-9]', joined_text))
            
            if is_empty:
                continue # Boşlukları atlıyoruz, başlangıcı veri olan ilk satır belirleyecek.
                
            # Veri varsa bloğa ekle (1. satır veya boşluktan sonraki ilk dolu satır)
            current_block.append(cols)
            
            # Bitiş Noktası Kontrolü: Eğer A sütunu "BELGE" ve "TİP" kelimelerini içeriyorsa
            if "BELGE" in col_a_upper and "T" in col_a_upper and "P" in col_a_upper:
                blocks.append(current_block)
                current_block = [] # Sonraki fiş için bloğu sıfırla

        # Dosya sonunda "Belge Tipi" yazısı eksik kalmış son bir fiş varsa onu da kurtar
        if len(current_block) > 0:
            blocks.append(current_block)

        # --- BLOKLARI (FİŞLERİ) İŞLEME ---
        yevmiye_sayaci = 0
        
        for block in blocks:
            # Sadece içinde hesap kodu barındıran geçerli blokları işle
            has_data = any(len(r[0]) >= 3 and r[0][0].isdigit() for r in block)
            if not has_data: continue

            # b. YevmiyeNo: Baştan itibaren sıra no
            yevmiye_sayaci += 1
            curr_yevmiye_no = str(yevmiye_sayaci)
            
            kayit_tarihi = ""
            belge_no = ""
            
            # c ve j: Tarih ve Belge No'yu blok içinde ilk geçtiği yerde yakala
            for r in block:
                if not kayit_tarihi and len(r) > 4:
                    t = extract_date(r[4]) # E Sütunu
                    if t: kayit_tarihi = t
                
                if not belge_no and len(r) > 3:
                    d_val = r[3].strip() # D Sütunu
                    # Sütun başlıklarını veya çöp veriyi belge no sanmaması için kontrol
                    if d_val and d_val.upper() not in ["NAN", "BELGE NO"] and not d_val.upper().startswith("COL"):
                        belge_no = d_val
                        
                if kayit_tarihi and belge_no:
                    break
            
            # h ve i: FisAciklamasi ve DetayAciklama (Bitiş noktası olan son satırdan alınır)
            son_satir = block[-1]
            detay_aciklama = clean_text(son_satir[0]) if len(son_satir) > 0 else ""  # A sütunu (Belge Tipi)
            fis_aciklamasi = clean_text(son_satir[1]) if len(son_satir) > 1 else ""  # B sütunu (Mahsup İşlemleri vb.)
            
            curr_hesap_kodu = ""
            curr_hesap_adi = ""
            curr_hesap_yonu = ""
            
            for r in block:
                col_a = clean_text(r[0])
                col_b = clean_text(r[1])
                col_f = r[5] if len(r) > 5 else "0"
                col_g = r[6] if len(r) > 6 else "0"
                
                col_a_clean = re.sub(r'\.0$', '', col_a)
                
                # d ve e: Ana Hesap ve Yön Tayini
                if re.match(r'^\d{3}$', col_a_clean):
                    curr_hesap_kodu = col_a_clean
                    curr_hesap_adi = col_b
                    
                    f_val = abs(clean_amount(col_f))
                    g_val = abs(clean_amount(col_g))
                    
                    if f_val > 0: curr_hesap_yonu = "BORC"
                    elif g_val > 0: curr_hesap_yonu = "ALACAK"
                    else: curr_hesap_yonu = "BORC"
                    
                # f ve g: Muavin Hesap, Borç ve Alacak Tayini (k ve l kuralları)
                elif len(col_a_clean) > 3 and col_a_clean[0].isdigit() and curr_hesap_kodu:
                    muavin_kodu = col_a_clean
                    muavin_adi = col_b
                    
                    mua_f = abs(clean_amount(col_f))
                    mua_g = abs(clean_amount(col_g))
                    
                    # Ana hesabın yönü neyse muavin o sütundan değer alır
                    if curr_hesap_yonu == "BORC":
                        borc = mua_f
                        alacak = 0.0
                    else:
                        borc = 0.0
                        alacak = mua_g
                    
                    kayit = {
                        "YevmiyeNo": curr_yevmiye_no,
                        "KayitTarihi": kayit_tarihi,
                        "BelgeNo": belge_no,
                        "FisAciklamasi": fis_aciklamasi,
                        "DetayAciklama": detay_aciklama,
                        "HesapKodu": curr_hesap_kodu,
                        "HesapAdi": curr_hesap_adi,
                        "MuavinKodu": muavin_kodu,
                        "MuavinAdi": muavin_adi,
                        "Borc": borc,
                        "Alacak": alacak
                    }
                    all_data.append(kayit)

        meta = {"unvan": "Canias ERP Formatı", "vkn": "-"}
        ek_bilgi = {"status": "OK"}
        msg = f"Başarılı! Toplam {yevmiye_sayaci} fiş ayrıştırıldı ve {len(all_data)} muavin satırı yakalandı."
        
        return all_data, meta, ek_bilgi, msg

    except Exception as e:
        import traceback
        return [], {}, {}, f"Hata: {str(e)}\n{traceback.format_exc()}"