import pandas as pd
import re
import os

# --- YARDIMCI FONKSİYONLAR ---
def clean_amount(val):
    """Metni güvenli float'a çevirir."""
    if pd.isna(val) or str(val).strip() == "": return 0.0
    try:
        clean = re.sub(r"[^0-9,.-]", "", str(val))
        if "," in clean and "." in clean:
             clean = clean.replace(".", "").replace(",", ".")
        elif "," in clean:
             clean = clean.replace(",", ".")
        return float(clean)
    except:
        return 0.0

def parse_belge_no(aciklama):
    """FisAciklamasi alanında ilk virgülden önceki metindir."""
    if not aciklama: return ""
    aciklama_str = str(aciklama)
    if "," in aciklama_str:
        return aciklama_str.split(",")[0].strip()
    return ""

def parse_date_from_row(text):
    """---01.01.2024--- şeklindeki tarihi temizler."""
    if not text: return None
    match = re.search(r'(\d{1,2})[.-/](\d{1,2})[.-/](\d{2,4})', str(text))
    if match:
        g, a, y = match.groups()
        if len(y) == 2: y = "20" + y
        return f"{y}-{int(a):02d}-{int(g):02d}"
    return None

def process_block(block_rows, dosya_adi):
    """Blok İşleme Mantığı (V7 ile aynı)"""
    if not block_rows: return []
    
    parsed_items = []
    
    # Detay Açıklama: Bloğun sondan 2. satırı
    block_detay_aciklama = ""
    if len(block_rows) >= 2:
        try:
            target_row = block_rows[-2]
            val_b = str(target_row.iloc[1]).strip() if pd.notna(target_row.iloc[1]) else ""
            if val_b: block_detay_aciklama = val_b
        except: pass
    
    # Blok İçi Değişkenler
    curr_yevmiye_no = 0
    curr_kayit_tarihi = "1900-01-01"
    
    # Başlık Analizi (İlk Satır)
    first_row_a = str(block_rows[0].iloc[0])
    match_no = re.search(r'Madde\s*[:#]?\s*(\d+)', first_row_a, re.IGNORECASE)
    if match_no:
        curr_yevmiye_no = int(match_no.group(1))
        first_row_b = str(block_rows[0].iloc[1])
        date_found = parse_date_from_row(first_row_b)
        if date_found: curr_kayit_tarihi = date_found
    
    curr_hesap_kodu = ""
    curr_hesap_adi = ""
    curr_muavin_kodu = ""
    curr_muavin_adi = ""
    active_direction = "Borc"

    for row in block_rows:
        cell_a = str(row.iloc[0]).strip() if pd.notna(row.iloc[0]) else ""
        cell_b = str(row.iloc[1]).strip() if pd.notna(row.iloc[1]) else ""
        cell_c = str(row.iloc[2]).strip() if len(row) > 2 and pd.notna(row.iloc[2]) else ""
        
        val_d = row.iloc[3] if len(row) > 3 else 0
        val_e = row.iloc[4] if len(row) > 4 else 0
        
        row_text = (cell_a + cell_b).upper()

        if "MADDE :" in str(cell_a).upper(): continue
        if "TOPLAM" in row_text or "NAKLİ" in row_text: continue

        # HESAP TANIM
        if cell_a:
            if re.match(r'^\d{3}$', cell_a): 
                curr_hesap_kodu = cell_a
                curr_hesap_adi = cell_b
                curr_muavin_kodu = curr_hesap_kodu
                curr_muavin_adi = curr_hesap_adi
            else:
                curr_muavin_kodu = cell_a
                curr_muavin_adi = cell_b
            
            amt_d = clean_amount(val_d)
            amt_e = clean_amount(val_e)
            if amt_d > 0: active_direction = "Borc"
            elif amt_e > 0: active_direction = "Alacak"
            continue

        # İŞLEM DETAY
        if not cell_a and cell_b:
            fis_aciklamasi = cell_b
            belge_no = parse_belge_no(fis_aciklamasi)
            
            tutar = clean_amount(cell_c)
            if tutar == 0:
                tutar = clean_amount(val_d) + clean_amount(val_e)
            
            if tutar > 0:
                final_borc = tutar if active_direction == "Borc" else 0.0
                final_alacak = tutar if active_direction == "Alacak" else 0.0
                
                item = {
                    "YevmiyeNo": curr_yevmiye_no,
                    "KayitTarihi": curr_kayit_tarihi,
                    "BelgeNo": belge_no,
                    "FisAciklamasi": fis_aciklamasi,
                    "DetayAciklama": block_detay_aciklama,
                    "HesapKodu": curr_hesap_kodu,
                    "HesapAdi": curr_hesap_adi,
                    "MuavinKodu": curr_muavin_kodu,
                    "MuavinAdi": curr_muavin_adi,
                    "Borc": final_borc,
                    "Alacak": final_alacak,
                    "KaynakDosya": dosya_adi
                }
                parsed_items.append(item)
                
    return parsed_items

def parse_mikro_excel(file_path):
    """
    MİKRO PARSER V8 - A1 UNVAN & A2 FORMAT KONTROLÜ
    """
    try:
        dosya_adi = os.path.basename(file_path)
        
        if file_path.lower().endswith('.csv'):
            df = pd.read_csv(file_path, sep=None, engine='python', dtype=str, header=None)
        else:
            df = pd.read_excel(file_path, dtype=str, header=None)
        
        all_data = []
        
        # --- GÜNCELLEME: UNVAN VE FORMAT KONTROLÜ ---
        detected_unvan = "Mikro Defter"
        
        # 1. Satır (Index 0): Unvan (Birleştirilmiş A1:E1 -> Pandas iloc[0,0] alır)
        try:
            val_a1 = str(df.iloc[0, 0]).strip()
            if val_a1 and val_a1.lower() != 'nan':
                detected_unvan = val_a1
        except: pass

        # 2. Satır (Index 1): "YEVMİYE DEFTERİ" Kontrolü
        # Bu opsiyonel bir güvenlik önlemidir. Eğer 2. satırda bu ifade varsa Mikro olduğundan emin oluruz.
        # İleride başka parserlar eklenirse bu kontrol işe yarar.
        try:
            val_a2 = str(df.iloc[1, 0]).strip().upper()
            # print(f"Format Kontrolü: {val_a2}") # Debug için
        except: pass

        # --- BLOK YÖNETİMİ ---
        current_block = []
        
        # İlk 2 satır başlık olduğu için döngüde atlanabilir veya Madde kontrolü zaten eler.
        # Biz yine de temiz bir başlangıç için Madde arayarak ilerliyoruz.
        
        for idx, row in df.iterrows():
            # İlk satırlar (Unvan vs) Madde içermediği için otomatik pas geçilir
            # ve current_block boş olduğu için işlem yapılmaz.
            
            cell_a = str(row.iloc[0]).strip() if pd.notna(row.iloc[0]) else ""
            
            # Yeni Madde mi?
            is_new_madde = "Madde" in cell_a and re.search(r'Madde\s*[:#]?\s*(\d+)', cell_a, re.IGNORECASE)
            
            if is_new_madde:
                if current_block:
                    items = process_block(current_block, dosya_adi)
                    all_data.extend(items)
                    current_block = []
                current_block.append(row)
            else:
                if current_block:
                    current_block.append(row)
        
        if current_block:
            items = process_block(current_block, dosya_adi)
            all_data.extend(items)

        # Meta Veri: VKN Arama
        detected_vkn = "0000000000"
        full_text = df.head(50).to_string()
        match_vkn = re.search(r'\b[0-9]{10}\b', full_text)
        if match_vkn: detected_vkn = match_vkn.group(0)
        
        # Yıl Tahmini
        tahmini_yil = "Bilinmiyor"
        for d in all_data:
            if d['KayitTarihi'] != "1900-01-01":
                tahmini_yil = d['KayitTarihi'].split("-")[0]
                break

        meta_data = {"vkn": detected_vkn, "unvan": detected_unvan}
        return all_data, meta_data, {"tahmini_donem": f"{tahmini_yil}-01"}, "OK"

    except Exception as e:
        import traceback
        return [], {}, {}, f"Mikro Parser Hatası: {str(e)}\n{traceback.format_exc()}"