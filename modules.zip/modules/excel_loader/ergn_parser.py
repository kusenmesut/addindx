import pandas as pd
import re
import warnings

warnings.filterwarnings("ignore")

class ErgnParser:
    def __init__(self, file_path):
        self.file_path = file_path
        self.parsed_items = []
        self.meta_unvan = "Bilinmiyor"

    def clean_amount(self, val):
        """Parasal değerleri temizler. (Örn: 1.051.298,28 -> 1051298.28)"""
        if pd.isna(val) or str(val).strip() == "": return 0.0
        val_str = str(val).strip().replace(" ", "").replace("\xa0", "")
        
        sign = 1.0
        if val_str.startswith('(') and val_str.endswith(')'):
            sign = -1.0
            val_str = val_str.replace('(', '').replace(')', '')
        
        val_str = re.sub(r"[^0-9,.-]", "", val_str)
        
        try:
            if "," in val_str and "." in val_str:
                if val_str.rfind(",") > val_str.rfind("."): 
                    val_str = val_str.replace(".", "").replace(",", ".")
                else: 
                    val_str = val_str.replace(",", "")
            elif "," in val_str:
                val_str = val_str.replace(",", ".")
            
            if not val_str: return 0.0
            return float(val_str) * sign
        except:
            return 0.0

    def clean_text(self, val):
        if pd.isna(val): return ""
        # Görünmez boşlukları (non-breaking space) da temizle
        return str(val).replace("\xa0", " ").strip()

    def parse_date(self, text):
        if not text: return None
        match = re.search(r'(\d{2})[./-](\d{2})[./-](\d{4})|(\d{4})[./-](\d{2})[./-](\d{2})', str(text))
        if match:
            if match.group(1): 
                d, m, y = match.group(1), match.group(2), match.group(3)
                return f"{y}-{m}-{d}"
            elif match.group(4): 
                y, m, d = match.group(4), match.group(5), match.group(6)
                return f"{y}-{m}-{d}"
        return None

    def process(self):
        try:
            # Excel Oku (Başlıksız, hepsi string)
            df = pd.read_excel(self.file_path, header=None, dtype=str)
            
            if len(df) > 0: self.meta_unvan = self.clean_text(df.iloc[0, 0])

            curr_yevmiye = 0
            curr_date = "1900-01-01"
            
            # Durum Değişkenleri
            active_direction = "BORC" # Varsayılan (Garanti olsun diye, ama kod bunu ezecek)
            current_account_code = ""
            current_account_name = ""
            
            # Kebir (Ana Hesap) bilgileri
            last_main_code = ""
            last_main_name = ""

            yevmiye_regex = re.compile(r"^[-'\s]*(\d+)[-'\s]*$")

            for idx, row in df.iterrows():
                def get_col(i): return self.clean_text(row[i]) if len(row) > i else ""
                def get_val(i): return self.clean_amount(row[i]) if len(row) > i else 0.0

                col_a = get_col(0) # Hesap Kodu / Yevmiye No
                col_b = get_col(1) # Açıklama
                col_c_val = get_val(2) # Detay Tutar (İşlem)
                col_d_val = get_val(3) # Borç (Başlık)
                col_e_val = get_val(4) # Alacak (Başlık)

                row_str = (col_a + col_b).upper().replace(" ", "")
                
                # --- 1. YEVMİYE NO ve TARİH TESPİTİ ---
                # A sütunu "4" gibi bir sayıysa ve B sütununda tarih varsa
                h_match = yevmiye_regex.search(col_a)
                if h_match and ("." in col_b or "/" in col_b or "---" in col_b):
                    curr_yevmiye = int(h_match.group(1))
                    f_date = self.parse_date(col_b)
                    if f_date: curr_date = f_date
                    
                    # Yeni fişte hafızayı sıfırla
                    current_account_code = ""
                    active_direction = None
                    continue

                # --- 2. HESAP KODU VE YÖN TAYİNİ (HEADER SATIRI) ---
                # Eğer A sütunu doluysa, bu bir hesap tanımlamasıdır.
                if col_a:
                    # Gereksiz satırları atla
                    if any(x in row_str for x in ["TOPLAM", "YEKÜN", "NAKLİ", "DEVREDEN"]):
                        continue

                    # Bu satırı "Geçerli Hesap" olarak belirle
                    current_account_code = col_a
                    current_account_name = col_b

                    # Eğer 3 haneli ise Kebir'dir, hafızaya al
                    if len(col_a.replace(".","").strip()) == 3:
                        last_main_code = col_a
                        last_main_name = col_b

                    # YÖN BELİRLEME KRİTİĞİ:
                    # D sütunu doluysa -> Alt satırlar BORÇ'tur
                    # E sütunu doluysa -> Alt satırlar ALACAK'tır
                    if col_d_val > 0:
                        active_direction = "BORC"
                    elif col_e_val > 0:
                        active_direction = "ALACAK"
                    
                    # Hesap kodu satırının kendisine işlem yapmıyoruz, 
                    # sadece yönü ve kodu hafızaya alıp devam ediyoruz.
                    continue

                # --- 3. İŞLEM SATIRI (DETAY) ---
                # A sütunu BOŞ ve C sütunu (Detay) DOLU ise
                if not col_a and col_c_val > 0:
                    if active_direction: # Yön belliyse (Borç mu Alacak mı)
                        
                        # Kebir kodunu mevcut kodun ilk 3 hanesinden türet (yoksa)
                        kebir_code = last_main_code if last_main_code else current_account_code[:3]
                        kebir_name = last_main_name if last_main_name else current_account_name

                        belge_no = col_b.split()[0] if col_b else ""

                        item = {
                            "YevmiyeNo": curr_yevmiye,
                            "KayitTarihi": curr_date,
                            "HesapKodu": kebir_code, # Ana Hesap
                            "HesapAdi": kebir_name,
                            "MuavinKodu": current_account_code, # En son gördüğümüz kod (örn: 400 00 05)
                            "MuavinAdi": current_account_name,
                            "FisAciklamasi": col_b,
                            "DetayAciklama": "",
                            "BelgeNo": belge_no,
                            "Borc": col_c_val if active_direction == "BORC" else 0.0,
                            "Alacak": col_c_val if active_direction == "ALACAK" else 0.0,
                            "Kaynak": "Seher_Parser_V4_ImgFix",
                            "VKN": "0000000000",
                            "Unvan": self.meta_unvan
                        }
                        self.parsed_items.append(item)
                
                # --- 4. DETAY AÇIKLAMA EKLEME ---
                elif not col_a and col_c_val == 0 and col_b:
                     if self.parsed_items and self.parsed_items[-1]["YevmiyeNo"] == curr_yevmiye:
                        self.parsed_items[-1]["DetayAciklama"] += " " + col_b

            if not self.parsed_items:
                return [], {"unvan": self.meta_unvan}, {}, "Format tanındı ancak veri çıkarılamadı (Parsing Kuralı Uymadı)."

            return self.parsed_items, {"unvan": self.meta_unvan, "vkn": "0000000000"}, {"tahmini_donem": curr_date[:4]}, "OK"

        except Exception as e:
            import traceback
            return [], {}, {}, f"Hata: {str(e)}\n{traceback.format_exc()}"

def parse_ergn_excel(file_path):
    return ErgnParser(file_path).process()