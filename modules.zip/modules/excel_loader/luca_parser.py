import pandas as pd
import re
import os
import warnings

# Gereksiz uyarıları kapat
warnings.filterwarnings("ignore")

# --- 1. YARDIMCI FONKSİYONLAR ---
def clean_amount(val):
    """Sayısal değerleri temizler"""
    if pd.isna(val) or str(val).strip() == "": return 0.0
    try:
        val_str = str(val).strip()
        if val_str.startswith("(") and val_str.endswith(")"):
            val_str = "-" + val_str[1:-1]
        
        # Bilimsel gösterim kontrolü (1.23E+04 gibi)
        if "E" in val_str.upper():
            return float(val_str)

        if "." in val_str and "," not in val_str:
             if val_str.count(".") > 1: return float(val_str.replace(".", ""))
             return float(val_str)
        clean = re.sub(r"[^0-9,.-]", "", val_str)
        clean = clean.replace(".", "").replace(",", ".")
        return float(clean)
    except:
        return 0.0

def clean_text(val):
    if pd.isna(val): return ""
    val = str(val).strip()
    if val.lower() == "nan": return ""
    return val

def extract_belge_no(text):
    """
    Belge No Yakalama Mantığı (V32):
    """
    if not text: return ""
    text = clean_text(text)
    
    # 1. AŞAMA: ÖNEK (PREFIX) KONTROLÜ
    prefix_pattern = r'\b(EF|FT|FTR|FATURA|EFAT|EARS|BELGE|GIB|ZR|Z RAPORU|SN|ÇK)\s*[:.\-]?\s*([A-Z0-9]{5,})'
    match = re.search(prefix_pattern, text, re.IGNORECASE)
    if match:
        return match.group(2).strip()

    # 2. AŞAMA: "000" İÇEREN KELİME KONTROLÜ (Fallback)
    zeros_pattern = r'\b([A-Z0-9]*000[A-Z0-9]*)\b'
    match_zero = re.search(zeros_pattern, text, re.IGNORECASE)
    if match_zero:
        return match_zero.group(1).strip()

    return ""

def parse_logo_header(text):
    """
    Başlık satırından Yevmiye No ve Tarih çeker.
    GÜNCELLEME: YYYY-MM-DD formatını da destekler.
    """
    parts = str(text).split('-----')
    yevmiye_no = 0
    tarih = "1900-01-01"
    
    if len(parts) >= 1:
        try: yevmiye_no = int(re.sub(r"[^0-9]", "", parts[0]))
        except: pass
    
    for part in reversed(parts):
        # 1. DENEME: TR Formatı (DD.MM.YYYY veya DD/MM/YYYY)
        match_tr = re.search(r'(\d{2})[./-](\d{2})[./-](\d{4})', part)
        if match_tr:
            d, m, y = match_tr.groups()
            tarih = f"{y}-{m}-{d}"
            break
            
        # 2. DENEME: ISO Formatı (YYYY-MM-DD) - Pandas bazen böyle okur
        match_iso = re.search(r'(\d{4})[./-](\d{2})[./-](\d{2})', part)
        if match_iso:
            y, m, d = match_iso.groups()
            tarih = f"{y}-{m}-{d}"
            break

    return yevmiye_no, tarih

# --- 2. ANA PARSER ---
def parse_luca_excel(file_path):
    try:
        dosya_adi = os.path.basename(file_path)
        
        # A. DOSYAYI OKU
        df = None
        if file_path.lower().endswith(('.xlsx', '.xls')):
            try: df = pd.read_excel(file_path, dtype=str, header=None)
            except: pass
        
        if df is None:
            # CSV Fallback
            encodings = ['utf-8', 'cp1254', 'latin1', 'iso-8859-9']
            separators = [None, ';', '\t', ',']
            for enc in encodings:
                for sep in separators:
                    try:
                        temp_df = pd.read_csv(file_path, sep=sep, encoding=enc, engine='python', dtype=str, header=None)
                        if not temp_df.empty and len(temp_df.columns) > 1:
                            df = temp_df
                            break
                    except: continue
                if df is not None: break
        
        if df is None or df.empty:
            return [], {"unvan": "HATA"}, {}, "Dosya okunamadı."

        # UNVAN ÇEKME
        meta_unvan = "LOGO_YUKLEME"
        try:
            if len(df) > 1:
                # Genelde başlık bilgisi ilk satırlarda olur
                candidate_unvan = str(df.iloc[1, 0]).strip()
                if candidate_unvan and candidate_unvan.lower() != 'nan':
                    meta_unvan = candidate_unvan
        except Exception as e:
            pass

        # B. TEMİZLİK
        mask_toplam = df.iloc[:, 0].astype(str).str.contains('TOPLAM', case=False, na=False)
        mask_bos = df.iloc[:, 0].isna() | (df.iloc[:, 0].astype(str).str.strip() == "")
        df_clean = df[~(mask_toplam | mask_bos)].copy()
        df_clean.reset_index(drop=True, inplace=True)
        
        all_data = []
        
        # C. DEĞİŞKENLER
        curr_yevmiye = 0
        curr_tarih = "1900-01-01"
        is_closing_block = False

        # D. BLOK TOPLAMA VE İŞLEME
        block_rows = []
        
        for idx, row in df_clean.iterrows():
            col_a_raw = str(row.iloc[0]) if len(row) > 0 and pd.notna(row.iloc[0]) else ""
            col_a_clean = clean_text(col_a_raw)
            
            # Blok Başlangıcı (-----) tespiti
            if "-----" in col_a_clean and re.search(r'\d+-----\d+', col_a_clean):
                # Önceki bloğu işle
                if block_rows:
                    all_data.extend(process_block_logic(block_rows, dosya_adi, curr_yevmiye, curr_tarih, is_closing_block))
                
                # Yeni Blok Ayarları
                block_rows = []
                yevmiye_no, tarih = parse_logo_header(col_a_clean)
                
                if yevmiye_no > 0: curr_yevmiye = yevmiye_no
                if tarih != "1900-01-01": curr_tarih = tarih
                
                is_closing_block = "KAPANIŞ" in col_a_clean.upper() or "AÇILIŞ" in col_a_clean.upper()
                continue
            
            block_rows.append(row)
            
        # Son bloğu işle
        if block_rows:
            all_data.extend(process_block_logic(block_rows, dosya_adi, curr_yevmiye, curr_tarih, is_closing_block))

        # Eğer hiç tarih bulamadıysa ama veri varsa, uyarı ver
        status_msg = "Başarılı"
        if all_data and curr_tarih == "1900-01-01":
            status_msg = "Veri okundu ancak tarih formatı algılanamadı (1900 yılına kaydedildi)."

        return all_data, {"unvan": meta_unvan, "vkn": "0000000000"}, {"status": "OK"}, status_msg

    except Exception as e:
        import traceback
        return [], {}, {}, f"Hata: {str(e)}\n{traceback.format_exc()}"

# --- 3. BLOK İŞLEME MOTORU ---
def process_block_logic(rows, dosya_adi, yevmiye_no, tarih, is_closing):
    processed_items = []
    
    # 1. Adım: Fiş Açıklamasını Bul
    fis_aciklama = ""
    data_rows = []
    
    for row in rows:
        c0 = clean_text(row.iloc[0])
        if "FİŞ AÇIKLAMA" in c0:
            val_b = clean_text(row.iloc[1]) if len(row) > 1 else ""
            if val_b: fis_aciklama = val_b
            else: fis_aciklama = c0.replace("FİŞ AÇIKLAMA", "").replace(":", "").strip()
        else:
            if "HESAP KODU" not in c0 and c0 != "":
                data_rows.append(row)
    
    if is_closing and not fis_aciklama:
        fis_aciklama = "Kapanış/Devir Kaydı"

    # 2. Adım: Hiyerarşi Analizi
    active_parent_code = ""
    active_parent_name = ""
    active_parent_dir = "BORC"

    for i in range(len(data_rows)):
        row = data_rows[i]
        
        raw_a = str(row.iloc[0]) if pd.notna(row.iloc[0]) else ""
        col_a = raw_a.strip()
        col_b = clean_text(row.iloc[1]) if len(row) > 1 else ""
        col_c = clean_text(row.iloc[2]) if len(row) > 2 else ""
        
        val_d = clean_amount(row.iloc[3]) if len(row) > 3 else 0.0
        val_e = clean_amount(row.iloc[4]) if len(row) > 4 else 0.0
        val_f = clean_amount(row.iloc[5]) if len(row) > 5 else 0.0
        
        indent_level = len(raw_a) - len(raw_a.lstrip())
        
        # A. ANA HESAP TESPİTİ
        if len(col_a) == 3 and col_a.isdigit():
            active_parent_code = col_a
            active_parent_name = col_b
            if abs(val_e) > 0.001: active_parent_dir = "BORC"
            elif abs(val_f) > 0.001: active_parent_dir = "ALACAK"
            continue

        # B. İŞLEM SATIRI KARARI
        should_take = False
        
        if not is_closing:
            # Standart fişlerde açıklama (Col C) genelde doludur
            if col_c != "": should_take = True
            # Bazen açıklama boştur ama para vardır
            elif abs(val_e) > 0.001 or abs(val_f) > 0.001: should_take = True
        else:
            has_money = (abs(val_d) > 0.001 or abs(val_e) > 0.001 or abs(val_f) > 0.001)
            if has_money:
                # Altında daha içeride bir satır yoksa bu en alt satırdır
                is_parent_group = False
                if i + 1 < len(data_rows):
                    next_row = data_rows[i+1]
                    next_raw_a = str(next_row.iloc[0]) if pd.notna(next_row.iloc[0]) else ""
                    next_indent = len(next_raw_a) - len(next_raw_a.lstrip())
                    if next_indent > indent_level and next_raw_a.strip() != "":
                        is_parent_group = True
                if not is_parent_group:
                    should_take = True

        if should_take:
            borc = 0.0
            alacak = 0.0
            
            if abs(val_e) > 0.001: borc = abs(val_e)
            elif abs(val_f) > 0.001: alacak = abs(val_f)
            elif abs(val_d) > 0.001:
                if active_parent_dir == "ALACAK": alacak = abs(val_d)
                else: borc = abs(val_d)
            
            satir_aciklama = col_c
            if not satir_aciklama and is_closing:
                satir_aciklama = "Kapanış Kaydı"

            processed_items.append({
                "YevmiyeNo": yevmiye_no,
                "KayitTarihi": tarih,
                "BelgeNo": extract_belge_no(satir_aciklama),
                "FisAciklamasi": satir_aciklama,
                "DetayAciklama": fis_aciklama,
                "HesapKodu": active_parent_code,
                "HesapAdi": active_parent_name,
                "MuavinKodu": col_a if col_a else active_parent_code,
                "MuavinAdi": col_b if col_b else active_parent_name,
                "Borc": borc,
                "Alacak": alacak,
                "KaynakDosya": dosya_adi
            })
            
    return processed_items