import pandas as pd
import sqlite3
import os
import sys
import calendar
import json
import numpy as np
from datetime import datetime

# --- DASHBOARD İÇİN GEREKLİ KÜTÜPHANELER ---
try:
    import customtkinter as ctk
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    import matplotlib.pyplot as plt
    HAS_DASHBOARD_LIBS = True
except ImportError:
    HAS_DASHBOARD_LIBS = False
    print("UYARI: customtkinter veya matplotlib eksik. Dashboard çalışmayacak.")

# --- PATH AYARLARI ---
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
try:
    from config import get_mukellefler_dir, get_base_dir
    from utils.session_db import get_last_session
except ImportError:
    # Bağımsız çalıştırılırsa fallback fonksiyonlar
    def get_mukellefler_dir(): return "."
    def get_last_session(): return {}
    def get_base_dir(): return "."

# --- JSON ENCODER ---
class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer): return int(obj)
        if isinstance(obj, np.floating): return float(obj)
        if isinstance(obj, np.ndarray): return obj.tolist()
        return super(NpEncoder, self).default(obj)

class FinancialReportEngine:
    def __init__(self, parent=None):
        self.df = pd.DataFrame()
        self.vkn = None
        self.year = None
        self.all_props = {} 
        self.mizan_cache = {} 
        self.status_msg = "Hazır"
        self.db_path = os.path.join(get_base_dir(), "financial_reports.db")
        
        # TDHP Eksi Karakterli (Düzenleyici) Hesaplar Listesi
        self.CONTRA_ACCOUNTS = ('103', '119', '122', '129', '199', '249', '257', '268', '278', '299', '322', '379', '422', '501', '580', '591')
        
        self._init_cache_db()
        self.load_data_meta()

    def _init_cache_db(self):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(report_cache)")
            columns = [col[1] for col in cursor.fetchall()]
            if columns and "period_type" not in columns:
                cursor.execute("DROP TABLE report_cache")
                conn.commit()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS report_cache (
                    vkn TEXT, year TEXT, report_type TEXT, period_type TEXT,
                    headers TEXT, rows TEXT, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (vkn, year, report_type, period_type)
                )
            """)
            conn.commit()
            conn.close()
        except Exception as e: print(f"DB Init Error: {e}")

    def load_data_meta(self):
        session = get_last_session()
        if session:
            self.vkn = session.get("vkn")
            self.year = session.get("year", session.get("yil"))

    def load_full_data(self):
        """
        Parquet dosyalarını okur, 'DetayAciklama' ve 'FisAciklamasi' 
        sütunlarını da hafızaya alır.
        """
        if not self.df.empty: return
        base_dir = get_mukellefler_dir()
        if not os.path.exists(base_dir) or not self.vkn: return
        
        # Kullanıcı klasörünü bul
        user_path = None
        target_folder_name = f"MUKELLEF-{self.vkn}"
        possible_path = os.path.join(base_dir, target_folder_name)
        
        if os.path.exists(possible_path): 
            user_path = possible_path
        else:
            for f in os.listdir(base_dir):
                if str(f).endswith(str(self.vkn)):
                    user_path = os.path.join(base_dir, f)
                    break
        
        if not user_path: return

        all_dfs = []
        try:
            sub_folders = os.listdir(user_path)
            for folder_year in sub_folders:
                if folder_year.isdigit() and len(folder_year) == 4:
                    target_file = os.path.join(user_path, folder_year, f"{folder_year}_FULL.parquet")
                    if os.path.exists(target_file):
                        try:
                            temp_df = pd.read_parquet(target_file)
                            # Sütun isimlerini normalize et
                            cols = {c.lower().strip(): c for c in temp_df.columns}
                            
                            # İstenen sütunları eşleştir
                            col_map = {
                                cols.get("kayittarihi", "Tarih"): "Tarih",
                                cols.get("yevmiyeno", "YevmiyeNo"): "YevmiyeNo",
                                cols.get("hesapkodu", "HesapKodu"): "HesapKodu",
                                cols.get("hesapadi", "HesapAdi"): "HesapAdi",
                                cols.get("borc", "Borc"): "Borc",
                                cols.get("alacak", "Alacak"): "Alacak",
                                cols.get("detayaciklama", "DetayAciklama"): "DetayAciklama", 
                                cols.get("fisaciklamasi", "FisAciklamasi"): "FisAciklamasi"   
                            }
                            
                            valid_cols = {k: v for k, v in col_map.items() if k in temp_df.columns}
                            temp_df.rename(columns=valid_cols, inplace=True)
                            
                            selection = ["Tarih", "YevmiyeNo", "HesapKodu", "HesapAdi", "Borc", "Alacak"]
                            if "DetayAciklama" in temp_df.columns: selection.append("DetayAciklama")
                            if "FisAciklamasi" in temp_df.columns: selection.append("FisAciklamasi")
                            
                            all_dfs.append(temp_df[selection])
                        except Exception as e: print(f"Hata ({folder_year}): {e}")

            if all_dfs:
                self.df = pd.concat(all_dfs, ignore_index=True)
                self.df.drop_duplicates(inplace=True)
                self.df['Tarih'] = pd.to_datetime(self.df['Tarih'], errors='coerce')
                
                for col in ["DetayAciklama", "FisAciklamasi"]:
                    if col in self.df.columns:
                        self.df[col] = self.df[col].astype(str).fillna("")

                if 'HesapKodu' in self.df.columns:
                    self.df['HesapKodu'] = self.df['HesapKodu'].astype(str).str.strip().str.replace(r'\.0$', '', regex=True)
                
                for c in ["Borc", "Alacak"]:
                    if c in self.df.columns: self.df[c] = pd.to_numeric(self.df[c], errors='coerce').fillna(0.0)
                
                if "YevmiyeNo" in self.df.columns:
                    self.df["YevmiyeNo"] = pd.to_numeric(self.df["YevmiyeNo"], errors='coerce').fillna(0).astype(int)
                    
        except Exception as e: self.status_msg = f"Veri Yükleme Hatası: {e}"

    def get_all_ledger_properties(self):
        db_path = os.path.join(get_base_dir(), "ledger_props.db")
        if not os.path.exists(db_path): return
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT year, opening_ids, reflection_ids, closing_ids FROM ledger_properties WHERE vkn=?", (str(self.vkn),))
            rows = cursor.fetchall()
            conn.close()
            self.all_props = {}
            for r in rows:
                y = int(r[0])
                def parse(ids): return [int(x) for x in str(ids).split(',') if x.strip().isdigit()] if ids else []
                self.all_props[y] = {"opening": parse(r[1]), "reflection": parse(r[2]), "closing": parse(r[3])}
        except: pass

    def _get_from_cache(self, r_type, p_type):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT headers, rows FROM report_cache WHERE vkn=? AND year=? AND report_type=? AND period_type=?", 
                           (str(self.vkn), str(self.year), r_type, p_type))
            row = cursor.fetchone()
            conn.close()
            return (json.loads(row[0]), json.loads(row[1])) if row else (None, None)
        except: return None, None

    def _save_to_cache(self, r_type, p_type, h, r):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("INSERT OR REPLACE INTO report_cache (vkn, year, report_type, period_type, headers, rows) VALUES (?,?,?,?,?,?)",
                           (str(self.vkn), str(self.year), r_type, p_type, json.dumps(h, cls=NpEncoder), json.dumps(r, cls=NpEncoder)))
            conn.commit()
            conn.close()
        except: pass

    def _detect_closing_ids(self, target_year):
        if self.df.empty: return []

        mask_date = (self.df['Tarih'].dt.year == target_year) & \
                    (self.df['Tarih'].dt.month == 12) & \
                    (self.df['Tarih'].dt.day == 31)
        
        df_eoy = self.df[mask_date]
        if df_eoy.empty: return []

        closing_ids = set()
        keywords = ["kapanış fişi", "kapanış", "kapanis", "kapanıs"]
        
        check_cols = []
        if "DetayAciklama" in df_eoy.columns: check_cols.append("DetayAciklama")
        if "FisAciklamasi" in df_eoy.columns: check_cols.append("FisAciklamasi")

        if check_cols:
            for col in check_cols:
                for keyword in keywords:
                    mask_keyword = df_eoy[col].str.contains(keyword, case=False, na=False)
                    ids = df_eoy.loc[mask_keyword, 'YevmiyeNo'].unique()
                    closing_ids.update(ids)

        if not closing_ids:
            max_yev = df_eoy['YevmiyeNo'].max()
            if pd.notna(max_yev) and max_yev > 0:
                closing_ids.add(int(max_yev))

        return list(closing_ids)

    def _prepare_mizan_for_period(self, end_date):
        if self.df.empty: return pd.DataFrame()
        target_year = end_date.year
        start_date = datetime(target_year, 1, 1)
        
        mask = (self.df['Tarih'] >= start_date) & (self.df['Tarih'] <= end_date)
        temp = self.df[mask]

        exclude_ids = self._detect_closing_ids(target_year)
        if exclude_ids: 
            temp = temp[~temp['YevmiyeNo'].isin(exclude_ids)]
        
        return temp.groupby("HesapKodu").agg({"HesapAdi": "first", "Borc": "sum", "Alacak": "sum"}).reset_index()

    def calculate_matrix(self, report_type, period_type, force_update=False):
        if not self.vkn: return [], []
        if not force_update:
            h, r = self._get_from_cache(report_type, period_type)
            if h and r: 
                self.status_msg = "Veri Tabanından Yüklendi"
                return h, r

        self.load_full_data()
        if self.df.empty: return [], []

        periods = []
        available_years = sorted(self.df['Tarih'].dt.year.dropna().unique(), reverse=True)
        if not available_years and self.year: available_years = [int(self.year)]

        try:
            if period_type == "Yıllık":
                for y in available_years: periods.append((str(y), datetime(y, 12, 31)))
            elif period_type == "3 Aylık":
                y = int(self.year) if self.year else available_years[0]
                for q in range(1, 5): periods.append((f"{y} / {q}.Çeyrek", datetime(y, q*3, calendar.monthrange(y, q*3)[1])))
            elif period_type == "Aylık":
                y = int(self.year) if self.year else available_years[0]
                for i, m in enumerate(["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"]):
                    periods.append((m, datetime(y, i+1, calendar.monthrange(y, i+1)[1])))
        except: return [], []

        self.mizan_cache = {p[0]: self._prepare_mizan_for_period(p[1]) for p in periods}
        headers = [p[0] for p in periods]
        rows = self._get_bilanco_structure(periods) if report_type == "Bilanço" else self._get_income_structure(periods)
        self._save_to_cache(report_type, period_type, headers, rows)
        self.status_msg = "Hesaplandı ve Kaydedildi"
        return headers, rows

    def get_multi_year_data(self):
        if not self.mizan_cache:
            self.calculate_matrix("Bilanço", "Yıllık", force_update=True)
        year_data = {}
        if self.mizan_cache:
            for key, df in self.mizan_cache.items():
                if key.isdigit() and len(key) == 4:
                    df_copy = df.copy()
                    if 'Bakiye' not in df_copy.columns: df_copy['Bakiye'] = df_copy['Borc'] - df_copy['Alacak']
                    df_copy['Kod'] = df_copy['HesapKodu'].astype(str)
                    year_data[int(key)] = df_copy
        if not year_data and self.mizan_cache:
             key = list(self.mizan_cache.keys())[0]
             df_copy = self.mizan_cache[key].copy()
             if 'Bakiye' not in df_copy.columns: df_copy['Bakiye'] = df_copy['Borc'] - df_copy['Alacak']
             df_copy['Kod'] = df_copy['HesapKodu'].astype(str)
             year_data[9999] = df_copy
        return year_data

    def _get_val_list(self, periods, group_code, nature="net"):
        """
        Bilanço değerlerini çeken geliştirilmiş mantık.
        """
        vals = []
        for p_label, _ in periods:
            df = self.mizan_cache.get(p_label)
            total = 0.0
            if df is not None and not df.empty:
                # O gruba ait tüm alt hesapları bul (örn: 10 grubundaki 100, 101, 103 vb.)
                mask = (df['HesapKodu'].str.startswith(str(group_code))) & (df['HesapKodu'].str.len() >= 3)
                sub = df[mask]
                
                if not sub.empty:
                    # İşlem gören 3 haneli hesap kodlarını benzersiz olarak al
                    active_codes = sub['HesapKodu'].str[:3].unique()
                    
                    for code in active_codes:
                        code_sub = df[df['HesapKodu'].str.startswith(str(code))]
                        
                        # Bilanço hesabı: Bakiye her zaman pozitif (mutlak) alınır
                        val = abs(code_sub['Borc'].sum() - code_sub['Alacak'].sum())
                        
                        # KURAL 1: Negatif değer almamalı
                        # Eğer çağrılan group_code 3 haneli spesifik bir hesapsa (Örn: 103), değeri pozitif bırak.
                        # Eğer çağrılan group_code 1 veya 2 haneliyse (Ana grup toplamı), o zaman eksi karakterli hesapları toplamdan DÜŞ.
                        if len(str(group_code)) < 3 and str(code) in self.CONTRA_ACCOUNTS:
                            total -= val
                        else:
                            total += val
                            
            vals.append(float(total))
        return vals

    def _get_income_val(self, periods, code, nature):
        """
        Gelir Tablosu (6'lı grup) değerlerini çeken mantık.
        Gelirler Alacak'tan, Giderler Borç'tan toplanır. Negatif olmaz.
        """
        vals = []
        for p_label, _ in periods:
            df = self.mizan_cache.get(p_label)
            val = 0.0
            if df is not None and not df.empty:
                sub = df[df['HesapKodu'].str.startswith(str(code))]
                if not sub.empty:
                    if nature == "income": 
                        val = sub['Alacak'].sum()
                    elif nature == "expense": 
                        val = sub['Borc'].sum()
            vals.append(float(val))
        return vals

    def _get_bilanco_structure(self, periods):
        def find_active_sub_accounts(group_code):
            found = {} 
            for p_label, _ in periods:
                df = self.mizan_cache.get(p_label)
                if df is not None and not df.empty:
                    mask = (df['HesapKodu'].str.startswith(str(group_code))) & (df['HesapKodu'].str.len() == 3)
                    sub = df[mask]
                    for _, r in sub.iterrows():
                        if r['HesapKodu'] not in found: found[r['HesapKodu']] = r['HesapAdi']
            return dict(sorted(found.items()))
        
        def grp_auto(txt, group_code):
            sub_dict = find_active_sub_accounts(group_code)
            children = []
            for code, name in sub_dict.items():
                children.append({"text": f"{code} {name}", "vals": self._get_val_list(periods, code, "net"), "type": "item"})
            group_vals = self._get_val_list(periods, group_code, "net")
            return {"text": txt, "vals": group_vals, "type": "group", "children": children}
            
        def gv(c): return self._get_val_list(periods, c, "net")
        
        donen = gv("1"); duran = gv("2")
        aktif = [donen[i]+duran[i] for i in range(len(periods))]
        kisa = gv("3"); uzun = gv("4"); ozk = gv("5")
        pasif = [kisa[i]+uzun[i]+ozk[i] for i in range(len(periods))]
        
        return [
            {"text": "AKTİF (VARLIKLAR)", "vals": ["" for _ in periods], "type": "header", "children":[]},
            {"text": "I. DÖNEN VARLIKLAR", "vals": donen, "type": "total", "children": []},
            grp_auto("A. HAZIR DEĞERLER", "10"), grp_auto("B. MENKUL KIYMETLER", "11"), grp_auto("C. TİCARİ ALACAKLAR", "12"), grp_auto("D. DİĞER ALACAKLAR", "13"), grp_auto("E. STOKLAR", "15"), grp_auto("F. YILLARA YAYGIN İNŞ.", "17"), grp_auto("G. GELİR TAHAKKUKLARI", "18"), grp_auto("H. DİĞER DÖNEN VARLIKLAR", "19"),
            {"text": "DÖNEN VARLIKLAR TOPLAMI", "vals": donen, "type": "total_final", "children":[]},
            {"text": "II. DURAN VARLIKLAR", "vals": duran, "type": "total", "children": []},
            grp_auto("A. TİCARİ ALACAKLAR", "22"), grp_auto("B. DİĞER ALACAKLAR", "23"), grp_auto("C. MALİ DURAN VARLIKLAR", "24"), grp_auto("D. MADDİ DURAN VARLIKLAR", "25"), grp_auto("E. MADDİ OLMAYAN DURAN VARLIKLAR", "26"), grp_auto("F. ÖZEL TÜKENMEYE TABİ VARLIKLAR", "27"), grp_auto("G. GELECEK YILLARA AİT GİDERLER", "28"), grp_auto("H. DİĞER DURAN VARLIKLAR", "29"),
            {"text": "DURAN VARLIKLAR TOPLAMI", "vals": duran, "type": "total_final", "children":[]},
            {"text": "AKTİF TOPLAMI", "vals": aktif, "type": "total_final", "children":[]},
            {"text": "", "vals": ["" for _ in periods], "type": "spacer", "children":[]},
            {"text": "PASİF (KAYNAKLAR)", "vals": ["" for _ in periods], "type": "header", "children":[]},
            {"text": "III. KISA VADELİ YABANCI KAYNAKLAR", "vals": kisa, "type": "total", "children":[]},
            grp_auto("A. MALİ BORÇLAR", "30"), grp_auto("B. TİCARİ BORÇLAR", "32"), grp_auto("C. DİĞER BORÇLAR", "33"), grp_auto("D. ALINAN AVANSLAR", "34"), grp_auto("E. YILLARA YAYGIN İNŞ.", "35"), grp_auto("F. ÖDENECEK VERGİLER", "36"), grp_auto("G. BORÇ VE GİDER KARŞILIKLARI", "37"), grp_auto("H. GELECEK AYLARA AİT GELİRLER", "38"), grp_auto("I. DİĞER KISA VADELİ YK.", "39"),
            {"text": "KISA VADELİ YK. TOPLAMI", "vals": kisa, "type": "total_final", "children":[]},
            {"text": "IV. UZUN VADELİ YABANCI KAYNAKLAR", "vals": uzun, "type": "total", "children":[]},
            grp_auto("A. MALİ BORÇLAR", "40"), grp_auto("B. TİCARİ BORÇLAR", "42"), grp_auto("C. DİĞER BORÇLAR", "43"), grp_auto("D. ALINAN AVANSLAR", "44"), grp_auto("E. BORÇ VE GİDER KARŞILIKLARI", "47"), grp_auto("F. GELECEK YILLARA AİT GELİRLER", "48"), grp_auto("G. DİĞER UZUN VADELİ YK.", "49"),
            {"text": "UZUN VADELİ YK. TOPLAMI", "vals": uzun, "type": "total_final", "children":[]},
            {"text": "V. ÖZ KAYNAKLAR", "vals": ozk, "type": "total", "children":[]},
            grp_auto("A. ÖDENMİŞ SERMAYE", "50"), grp_auto("B. SERMAYE YEDEKLERİ", "52"), grp_auto("C. KAR YEDEKLERİ", "54"), grp_auto("D. GEÇMİŞ YILLAR KARLARI", "57"), grp_auto("E. GEÇMİŞ YILLAR ZARARLARI (-)", "58"), grp_auto("F. DÖNEM NET KARI (ZARARI)", "59"),
            {"text": "ÖZ KAYNAKLAR TOPLAMI", "vals": ozk, "type": "total_final", "children":[]},
            {"text": "PASİF TOPLAMI", "vals": pasif, "type": "total_final", "children":[]}
        ]

    def _get_income_structure(self, periods):
        def L(a, b, op): return [x + y if op == "+" else x - y for x, y in zip(a, b)]
        def SUM(*ls): return [sum(x) for x in zip(*ls)] if ls else [0.0]*len(periods)
        
        def sub_items_auto(prefix, nature):
            found = {}
            for p_label, _ in periods:
                df = self.mizan_cache.get(p_label)
                if df is not None and not df.empty:
                    mask = (df['HesapKodu'].str.startswith(str(prefix))) & (df['HesapKodu'].str.len() == 3)
                    sub = df[mask]
                    for _, r in sub.iterrows():
                        if r['HesapKodu'] not in found: found[r['HesapKodu']] = r['HesapAdi']
            sorted_codes = sorted(found.keys())
            res = []
            vals_list = []
            for code in sorted_codes:
                v = self._get_income_val(periods, code, nature)
                res.append({"text": f"{code} {found[code]}", "vals": v, "type": "item"})
                vals_list.append(v)
            if not vals_list: return res, [0.0]*len(periods)
            return res, SUM(*vals_list)
            
        items_a, grp_a = sub_items_auto("60", "income"); items_b, grp_b = sub_items_auto("61", "expense")
        grp_c = L(grp_a, grp_b, "-")
        items_d, grp_d = sub_items_auto("62", "expense"); res_brut = L(grp_c, grp_d, "-")
        items_e, grp_e = sub_items_auto("63", "expense"); res_faal = L(res_brut, grp_e, "-")
        items_f, grp_f = sub_items_auto("64", "income"); items_g, grp_g = sub_items_auto("65", "expense")
        items_h, grp_h = sub_items_auto("66", "expense")
        res_olagan = L(L(L(res_faal, grp_f, "+"), grp_g, "-"), grp_h, "-")
        items_i, grp_i = sub_items_auto("67", "income"); items_j, grp_j = sub_items_auto("68", "expense")
        res_donem = L(L(res_olagan, grp_i, "+"), grp_j, "-")
        items_k, grp_k = sub_items_auto("691", "expense"); res_net = L(res_donem, grp_k, "-")
        
        return [
            {"text":"A- BRÜT SATIŞLAR","vals":grp_a,"type":"group","children":items_a},
            {"text":"B- SATIŞ İNDİRİMLERİ (-)","vals":grp_b,"type":"group","children":items_b},
            {"text":"C- NET SATIŞLAR","vals":grp_c,"type":"total","children":[]},
            {"text":"D- SATIŞLARIN MALİYETİ (-)","vals":grp_d,"type":"group","children":items_d},
            {"text":"BRÜT SATIŞ KARI/ZARARI","vals":res_brut,"type":"total","children":[]},
            {"text":"E- FAALİYET GİDERLERİ (-)","vals":grp_e,"type":"group","children":items_e},
            {"text":"FAALİYET KARI/ZARARI","vals":res_faal,"type":"total","children":[]},
            {"text":"F- DİĞER OLAĞAN GELİRLER","vals":grp_f,"type":"group","children":items_f},
            {"text":"G- DİĞER OLAĞAN GİDERLER (-)","vals":grp_g,"type":"group","children":items_g},
            {"text":"H- FİNANSMAN GİDERLERİ (-)","vals":grp_h,"type":"group","children":items_h},
            {"text":"OLAĞAN KAR/ZARAR","vals":res_olagan,"type":"total","children":[]},
            {"text":"I- OLAĞANDIŞI GELİRLER","vals":grp_i,"type":"group","children":items_i},
            {"text":"J- OLAĞANDIŞI GİDERLER (-)","vals":grp_j,"type":"group","children":items_j},
            {"text":"DÖNEM KARI/ZARARI","vals":res_donem,"type":"total","children":[]},
            {"text":"K- VERGİ VE YASAL YÜK. (-)","vals":grp_k,"type":"group","children":items_k},
            {"text":"DÖNEM NET KARI/ZARARI","vals":res_net,"type":"total_final","children":[]}
        ]

    def get_analysis_result(self, raw_headers, raw_rows, analysis_type, report_type):
        if analysis_type == "Beyan": return raw_headers, raw_rows
        elif analysis_type == "Yatay Analiz": return self._apply_horizontal(raw_headers, raw_rows)
        elif analysis_type == "Düşey Analiz": return self._apply_vertical(raw_headers, raw_rows, report_type)
        return raw_headers, raw_rows

    def _apply_horizontal(self, headers, rows):
        new_headers = []
        for i, h in enumerate(headers):
            new_headers.append(h)
            if i > 0: new_headers.append(f"{h} %")
        def process_recursive(item_list):
            new_list = []
            for item in item_list:
                new_item = item.copy()
                orig_vals = item["vals"]
                new_vals = []
                for i, val in enumerate(orig_vals):
                    new_vals.append(val)
                    if i > 0:
                        prev = orig_vals[i-1]
                        curr = val
                        if isinstance(prev, (int, float)) and isinstance(curr, (int, float)):
                            if prev != 0: change = ((curr - prev) / abs(prev)) * 100
                            else: change = 100.0 if curr > 0 else 0.0
                            new_vals.append(change)
                        else: new_vals.append(0.0)
                new_item["vals"] = new_vals
                if "children" in item and item["children"]:
                    new_item["children"] = process_recursive(item["children"])
                new_list.append(new_item)
            return new_list
        return new_headers, process_recursive(rows)

    def _apply_vertical(self, headers, rows, report_type):
        base_values = [0.0] * len(headers)
        def find_base(items, target_text):
            for item in items:
                if target_text in item["text"]: return item["vals"]
                if "children" in item:
                    res = find_base(item["children"], target_text)
                    if res: return res
            return None
        target = "AKTİF TOPLAMI" if report_type == "Bilanço" else "C- NET SATIŞLAR"
        found_base = find_base(rows, target)
        if not found_base and report_type == "Gelir Tablosu": found_base = find_base(rows, "A- BRÜT SATIŞLAR")
        if found_base: base_values = found_base
        new_headers = []
        for h in headers:
            new_headers.append(h)
            new_headers.append(f"{h} Pay %")
        def process_recursive(item_list):
            new_list = []
            for item in item_list:
                new_item = item.copy()
                orig_vals = item["vals"]
                new_vals = []
                for i, val in enumerate(orig_vals):
                    new_vals.append(val)
                    base = base_values[i] if i < len(base_values) else 0
                    if isinstance(val, (int, float)) and isinstance(base, (int, float)) and base != 0:
                        new_vals.append((val / base) * 100)
                    else: new_vals.append(0.0)
                new_item["vals"] = new_vals
                if "children" in item and item["children"]:
                    new_item["children"] = process_recursive(item["children"])
                new_list.append(new_item)
            return new_list
        return new_headers, process_recursive(rows)

# =============================================================================
# POWER BI STİLİ DASHBOARD SINIFI
# =============================================================================
if HAS_DASHBOARD_LIBS:
    THEME = {
        "bg_main": "#252433", "bg_card": "#2F2F41", "text_white": "#FFFFFF",
        "text_gray": "#8D8D99", "gold": "#F2C94C", "red": "#EB5757",
        "blue": "#2F80ED", "green": "#27AE60"
    }
    try:
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("dark-blue")
    except: pass

    class PowerBIBoard(ctk.CTkToplevel):
        def __init__(self, parent, data_dict):
            super().__init__(parent)
            self.title("Mali Analiz - Yönetici Kokpiti")
            self.geometry("1400x900")
            self.configure(fg_color=THEME["bg_main"])
            self.protocol("WM_DELETE_WINDOW", self.on_closing)
            try: self.state("zoomed")
            except: pass

            self.raw_data = data_dict
            self.years = sorted(list(data_dict.keys()))
            self.current_year = self.years[-1] if self.years else datetime.now().year
            self.df_summary = self.process_accounting_data()
            self.setup_layout()
            self.after(100, lambda: self.update_charts(self.current_year))

        def on_closing(self):
            plt.close('all')
            self.destroy()

        def process_accounting_data(self):
            summary_list = []
            for year in self.years:
                df = self.raw_data[year]
                def get_sum(codes, col="Bakiye"):
                    if df.empty: return 0.0
                    mask = df['Kod'].astype(str).str.startswith(tuple(codes))
                    subset = df[mask]
                    if col == "Bakiye" and "Bakiye" not in df.columns:
                        return (subset['Borc'] - subset['Alacak']).sum()
                    return subset[col].sum() if col in subset.columns else 0.0

                gross = get_sum(['600', '601'], "Alacak")
                disc = get_sum(['610', '611', '612'], "Borc")
                net_rev = gross - disc
                cogs = get_sum(['620', '621', '622', '623'], "Borc")
                g_profit = net_rev - cogs
                opex = get_sum(['630', '631', '632'], "Borc")
                ebit = g_profit - opex
                fin = get_sum(['660', '661', '780'], "Borc")
                tax = get_sum(['691'], "Borc")
                net = get_sum(['690', '692'], "Alacak") - get_sum(['690', '692'], "Borc")
                
                if net == 0 and net_rev > 0:
                    other_inc = get_sum(['64'], "Alacak")
                    other_exp = get_sum(['65'], "Borc")
                    net = ebit + other_inc - other_exp - fin - tax

                summary_list.append({
                    "Year": year, "Revenue": net_rev, "COGS": -cogs,
                    "Gross Profit": g_profit, "Opex": -opex, "EBIT": ebit,
                    "Interest_Tax": -(fin + tax), "Net Profit": net
                })
            return pd.DataFrame(summary_list)

        def setup_layout(self):
            self.sidebar = ctk.CTkFrame(self, width=220, corner_radius=0, fg_color="#1E1E2C")
            self.sidebar.pack(side="left", fill="y")
            ctk.CTkLabel(self.sidebar, text="FİNANSAL\nKOKPİT", font=("Roboto", 22, "bold"), text_color=THEME["gold"]).pack(pady=40)
            
            ctk.CTkLabel(self.sidebar, text="Dönem Seçimi", text_color="white", anchor="w").pack(fill="x", padx=20, pady=(20,5))
            self.combo_year = ctk.CTkComboBox(self.sidebar, values=[str(y) for y in self.years], command=self.on_year_change)
            if str(self.current_year) in [str(y) for y in self.years]: self.combo_year.set(str(self.current_year))
            self.combo_year.pack(fill="x", padx=20)

            self.main_area = ctk.CTkFrame(self, fg_color="transparent")
            self.main_area.pack(side="right", fill="both", expand=True, padx=20, pady=20)

            self.kpi_frame = ctk.CTkFrame(self.main_area, fg_color="transparent", height=100)
            self.kpi_frame.pack(fill="x", pady=(0, 20))
            self.kpi_lbls = {}
            for m in ["Revenue", "Gross Profit", "EBIT", "Net Profit"]:
                card = ctk.CTkFrame(self.kpi_frame, fg_color=THEME["bg_card"], corner_radius=10)
                card.pack(side="left", fill="both", expand=True, padx=5)
                self.kpi_lbls[m] = ctk.CTkLabel(card, text="...", font=("Roboto", 20, "bold"), text_color=THEME["gold"])
                self.kpi_lbls[m].pack(pady=(15,0))
                ctk.CTkLabel(card, text=m.upper(), font=("Roboto", 10), text_color=THEME["text_gray"]).pack(pady=(2,15))

            self.charts_frame = ctk.CTkFrame(self.main_area, fg_color="transparent")
            self.charts_frame.pack(fill="both", expand=True)
            self.charts_frame.grid_columnconfigure(0, weight=1)
            self.charts_frame.grid_rowconfigure(0, weight=1)
            self.charts_frame.grid_rowconfigure(1, weight=1)

        def update_charts(self, year):
            try:
                row = self.df_summary[self.df_summary['Year'] == int(year)]
                if row.empty: return
            except: return
            for m in ["Revenue", "Gross Profit", "EBIT", "Net Profit"]:
                self.kpi_lbls[m].configure(text=f"{row[m].values[0]:,.0f} ₺")
            for w in self.charts_frame.winfo_children(): w.destroy()

            # Trend Grafik
            fr_top = ctk.CTkFrame(self.charts_frame, fg_color=THEME["bg_card"])
            fr_top.grid(row=0, column=0, sticky="nsew", pady=(0, 10))
            fig1, ax1 = plt.subplots(figsize=(8, 3), facecolor=THEME["bg_card"])
            ax1.bar(self.df_summary['Year'].astype(str), self.df_summary['Revenue'], color=THEME["blue"], alpha=0.7)
            ax2 = ax1.twinx()
            marg = (self.df_summary['Net Profit']/self.df_summary['Revenue']*100).fillna(0)
            ax2.plot(self.df_summary['Year'].astype(str), marg, color=THEME["gold"], marker='o', lw=2)
            ax1.set_title("Ciro ve Karlılık Trendi", color="white", loc="left", fontsize=10)
            for ax in [ax1, ax2]: 
                ax.patch.set_alpha(0)
                ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
                ax.spines['bottom'].set_visible(False); ax.spines['left'].set_visible(False)
                ax.tick_params(colors='white', labelsize=8)
                ax.grid(False)
            canvas1 = FigureCanvasTkAgg(fig1, fr_top)
            canvas1.draw()
            canvas1.get_tk_widget().pack(fill="both", expand=True, padx=5, pady=5)

            # Waterfall Grafik
            fr_bot = ctk.CTkFrame(self.charts_frame, fg_color=THEME["bg_card"])
            fr_bot.grid(row=1, column=0, sticky="nsew")
            vals = [row[c].values[0] for c in ['Revenue', 'COGS', 'Gross Profit', 'Opex', 'EBIT', 'Interest_Tax', 'Net Profit']]
            steps = ['Gelir', 'Maliyet', 'Brüt', 'Gider', 'F.Kar', 'Vergi', 'Net']
            fig2, ax3 = plt.subplots(figsize=(8, 3.5), facecolor=THEME["bg_card"])
            colors = [THEME["blue"], THEME["red"], THEME["gold"], THEME["red"], THEME["gold"], THEME["red"], THEME["green"]]
            x_pos = range(len(steps))
            ax3.bar(x_pos, [abs(v) for v in vals], color=colors)
            for i, v in enumerate(vals):
                txt = f"{v/1000:.0f}K"
                ax3.text(i, abs(v), txt, ha='center', va='bottom', color='white', fontsize=8)
            ax3.set_title(f"{year} Detay Analizi", color="white", loc="left", fontsize=10)
            ax3.set_xticks(x_pos)
            ax3.set_xticklabels(steps, color="white", fontsize=8)
            ax3.get_yaxis().set_visible(False)
            ax3.patch.set_alpha(0)
            for s in ax3.spines.values(): s.set_visible(False)
            canvas2 = FigureCanvasTkAgg(fig2, fr_bot)
            canvas2.draw()
            canvas2.get_tk_widget().pack(fill="both", expand=True, padx=5, pady=5)

        def on_year_change(self, choice):
            self.update_charts(choice)
else:
    class PowerBIBoard:
        def __init__(self, parent, data):
             from tkinter import messagebox
             messagebox.showerror("Hata", "Gerekli kütüphaneler (customtkinter) yüklü değil.\nLütfen 'pip install customtkinter' çalıştırın.")