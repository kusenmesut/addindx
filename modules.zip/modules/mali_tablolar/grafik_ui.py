import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import sys
import os

# --- KLASÖR YOLU (PATH) YAMASI ---
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.abspath(os.path.join(current_dir, '..'))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

try:
    from mizan_analiz.engine import FinancialReportEngine
except ImportError:
    try:
        from engine import FinancialReportEngine
    except ImportError as e:
        print(f"Modül yükleme hatası: {e}")
        FinancialReportEngine = None

# --- GÖRSEL TEMA ---
THEME = {
    "bg_main": "#252433", "bg_card": "#2F2F41", 
    "text_white": "#FFFFFF", "text_gray": "#8D8D99",
    "gold": "#F2C94C", "red": "#EB5757", "blue": "#2F80ED", "green": "#27AE60",
    "purple": "#9B51E0", "orange": "#F2994A", "cyan": "#56CCF2",
    "tooltip_bg": "#FFFACD", "tooltip_border": "#F2994A"
}

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")

# --- 20 ADET ÖZET GRAFİK AÇIKLAMALARI ---
CHART_INFO = {
    "G1": "Grafik 1 - Ciro ve Net Kâr Trendi:\nYıllar itibarıyla Ciro büyümesini ve Net Kâr seviyesindeki değişimi gösterir.",
    "G2": "Grafik 2 - Kârlılık Şelalesi (Waterfall):\nCirodan başlayarak maliyet ve giderlerin düşülmesiyle Net Kâra nasıl ulaşıldığını adım adım gösterir.",
    "G3": "Grafik 3 - Gelir Kaynakları:\nBrüt satışların (600, 601, 602) kendi içindeki dağılımını ifade eder.",
    "G4": "Grafik 4 - Gider ve Maliyet Yapısı:\nİşletmenin toplam harcamalarının ne kadarının SMM, ne kadarının Faaliyet Gideri ve Finansman olduğunu oranlar.",
    "G5": "Grafik 5 - Kâr Marjları Trendi:\nBrüt Kâr, FAVÖK ve Net Kâr Marjlarının (İlgili Kâr / Ciro) yıllar içindeki gelişimini yüzdesel olarak sunar.",
    "G6": "Grafik 6 - Faaliyet Giderleri Kırılımı:\n630 Ar-Ge, 631 Pazarlama ve 632 Yönetim giderlerinin faaliyet giderleri içindeki payıdır.",
    "G7": "Grafik 7 - 100 TL'nin Dağılımı:\nElde edilen her 100 TL'lik Ciro'nun ne kadarının Maliyete, Gidere ve Kâra dönüştüğünü gösteren dikey analizdir.",
    "G8": "Grafik 8 - Operasyonel vs Finansman:\nEsas faaliyetlerden kazanılan para (FAVÖK) ile Finansman Giderlerinin (Faiz vb.) kıyaslamasıdır. Ödeme gücünü gösterir.",
    "G9": "Grafik 9 - Kambiyo Performansı:\nKur Farkı ve Kambiyo Karları (646) ile Kambiyo Zararlarının (656) karşılaştırmasıdır.",
    "G10": "Grafik 10 - Ana vs Yan Faaliyetler:\nŞirketin kazancının ne kadarının Esas Faaliyetten, ne kadarının Diğer Gelir/Gider (64-65) kalemlerinden geldiğini ölçer.",
    "G11": "Grafik 11 - İşletme Sermayesi İhtiyacı:\nTicari Alacaklar (12) ile Ticari Borçların (32) kıyaslamasıdır. Alacakların borçları karşılama durumunu gösterir.",
    "G12": "Grafik 12 - Nakit ve Borç Dengesi:\nHazır Değerler (10) ile Kısa Vadeli Mali Borçların (30) karşılaştırmasıdır. Ani likidite durumunu ölçer.",
    "G13": "Grafik 13 - Finansal Kaldıraç Oranı:\nŞirketin kaynaklarının ne kadarının Özkaynak (5), ne kadarının Yabancı Kaynak (Borç - 3, 4) olduğunu gösterir.",
    "G14": "Grafik 14 - Borç Vade Yapısı:\nToplam Yabancı Kaynaklar içinde Kısa Vadeli (3) ve Uzun Vadeli (4) borçların dağılımıdır.",
    "G15": "Grafik 15 - Vergi Yükü Oranı:\nVergi Öncesi Ticari Kâr (690) üzerinden ne kadarlık Dönem Vergi Karşılığı (691) ayrıldığını gösterir.",
    "G16": "Grafik 16 - Olağandışı Kalemlerin Hacmi:\nOlağandışı Gelir (679) ve Gider (689) hesaplarının büyüklüğüdür. Kalitenin sürekliliğini analiz eder.",
    "G17": "Grafik 17 - Finansman Yükü Trendi:\nFinansman Giderlerinin Ciroya oranının yıllar içindeki trendidir.",
    "G18": "Grafik 18 - Satış İndirim Oranı:\nToplam Brüt Satışların yüzde kaçının İndirim, İade veya İskonto (61) olarak geri döndüğünü gösterir.",
    "G19": "Grafik 19 - KKEG Risk Tahmini:\nDiğer Olağandışı Giderler (689) hesabının, toplam Faaliyet Giderleri (63) içindeki payıdır. İnceleme riskini gösterir.",
    "G20": "Grafik 20 - Kârın Kur Bağımlılığı:\nRaporlanan Net Kâr ile, Kur Farkı/Kambiyo etkisinden (646, 656) arındırılmış Net Kârın kıyaslamasıdır."
}

def fmt_num(val):
    if abs(val) >= 1_000_000: return f'{val/1_000_000:.1f}M'
    elif abs(val) >= 1_000: return f'{val/1_000:.0f}K'
    else: return f'{val:.0f}'

class PowerBIBoard(ctk.CTkToplevel):
    def __init__(self, parent, data_dict):
        super().__init__(parent)
        self.title("Yönetici Kokpiti - Özet Mali Analiz")
        self.geometry("1500x950")
        self.configure(fg_color=THEME["bg_main"])
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

        self.lift()
        self.focus_force()
        try: self.state("zoomed")
        except: pass
        
        self.raw_data = data_dict
        self.years = sorted(list(data_dict.keys()))
        self.current_year = self.years[-1] if self.years else 2024
        
        self.df_summary = self.process_accounting_data()
        self.active_view = "🏠 Genel Bakış"

        self.setup_layout()
        self.after(100, self.update_view)

    def on_closing(self):
        try:
            plt.close('all')
            self.destroy()
        except: pass

    def get_account_balance(self, year, code_start, bal_type="net"):
        if year not in self.raw_data: return 0.0
        df = self.raw_data[year]
        if df.empty: return 0.0
        mask = df['Kod'].astype(str).str.startswith(tuple(code_start))
        sub = df[mask]
        if sub.empty: return 0.0
        
        cols = {c.lower(): c for c in sub.columns}
        col_b = cols.get('borc', 'Borc')
        col_a = cols.get('alacak', 'Alacak')
        borc = sub[col_b].sum() if col_b in sub.columns else 0.0
        alacak = sub[col_a].sum() if col_a in sub.columns else 0.0
        
        if bal_type == "borc": return float(borc)
        if bal_type == "alacak": return float(alacak)
        return float(borc - alacak) 

    def process_accounting_data(self):
        summary_list = []
        for year in self.years:
            gross_sales = self.get_account_balance(year, ['600', '601', '602'], "alacak")
            discounts = self.get_account_balance(year, ['610', '611', '612'], "borc")
            net_rev = gross_sales - discounts
            cogs = self.get_account_balance(year, ['620', '621', '622', '623'], "borc")
            g_prof = net_rev - cogs
            opex = self.get_account_balance(year, ['630', '631', '632'], "borc")
            ebit = g_prof - opex
            
            fin_exp = self.get_account_balance(year, ['660', '661', '780'], "borc")
            other_inc = self.get_account_balance(year, ['64'], "alacak")
            other_exp = self.get_account_balance(year, ['65'], "borc")
            tax = self.get_account_balance(year, ['691'], "borc")
            
            net_prof = self.get_account_balance(year, ['690', '692'], "alacak") - self.get_account_balance(year, ['690', '692'], "borc")
            if net_prof == 0 and net_rev > 0:
                net_prof = ebit + other_inc - other_exp - fin_exp - tax

            summary_list.append({
                "Year": year, "Ciro": net_rev, "SMM": -cogs, "Brüt Kar": g_prof,
                "Faal.Gid.": -opex, "FAVÖK": ebit, "Net Kar": net_prof
            })
        return pd.DataFrame(summary_list)

    def setup_layout(self):
        self.sidebar = ctk.CTkFrame(self, width=240, corner_radius=0, fg_color="#1E1E2C")
        self.sidebar.pack(side="left", fill="y")
        ctk.CTkLabel(self.sidebar, text="YÖNETİCİ\nKOKPİTİ", font=("Roboto", 24, "bold"), text_color=THEME["gold"]).pack(pady=30)
        
        ctk.CTkLabel(self.sidebar, text="Dönem", text_color="gray", anchor="w").pack(fill="x", padx=20, pady=(10,5))
        self.combo_year = ctk.CTkComboBox(self.sidebar, values=[str(y) for y in self.years], command=self.on_year_change, 
                                          fg_color=THEME["bg_card"], border_color=THEME["bg_card"])
        if str(self.current_year) in [str(y) for y in self.years]: self.combo_year.set(str(self.current_year))
        self.combo_year.pack(fill="x", padx=20)

        ctk.CTkLabel(self.sidebar, text="GÖRÜNÜMLER", text_color="gray", anchor="w", font=("Arial", 10, "bold")).pack(fill="x", padx=20, pady=(30,5))
        self.nav_buttons = {}
        menus = [
            "🏠 Genel Bakış", 
            "📈 Karlılık ve Verimlilik", 
            "⚖️ Risk ve Finansman",
            "💼 Bilanço ve Likidite",
            "🔍 Özel Yönetsel Analizler"
        ]
        
        for m in menus:
            btn = ctk.CTkButton(self.sidebar, text=f" {m}", fg_color="transparent", anchor="w", 
                                text_color="#A0A0A0", hover_color=THEME["bg_card"], height=45, font=("Roboto", 13),
                                command=lambda x=m: self.change_view(x))
            btn.pack(fill="x", padx=10, pady=2)
            self.nav_buttons[m] = btn

        self.main_area = ctk.CTkFrame(self, fg_color="transparent")
        self.main_area.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        
        self.kpi_frame = ctk.CTkFrame(self.main_area, fg_color="transparent", height=80)
        self.kpi_frame.pack(fill="x", pady=(0, 10))
        self.setup_kpi_cards()
        
        self.scroll_frame = ctk.CTkScrollableFrame(self.main_area, fg_color="transparent")
        self.scroll_frame.pack(fill="both", expand=True)

    def setup_kpi_cards(self):
        self.kpi_widgets = {}
        metrics = ["Ciro", "Brüt Kar", "FAVÖK", "Net Kar"]
        for key in metrics:
            card = ctk.CTkFrame(self.kpi_frame, fg_color=THEME["bg_card"], corner_radius=10)
            card.pack(side="left", fill="both", expand=True, padx=5)
            val = ctk.CTkLabel(card, text="...", font=("Roboto", 22, "bold"), text_color=THEME["gold"])
            val.pack(pady=(10,0))
            title = ctk.CTkLabel(card, text=key, font=("Arial", 12), text_color="gray")
            title.pack(pady=(0,10))
            self.kpi_widgets[key] = val

    def add_chart_with_features(self, fig, row, col, title, chart_id, rowspan=1, colspan=1):
        fr = ctk.CTkFrame(self.scroll_frame, fg_color=THEME["bg_card"], corner_radius=10)
        fr.grid(row=row, column=col, rowspan=rowspan, columnspan=colspan, sticky="nsew", padx=5, pady=5)
        
        header_fr = ctk.CTkFrame(fr, fg_color="transparent", height=30)
        header_fr.pack(fill="x", padx=10, pady=5)
        lbl = ctk.CTkLabel(header_fr, text=title, font=("Arial", 12, "bold"), text_color="white", anchor="w")
        lbl.pack(side="left")
        info_btn = ctk.CTkButton(header_fr, text="?", width=25, height=25, corner_radius=12,
                                 fg_color="#4B4B5E", hover_color="#6B6B7F", text_color="white",
                                 command=lambda cid=chart_id: self.show_chart_info(cid, title))
        info_btn.pack(side="right")
        
        canvas = FigureCanvasTkAgg(fig, master=fr)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=5, pady=5)
        plt.close(fig)

    def show_chart_info(self, chart_id, title):
        info_text = CHART_INFO.get(chart_id, "Detay yok.")
        top = ctk.CTkToplevel(self)
        top.title("Bilgi")
        top.geometry("400x250")
        top.attributes("-topmost", True)
        top.configure(fg_color=THEME["bg_card"])
        ctk.CTkLabel(top, text=title, font=("Roboto", 14, "bold"), text_color=THEME["gold"]).pack(pady=10)
        ctk.CTkTextbox(top, width=380, height=180, fg_color="#1E1E2C", text_color="white", wrap="word").pack(pady=5, padx=10)
        top.children["!ctktextbox"].insert("0.0", info_text)
        top.children["!ctktextbox"].configure(state="disabled")

    def create_fig(self, figsize=(5, 4)):
        fig, ax = plt.subplots(figsize=figsize, facecolor=THEME["bg_card"])
        ax.set_facecolor(THEME["bg_card"])
        ax.tick_params(colors="white", labelsize=9)
        for s in ax.spines.values(): s.set_visible(False)
        return fig, ax

    def add_labels(self, ax, container=None, fmt='num'):
        if container:
            if fmt == 'num':
                ax.bar_label(container, fmt=lambda x: fmt_num(x), color='white', padding=3, fontsize=9)
            elif fmt == 'pct':
                ax.bar_label(container, fmt='%.1f%%', color='white', padding=3, fontsize=9)
        else:
            for line in ax.lines:
                y_data = line.get_ydata()
                x_data = line.get_xdata()
                for i, y in enumerate(y_data):
                    lbl = fmt_num(y) if fmt == 'num' else f"{y:.1f}%"
                    ax.annotate(lbl, (x_data[i], y), textcoords="offset points", xytext=(0,5), ha='center', color='white', fontsize=9)

    # ------------------ 1. GENEL BAKIŞ ------------------
    def draw_overview(self, year):
        self.scroll_frame.grid_columnconfigure((0,1), weight=1)
        
        fig1, ax1 = self.create_fig(figsize=(6, 4))
        if len(self.df_summary) > 1:
            yrs = self.df_summary['Year'].astype(str)
            ax1.bar(yrs, self.df_summary['Ciro'], color=THEME["blue"], label="Ciro", alpha=0.8)
            ax2 = ax1.twinx()
            ax2.plot(yrs, self.df_summary['Net Kar'], color=THEME["green"], marker="o", label="Net Kar", linewidth=2)
            ax2.tick_params(colors="white")
            ax2.spines['top'].set_visible(False); ax2.spines['right'].set_visible(False)
            ax2.spines['bottom'].set_visible(False); ax2.spines['left'].set_visible(False)
            fig1.legend(loc="upper right", facecolor=THEME["bg_card"], labelcolor="white")
        else:
            row = self.df_summary[self.df_summary['Year'] == year]
            bars = ax1.bar(["Ciro", "Net Kar"], [row['Ciro'].values[0], row['Net Kar'].values[0]], color=[THEME["blue"], THEME["green"]])
            self.add_labels(ax1, bars)
        self.add_chart_with_features(fig1, 0, 0, "1. Ciro ve Net Kâr Trendi", "G1")

        fig2, ax2 = self.create_fig(figsize=(6, 4))
        row = self.df_summary[self.df_summary['Year'] == year]
        if not row.empty:
            vals = [row['Ciro'].values[0], row['SMM'].values[0], row['Brüt Kar'].values[0], 
                    row['Faal.Gid.'].values[0], row['FAVÖK'].values[0], 
                    row['Net Kar'].values[0] - row['FAVÖK'].values[0], row['Net Kar'].values[0]]
            labels = ["Ciro", "Maliyet", "Brüt", "Faal.Gid", "FAVÖK", "Fin/Vergi", "Net Kar"]
            colors = [THEME["blue"], THEME["red"], THEME["gold"], THEME["red"], THEME["orange"], THEME["red"], THEME["green"]]
            
            bars2 = ax2.bar(labels, [abs(v) for v in vals], color=colors)
            for i, (bar, val) in enumerate(zip(bars2, vals)):
                prefix = "-" if val < 0 and i not in [0, 2, 4, 6] else ""
                ax2.text(bar.get_x() + bar.get_width()/2., bar.get_height(), 
                         f"{prefix}{fmt_num(abs(val))}", ha='center', va='bottom', color='white', fontsize=9)
            ax2.get_yaxis().set_visible(False)
        self.add_chart_with_features(fig2, 0, 1, "2. Kârlılık Şelalesi", "G2")

        fig3, ax3 = self.create_fig()
        v_yici = self.get_account_balance(year, ['600'], "alacak")
        v_yurt = self.get_account_balance(year, ['601'], "alacak")
        v_diger = self.get_account_balance(year, ['602'], "alacak")
        v = [v_yici, v_yurt, v_diger]; l = ['Yurt İçi', 'Yurt Dışı', 'Diğer Gelirler']
        clean_v = [(val, lab) for val, lab in zip(v, l) if val > 0]
        if clean_v:
            vals, labs = zip(*clean_v)
            ax3.pie(vals, labels=labs, autopct='%1.1f%%', colors=[THEME["blue"], THEME["purple"], THEME["cyan"]], textprops={'color':"white"})
        self.add_chart_with_features(fig3, 1, 0, "3. Gelir Kaynakları", "G3")

        fig4, ax4 = self.create_fig()
        smm = self.get_account_balance(year, ['62'], "borc")
        faal = self.get_account_balance(year, ['63'], "borc")
        fin = self.get_account_balance(year, ['66', '78'], "borc")
        v_g = [smm, faal, fin]; l_g = ['SMM', 'Faaliyet Gideri', 'Finansman']
        clean_g = [(val, lab) for val, lab in zip(v_g, l_g) if val > 0]
        if clean_g:
            vals, labs = zip(*clean_g)
            ax4.pie(vals, labels=labs, autopct='%1.1f%%', colors=[THEME["red"], THEME["orange"], "gray"], textprops={'color':"white"})
            centre_circle = plt.Circle((0,0),0.70,fc=THEME['bg_card'])
            fig4.gca().add_artist(centre_circle)
        self.add_chart_with_features(fig4, 1, 1, "4. Gider ve Maliyet Dağılımı", "G4")

    # ------------------ 2. KARLILIK VE VERİMLİLİK ------------------
    def draw_profitability(self, year):
        self.scroll_frame.grid_columnconfigure((0,1), weight=1)
        
        fig5, ax5 = self.create_fig(figsize=(6, 4))
        yrs = self.df_summary['Year'].astype(str)
        bm = (self.df_summary['Brüt Kar']/self.df_summary['Ciro']*100).fillna(0)
        fm = (self.df_summary['FAVÖK']/self.df_summary['Ciro']*100).fillna(0)
        nm = (self.df_summary['Net Kar']/self.df_summary['Ciro']*100).fillna(0)
        
        ax5.plot(yrs, bm, marker='o', label="Brüt %", color=THEME["gold"])
        ax5.plot(yrs, fm, marker='s', label="FAVÖK %", color=THEME["cyan"])
        ax5.plot(yrs, nm, marker='^', label="Net %", color=THEME["green"])
        ax5.legend(facecolor=THEME["bg_card"], labelcolor="white")
        self.add_labels(ax5, fmt='pct')
        self.add_chart_with_features(fig5, 0, 0, "5. Kâr Marjları Gelişimi", "G5", colspan=2)

        fig6, ax6 = self.create_fig()
        arge = self.get_account_balance(year, ['630'], "borc")
        paz = self.get_account_balance(year, ['631'], "borc")
        yon = self.get_account_balance(year, ['632'], "borc")
        bars6 = ax6.bar(['Ar-Ge', 'Pazarlama', 'Yönetim'], [arge, paz, yon], color=THEME["orange"])
        self.add_labels(ax6, bars6)
        self.add_chart_with_features(fig6, 1, 0, "6. Faaliyet Giderleri Kırılımı", "G6")

        fig7, ax7 = self.create_fig()
        row = self.df_summary[self.df_summary['Year'] == year]
        ciro = row['Ciro'].values[0]
        if ciro > 0:
            maliyet_p = (abs(row['SMM'].values[0]) / ciro) * 100
            gider_p = (abs(row['Faal.Gid.'].values[0]) / ciro) * 100
            kar_p = (row['Net Kar'].values[0] / ciro) * 100
            
            bars7 = ax7.barh(['Net Kâr', 'Faaliyet Gid.', 'SMM (Maliyet)'], [kar_p, gider_p, maliyet_p], 
                             color=[THEME["green"], THEME["orange"], THEME["red"]])
            self.add_labels(ax7, bars7, fmt='pct')
        self.add_chart_with_features(fig7, 1, 1, "7. Her 100 TL Cironun Dağılımı", "G7")

    # ------------------ 3. RİSK VE FİNANSMAN ------------------
    def draw_risk_finance(self, year):
        self.scroll_frame.grid_columnconfigure((0,1), weight=1)
        
        fig8, ax8 = self.create_fig()
        efk = self.df_summary[self.df_summary['Year']==year]['FAVÖK'].values[0]
        fin = self.get_account_balance(year, ['66', '78'], "borc")
        bars8 = ax8.bar(['FAVÖK (Kazanılan)', 'Fin.Gideri (Ödenen)'], [efk, fin], color=[THEME["blue"], THEME["red"]])
        self.add_labels(ax8, bars8)
        self.add_chart_with_features(fig8, 0, 0, "8. FAVÖK ve Finansman Yükü", "G8")

        fig9, ax9 = self.create_fig()
        k_kar = self.get_account_balance(year, ['646'], "alacak")
        k_zarar = self.get_account_balance(year, ['656'], "borc")
        bars9 = ax9.bar(['Kambiyo Kârı', 'Kambiyo Zararı'], [k_kar, k_zarar], color=[THEME["green"], THEME["red"]])
        self.add_labels(ax9, bars9)
        self.add_chart_with_features(fig9, 0, 1, "9. Kur Farkı ve Kambiyo Sonucu", "G9")

        fig10, ax10 = self.create_fig(figsize=(6, 4))
        fk = self.df_summary[self.df_summary['Year']==year]['FAVÖK'].values[0]
        yan_gelir = self.get_account_balance(year, ['64'], "alacak")
        yan_gider = self.get_account_balance(year, ['65'], "borc")
        
        bars10 = ax10.barh(['Diğer Gider (65)', 'Diğer Gelir (64)', 'Ana Faaliyet (FAVÖK)'], 
                           [yan_gider, yan_gelir, fk], color=[THEME["red"], THEME["purple"], THEME["green"]])
        self.add_labels(ax10, bars10)
        self.add_chart_with_features(fig10, 1, 0, "10. Ana ve Yan Faaliyetlerin Ağırlığı", "G10", colspan=2)

    # ------------------ 4. BİLANÇO VE LİKİDİTE (YENİ) ------------------
    def draw_balance_liquidity(self, year):
        self.scroll_frame.grid_columnconfigure((0,1), weight=1)

        # G11: Alacak ve Borç Dengesi (12 vs 32)
        fig11, ax11 = self.create_fig()
        alacak = abs(self.get_account_balance(year, ['12']))
        borc = abs(self.get_account_balance(year, ['32']))
        bars11 = ax11.bar(['Ticari Alacaklar (12)', 'Ticari Borçlar (32)'], [alacak, borc], color=[THEME["blue"], THEME["orange"]])
        self.add_labels(ax11, bars11)
        self.add_chart_with_features(fig11, 0, 0, "11. Ticari Alacak / Borç Dengesi", "G11")

        # G12: Nakit vs Kısa Vadeli Mali Borç (10 vs 30)
        fig12, ax12 = self.create_fig()
        nakit = abs(self.get_account_balance(year, ['10']))
        kv_mali_borc = abs(self.get_account_balance(year, ['30']))
        bars12 = ax12.bar(['Hazır Değerler (10)', 'K.V. Mali Borç (30)'], [nakit, kv_mali_borc], color=[THEME["green"], THEME["red"]])
        self.add_labels(ax12, bars12)
        self.add_chart_with_features(fig12, 0, 1, "12. Ani Likidite Karşılama", "G12")

        # G13: Kaldıraç Oranı (Kaynak Yapısı)
        fig13, ax13 = self.create_fig()
        ozkaynak = abs(self.get_account_balance(year, ['5']))
        yabanci_kaynak = abs(self.get_account_balance(year, ['3', '4']))
        v = [ozkaynak, yabanci_kaynak]; l = ['Özkaynak', 'Yabancı Kaynak']
        clean_v = [(val, lab) for val, lab in zip(v, l) if val > 0]
        if clean_v:
            vals, labs = zip(*clean_v)
            ax13.pie(vals, labels=labs, autopct='%1.1f%%', colors=[THEME["cyan"], THEME["red"]], textprops={'color':"white"})
        self.add_chart_with_features(fig13, 1, 0, "13. Finansal Kaldıraç (Kaynaklar)", "G13")

        # G14: Borç Vade Yapısı (3 vs 4)
        fig14, ax14 = self.create_fig()
        kisa_borc = abs(self.get_account_balance(year, ['3']))
        uzun_borc = abs(self.get_account_balance(year, ['4']))
        bars14 = ax14.bar(['Kısa Vadeli Borç', 'Uzun Vadeli Borç'], [kisa_borc, uzun_borc], color=[THEME["orange"], THEME["purple"]])
        self.add_labels(ax14, bars14)
        self.add_chart_with_features(fig14, 1, 1, "14. Borç Vade Yapısı", "G14")

    # ------------------ 5. ÖZEL YÖNETSEL ANALİZLER (YENİ) ------------------
    def draw_special_analysis(self, year):
        self.scroll_frame.grid_columnconfigure((0,1), weight=1)

        # G15: Vergi Yükü Oranı (690 vs 691)
        fig15, ax15 = self.create_fig()
        v_oncesi_kar = self.get_account_balance(year, ['690'], "alacak")
        v_karsiligi = self.get_account_balance(year, ['691'], "borc")
        bars15 = ax15.bar(['Vergi Öncesi Tic. Kar', 'Vergi Karşılığı'], [v_oncesi_kar, v_karsiligi], color=[THEME["blue"], THEME["red"]])
        self.add_labels(ax15, bars15)
        self.add_chart_with_features(fig15, 0, 0, "15. Vergi Yükü Analizi", "G15")

        # G16: Olağandışı Kalemlerin Hacmi (679 vs 689)
        fig16, ax16 = self.create_fig()
        o_gelir = self.get_account_balance(year, ['679'], "alacak")
        o_gider = self.get_account_balance(year, ['689'], "borc")
        bars16 = ax16.bar(['Olağandışı Gelir', 'Olağandışı Gider'], [o_gelir, o_gider], color=[THEME["green"], THEME["orange"]])
        self.add_labels(ax16, bars16)
        self.add_chart_with_features(fig16, 0, 1, "16. Olağandışı Kalem Etkisi", "G16")

        # G17: Finansman Yükü Trendi (Tüm Yıllar)
        fig17, ax17 = self.create_fig()
        yrs = self.df_summary['Year'].astype(str)
        fin_list = []
        for y in self.df_summary['Year']:
            ciro = self.df_summary[self.df_summary['Year']==y]['Ciro'].values[0]
            fin = self.get_account_balance(y, ['66', '78'], "borc")
            oran = (fin / ciro * 100) if ciro > 0 else 0
            fin_list.append(oran)
            
        ax17.plot(yrs, fin_list, marker='o', color=THEME["red"], linewidth=2)
        self.add_labels(ax17, fmt='pct')
        self.add_chart_with_features(fig17, 1, 0, "17. Finansman Yükü Oranı Trendi", "G17")

        # G18: Satış İndirim Oranı (61 vs Brüt)
        fig18, ax18 = self.create_fig()
        brut = self.get_account_balance(year, ['60'], "alacak")
        indirim = self.get_account_balance(year, ['61'], "borc")
        net = brut - indirim
        v = [net, indirim]; l = ['Net Satış', 'Satış İndirimleri']
        clean_v = [(val, lab) for val, lab in zip(v, l) if val > 0]
        if clean_v:
            vals, labs = zip(*clean_v)
            ax18.pie(vals, labels=labs, autopct='%1.1f%%', colors=[THEME["blue"], THEME["red"]], textprops={'color':"white"})
        self.add_chart_with_features(fig18, 1, 1, "18. Satış İndirim Oranı", "G18")

        # G19: KKEG Risk Tahmini (689 / 63)
        fig19, ax19 = self.create_fig()
        kkeg_tahmin = self.get_account_balance(year, ['689'], "borc")
        faal_gider = self.get_account_balance(year, ['63'], "borc")
        diger = faal_gider - kkeg_tahmin if faal_gider > kkeg_tahmin else faal_gider
        
        v = [kkeg_tahmin, diger]; l = ['689 (Potansiyel KKEG)', 'Diğer Faal. Giderleri']
        clean_v = [(val, lab) for val, lab in zip(v, l) if val > 0]
        if clean_v:
            vals, labs = zip(*clean_v)
            ax19.pie(vals, labels=labs, autopct='%1.1f%%', colors=["orange", THEME["blue"]], textprops={'color':"white"})
            centre_circle = plt.Circle((0,0),0.70,fc=THEME['bg_card'])
            fig19.gca().add_artist(centre_circle)
        self.add_chart_with_features(fig19, 2, 0, "19. KKEG Risk Oranı (Giderler İçi)", "G19")

        # G20: Kârın Kur Bağımlılığı (Net Kar vs Kur Etkisi)
        fig20, ax20 = self.create_fig()
        raporlanan_kar = self.df_summary[self.df_summary['Year']==year]['Net Kar'].values[0]
        kur_kar = self.get_account_balance(year, ['646'], "alacak")
        kur_zarar = self.get_account_balance(year, ['656'], "borc")
        net_kur_etkisi = kur_kar - kur_zarar
        karsiz_kar = raporlanan_kar - net_kur_etkisi
        
        bars20 = ax20.bar(['Raporlanan Net Kar', 'Kur Etkisi Arındırılmış'], [raporlanan_kar, karsiz_kar], color=[THEME["green"], THEME["cyan"]])
        self.add_labels(ax20, bars20)
        self.add_chart_with_features(fig20, 2, 1, "20. Kur Etkisinden Arındırılmış Kar", "G20")

    # ------------------ MENÜ YÖNETİMİ ------------------
    def change_view(self, view_name):
        self.active_view = view_name
        for name, btn in self.nav_buttons.items():
            color = THEME["bg_card"] if name == view_name else "transparent"
            text_c = THEME["gold"] if name == view_name else "#A0A0A0"
            btn.configure(fg_color=color, text_color=text_c)
        self.update_view()

    def update_view(self, event=None):
        for w in self.scroll_frame.winfo_children(): w.destroy()
        try: y_int = int(self.combo_year.get())
        except: return
        
        row = self.df_summary[self.df_summary['Year'] == y_int]
        if not row.empty:
            for k, w in self.kpi_widgets.items(): w.configure(text=f"{row[k].values[0]:,.0f} ₺")
            
        if "Genel Bakış" in self.active_view: self.draw_overview(y_int)
        elif "Karlılık" in self.active_view: self.draw_profitability(y_int)
        elif "Risk" in self.active_view: self.draw_risk_finance(y_int)
        elif "Bilanço" in self.active_view: self.draw_balance_liquidity(y_int)
        elif "Özel" in self.active_view: self.draw_special_analysis(y_int)

    def on_year_change(self, choice):
        self.current_year = int(choice)
        self.update_view()

if __name__ == "__main__":
    app = ctk.CTk()
    app.withdraw()

    try:
        if FinancialReportEngine is None:
            raise ImportError("engine.py modülü projede bulunamadı veya içe aktarılamadı.")
            
        engine = FinancialReportEngine()
        real_data = engine.get_multi_year_data()
        
        if not real_data:
            messagebox.showwarning("Veri Bulunamadı", "Engine üzerinden işlenebilecek finansal veri bulunamadı.\nSession bilgilerinizi kontrol edin.")
            app.destroy()
        else:
            board = PowerBIBoard(app, real_data)
            app.mainloop()
            
    except Exception as e:
        messagebox.showerror("Hata", f"Veri motoru yüklenirken hata oluştu:\n{str(e)}")
        app.destroy()