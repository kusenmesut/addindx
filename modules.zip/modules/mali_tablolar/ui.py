import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os
import pandas as pd
import numpy as np
import matplotlib.patches as mpatches
from tkinter import ttk, messagebox, filedialog # filedialog EKLENDİ
# --- MATPLOTLIB ---
from matplotlib.figure import Figure 
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.ticker import FuncFormatter
import matplotlib.pyplot as plt

# --- IMPORT AYARLARI ---
# Artık PowerBIBoard'u direkt engine'den çekiyoruz
try:
    from .engine import FinancialReportEngine, PowerBIBoard
except ImportError:
    # Eğer engine modülünden PowerBIBoard gelmezse (örneğin eski engine.py varsa)
    # Hata vermemesi için dummy tanımla
    class FinancialReportEngine:
        def __init__(self, parent): pass
        def calculate_matrix(self, r, p, f): return [], []
        def get_analysis_result(self, h, r, m, rep): return [], []
        def get_multi_year_data(self): return {}
    PowerBIBoard = None

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
try:
    from config import CLR_BODY_BG
except ImportError:
    CLR_BODY_BG = "#F8F9FC"

# --- RENK PALETİ ---
CLR_BG_MAIN = "#F8F9FC"
CLR_BG_WHITE = "#FFFFFF"
CLR_HEADER = "#1B2559"
CLR_ACCENT = "#4318FF"
CLR_INACTIVE = "#F4F7FE"
CLR_TEXT_GRAY = "#A3AED0"
CLR_TEXT_DARK = "#2B3674"
CLR_ORANGE = "#FFB547"
CLR_SELECTED = "#FF9F43"
CLR_GREEN = "#05CD99"
CLR_BLACK = "#000000"
CLR_DASHBOARD_BTN = "#2E86C1"

# --- YARDIMCI FONKSİYONLAR ---
def format_tl(x, pos):
    if x is None: return "0"
    return "{:,.0f}".format(x).replace(",", "X").replace(".", ",").replace("X", ".")

# --- YUVARLAK BUTON SINIFI ---
# ui.py içindeki RoundedButton sınıfını bununla güncelle:
class RoundedButton(tk.Canvas):
    def __init__(self, parent, text, command, width=100, height=32, corner=16, 
                 bg_col=CLR_INACTIVE, fg_col=CLR_BLACK, 
                 act_bg=CLR_ACCENT, act_fg=CLR_BG_WHITE, icon=None):
        super().__init__(parent, width=width, height=height, bg=parent["bg"], bd=0, highlightthickness=0)
        self.command = command
        self.bg_col = bg_col
        self.fg_col = fg_col
        self.act_bg = act_bg
        self.act_fg = act_fg
        self.rect = self.create_rounded_rect(0, 0, width, height, corner, fill=bg_col, outline=bg_col)
        if icon:
            self.create_text(20, height/2, text=icon, fill=fg_col, font=("Segoe UI Emoji", 10), tags=("content","txt"))
            self.text_id = self.create_text(width/2 + 10, height/2, text=text, fill=fg_col, font=("DM Sans", 9, "bold"), tags=("content","txt"))
        else:
            self.text_id = self.create_text(width/2, height/2, text=text, fill=fg_col, font=("DM Sans", 9, "bold"), tags=("content","txt"))
        
        # --- DÜZELTME BURADA ---
        # Sadece Canvas'a tıklama özelliği veriyoruz, içeriğe ("content") ayrıca verirsek olay 2 kere tetiklenir.
        self.bind("<Button-1>", self.on_click) 
        # self.tag_bind("content", "<Button-1>", self.on_click)  <-- BU SATIRI SİLDİK/İPTAL ETTİK

        self.bind("<Enter>", lambda e: self.config(cursor="hand2"))
        self.bind("<Leave>", lambda e: self.config(cursor=""))

    def create_rounded_rect(self, x1, y1, x2, y2, r, **kwargs):
        points = (x1+r, y1, x1+r, y1, x2-r, y1, x2-r, y1, x2, y1, x2, y1+r, x2, y1+r, x2, y2-r, x2, y2-r, x2, y2, x2-r, y2, x2-r, y2, x1+r, y2, x1+r, y2, x1, y2-r, x1, y2-r, x1, y1+r, x1, y1+r, x1, y1)
        return self.create_polygon(points, **kwargs, smooth=True)

    def on_click(self, event):
        if self.command: self.command()

    def set_active(self, state):
        if state:
            self.itemconfig(self.rect, fill=self.act_bg, outline=self.act_bg)
            self.itemconfig("txt", fill=self.act_fg)
        else:
            self.itemconfig(self.rect, fill=self.bg_col, outline=self.bg_col)
            self.itemconfig("txt", fill=self.fg_col)

# --- ANA GÖRÜNÜM SINIFI ---
class FinancialReportsView(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BG_MAIN)
        self.engine = FinancialReportEngine(parent=None)
        self.mode = "Beyan"
        self.report = "Bilanço"
        self.row_cnt = 0
        self.graph_window = None
        self.setup_styles()
        self.setup_ui()
        self.after(200, lambda: self.refresh_data())

    def setup_styles(self):
        s = ttk.Style()
        try: s.theme_use("clam") 
        except: pass
        s.configure("Fin.Treeview.Heading", background=CLR_HEADER, foreground="white", font=("DM Sans", 10, "bold"), relief="flat", borderwidth=0)
        s.configure("Fin.Treeview", background="white", fieldbackground="white", foreground=CLR_TEXT_DARK, font=("DM Sans", 10), rowheight=30, borderwidth=0)
        s.map("Fin.Treeview", background=[("selected", CLR_SELECTED)], foreground=[("selected", "white")])
        s.configure("TCombobox", fieldbackground="white", background="white")

    def setup_ui(self):
        card = tk.Frame(self, bg="white", padx=20, pady=20)
        card.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        frm_link = tk.Frame(card, bg="white")
        frm_link.pack(fill=tk.X, pady=(0, 15))
        self.btn_rep_bilanco = RoundedButton(frm_link, "Bilanço Özeti", lambda: self.set_report("Bilanço"), width=120, height=30, bg_col="white", fg_col=CLR_TEXT_GRAY, act_bg=CLR_HEADER, act_fg="white")
        self.btn_rep_bilanco.pack(side=tk.LEFT, padx=(0, 10))
        self.btn_rep_gelir = RoundedButton(frm_link, "Gelir Tablosu", lambda: self.set_report("Gelir Tablosu"), width=120, height=30, bg_col="white", fg_col=CLR_TEXT_GRAY, act_bg=CLR_HEADER, act_fg="white")
        self.btn_rep_gelir.pack(side=tk.LEFT)
        self.btn_rep_bilanco.set_active(True)
        self.line = tk.Frame(card, bg="#E0E5F2", height=1)
        self.line.place(x=0, y=45, relwidth=1.0)
        frm_ctrl = tk.Frame(card, bg="white")
        frm_ctrl.pack(fill=tk.X, pady=(15, 15))
        self.frm_pills = tk.Frame(frm_ctrl, bg="white")
        self.frm_pills.pack(side=tk.LEFT)
        self.btn_beyan = RoundedButton(self.frm_pills, "Beyan", lambda: self.set_mode("Beyan"), width=80)
        self.btn_beyan.pack(side=tk.LEFT, padx=2)
        self.btn_dusey = RoundedButton(self.frm_pills, "Düşey Analiz", lambda: self.set_mode("Düşey Analiz"), width=110)
        self.btn_dusey.pack(side=tk.LEFT, padx=2)
        self.btn_yatay = RoundedButton(self.frm_pills, "Yatay Analiz", lambda: self.set_mode("Yatay Analiz"), width=110)
        self.btn_yatay.pack(side=tk.LEFT, padx=2)
        tk.Label(frm_ctrl, text="ℹ️ Çoklu seçim: CTRL + Tık", bg="white", fg=CLR_TEXT_GRAY, font=("DM Sans", 9, "italic")).pack(side=tk.LEFT, padx=20)
        self.btn_dash = RoundedButton(frm_ctrl, "YÖNETİCİ KOKPİTİ", self.open_dashboard, width=140, bg_col=CLR_DASHBOARD_BTN, fg_col="white", act_bg="#1B4F72", icon="📈")
        self.btn_dash.pack(side=tk.RIGHT, padx=5)
        self.btn_ref = RoundedButton(frm_ctrl, "YENİLE", lambda: self.refresh_data(True), width=100, bg_col=CLR_ORANGE, fg_col="white", act_bg="#E5A33F", icon="↻")
        self.btn_ref.pack(side=tk.RIGHT, padx=5)
        self.btn_grf = RoundedButton(frm_ctrl, "GRAFİK SEÇ", self.show_graph, width=120, bg_col=CLR_GREEN, fg_col="white", act_bg="#04A67C", icon="📊")
        self.btn_grf.pack(side=tk.RIGHT, padx=5)
# --- YENİ EKLENEN EXCEL BUTONU ---
        self.btn_excel = RoundedButton(frm_ctrl, "EXCEL", self.export_to_excel, width=90, bg_col="#107C41", fg_col="white", act_bg="#0C5E31", icon="📥")
        self.btn_excel.pack(side=tk.RIGHT, padx=5)

        self.cb_per = ttk.Combobox(frm_ctrl, values=["Yıllık", "Aylık", "3 Aylık"], state="readonly", width=10)
        self.cb_per.current(0)
        self.cb_per.pack(side=tk.RIGHT, padx=10)
        self.cb_per.bind("<<ComboboxSelected>>", lambda e: self.refresh_data())
        self.update_tabs()
        self.tree = ttk.Treeview(card, style="Fin.Treeview", show="tree headings", selectmode="extended")
        vsb = ttk.Scrollbar(card, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(card, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.tag_configure("header", background="#E0E5F2", font=("DM Sans", 10, "bold"), foreground=CLR_HEADER)
        self.tree.tag_configure("total", background="#F4F7FE", font=("DM Sans", 10, "bold"), foreground=CLR_HEADER)
        self.tree.tag_configure("odd", background="#F8F9FC")
        self.tree.tag_configure("even", background="white")

    def open_dashboard(self):
        # 1. Veriyi Çek
        try:
            df_dict = self.engine.get_multi_year_data()
            if not df_dict:
                messagebox.showwarning("Veri Yok", "Dashboard için veri bulunamadı.\nLütfen önce 'Yenile' butonuna basın.")
                return
        except Exception as e:
            messagebox.showerror("Veri Hatası", f"Veri çekilirken hata oluştu:\n{str(e)}")
            return

        # 2. Modülü Çağır ve Başlat
        try:
            # --- YOL DÜZELTME (PATH FIX) ---
            # Python'a, bu dosyanın (ui.py) olduğu klasöre bakmasını söylüyoruz.
            import sys
            import os
            current_dir = os.path.dirname(os.path.abspath(__file__))
            if current_dir not in sys.path:
                sys.path.append(current_dir)
            
            # Artık dosyayı bulabilir
            import grafik_ui
            
            # Modülü yeniden yükle (Kod değiştirirsen kapatıp açtığında güncellensin diye)
            import importlib
            importlib.reload(grafik_ui)
            
            # Pencereyi aç
            dashboard_window = grafik_ui.PowerBIBoard(self.winfo_toplevel(), df_dict)
            
            # Pencere öne gelsin (Focus)
            dashboard_window.after(100, dashboard_window.lift)
            dashboard_window.after(100, dashboard_window.focus_force)
            
        except ImportError as e:
            # Eğer hala bulamazsa veya kütüphane eksikse
            err_msg = str(e)
            if "customtkinter" in err_msg:
                messagebox.showerror("Kütüphane Eksik", "Lütfen terminalden şu komutu çalıştırın:\npip install customtkinter")
            else:
                messagebox.showerror("Dosya Bulunamadı", f"grafik_ui.py dosyası '{current_dir}' klasöründe bulunamadı.\n\nHata: {err_msg}")
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Beklenmeyen Hata", f"Dashboard açılırken bir hata oluştu:\n{str(e)}")
    
    
    def set_report(self, r):
        self.report = r
        if r == "Bilanço":
            self.btn_rep_bilanco.set_active(True)
            self.btn_rep_gelir.set_active(False)
        else:
            self.btn_rep_bilanco.set_active(False)
            self.btn_rep_gelir.set_active(True)
        self.refresh_data()

    def set_mode(self, m):
        self.mode = m
        self.update_tabs()
        self.refresh_data()

    def update_tabs(self):
        self.btn_beyan.set_active(self.mode == "Beyan")
        self.btn_dusey.set_active(self.mode == "Düşey Analiz")
        self.btn_yatay.set_active(self.mode == "Yatay Analiz")

    def refresh_data(self, force=False):
        h_raw, r_raw = self.engine.calculate_matrix(self.report, self.cb_per.get(), force)
        if not r_raw:
            self.tree.delete(*self.tree.get_children())
            return
        headers, rows = self.engine.get_analysis_result(h_raw, r_raw, self.mode, self.report)
        self.tree["columns"] = headers
        self.tree.heading("#0", text=" HESAP KALEMLERİ", anchor="w")
        self.tree.column("#0", width=400, minwidth=300)
        for h in headers:
            self.tree.heading(h, text=h, anchor="center")
            self.tree.column(h, width=110, anchor="center")
        self.tree.delete(*self.tree.get_children())
        self.row_cnt = 0
        self.fill_tree("", rows, headers)

    def fill_tree(self, parent, items, headers):
        for item in items:
            vals = []
            for i, v in enumerate(item["vals"]):
                col = headers[i]
                if isinstance(v, (int, float)):
                    if "%" in col:
                        sym = "▲" if v > 0 else "▼" if v < 0 else ""
                        vals.append(f"{sym} %{abs(v):,.1f}")
                    else:
                        if v == 0: vals.append("-")
                        else: vals.append("{:,.2f}".format(v).replace(",", "X").replace(".", ",").replace("X", "."))
                else: vals.append(v)
            tags = ["odd"] if self.row_cnt % 2 != 0 else ["even"]
            itype = item.get("type", "item")
            if itype == "header": tags.append("header")
            elif itype in ["total", "total_final", "group"]: tags.append("total")
            iid = self.tree.insert(parent, "end", text="  " + item["text"], values=vals, tags=tags, open=True)
            self.row_cnt += 1
            if "children" in item: self.fill_tree(iid, item["children"], headers)

    def show_graph(self):
        selected_iids = self.tree.selection()
        if not selected_iids:
            messagebox.showinfo("Bilgi", "Lütfen grafiğini görmek istediğiniz satırları (CTRL tuşu ile) seçiniz.")
            return
        if self.graph_window is not None and tk.Toplevel.winfo_exists(self.graph_window):
            self.graph_window.destroy()
        self.graph_window = tk.Toplevel(self)
        self.graph_window.title("İnteraktif Grafik Analizi")
        self.graph_window.geometry("950x600")
        self.graph_window.config(bg="white")
        fig = Figure(figsize=(8, 5), dpi=100)
        ax = fig.add_subplot(111)
        ax.yaxis.set_major_formatter(FuncFormatter(format_tl))
        colors = ["#4318FF", "#00C9A7", "#FFB547", "#E31A1A", "#2B3674", "#FF00FF"]
        all_lines = []
        all_fills = []
        found_data = False
        for idx, tid in enumerate(selected_iids):
            item = self.tree.item(tid)
            if not item["values"]: continue
            vals = item["values"]
            cols = self.tree["columns"]
            X, Y = [], []
            for i, c in enumerate(cols):
                if "%" in c: continue
                try:
                    v_str = str(vals[i]).replace(".","").replace(",",".")
                    if "▲" in v_str or "▼" in v_str or v_str == "-": continue
                    val = float(v_str)
                    X.append(c)
                    Y.append(val)
                except: pass
            if X:
                X.reverse(); Y.reverse()
                clr = colors[idx % len(colors)]
                lbl = item["text"].strip()
                line, = ax.plot(X, Y, marker='o', lw=2.5, label=lbl, color=clr)
                fill = ax.fill_between(X, Y, color=clr, alpha=0.1)
                all_lines.append(line)
                all_fills.append(fill)
                found_data = True
        if not found_data:
            self.graph_window.destroy()
            messagebox.showerror("Hata", "Seçilen satırlarda grafik verisi yok.")
            return
        ax.grid(linestyle=":", alpha=0.5)
        ax.set_title("Dönemsel Trend", color=CLR_HEADER, fontweight="bold", pad=15)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        annot = ax.annotate("", xy=(0,0), xytext=(10,10), textcoords="offset points", bbox=dict(boxstyle="round", fc="#FFFACD", ec="orange", alpha=0.9), arrowprops=dict(arrowstyle="->"))
        annot.set_visible(False)
        def update_annot(ind, line):
            x, y = line.get_data()
            idx = ind["ind"][0]
            pos_x, pos_y = x[idx], y[idx]
            annot.xy = (pos_x, pos_y)
            formatted_val = "{:,.2f}".format(pos_y).replace(",", "X").replace(".", ",").replace("X", ".")
            annot.set_text(f"Dönem: {pos_x}\nTutar: {formatted_val} TL")
            annot.get_bbox_patch().set_alpha(0.9)
        def hover(event):
            vis = annot.get_visible()
            if event.inaxes == ax:
                for line in all_lines:
                    cont, ind = line.contains(event)
                    if cont:
                        update_annot(ind, line)
                        annot.set_visible(True)
                        fig.canvas.draw_idle()
                        return
            if vis:
                annot.set_visible(False)
                fig.canvas.draw_idle()
        fig.canvas.mpl_connect("motion_notify_event", hover)
        leg = ax.legend(fancybox=True, shadow=False, loc='upper center', bbox_to_anchor=(0.5, -0.05), ncol=3)
        temp_map = {}
        for legline, origline, origfill in zip(leg.get_lines(), all_lines, all_fills):
            legline.set_picker(5)
            temp_map[legline] = (origline, origfill)
        for legtext, origline, origfill in zip(leg.get_texts(), all_lines, all_fills):
            legtext.set_picker(5)
            temp_map[legtext] = (origline, origfill)
        def on_pick(event):
            leg_artist = event.artist
            if leg_artist not in temp_map: return
            orig_line, orig_fill = temp_map[leg_artist]
            is_visible = not orig_line.get_visible()
            orig_line.set_visible(is_visible)
            orig_fill.set_visible(is_visible)
            leg_artist.set_alpha(1.0 if is_visible else 0.2)
            fig.canvas.draw()
        fig.canvas.mpl_connect('pick_event', on_pick)
        can = FigureCanvasTkAgg(fig, self.graph_window)
        can.draw()
        can.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=20, pady=20)


    def export_to_excel(self):
        # 1. Tabloda veri var mı kontrol et
        if not self.tree.get_children():
            messagebox.showwarning("Uyarı", "Dışa aktarılacak veri bulunamadı!")
            return

        # 2. Kaydedilecek yeri kullanıcıya sor
        file_path = filedialog.asksaveasfilename(
            title="Excel Olarak Kaydet",
            defaultextension=".xlsx",
            filetypes=[("Excel Dosyaları", "*.xlsx"), ("Tüm Dosyalar", "*.*")],
            initialfile=f"{self.report}_Analizi.xlsx"
        )
        
        if not file_path:  # İptale basıldıysa işlemi durdur
            return

        # 3. Treeview'dan (Tablodan) verileri çek
        columns = ["Hesap Kalemleri"] + list(self.tree["columns"])
        data = []

        def get_all_children(parent_id=""):
            for child_id in self.tree.get_children(parent_id):
                # Satır başlığını (Hesap adını) al, başındaki boşlukları temizle
                item_text = self.tree.item(child_id, "text").strip()
                # Satırın sayısal değerlerini al
                item_values = self.tree.item(child_id, "values")
                
                # Listeyi birleştirip data listesine ekle
                row = [item_text] + list(item_values)
                data.append(row)
                
                # Alt dallar (çocuklar) varsa onları da tara
                get_all_children(child_id)

        # Kök dizinden başlayarak tüm tabloyu tara
        get_all_children()

        # 4. Pandas ile Excel'e dönüştür ve kaydet
        try:
            df = pd.DataFrame(data, columns=columns)
            df.to_excel(file_path, index=False)
            messagebox.showinfo("Başarılı", f"Rapor başarıyla kaydedildi:\n{file_path}")
        except Exception as e:
            messagebox.showerror("Hata", f"Excel oluşturulurken bir hata meydana geldi:\n{str(e)}")