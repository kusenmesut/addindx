import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from PIL import Image, ImageTk
import base64
import io
import threading

# Import Yönetimi
try:
    from .engine import ProfilEngine
except ImportError:
    from engine import ProfilEngine

class ProfilFrame(tk.Frame):
    def __init__(self, parent, controller=None):
        super().__init__(parent)
        self.controller = controller
        self.engine = ProfilEngine()
        self.selected_logo_base64 = None 
        
        # --- AYARLAR ---
        self.CANVAS_SIZE = 450  
        self.IMG_MAX_SIZE = 400 
        self.CENTER_POINT = self.CANVAS_SIZE // 2

        # --- RENK PALETİ ---
        self.col_bg = "#f0f2f5"        
        self.col_card_bg = "#ffffff"   
        self.col_left_panel = "#c0392b" 
        self.col_text = "#2c3e50"
        self.col_entry_border = "#dfe6e9"

        self.setup_styles()
        self.setup_ui()
        
        self.after(100, self.verileri_yukle)
        self.after(200, self.listeyi_yenile)
        self.after(300, self.kredi_listesini_yenile)
        # Otomatik eşitleme başlat (2 sn sonra)
        self.after(2000, lambda: self.trigger_auto_sync(silent=True))

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam') 
        style.configure("Card.TFrame", background=self.col_card_bg)
        style.configure("LeftPanel.TLabel", background=self.col_left_panel, foreground="white", font=("Segoe UI", 14, "bold"))
        style.configure("LeftLink.TButton", font=("Segoe UI", 10, "underline"), background=self.col_left_panel, foreground="#ecf0f1", borderwidth=0)
        style.configure("Header.TLabel", font=("Segoe UI", 18, "bold"), background=self.col_card_bg, foreground=self.col_text)
        style.configure("FieldLabel.TLabel", font=("Segoe UI", 9, "bold"), background=self.col_card_bg, foreground="#7f8c8d")
        style.configure("Modern.TEntry", fieldbackground="#ffffff", bordercolor=self.col_entry_border, padding=5)
        style.configure("Action.TButton", font=("Segoe UI", 11, "bold"), background=self.col_left_panel, foreground="white", borderwidth=0)
        style.map("Action.TButton", background=[("active", "#a93226")]) 
        style.configure("TNotebook", background=self.col_bg, borderwidth=0)
        style.configure("TNotebook.Tab", font=("Segoe UI", 11, "bold"), padding=[15, 5], background="#dfe6e9", foreground="#2d3436")
        style.map("TNotebook.Tab", background=[("selected", self.col_card_bg)], foreground=[("selected", self.col_left_panel)])
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=30)
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#ecf0f1", foreground="#2c3e50")

    def setup_ui(self):
        self.bg_frame = tk.Frame(self, bg=self.col_bg)
        self.bg_frame.pack(fill="both", expand=True)

        self.card = tk.Frame(self.bg_frame, bg=self.col_bg, padx=0, pady=0)
        self.card.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.95, relheight=0.95)

        self.notebook = ttk.Notebook(self.card)
        self.notebook.pack(fill="both", expand=True)

        # Sekmeler
        self.tab_profil = tk.Frame(self.notebook, bg=self.col_card_bg)
        self.notebook.add(self.tab_profil, text="👤 Profil Ayarları")
        self.setup_profil_tab()

        self.tab_liste = tk.Frame(self.notebook, bg=self.col_card_bg)
        self.notebook.add(self.tab_liste, text="📂 Mükellef Arşivi")
        self.setup_liste_tab()

        self.tab_kredi = tk.Frame(self.notebook, bg=self.col_card_bg)
        self.notebook.add(self.tab_kredi, text="💳 Harcama Geçmişi")
        self.setup_kredi_tab()

    def setup_profil_tab(self):
        self.left_panel = tk.Frame(self.tab_profil, bg=self.col_left_panel)
        self.left_panel.pack(side="left", fill="both", expand=True)
        self.left_content = tk.Frame(self.left_panel, bg=self.col_left_panel)
        self.left_content.pack(expand=True) 

        self.logo_canvas = tk.Canvas(self.left_content, width=self.CANVAS_SIZE, height=self.CANVAS_SIZE, bg=self.col_left_panel, highlightthickness=0)
        self.logo_canvas.pack(pady=40)
        self.draw_placeholder_logo()

        btn_logo = ttk.Button(self.left_content, text="Logoyu Güncelle", style="LeftLink.TButton", command=self.logo_sec)
        btn_logo.pack(pady=10)

        self.right_panel = tk.Frame(self.tab_profil, bg=self.col_card_bg)
        self.right_panel.pack(side="right", fill="both", expand=True)
        self.form_container = tk.Frame(self.right_panel, bg=self.col_card_bg)
        self.form_container.pack(expand=True, fill="both", padx=60, pady=20)

        ttk.Label(self.form_container, text="Kullanıcı Bilgileri", style="Header.TLabel").pack(anchor="w", pady=(0, 20))

        fields = [
            ("Yetkili Adı", "ent_ad", False),
            ("Yetkili Soyadı", "ent_soyad", False),
            ("Telefon", "ent_telefon", False),
            ("Şirket Ünvanı", "ent_unvan", False),
            ("Vergi No", "ent_vergino", False),
            ("E-Posta (Sabit)", "ent_email", True),
            ("Yeni Şifre", "ent_sifre", False)
        ]

        for label_text, var_name, is_readonly in fields:
            row_frame = tk.Frame(self.form_container, bg=self.col_card_bg)
            row_frame.pack(fill="x", pady=5)
            ttk.Label(row_frame, text=label_text, style="FieldLabel.TLabel").pack(anchor="w")
            
            show_char = "•" if var_name == "ent_sifre" else ""
            state = "readonly" if is_readonly else "normal"
            entry = ttk.Entry(row_frame, style="Modern.TEntry", show=show_char, state=state, font=("Segoe UI", 11))
            entry.pack(fill="x", ipady=6)
            setattr(self, var_name, entry)

        btn_save = ttk.Button(self.form_container, text="KAYDET", style="Action.TButton", command=self.kaydet)
        btn_save.pack(fill="x", pady=(20, 0), ipady=10)

    def setup_liste_tab(self):
        top_bar = tk.Frame(self.tab_liste, bg=self.col_card_bg)
        top_bar.pack(fill="x", padx=20, pady=10)
        ttk.Label(top_bar, text="Sistemdeki Mükellef Klasörleri", style="Header.TLabel").pack(side="left")
        ttk.Button(top_bar, text="🔄 Yenile", command=lambda: [self.listeyi_yenile(), self.trigger_auto_sync(silent=True)]).pack(side="right")

        tree_frame = tk.Frame(self.tab_liste, bg="white")
        tree_frame.pack(fill="both", expand=True, padx=20, pady=10)
        cols = ("unvan", "vkn", "donemler")
        self.tree = ttk.Treeview(tree_frame, columns=cols, show="headings")
        self.tree.heading("unvan", text="Mükellef Unvanı")
        self.tree.heading("vkn", text="VKN / TCKN")
        self.tree.heading("donemler", text="İşlenmiş Dönemler")
        self.tree.column("unvan", width=250)
        self.tree.column("vkn", width=120)
        self.tree.column("donemler", width=400)
        scroll_y = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=scroll_y.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll_y.pack(side="right", fill="y")

    def setup_kredi_tab(self):
        top_bar = tk.Frame(self.tab_kredi, bg=self.col_card_bg)
        top_bar.pack(fill="x", padx=20, pady=10)
        ttk.Label(top_bar, text="Kredi Kullanım Detayları", style="Header.TLabel").pack(side="left")
        frame_btns = tk.Frame(top_bar, bg=self.col_card_bg)
        frame_btns.pack(side="right")
        ttk.Button(frame_btns, text="🔄 Yenile", command=self.kredi_listesini_yenile).pack(side="right", padx=5)
        ttk.Button(frame_btns, text="+ Test Kaydı", command=lambda: [self.engine.kredi_islem_kaydet("Otomatik Test", 1), self.kredi_listesini_yenile(), self.trigger_auto_sync(silent=True)]).pack(side="right")

        tree_frame = tk.Frame(self.tab_kredi, bg="white")
        tree_frame.pack(fill="both", expand=True, padx=20, pady=10)
        cols = ("tarih", "islem", "tutar")
        self.tree_kredi = ttk.Treeview(tree_frame, columns=cols, show="headings")
        self.tree_kredi.heading("tarih", text="İşlem Tarihi")
        self.tree_kredi.heading("islem", text="İşlem / Grup Adı")
        self.tree_kredi.heading("tutar", text="Düşülen Miktar")
        self.tree_kredi.column("tarih", width=150, anchor="center")
        self.tree_kredi.column("islem", width=300, anchor="w")
        self.tree_kredi.column("tutar", width=100, anchor="center")
        scroll_y = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree_kredi.yview)
        self.tree_kredi.configure(yscroll=scroll_y.set)
        self.tree_kredi.pack(side="left", fill="both", expand=True)
        scroll_y.pack(side="right", fill="y")

    def draw_placeholder_logo(self):
        self.logo_canvas.delete("all")
        c = self.CENTER_POINT
        s = 100 
        self.logo_canvas.create_rectangle(c - s, c - s*1.2, c + s, c + s, outline="white", width=5)
        self.logo_canvas.create_line(c - s + 20, c - 40, c + s - 20, c - 40, fill="white", width=4)
        self.logo_canvas.create_line(c - s + 20, c, c + s - 20, c, fill="white", width=4)
        self.logo_canvas.create_line(c - s + 20, c + 40, c + s - 20, c + 40, fill="white", width=4)
        self.logo_canvas.create_oval(c + 20, c + 20, c + 120, c + 120, outline="white", width=6)
        self.logo_canvas.create_line(c + 100, c + 100, c + 140, c + 140, fill="white", width=6)

    def logo_sec(self):
        file_path = filedialog.askopenfilename(filetypes=[("Resim", "*.png;*.jpg;*.jpeg")])
        if file_path:
            try:
                img = Image.open(file_path)
                img.thumbnail((self.IMG_MAX_SIZE, self.IMG_MAX_SIZE))
                self.tk_img = ImageTk.PhotoImage(img)
                self.logo_canvas.delete("all")
                self.logo_canvas.create_image(self.CENTER_POINT, self.CENTER_POINT, image=self.tk_img, anchor="center")
                buffered = io.BytesIO()
                img.save(buffered, format="PNG") 
                img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
                self.selected_logo_base64 = img_str
            except Exception as e:
                messagebox.showerror("Hata", f"Resim hatası: {e}")

    def verileri_yukle(self):
        try:
            if not hasattr(self.engine, 'bilgileri_getir'): return
            data = self.engine.bilgileri_getir()
            if data:
                self.ent_email.config(state="normal")
                self.safe_insert(self.ent_email, data.get("email"))
                self.safe_insert(self.ent_unvan, data.get("unvan"))
                self.safe_insert(self.ent_ad, data.get("ad"))
                self.safe_insert(self.ent_soyad, data.get("soyad"))
                self.safe_insert(self.ent_telefon, data.get("telefon"))
                self.safe_insert(self.ent_vergino, data.get("vergi_no"))
                self.ent_email.config(state="readonly")
                
                logo_b64 = data.get("logo_data")
                if logo_b64:
                    try:
                        img_data = base64.b64decode(logo_b64)
                        img = Image.open(io.BytesIO(img_data))
                        img.thumbnail((self.IMG_MAX_SIZE, self.IMG_MAX_SIZE))
                        self.tk_img_db = ImageTk.PhotoImage(img)
                        self.logo_canvas.delete("all")
                        self.logo_canvas.create_image(self.CENTER_POINT, self.CENTER_POINT, image=self.tk_img_db, anchor="center")
                    except: pass
        except Exception as e:
            print(f"Veri Yükleme Hatası: {e}")

    def safe_insert(self, entry, value):
        entry.delete(0, tk.END)
        entry.insert(0, str(value) if value is not None else "")

    def listeyi_yenile(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        if hasattr(self.engine, "klasor_tabanli_mukellefleri_getir"):
            data_list = self.engine.klasor_tabanli_mukellefleri_getir()
            for item in data_list:
                self.tree.insert("", "end", values=(item["unvan"], item["vkn"], item["donemler"]))

    def kredi_listesini_yenile(self):
        for item in self.tree_kredi.get_children():
            self.tree_kredi.delete(item)
        if hasattr(self.engine, "kredi_gecmisini_getir"):
            history = self.engine.kredi_gecmisini_getir()
            for item in history:
                self.tree_kredi.insert("", "end", values=(item["tarih"], item["islem"], item["tutar"]))

    def trigger_auto_sync(self, silent=True):
        threading.Thread(target=self._sync_thread, args=(silent,), daemon=True).start()

    def _sync_thread(self, silent):
        if hasattr(self.engine, 'sync_data_to_web'):
            try:
                success, msg = self.engine.sync_data_to_web()
                if not success and not silent:
                    print(f"Sync Hata: {msg}") 
            except: pass

    def kaydet(self):
        data = {
            "unvan": self.ent_unvan.get(),
            "ad": self.ent_ad.get(),
            "soyad": self.ent_soyad.get(),
            "telefon": self.ent_telefon.get(),
            "vergi_no": self.ent_vergino.get(),
            "yeni_sifre": self.ent_sifre.get(),
            "logo_data": self.selected_logo_base64
        }
        try:
            # GÜNCELLEME: Artık (status, msg) dönüyor
            status, msg = self.engine.bilgileri_kaydet(data)
            
            if status:
                messagebox.showinfo("Başarılı", msg)
                self.selected_logo_base64 = None
                self.ent_sifre.delete(0, tk.END)
                self.verileri_yukle()
                # Veri değiştiği için arka planda eşitle
                self.trigger_auto_sync(silent=True)
            else:
                messagebox.showerror("Kayıt Başarısız", msg)
                
        except Exception as e:
            messagebox.showerror("Hata", str(e))

class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Mali Analiz ve Profil Sistemi")
        self.geometry("1100x800")
        container = tk.Frame(self)
        container.pack(fill="both", expand=True)
        self.profil_frame = ProfilFrame(container, self)
        self.profil_frame.pack(fill="both", expand=True)

if __name__ == "__main__":
    app = MainApp()
    app.mainloop()