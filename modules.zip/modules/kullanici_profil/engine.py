import sqlite3
import json
import os
import hashlib
import datetime

# --- VERİTABANI BAĞLANTI AYARLARI (SABİT) ---
DB_PARAMS = {
    "host": "aws-1-eu-central-1.pooler.supabase.com",
    "port": "6543",
    "database": "postgres",
    "user": "postgres.vzhokozqlsumnhhxntql",
    "password": "Adana146919Mesut"
}

try:
    import psycopg2
    PG_AKTIF = True
except ImportError:
    PG_AKTIF = False
    print("UYARI: psycopg2 modülü yüklü değil. Web senkronizasyonu çalışmayacak.")

class ProfilEngine:
    def __init__(self):
        # 1. Klasör ve Veritabanı Yolları
        self.root_dir = self.find_mukellefler_dir()
        self.local_db_path = os.path.join(os.path.dirname(__file__), "local_assets.db")
        
        # 2. Varsayılan Email
        self.current_email = "demo@sistem.com" 
        try:
            email = self.get_logged_in_email()
            if email:
                self.current_email = email
        except:
            pass

        self._init_local_db()

    # --- YARDIMCI: KLASÖR BUL ---
    def find_mukellefler_dir(self):
        search_path = os.path.dirname(os.path.abspath(__file__)) 
        for _ in range(5):
            candidate = os.path.join(search_path, "MUKELLEFLER")
            if os.path.exists(candidate):
                return candidate
            parent = os.path.dirname(search_path)
            if parent == search_path: break
            search_path = parent
        return os.path.join(os.getcwd(), "MUKELLEFLER")

    # --- YARDIMCI: YEREL DB BAŞLAT ---
    def _init_local_db(self):
        try:
            conn = sqlite3.connect(self.local_db_path)
            cursor = conn.cursor()
            cursor.execute("""CREATE TABLE IF NOT EXISTS user_assets (email TEXT PRIMARY KEY, logo_base64 TEXT)""")
            cursor.execute("""CREATE TABLE IF NOT EXISTS credit_history (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, islem_tarihi TEXT, islem_adi TEXT, dusulen_miktar INTEGER, detay TEXT)""")
            conn.commit()
            conn.close()
        except Exception as e: print(f"Yerel DB hatası: {e}")

    # --- YARDIMCI: LOGIN EMAIL ÇEK ---
    def get_logged_in_email(self):
        try:
            path = os.path.join(os.path.dirname(self.root_dir), "login_data.json")
            if not os.path.exists(path): path = os.path.join(os.getcwd(), "login_data.json")
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f).get("email")
        except: pass
        return None

    # --- KREDİ GEÇMİŞİ (YEREL) ---
    def kredi_gecmisini_getir(self):
        history = []
        try:
            conn = sqlite3.connect(self.local_db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT islem_tarihi, islem_adi, dusulen_miktar FROM credit_history WHERE email = ? ORDER BY id DESC", (self.current_email,))
            for row in cursor.fetchall():
                history.append({"tarih": row[0], "islem": row[1], "tutar": f"{row[2]} Kredi"})
            conn.close()
        except: pass
        return history

    def kredi_islem_kaydet(self, islem_adi, miktar=1):
        try:
            tarih = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            conn = sqlite3.connect(self.local_db_path)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO credit_history (email, islem_tarihi, islem_adi, dusulen_miktar) VALUES (?, ?, ?, ?)", (self.current_email, tarih, islem_adi, miktar))
            conn.commit()
            conn.close()
        except: pass

    # --- KLASÖR TARAMA ---
    def klasor_tabanli_mukellefleri_getir(self):
        mukellef_listesi = []
        if not os.path.exists(self.root_dir): return []
        try:
            klasorler = [d for d in os.listdir(self.root_dir) if os.path.isdir(os.path.join(self.root_dir, d))]
            for k in klasorler:
                if '-' in k:
                    parts = k.rsplit('-', 1)
                    unvan = parts[0].strip()
                    vkn = parts[1].strip()
                else:
                    unvan = k
                    vkn = "Belirsiz"
                
                tam_yol = os.path.join(self.root_dir, k)
                donemler = []
                try:
                    yillar = [y for y in os.listdir(tam_yol) if os.path.isdir(os.path.join(tam_yol, y)) and y.isdigit() and len(y)==4]
                    yillar.sort(reverse=True)
                    for yil in yillar: donemler.append(f"{yil}")
                except: pass
                mukellef_listesi.append({"unvan": unvan, "vkn": vkn, "donemler": " | ".join(donemler) if donemler else "Veri Yok"})
        except: pass
        return mukellef_listesi

    # --- PROFİL BİLGİLERİ GETİR ---
    def bilgileri_getir(self):
        user_data = {"unvan": "Demo A.Ş.", "email": self.current_email, "ad": "", "soyad": "", "telefon": "", "vergi_no": "", "logo_data": None}
        
        # 1. Web'den Veri Çek
        if PG_AKTIF:
            try:
                conn = psycopg2.connect(**DB_PARAMS)
                cur = conn.cursor()
                # Email eşleşmesi önemli
                cur.execute("SELECT company_name, first_name, last_name, phone, tax_number FROM users WHERE email = %s", (self.current_email,))
                row = cur.fetchone()
                if row:
                    user_data["unvan"] = row[0] if row[0] else ""
                    user_data["ad"] = row[1] if row[1] else ""
                    user_data["soyad"] = row[2] if row[2] else ""
                    user_data["telefon"] = row[3] if row[3] else ""
                    user_data["vergi_no"] = row[4] if row[4] else ""
                conn.close()
            except Exception as e:
                print(f"Web veri çekme hatası: {e}")

        # 2. Yerelden Logo Çek
        try:
            conn = sqlite3.connect(self.local_db_path)
            cur = conn.cursor()
            cur.execute("SELECT logo_base64 FROM user_assets WHERE email=?", (self.current_email,))
            row = cur.fetchone()
            if row: user_data["logo_data"] = row[0]
            conn.close()
        except: pass
        
        return user_data

    # --- PROFİL BİLGİLERİ KAYDET ---
    def bilgileri_kaydet(self, data):
        """
        Form verilerini hem yerel hem web veritabanına kaydeder.
        Return: (Başarılı mı?, Mesaj)
        """
        if not PG_AKTIF:
            return False, "Veritabanı bağlantı modülü (psycopg2) eksik!"
        
        if "demo" in self.current_email:
            return False, "Demo modunda kayıt yapılamaz. Lütfen giriş yapın."

        msg = []
        
        # 1. Yerel Logo Kaydı
        if "logo_data" in data and data["logo_data"]:
            try:
                conn = sqlite3.connect(self.local_db_path)
                conn.execute("INSERT OR REPLACE INTO user_assets (email, logo_base64) VALUES (?, ?)", (self.current_email, data["logo_data"]))
                conn.commit(); conn.close()
            except Exception as e:
                msg.append(f"Logo Yerel Hata: {e}")

        # 2. Web Profil Kaydı
        try:
            conn = psycopg2.connect(**DB_PARAMS)
            cursor = conn.cursor()
            
            # Şifre var mı?
            if data.get("yeni_sifre"):
                hp = hashlib.sha256(data["yeni_sifre"].encode()).hexdigest()
                cursor.execute("UPDATE users SET password_hash=%s WHERE email=%s", (hp, self.current_email))
                msg.append("Şifre güncellendi.")
            
            # Profil Update
            cursor.execute("""
                UPDATE users 
                SET company_name=%s, first_name=%s, last_name=%s, phone=%s, tax_number=%s 
                WHERE email=%s
            """, (
                data.get("unvan"), data.get("ad"), data.get("soyad"), 
                data.get("telefon"), data.get("vergi_no"), self.current_email
            ))
            
            rows_updated = cursor.rowcount
            conn.commit()
            cursor.close()
            conn.close()
            
            if rows_updated == 0:
                return False, "Kullanıcı bulunamadı! E-Posta adresiniz veritabanında kayıtlı değil."
            
            msg.append("Profil bilgileri buluta kaydedildi.")
            return True, "\n".join(msg)

        except Exception as e:
            return False, f"Sunucu Hatası: {e}"

    # --- WEB SENKRONİZASYON ---
    def sync_data_to_web(self):
        if not PG_AKTIF: return False, "Veritabanı modülü yok."
        if "demo" in self.current_email: return False, "Demo modundasınız."

        try:
            conn = psycopg2.connect(**DB_PARAMS)
            cur = conn.cursor()

            # --- 1. MÜKELLEF (KLASÖR) FARK ANALİZİ VE SENKRONİZASYON ---
            # Mevcut web DB verilerini çek (vkn -> {unvan, periods} sözlüğü oluştur)
            cur.execute("SELECT vkn, unvan, periods FROM client_taxpayers WHERE email = %s", (self.current_email,))
            db_mukellefler = {row[0]: {"unvan": row[1], "donemler": row[2]} for row in cur.fetchall()}

            local_mukellefler = self.klasor_tabanli_mukellefleri_getir()
            local_vkn_list = []
            
            added_logs = []
            removed_logs = []

            for m in local_mukellefler:
                vkn = m['vkn']
                unvan = m['unvan']
                donemler = m['donemler']
                local_vkn_list.append(vkn)

                if vkn not in db_mukellefler:
                    # 1.A: DB'de yok, yeni eklenmiş -> INSERT
                    cur.execute("INSERT INTO client_taxpayers (email, vkn, unvan, periods) VALUES (%s, %s, %s, %s)",
                               (self.current_email, vkn, unvan, donemler))
                    added_logs.append((vkn, unvan))
                else:
                    # 1.B: DB'de var, değişim var mı kontrol et (Örn: Klasöre yeni yıl eklendiyse) -> UPDATE
                    if db_mukellefler[vkn]["unvan"] != unvan or db_mukellefler[vkn]["donemler"] != donemler:
                        cur.execute("UPDATE client_taxpayers SET unvan = %s, periods = %s WHERE email = %s AND vkn = %s",
                                   (unvan, donemler, self.current_email, vkn))

            # 1.C: DB'de var ama lokalden silinmiş -> DELETE
            for db_vkn, db_data in db_mukellefler.items():
                if db_vkn not in local_vkn_list:
                    cur.execute("DELETE FROM client_taxpayers WHERE email = %s AND vkn = %s", (self.current_email, db_vkn))
                    removed_logs.append((db_vkn, db_data["unvan"]))

            # --- 2. KREDİ GEÇMİŞİ SENKRONİZASYONU (Sadece Yeniler) ---
            # Mükerrer kaydı önlemek için web'deki mevcut logları set olarak al
            cur.execute("SELECT action_name, log_date FROM client_credit_logs WHERE email = %s", (self.current_email,))
            db_logs = {(row[0], row[1]) for row in cur.fetchall()}

            local_kredi = self.kredi_gecmisini_getir()
            for k in local_kredi:
                log_key = (k['islem'], k['tarih'])
                if log_key not in db_logs:
                    # Sadece DB'de eşleşmesi olmayan (yeni) logları ekle
                    cur.execute("INSERT INTO client_credit_logs (email, action_name, amount, log_date) VALUES (%s, %s, %s, %s)", 
                               (self.current_email, k['islem'], k['tutar'], k['tarih']))

            # --- 3. FARK LOGLARINI (ARŞİV EKLENDİ/SİLİNDİ) SİSTEME YAZ ---
            now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            
            for vkn, unvan in added_logs:
                cur.execute("INSERT INTO client_credit_logs (email, action_name, amount, log_date) VALUES (%s, %s, %s, %s)",
                           (self.current_email, f"Arşiv Eklendi: {unvan}", f"VKN: {vkn}", now_str))
            
            for vkn, unvan in removed_logs:
                cur.execute("INSERT INTO client_credit_logs (email, action_name, amount, log_date) VALUES (%s, %s, %s, %s)",
                           (self.current_email, f"Arşiv Silindi: {unvan}", f"VKN: {vkn}", now_str))

            # İşlemleri onayla ve kapat
            conn.commit()
            conn.close()
            return True, "Veriler başarıyla (sadece farklar) eşitlendi."

        except Exception as e:
            return False, f"Eşitleme Hatası: {e}"