import tkinter as tk
from tkinter import ttk, messagebox
import json
import sys
import os
# ui.py'nin bulunduğu dizinden 3 seviye yukarı (ANADIZIN)
# Bu satır, config.py'nin bulunduğu dizini sys.path'e ekler.
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
from config import CLR_BODY_BG, CLR_ACCENT, CLR_SIDEBAR_BG, get_base_dir
# Geri kalan kod
from config import CLR_BODY_BG, CLR_ACCENT, CLR_SIDEBAR_BG, get_base_dir
# --- ÖNEMLİ: Döngüsel import hatasını önlemek için importu class içinde yapacağız ---
# from utils.module_registry import get_available_forms (BURADAN SİLİNDİ)
CONFIG_PATH = os.path.join(get_base_dir(), "menu_config.json")
ICONS = ["📁", "🧾", "🔎", "📈", "👥", "🧮", "👤", "⚙️", "🔔", "🗑️", "📊", "💰", "🛡️", "🏗️"]
class MenuYonetimFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.menu_data = []
        self.setup_ui()
        self.load_config()
    def setup_ui(self):
        # --- Importu burada yapıyoruz ---
        from utils.module_registry import get_available_forms
        # --------------------------------
        tk.Label(self, text="⚙️ MENÜ VE FORM YÖNETİMİ", font=("Segoe UI", 16, "bold"), bg=CLR_BODY_BG, fg="#2c3e50").pack(pady=15)
       
        main_paned = tk.PanedWindow(self, orient=tk.HORIZONTAL, bg=CLR_BODY_BG)
        main_paned.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        # --- SOL PANEL (AĞAÇ YAPISI) ---
        left_frame = tk.Frame(main_paned, bg="white", bd=1, relief="solid")
        main_paned.add(left_frame, width=450)
        # Scrollbar ekleyelim
        tree_scroll = ttk.Scrollbar(left_frame)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree = ttk.Treeview(left_frame, yscrollcommand=tree_scroll.set)
        self.tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        tree_scroll.config(command=self.tree.yview)
       
        self.tree.heading("#0", text="Mevcut Menü Yapısı", anchor="w")
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)
        # Ekle/Sil Butonları
        btn_frame = tk.Frame(left_frame, bg="white")
        btn_frame.pack(fill=tk.X, padx=5, pady=5)
        tk.Button(btn_frame, text="➕ Ana Menü", command=self.add_root, bg="#27ae60", fg="white", font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2, fill=tk.X, expand=True)
        tk.Button(btn_frame, text="➕ Alt Menü", command=self.add_child, bg="#2980b9", fg="white", font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2, fill=tk.X, expand=True)
        tk.Button(btn_frame, text="🗑️ Sil", command=self.delete_item, bg="#c0392b", fg="white", font=("Segoe UI", 9)).pack(side=tk.RIGHT, padx=2)
        tk.Button(btn_frame, text="🔄 Sırala", command=self.sort_menus, bg="#8e44ad", fg="white", font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2)
        # --- SAĞ PANEL (DÜZENLEME) ---
        right_frame = tk.Frame(main_paned, bg=CLR_BODY_BG, padx=20)
        main_paned.add(right_frame)
        tk.Label(right_frame, text="Seçili Öğe Özellikleri", font=("Segoe UI", 12, "bold"), bg=CLR_BODY_BG, fg=CLR_ACCENT).pack(anchor="w", pady=(0, 20))
       
        # 1. Başlık
        tk.Label(right_frame, text="Görünen Başlık:", bg=CLR_BODY_BG, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.ent_title = tk.Entry(right_frame, width=40, font=("Segoe UI", 10))
        self.ent_title.pack(anchor="w", pady=(0, 15))
        # 2. İkon
        tk.Label(right_frame, text="İkon (Sadece Ana Menüler):", bg=CLR_BODY_BG, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.cmb_icon = ttk.Combobox(right_frame, values=ICONS, state="readonly", width=15, font=("Segoe UI", 12))
        self.cmb_icon.pack(anchor="w", pady=(0, 15))
        # 2.5 Sıra Numarası
        tk.Label(right_frame, text="Sıra Numarası (Küçükten Büyüğe):", bg=CLR_BODY_BG, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.ent_order = tk.Entry(right_frame, width=10, font=("Segoe UI", 10))
        self.ent_order.pack(anchor="w", pady=(0, 15))
        # 3. Hedef Form
        # 3. Hedef Form
        tk.Label(right_frame, text="Açılacak Form / Modül:", bg=CLR_BODY_BG, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        
        # ===== DEĞİŞEN KISIM =====
        form_listesi = get_available_forms()
        if "OzelHTML" not in form_listesi:
            form_listesi.append("OzelHTML") # Özel HTML seçeneğimizi listeye ekliyoruz
            
        self.cmb_target = ttk.Combobox(right_frame, values=form_listesi, state="readonly", width=40)
        # =========================
        
        self.cmb_target.pack(anchor="w", pady=(0, 15))
        # 4. Popup Checkbox
        self.var_popup = tk.BooleanVar()
        self.chk_popup = tk.Checkbutton(right_frame, text="Bu formu yeni pencerede (Pop-up) aç", variable=self.var_popup, bg=CLR_BODY_BG, font=("Segoe UI", 10))
        self.chk_popup.pack(anchor="w", pady=(10, 10))

        # --- YENİ EKLENEN: HTML İÇERİK EDİTÖRÜ ---
        tk.Label(right_frame, text="HTML İçeriği (Sadece 'Özel HTML Penceresi' hedefi için):", bg=CLR_BODY_BG, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.txt_html = tk.Text(right_frame, height=8, width=55, font=("Consolas", 10), bd=1, relief="solid")
        self.txt_html.pack(anchor="w", pady=(0, 20))
        # ----------------------------------------

        # Bilgi Notu
        tk.Label(right_frame, text="ℹ️ Not: Değişiklik yapınca önce 'Uygula' sonra 'Kaydet' yapınız.", bg=CLR_BODY_BG, fg="gray").pack(anchor="w")
        # KAYDETME BUTONLARI
        btn_save_container = tk.Frame(right_frame, bg=CLR_BODY_BG)
        btn_save_container.pack(fill=tk.X, pady=20)
        tk.Button(btn_save_container, text="💾 DEĞİŞİKLİKLERİ LİSTEYE UYGULA", command=self.apply_changes,
                  bg="#f39c12", fg="white", font=("Segoe UI", 10, "bold"), pady=8).pack(fill=tk.X, pady=5)
       
        tk.Button(btn_save_container, text="✅ TÜM AYARLARI DOSYAYA KAYDET", command=self.save_to_file,
                  bg=CLR_ACCENT, fg="white", font=("Segoe UI", 11, "bold"), pady=12).pack(fill=tk.X, pady=10)
    def load_config(self):
        """JSON dosyasını yükler"""
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    self.menu_data = json.load(f)
            except Exception as e:
                messagebox.showerror("Hata", f"Ayar dosyası bozuk: {e}")
                self.menu_data = []
        else:
            self.menu_data = []
        self.sort_menus()  # Yükleme sonrası sırala
        self.refresh_tree()
    def refresh_tree(self):
        """Ağaç yapısını self.menu_data'dan tekrar çizer"""
        # Mevcut seçimi hatırla (opsiyonel geliştirme olabilir)
        self.tree.delete(*self.tree.get_children())
       
        for idx, main_menu in enumerate(self.menu_data):
            # Ana Menü Düğümü
            title = main_menu.get('title', 'Başlıksız')
            icon = main_menu.get('icon', '•')
            order = main_menu.get('order', 0)
            main_id = self.tree.insert("", "end", text=f"{icon} {title} (Sıra: {order})", open=True, values=("ROOT", idx))
           
            # Alt Menü Düğümleri
            for sub_idx, item in enumerate(main_menu.get("items", [])):
                sub_title = item.get('title', 'Başlıksız')
                is_popup = " [POPUP]" if item.get("popup") else ""
                target = item.get("target", "---")
               
                display_text = f"• {sub_title} ({target}){is_popup}"
                self.tree.insert(main_id, "end", text=display_text, values=("CHILD", idx, sub_idx))
    def on_tree_select(self, event):
        """Ağaçtan bir şeye tıklanınca sağ tarafı doldur"""
        sel = self.tree.selection()
        if not sel: return
       
        vals = self.tree.item(sel[0])['values']
       
        # Alanları sıfırla
        self.ent_title.delete(0, tk.END)
        self.cmb_icon.set("")
        self.cmb_target.set("")
        self.var_popup.set(False)
        self.ent_order.delete(0, tk.END)
        self.txt_html.delete("1.0", tk.END) # YENİ: Editörü temizle

        if vals[0] == "ROOT":
            # Ana Menü Seçildi
            d = self.menu_data[vals[1]]
            self.ent_title.insert(0, d.get("title", ""))
            self.cmb_icon.set(d.get("icon", ""))
            self.ent_order.insert(0, str(d.get("order", 0)))
           
            # Ana menüde target, popup ve HTML olmaz
            self.cmb_target.config(state="disabled")
            self.chk_popup.config(state="disabled")
            self.txt_html.config(state="disabled") # YENİ
            self.ent_order.config(state="normal")
           
        elif vals[0] == "CHILD":
            # Alt Menü Seçildi
            d = self.menu_data[vals[1]]["items"][vals[2]]
            self.ent_title.insert(0, d.get("title", ""))
           
            self.cmb_target.config(state="normal") # Readonly yerine normal yap ki el ile 'OzelHTML' yazılabilsin
            self.cmb_target.set(d.get("target", ""))
           
            self.chk_popup.config(state="normal")
            self.var_popup.set(d.get("popup", False))

            # YENİ: HTML İçeriğini yükle
            self.txt_html.config(state="normal")
            self.txt_html.insert("1.0", d.get("html_content", ""))
           
            # Alt menüde ikon olmaz
            self.cmb_icon.config(state="disabled")
            self.ent_order.config(state="disabled")
           
        elif vals[0] == "CHILD":
            # Alt Menü Seçildi
            d = self.menu_data[vals[1]]["items"][vals[2]]
            self.ent_title.insert(0, d.get("title", ""))
           
            self.cmb_target.config(state="readonly")
            self.cmb_target.set(d.get("target", ""))
           
            self.chk_popup.config(state="normal")
            self.var_popup.set(d.get("popup", False))
           
            # Alt menüde ikon olmaz (bizim tasarımda)
            self.cmb_icon.config(state="disabled")
            self.ent_order.config(state="disabled")
    def apply_changes(self):
        """Sağdaki kutulardaki veriyi hafızadaki listeye (self.menu_data) yazar"""
        sel = self.tree.selection()
        if not sel:
            return False # Seçim yok
        vals = self.tree.item(sel[0])['values']
        new_title = self.ent_title.get()
        if vals[0] == "ROOT":
            self.menu_data[vals[1]]["title"] = new_title
            self.menu_data[vals[1]]["icon"] = self.cmb_icon.get()
            try:
                order = int(self.ent_order.get())
                self.menu_data[vals[1]]["order"] = order
            except:
                pass
           
        elif vals[0] == "CHILD":
            idx = self.menu_data[vals[1]]["items"][vals[2]]
            idx["title"] = new_title
            idx["target"] = self.cmb_target.get()
            idx["popup"] = self.var_popup.get()
            idx["html_content"] = self.txt_html.get("1.0", "end-1c")
           
        self.refresh_tree()
        # Seçimi geri getir (Kullanıcı deneyimi için)
        # (Basitlik adına şimdilik yapmıyoruz, tree refresh olunca seçim gidiyor)
        return True
    def add_root(self):
        max_order = max([m.get("order", 0) for m in self.menu_data], default=0)
        self.menu_data.append({"title": "YENİ MENÜ GRUBU", "icon": "📁", "items": [], "order": max_order + 1})
        self.refresh_tree()
        # En son ekleneni seçili yap (Geliştirilebilir)
    def add_child(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Uyarı", "Lütfen önce bir Ana Menü Grubu seçin.")
            return
           
        vals = self.tree.item(sel[0])['values']
       
        # Eğer alt menü seçiliyse, onun üst menüsünü bul
        root_index = vals[1]
       
        self.menu_data[root_index]["items"].append({
            "title": "Yeni Form İşlemi",
            "target": "Placeholder",
            "popup": False
        })
        self.refresh_tree()
    def delete_item(self):
        try:
            # 1. Seçimi Kontrol Et
            sel = self.tree.selection()
            if not sel: return
           
            # 2. Onay İste
            if not messagebox.askyesno("Silme Onayı", "Bu menü öğesini silmek istediğinize emin misiniz?"):
                return

            # 3. Verileri Al
            # Treeview'dan gelen veriyi alıyoruz
            vals = self.tree.item(sel[0])['values']
            
            # --- KRİTİK DÜZELTME ---
            # Veriler bazen string ('1'), bazen int (1) gelir.
            # Garanti olması için int() ile çeviriyoruz.
            root_idx = int(vals[1])
            
            # 4. Silme İşlemi
            if vals[0] == "ROOT":
                # Ana Menü Silme
                # Liste sınırları içinde mi diye kontrol ediyoruz (IndexError önlemek için)
                if 0 <= root_idx < len(self.menu_data):
                    del self.menu_data[root_idx]
                else:
                    raise IndexError("Menü indeksi bulunamadı.")
                    
            elif vals[0] == "CHILD":
                # Alt Menü Silme
                child_idx = int(vals[2]) # Bunu da sayıya çeviriyoruz
                
                # Önce ana menü var mı bak
                if 0 <= root_idx < len(self.menu_data):
                    items_list = self.menu_data[root_idx]["items"]
                    # Sonra alt menü var mı bak
                    if 0 <= child_idx < len(items_list):
                        del items_list[child_idx]
                    else:
                        raise IndexError("Alt menü indeksi bulunamadı.")
                else:
                    raise IndexError("Ana menü bulunamadı.")
            
            # 5. Listeyi Yenile
            self.refresh_tree()
            # İşlem başarılı mesajı (İsteğe bağlı, kafa karıştırmaması için kapalı tutulabilir)
            # messagebox.showinfo("Bilgi", "Kayıt başarıyla silindi.")

        except Exception as e:
            # Eğer bir hata olursa ekrana basar, böylece neden başarısız olduğunu görürüz.
            messagebox.showerror("Silme Hatası", f"İşlem sırasında bir hata oluştu:\n{str(e)}")
            print(f"HATA DETAYI: {e}")
    def sort_menus(self):
        self.menu_data = sorted(self.menu_data, key=lambda x: x.get("order", 0))
        self.refresh_tree()
    def save_to_file(self):
        """Hafızadaki veriyi JSON dosyasına yazar"""
       
        # 1. ÖNCE OTOMATİK UYGULA (Kullanıcı unutursa diye)
        self.apply_changes()
       
        # 2. SIRALA (Kaydetmeden önce sırala)
        self.sort_menus()
       
        # 3. DOSYAYA YAZ
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(self.menu_data, f, ensure_ascii=False, indent=4)
           
            messagebox.showinfo("Başarılı", "✅ Menü ayarları başarıyla kaydedildi!\n\nDeğişikliklerin aktif olması için programı kapatıp açmanız gerekebilir.")
        except Exception as e:
            messagebox.showerror("Kayıt Hatası", f"Dosya yazılamadı:\n{str(e)}")