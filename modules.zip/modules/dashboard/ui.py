import tkinter as tk
from tkinter import ttk, messagebox
import os
import pandas as pd
from datetime import datetime

from config import CLR_BODY_BG
from modules.dashboard.engine import DashboardEngine

def turkce_kucuk_yap(metin):
    """Metinlerdeki Türkçe karakterleri bozmadan küçük harfe çevirir."""
    if not isinstance(metin, str):
        return ""
    
    harfler = {"I": "ı", "İ": "i", "Ş": "ş", "Ç": "ç", "Ğ": "ğ", "Ö": "ö", "Ü": "ü"}
    for buyuk, kucuk in harfler.items():
        metin = metin.replace(buyuk, kucuk)
    return metin.lower()


# =========================================================================
# 1. BÖLÜM: DEFTER SEÇİM PANELİ (Aynı Bırakıldı)
# =========================================================================
class SidebarDefterSecimPanel(tk.Frame):
    def __init__(self, master, main_app, **kwargs):
        self.bg_color = kwargs.pop("bg", "#2c3e50")
        super().__init__(master, bg=self.bg_color, **kwargs)
        
        self.main_app = main_app
        self.secili_mukellef = None
        self.secili_yil = None
        self.mukellef_listesi = []
        
        self.mukellef_popup = None
        self.donem_butonlari = []    
        self.versiyon_butonlari = [] 
        
        # 1. SATIR: Sadece Arama Çubuğu
        self.row1 = tk.Frame(self, bg=self.bg_color)
        self.row1.pack(fill=tk.X, padx=10, pady=(10, 10))
        
        self.search_border = tk.Frame(self.row1, bg="red")
        self.search_border.pack(fill=tk.X, expand=True)
        
        self.search_inner = tk.Frame(self.search_border, bg="#bdc3c7", cursor="hand2")
        self.search_inner.pack(fill=tk.BOTH, expand=True, padx=2, pady=2) 
        
        self.lbl_selected_mukellef = tk.Label(self.search_inner, text="Arama.. Unvan VKN TCKN", bg="#bdc3c7", fg="black", font=("Segoe UI", 10, "bold"), anchor="w")
        self.lbl_selected_mukellef.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10, pady=5)
        
        self.lbl_search_icon = tk.Label(self.search_inner, text="🔍", bg="#bdc3c7", fg="#2c3e50", font=("Segoe UI", 11))
        self.lbl_search_icon.pack(side=tk.RIGHT, padx=10)

        for w in [self.search_inner, self.lbl_selected_mukellef, self.lbl_search_icon]:
            w.bind("<Button-1>", self.show_mukellef_popup)

        # 2. SATIR: Dönem Seçimi
        self.row2 = tk.Frame(self, bg=self.bg_color)
        self.lbl_donem = tk.Label(self.row2, text="Dönem:", bg=self.bg_color, fg="#2c3e50", font=("Segoe UI", 10, "bold"))
        self.lbl_donem.pack(side=tk.LEFT, padx=(10, 5))
        self.donem_btns_frame = tk.Frame(self.row2, bg=self.bg_color)
        self.donem_btns_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # 3. SATIR: Versiyon Seçimi
        self.row3 = tk.Frame(self, bg=self.bg_color)
        self.lbl_versiyon = tk.Label(self.row3, text="Versiyon:", bg=self.bg_color, fg="#2c3e50", font=("Segoe UI", 10, "bold"))
        self.lbl_versiyon.pack(side=tk.LEFT, padx=(10, 5))
        self.versiyon_btns_frame = tk.Frame(self.row3, bg=self.bg_color)
        self.versiyon_btns_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        self.row2.pack_forget()
        self.row3.pack_forget()
        self.verileri_doldur()

    def create_custom_button(self, parent, text, command, selected=False):
        border_color = "red"
        bg_color = "white" if selected else "#bdc3c7"
        container = tk.Frame(parent, bg=border_color)
        container.pack(side=tk.LEFT, padx=3, pady=2)
        lbl = tk.Label(container, text=text, bg=bg_color, fg="black", font=("Segoe UI", 9, "bold"), cursor="hand2", padx=10, pady=2)
        lbl.pack(padx=2, pady=2)
        lbl.bind("<Button-1>", lambda e: command())
        return container, lbl

    def reset_panel(self):
        self.lbl_selected_mukellef.config(text="Arama.. Unvan VKN TCKN")
        self.secili_mukellef = None
        self.secili_yil = None
        for container, _, _ in self.donem_butonlari: container.destroy()
        for container, _, _, _ in self.versiyon_butonlari: container.destroy()
        self.donem_butonlari.clear()
        self.versiyon_butonlari.clear()
        self.row2.pack_forget()
        self.row3.pack_forget()

    def show_mukellef_popup(self, event):
        if self.mukellef_popup and self.mukellef_popup.winfo_exists():
            self.mukellef_popup.destroy()
            return
            
        self.mukellef_popup = tk.Toplevel(self)
        self.mukellef_popup.wm_overrideredirect(True) 
        self.mukellef_popup.configure(bg="#34495e", highlightbackground="red", highlightthickness=2)
        
        x = self.row1.winfo_rootx()
        y = self.row1.winfo_rooty() + self.row1.winfo_height()
        width = self.row1.winfo_width()
        self.mukellef_popup.geometry(f"{width}x250+{x}+{y}")
        
        search_frame = tk.Frame(self.mukellef_popup, bg="#2c3e50", pady=5)
        search_frame.pack(fill=tk.X)
        
        tk.Label(search_frame, text="🔍", bg="#2c3e50", fg="white").pack(side=tk.LEFT, padx=5)
        search_var = tk.StringVar()
        entry_search = tk.Entry(search_frame, textvariable=search_var, font=("Segoe UI", 10), bg="white", fg="black")
        entry_search.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        entry_search.focus_set()

        list_frame = tk.Frame(self.mukellef_popup, bg="#34495e")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical")
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        listbox = tk.Listbox(list_frame, font=("Segoe UI", 10), bg="#34495e", fg="white", selectbackground="#E97D35", bd=0, highlightthickness=0, yscrollcommand=scrollbar.set)
        listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=listbox.yview)

        def update_list(*args):
            search_term = turkce_kucuk_yap(search_var.get())
            listbox.delete(0, tk.END)
            for m in self.mukellef_listesi:
                if search_term in turkce_kucuk_yap(m):
                    listbox.insert(tk.END, m)
                    
        search_var.trace("w", update_list)
        update_list() 
        
        def on_select(evt):
            selection = listbox.curselection()
            if selection:
                secilen = listbox.get(selection[0])
                self.lbl_selected_mukellef.config(text=secilen)
                self.secili_mukellef = secilen
                self.on_mukellef_select() 
                self.mukellef_popup.destroy()

        listbox.bind("<<ListboxSelect>>", on_select)
        
        def close_popup(e=None):
            if self.mukellef_popup: self.mukellef_popup.destroy()
                
        self.mukellef_popup.bind("<Escape>", close_popup)
        entry_search.bind("<Escape>", close_popup)

    def set_collapsed_mode(self, collapsed):
        if collapsed:
            self.row1.pack_forget()
            self.row2.pack_forget()
            self.row3.pack_forget()
            if self.mukellef_popup and self.mukellef_popup.winfo_exists():
                self.mukellef_popup.destroy()
        else:
            self.row1.pack(fill=tk.X, padx=10, pady=(15, 10))
            if self.secili_mukellef: self.row2.pack(fill=tk.X, padx=10, pady=5)
            if self.secili_yil: self.row3.pack(fill=tk.X, padx=10, pady=5)

    def verileri_doldur(self):
        try:
            from modules.arsiv_yukle.engine import arsivdeki_mukellefleri_getir
            self.mukellef_listesi = arsivdeki_mukellefleri_getir()
        except Exception as e:
            print(f"Mükellefler yüklenemedi: {e}")

    def on_mukellef_select(self):
        self.secili_yil = None
        for container, _, _ in self.donem_butonlari: container.destroy()
        for container, _, _, _ in self.versiyon_butonlari: container.destroy()
        self.donem_butonlari.clear()
        self.versiyon_butonlari.clear()
        self.row3.pack_forget()

        try:
            from modules.arsiv_yukle.engine import mukellef_yillarini_getir
            yillar = mukellef_yillarini_getir(self.secili_mukellef)
            
            if yillar:
                self.row2.pack(fill=tk.X, padx=10, pady=5)
                for yil in yillar:
                    cont, lbl = self.create_custom_button(self.donem_btns_frame, yil, lambda y=yil: self.on_yil_select(y), selected=False)
                    self.donem_butonlari.append((cont, lbl, yil))
        except Exception as e:
            print(f"Yıllar yüklenemedi: {e}")

    def on_yil_select(self, secilen_yil):
        self.secili_yil = secilen_yil
        for _, lbl, yil_text in self.donem_butonlari:
            if yil_text == secilen_yil:
                lbl.config(bg="white")
            else:
                lbl.config(bg="#bdc3c7")
                
        for container, _, _, _ in self.versiyon_butonlari: container.destroy()
        self.versiyon_butonlari.clear()
        
        try:
            from modules.arsiv_yukle.engine import yil_dosyalarini_getir
            dosyalar = yil_dosyalarini_getir(self.secili_mukellef, self.secili_yil)
            yillik_dosyalar = [d for d in dosyalar if "YILLIK" in d['tip'] or "FULL" in d['ad']]
            
            if yillik_dosyalar:
                self.row3.pack(fill=tk.X, padx=10, pady=5)
                for idx, d in enumerate(yillik_dosyalar):
                    btn_text = f"Versiyon-{idx+1}"
                    cont, lbl = self.create_custom_button(self.versiyon_btns_frame, btn_text, lambda dosya=d, txt=btn_text: self.on_versiyon_select(dosya, txt), selected=False)
                    self.versiyon_butonlari.append((cont, lbl, btn_text, d))
            else:
                self.row3.pack_forget()
        except Exception as e:
            print(f"Dosyalar yüklenemedi: {e}")

    def on_versiyon_select(self, dosya, secilen_btn_text):
        for _, lbl, btn_text, _ in self.versiyon_butonlari:
            if btn_text == secilen_btn_text:
                lbl.config(bg="white")
            else:
                lbl.config(bg="#bdc3c7")
        self.yukle_click(dosya)

    def yukle_click(self, dosya_bilgisi):
        dosya_yolu = dosya_bilgisi['yol']
        acik_sekmeler = [t for t in self.main_app.opened_tabs.keys() if t != "Dashboard"]
        
        if acik_sekmeler:
            onay = messagebox.askyesno("Sekmeler Kapatılacak", f"'{dosya_bilgisi['ad']}' versiyonunu yükleyebilmek için açık olan tüm çalışma sekmelerinin kapatılması gerekiyor.\n\nDevam etmek ve sekmeleri kapatmak istiyor musunuz?")
            if not onay: return
            self.main_app.close_all_tabs()
        else:
            onay = messagebox.askyesno("Veri Yükleme", f"{dosya_bilgisi['ad']} versiyonunu yüklemek istiyor musunuz?")
            if not onay: return

        os.environ['EDENETIM_AKTIF_DOSYA'] = str(dosya_yolu)
        
        if not hasattr(pd, '_orijinal_read_parquet'):
            pd._orijinal_read_parquet = pd.read_parquet
            
        def _korsan_read_parquet(path, *args, **kwargs):
            if os.environ.get('EDENETIM_ARAYUZ_TABLO_OKUMA') == "1":
                return pd._orijinal_read_parquet(path, *args, **kwargs)

            aktif_arsiv = os.environ.get('EDENETIM_AKTIF_DOSYA')
            if isinstance(path, str) and path.endswith(".parquet") and aktif_arsiv:
                if os.path.exists(aktif_arsiv):
                    istenen = os.path.basename(path)
                    aktif = os.path.basename(aktif_arsiv)
                    if "FULL" in istenen and istenen != aktif:
                        return pd._orijinal_read_parquet(aktif_arsiv, *args, **kwargs)
            return pd._orijinal_read_parquet(path, *args, **kwargs)
            
        pd.read_parquet = _korsan_read_parquet

        from modules.arsiv_yukle.engine import parquet_yukle
        df, msg = parquet_yukle(dosya_yolu)
        
        if df is not None:
            try:
                parts = self.secili_mukellef.rsplit('-', 1)
                vkn = parts[1] if len(parts) > 1 and parts[1].isdigit() else "0000000000"
                unvan = parts[0] if len(parts) > 1 else self.secili_mukellef
                yil = str(self.secili_yil)

                self.main_app.df = df  
                self.main_app.aktif_dosya_yolu = dosya_yolu 

                try:
                    from modules.mizan_analiz.engine import MizanEngine
                    from modules.mali_tablolar.engine import FinancialReportEngine
                    mizan_motoru = MizanEngine()
                    mizan_motoru.save_to_sqlite()
                    mali_motor = FinancialReportEngine(parent=None)
                    mali_motor.calculate_matrix("Bilanco", "Yillik", force_update=True)
                    mali_motor.calculate_matrix("Gelir Tablosu", "Yillik", force_update=True)
                except Exception as ex:
                    print(f"Hesaplama Motoru Hatası: {ex}")

                if hasattr(self.main_app, 'update_header_info'):
                    self.main_app.update_header_info(unvan, vkn, yil)
                
                messagebox.showinfo("Başarılı", f"{dosya_bilgisi['ad']} başarıyla yüklendi!")

                if hasattr(self.main_app, 'refresh_app'):
                    self.main_app.refresh_app()

            except Exception as e:
                messagebox.showerror("Hata", f"Veri işleme hatası: {e}")
        else:
            messagebox.showerror("Hata", f"Dosya okunamadı: {msg}")


# =========================================================================
# 2. BÖLÜM: YENİ SABİT VE YÜKSEK PERFORMANSLI DASHBOARD
# =========================================================================
class DashboardFrame(tk.Frame):
    def __init__(self, parent, main_app, application_path):
        super().__init__(parent, bg=CLR_BODY_BG)
        self.main_app = main_app
        self.application_path = application_path
        self.dash_data = []
        self.max_kayit = 1
        
        self._search_timer = None 
        self._canvas_width = 1150 # Tablo genişliğini tutar
        
        self.engine = DashboardEngine(application_path)
        self.setup_ui()
        self.load_data()

    def setup_ui(self):
        # --- Üst Alanlar ---
        header_frame = tk.Frame(self, bg=CLR_BODY_BG)
        header_frame.pack(fill="x", pady=(20, 10), padx=40)
        
        search_wrapper = tk.Frame(header_frame, bg=CLR_BODY_BG)
        search_wrapper.pack(side=tk.LEFT, fill=tk.X)
        self.defter_secim_panel = SidebarDefterSecimPanel(search_wrapper, main_app=self.main_app, bg=CLR_BODY_BG)
        self.defter_secim_panel.pack(side=tk.LEFT, fill=tk.X)

        center_container = tk.Frame(self, bg=CLR_BODY_BG)
        center_container.pack(fill="both", expand=True, padx=40, pady=10)

        card_frame = tk.Frame(center_container, bg="#ffffff", highlightthickness=1, highlightbackground="#e2e8f0")
        card_frame.pack(fill=tk.BOTH, expand=True)

        top_header_container = tk.Frame(card_frame, bg="#ffffff")
        top_header_container.pack(fill=tk.X, padx=25, pady=(20, 15))

        row1 = tk.Frame(top_header_container, bg="#ffffff")
        row1.pack(fill=tk.X, pady=(0, 15))
        
        title_frame = tk.Frame(row1, bg="#ffffff")
        title_frame.pack(side=tk.LEFT)
        tk.Label(title_frame, text="📊", font=("Segoe UI", 18), bg="#ffffff", fg="#2980b9").pack(side=tk.LEFT, padx=(0, 8))
        tk.Label(title_frame, text="MÜKELLEF VERİ DURUM ÖZETİ", font=("Segoe UI", 15, "bold"), bg="#ffffff", fg="#1e293b").pack(side=tk.LEFT)
        
        aylar = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
        tarih_str = f"{datetime.now().day} {aylar[datetime.now().month-1]} {datetime.now().year}"
        tk.Label(row1, text=f"Son Güncelleme: {tarih_str}", font=("Segoe UI", 9), bg="#ffffff", fg="#94a3b8").pack(side=tk.RIGHT)

        row2 = tk.Frame(top_header_container, bg="#ffffff")
        row2.pack(fill=tk.X)

        filter_frame = tk.Frame(row2, bg="#ffffff")
        filter_frame.pack(side=tk.LEFT)
        tk.Label(filter_frame, text="Yıl Filtresi", font=("Segoe UI", 10), bg="#ffffff", fg="#475569").pack(side=tk.LEFT, padx=(0, 10))
        
        self.year_buttons_frame = tk.Frame(filter_frame, bg="#ffffff", highlightthickness=1, highlightbackground="#cbd5e1", padx=2, pady=2)
        self.year_buttons_frame.pack(side=tk.LEFT)
        tk.Label(self.year_buttons_frame, text="📅", bg="#ffffff", fg="#64748b", font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=(4, 5))
        
        self.year_filter_var = tk.StringVar(self)
        self.year_filter_var.set("Tümü")
        self.year_btn_widgets = []

        search_box = tk.Frame(row2, bg="#ffffff", highlightthickness=1, highlightbackground="#cbd5e1", padx=5, pady=2)
        search_box.pack(side=tk.RIGHT)
        tk.Label(search_box, text="🔍", bg="#ffffff", fg="#94a3b8").pack(side=tk.RIGHT, padx=(0, 5))
        
        # --- ARAMA GECİKTİRİCİ ---
        self.dash_search_var = tk.StringVar()
        def gecikmeli_arama(*args):
            if self._search_timer:
                self.after_cancel(self._search_timer)
            self._search_timer = self.after(300, self._render_dash_table)
            
        self.dash_search_var.trace("w", gecikmeli_arama)
        tk.Entry(search_box, textvariable=self.dash_search_var, font=("Segoe UI", 9), width=25, bd=0, bg="#ffffff").pack(side=tk.RIGHT, ipady=3)

        # --- YÜKSEK PERFORMANSLI CANVAS MOTORU ---
        # Artık içinde binlerce Frame barındırmıyor. Şekilleri direkt ekrana çiziyor!
        self.table_canvas = tk.Canvas(card_frame, bg="#ffffff", highlightthickness=0)
        table_scroll = ttk.Scrollbar(card_frame, orient="vertical", command=self.table_canvas.yview)
        self.table_canvas.configure(yscrollcommand=table_scroll.set)

        self.table_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(25, 0), pady=(0, 20))
        table_scroll.pack(side=tk.RIGHT, fill=tk.Y, pady=(0, 20), padx=(0, 20))

        # Ekran boyutlandırma yakalayıcısı
        def _on_canvas_resize(event):
            # Genişlik sadece önemli ölçüde değiştiğinde arayüzü tekrar çiz. 
            # (Sekmeler arası geçişlerde boyut aynı kaldığı için çizim donmasını ENGELLER)
            if abs(getattr(self, '_canvas_width', 1150) - event.width) > 10:
                self._canvas_width = event.width
                if self.dash_data: 
                    self._render_dash_table()

        self.table_canvas.bind("<Configure>", _on_canvas_resize)

    def load_data(self):
        self.dash_data, self.max_kayit = self.engine.get_dashboard_data()
        
        unique_years = set(row['yil'] for row in self.dash_data if row['yil'] != "-")
        sorted_years = sorted(list(unique_years), reverse=True)
        all_options = ["Tümü"] + sorted_years

        for _, lbl in self.year_btn_widgets: lbl.destroy()
        self.year_btn_widgets.clear()

        for option in all_options:
            lbl = tk.Label(self.year_buttons_frame, text=option, font=("Segoe UI", 9, "bold"), bg="#ffffff", fg="#475569", cursor="hand2", padx=8, pady=2)
            lbl.pack(side=tk.LEFT, padx=1)
            
            def on_year_click(e, opt=option):
                self.year_filter_var.set(opt)
                self.update_year_button_styles()
                self._render_dash_table()
                
            lbl.bind("<Button-1>", on_year_click)
            self.year_btn_widgets.append((option, lbl))

        self.year_filter_var.set("Tümü")
        self.update_year_button_styles()
        self._render_dash_table()

    def update_year_button_styles(self):
        selected = self.year_filter_var.get()
        for opt, lbl in self.year_btn_widgets:
            if opt == selected:
                lbl.config(bg="#e2e8f0", fg="#0f172a") 
            else:
                lbl.config(bg="#ffffff", fg="#475569")

    # =====================================================================
    # NATIVE CANVAS RENDERER - Mükemmel Akıcılık Sağlayan Kısım
    # =====================================================================
    def _render_dash_table(self, *args):
        # 1. Eski çizimleri saniyenin binde biri hızında siler
        self.table_canvas.delete("all")

        search_q = self.dash_search_var.get().lower()
        selected_year = self.year_filter_var.get()

        # Kayıt sütunu SİLİNDİ, X koordinatları ekrana yayıldı ve hizalamalar Ortalandı ("c")
        headers = [
            ("🏢 Mükellef Unvanı", "w", 20),
            ("📅 Dönem", "c", 280),
            ("📑 Defter Detay", "c", 400),
            ("📥 Fatura Gelen", "c", 550),
            ("📤 Fatura Giden", "c", 660),
            ("🚫 Fatura İptal", "c", 770),
            ("📊 Rapor", "c", 880),
            ("⚠️ Risk", "c", 990),
            ("📝 Açık Not", "c", 1100)
        ]

        y_offset = 20
        # Başlıkları doğrudan Canvas'a yaz (Hizalamalara göre)
        for txt, align, x_pos in headers:
            anchor_pos = "w" if align == "w" else "center"
            self.table_canvas.create_text(x_pos, y_offset, text=txt, font=("Segoe UI", 9, "bold"), fill="#475569", anchor=anchor_pos)

        y_offset += 20
        c_width = max(self._canvas_width, 1150)
        self.table_canvas.create_line(10, y_offset, c_width, y_offset, fill="#e2e8f0", width=2)
        y_offset += 2

        row_idx = 0
        for row in self.dash_data:
            if selected_year != "Tümü" and row['yil'] != selected_year: continue
            if search_q and search_q not in row['unvan'].lower() and search_q not in str(row['yil']): continue

            bg_color = "#ffffff" if row_idx % 2 == 0 else "#f8fafc"

            # 1. Satır Arkaplanı
            self.table_canvas.create_rectangle(0, y_offset, c_width, y_offset+45, fill=bg_color, outline="")

            # 2. Ünvan (Sola Dayalı)
            unvan = row['unvan']
            if len(unvan) > 35: unvan = unvan[:32] + "..."
            self.table_canvas.create_text(20, y_offset+22, text=unvan, font=("Segoe UI", 9), fill="#1e293b", anchor="w")

            # 3. Yıl (Ortalanmış)
            display_yil = str(row['yil'])
            display_defter_tip = row['defter_tip']
            is_version = "Versiyon-" in display_defter_tip

            if is_version and " / " in display_defter_tip:
                donem_part, versiyon_part = display_defter_tip.split(" / ", 1)
                display_yil = f"{row['yil']} ({versiyon_part})"
                display_defter_tip = donem_part

            self.table_canvas.create_text(280, y_offset+22, text=display_yil, font=("Segoe UI", 9), fill="#475569", anchor="center")

            # 4. Detay (Ortalanmış)
            det_font = ("Segoe UI", 9, "bold") if is_version else ("Segoe UI", 9)
            det_color = "#16a085" if is_version else "#475569"
            self.table_canvas.create_text(400, y_offset+22, text=display_defter_tip, font=det_font, fill=det_color, anchor="center")

            # Helper Fonksiyon: Orijinal Tasarımdaki Rozetleri Şekillerle Çizer
            def draw_badge(cx, val, active_bg, active_fg, icon):
                if val > 0:
                    txt = f"{val:,}".replace(",", ".") + f" {icon}"
                    t_id = self.table_canvas.create_text(cx, y_offset+22, text=txt, font=("Segoe UI", 9, "bold"), fill=active_fg, anchor="center")
                    bbox = self.table_canvas.bbox(t_id)
                    r_id = self.table_canvas.create_rectangle(bbox[0]-6, bbox[1]-4, bbox[2]+6, bbox[3]+4, fill=active_bg, outline="")
                    self.table_canvas.tag_lower(r_id, t_id)
                else:
                    self.table_canvas.create_text(cx, y_offset+22, text="0", font=("Segoe UI", 9), fill="#94a3b8", anchor="center")

            # 5. İstatistik Rozetleri (Ortalanmış X Koordinatları)
            draw_badge(550, row['gelen'], "#d1fae5", "#065f46", "✔")
            draw_badge(660, row['giden'], "#d1fae5", "#065f46", "✔")
            
            # Kırmızı İptal Rozeti (🚫) Eklendi
            draw_badge(770, row['iptal'], "#fee2e2", "#b91c1c", "🚫") 
            
            draw_badge(880, row.get('rapor_sayisi', 0), "#e0f2fe", "#0369a1", "✔")
            draw_badge(990, row.get('risk_sayisi', 0), "#fee2e2", "#b91c1c", "⚠")
            draw_badge(1100, row.get('devam_not', 0), "#fef3c7", "#92400e", "⏳")

            y_offset += 45
            self.table_canvas.create_line(10, y_offset, c_width, y_offset, fill="#f1f5f9", width=1)
            row_idx += 1

        # Tablonun toplam uzunluğunu Scroll alanına tanıt
        self.table_canvas.config(scrollregion=(0, 0, c_width, y_offset + 20))