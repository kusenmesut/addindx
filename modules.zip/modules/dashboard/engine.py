import os
import sqlite3
import pandas as pd
import json

def aylari_rakamla_goster(aylar_listesi):
    rakamlar = []
    for ay_str in aylar_listesi:
        if "-" in ay_str:
            try:
                ay_kodu = int(ay_str.split("-")[1])
                rakamlar.append(str(ay_kodu))
            except:
                pass
    if not rakamlar:
        return "-"
    if len(rakamlar) == 12:
        return "1-12"
    return ", ".join(rakamlar)


class DashboardEngine:
    def __init__(self, application_path):
        self.application_path = application_path

    def get_dashboard_data(self):
        from config import get_mukellefler_dir
        from modules.arsiv_yukle.engine import arsivdeki_mukellefleri_getir, mukellef_yillarini_getir, yil_dosyalarini_getir
        
        db_path_notes = os.path.join(self.application_path, "notes.db")
        pending_notes_map = {}
        if os.path.exists(db_path_notes):
            try:
                conn_n = sqlite3.connect(db_path_notes)
                cursor_n = conn_n.cursor()
                cursor_n.execute("SELECT vkn, SUM(CASE WHEN status='Devam' THEN 1 ELSE 0 END) FROM risk_notes GROUP BY vkn")
                for r in cursor_n.fetchall(): pending_notes_map[str(r[0])] = r[1] or 0
                conn_n.close()
            except: pass

        mukellefler = arsivdeki_mukellefleri_getir()
        dash_data = []
        max_k = 0
        
        for m in mukellefler:
            unvan = m.split('-')[0] if '-' in m else m
            vkn_no = m.split('-')[1] if '-' in m and len(m.split('-')) > 1 else ""
            yillar = mukellef_yillarini_getir(m)
            
            pending_count = pending_notes_map.get(vkn_no, 0)
            
            if not yillar:
                dash_data.append({"unvan": unvan, "yil": "-", "defter_tip": "Yüklü Değil", "kayit": 0, "gelen": 0, "giden": 0, "iptal": 0, "rapor_sayisi": 0, "risk_sayisi": 0, "devam_not": pending_count})
                continue

            istatistik_yolu = os.path.join(get_mukellefler_dir(), m, "yukleme_istatistikleri.json")
            stats = []
            if os.path.exists(istatistik_yolu):
                try:
                    with open(istatistik_yolu, "r", encoding="utf-8") as f: stats = json.load(f)
                except: pass

            for yil in yillar:
                dosyalar = yil_dosyalarini_getir(m, yil)
                aylik = [d for d in dosyalar if "AYLIK" in d['tip']]
                yillik = [d for d in dosyalar if "YILLIK" in d['tip'] or "FULL" in d['ad']]

                donem_sayisi = 0
                hedef_aylar = []
                for s in stats:
                    if any(str(yil) in str(a) for a in s.get('aylar', [])):
                        if s.get('ay_sayisi', 0) > donem_sayisi:
                            donem_sayisi = s.get('ay_sayisi', 0)
                            hedef_aylar = s.get('aylar', [])

                if hedef_aylar:
                    ay_metni = aylari_rakamla_goster(hedef_aylar)
                elif donem_sayisi == 0 and aylik: 
                    ay_metni = f"{len(aylik)} Ay"
                elif donem_sayisi == 0 and yillik: 
                    ay_metni = "1-12"
                else:
                    ay_metni = f"{donem_sayisi} Ay" if donem_sayisi > 0 else "-"

                if yillik:
                    yillik_sirali = sorted(yillik, key=lambda x: os.path.getmtime(x['yol']))
                    for idx, d in enumerate(yillik_sirali):
                        gelen_c, giden_c, iptal_c = 0, 0, 0
                        rapor_sayisi, risk_sayisi = 0, 0
                        kayit_sayisi = 0

                        versiyon_klasoru = os.path.dirname(d['yol'])

                        # 1. FATURA VERİLERİ VE İPTAL OKUMA (YILLIK)
                        fatura_db = os.path.join(versiyon_klasoru, f"fatura_data_{yil}.db")
                        if os.path.exists(fatura_db):
                            try:
                                conn = sqlite3.connect(fatura_db)
                                cursor = conn.cursor()
                                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
                                tables = cursor.fetchall()
                                if tables:
                                    t_name = tables[0][0]
                                    cursor.execute(f"PRAGMA table_info({t_name});")
                                    cols = [info[1] for info in cursor.fetchall()]

                                    fat_col = next((c for c in cols if c == "NO_FATURA" or ('FATURA' in c.upper() and 'NO' in c.upper())), None)
                                    c_q = f'COUNT(DISTINCT "{fat_col}")' if fat_col else 'COUNT(*)'

                                    alici_col = next((c for c in cols if 'ALICI' in c.upper() and ('VKN' in c.upper() or 'TCKN' in c.upper())), None)
                                    satici_col = next((c for c in cols if 'SATICI' in c.upper() and ('VKN' in c.upper() or 'TCKN' in c.upper())), None)
                                    tip_cols = [c for c in cols if c.upper() in ["TUR_FATURA", "TIP_FATURA", "FATURA_TIPI", "FATURA_TURU", "SENARYO"]]

                                    if alici_col and vkn_no:
                                        cursor.execute(f'SELECT {c_q} FROM "{t_name}" WHERE "{alici_col}" = ?', (vkn_no,))
                                        gelen_c = cursor.fetchone()[0] or 0
                                    if satici_col and vkn_no:
                                        cursor.execute(f'SELECT {c_q} FROM "{t_name}" WHERE "{satici_col}" = ?', (vkn_no,))
                                        giden_c = cursor.fetchone()[0] or 0
                                    
                                    # YENİ İPTAL OKUMA MANTIĞI (Tüm Olasılıklar ve Sütunlar Taranıyor)
                                    if tip_cols:
                                        iptal_sartlari = []
                                        for c in tip_cols:
                                            iptal_sartlari.extend([
                                                f'"{c}" LIKE \'%IPTAL%\'', f'"{c}" LIKE \'%İPTAL%\'', 
                                                f'"{c}" LIKE \'%iptal%\'', f'"{c}" LIKE \'%İptal%\''
                                            ])
                                        sart_str = " OR ".join(iptal_sartlari)
                                        cursor.execute(f'SELECT {c_q} FROM "{t_name}" WHERE {sart_str}')
                                        iptal_c = cursor.fetchone()[0] or 0
                                conn.close()
                            except: pass

                        # 2. DENETİM VERİLERİ
                        olasi_yollar = [
                            os.path.join(get_mukellefler_dir(), m, f"audit_results_{yil}.db"),
                            os.path.join(get_mukellefler_dir(), m, "audit_results.db"),
                            os.path.join(versiyon_klasoru, f"audit_results_{yil}.db"),
                            os.path.join(versiyon_klasoru, "audit_results.db"),
                            os.path.join(get_mukellefler_dir(), m, str(yil), f"audit_results_{yil}.db"),
                            os.path.join(self.application_path, f"audit_results_{yil}.db"),
                            os.path.join(self.application_path, "audit_results.db")
                        ]
                        
                        audit_db_path = None
                        for yol in olasi_yollar:
                            if os.path.exists(yol):
                                audit_db_path = yol
                                break

                        if audit_db_path:
                            try:
                                conn_a = sqlite3.connect(audit_db_path)
                                cursor_a = conn_a.cursor()
                                cursor_a.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='report_details';")
                                if cursor_a.fetchone():
                                    cursor_a.execute("SELECT COUNT(DISTINCT report_id), COUNT(id) FROM report_details")
                                    res = cursor_a.fetchone()
                                    if res:
                                        rapor_sayisi = res[0] if res[0] else 0
                                        risk_sayisi = res[1] if res[1] else 0
                                else:
                                    cursor_a.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='reports';")
                                    if cursor_a.fetchone():
                                        cursor_a.execute("SELECT COUNT(id), SUM(total_risks) FROM reports")
                                        res2 = cursor_a.fetchone()
                                        if res2:
                                            rapor_sayisi = res2[0] if res2[0] else 0
                                            risk_sayisi = res2[1] if res2[1] else 0
                                conn_a.close()
                            except: pass

                        try:
                            import pyarrow.parquet as pq
                            kayit_sayisi = pq.read_metadata(d['yol']).num_rows
                        except:
                            try: kayit_sayisi = len(pd.read_parquet(d['yol'], columns=[]))
                            except: pass

                        if kayit_sayisi > max_k: max_k = kayit_sayisi
                        defter_tip = f"{ay_metni} / Versiyon-{idx+1}"
                        dash_data.append({"unvan": unvan, "yil": str(yil), "defter_tip": defter_tip, "kayit": kayit_sayisi, "gelen": gelen_c, "giden": giden_c, "iptal": iptal_c, "rapor_sayisi": rapor_sayisi, "risk_sayisi": risk_sayisi,  "devam_not": pending_count})

                elif aylik:
                    gelen_c, giden_c, iptal_c = 0, 0, 0
                    rapor_sayisi, risk_sayisi = 0, 0
                    kayit_sayisi = 0
                    
                    for d in aylik:
                        versiyon_klasoru = os.path.dirname(d['yol'])
                        
                        fatura_db = os.path.join(versiyon_klasoru, f"fatura_data_{yil}.db")
                        if os.path.exists(fatura_db):
                            try:
                                conn = sqlite3.connect(fatura_db)
                                cursor = conn.cursor()
                                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
                                tables = cursor.fetchall()
                                if tables:
                                    t_name = tables[0][0]
                                    cursor.execute(f"PRAGMA table_info({t_name});")
                                    cols = [info[1] for info in cursor.fetchall()]
                                    fat_col = next((c for c in cols if c == "NO_FATURA" or ('FATURA' in c.upper() and 'NO' in c.upper())), None)
                                    c_q = f'COUNT(DISTINCT "{fat_col}")' if fat_col else 'COUNT(*)'
                                    
                                    alici_col = next((c for c in cols if 'ALICI' in c.upper() and ('VKN' in c.upper() or 'TCKN' in c.upper())), None)
                                    satici_col = next((c for c in cols if 'SATICI' in c.upper() and ('VKN' in c.upper() or 'TCKN' in c.upper())), None)
                                    tip_cols = [c for c in cols if c.upper() in ["TUR_FATURA", "TIP_FATURA", "FATURA_TIPI", "FATURA_TURU", "SENARYO"]]

                                    if alici_col and vkn_no:
                                        cursor.execute(f'SELECT {c_q} FROM "{t_name}" WHERE "{alici_col}" = ?', (vkn_no,))
                                        gelen_c += cursor.fetchone()[0] or 0
                                    if satici_col and vkn_no:
                                        cursor.execute(f'SELECT {c_q} FROM "{t_name}" WHERE "{satici_col}" = ?', (vkn_no,))
                                        giden_c += cursor.fetchone()[0] or 0
                                    
                                    # YENİ İPTAL OKUMA MANTIĞI (Aylık dosyalar için)
                                    if tip_cols:
                                        iptal_sartlari = []
                                        for c in tip_cols:
                                            iptal_sartlari.extend([
                                                f'"{c}" LIKE \'%IPTAL%\'', f'"{c}" LIKE \'%İPTAL%\'', 
                                                f'"{c}" LIKE \'%iptal%\'', f'"{c}" LIKE \'%İptal%\''
                                            ])
                                        sart_str = " OR ".join(iptal_sartlari)
                                        cursor.execute(f'SELECT {c_q} FROM "{t_name}" WHERE {sart_str}')
                                        iptal_c += cursor.fetchone()[0] or 0
                                conn.close()
                            except: pass
                            
                        audit_db_1 = os.path.join(versiyon_klasoru, f"audit_results_{yil}.db")
                        audit_db_2 = os.path.join(versiyon_klasoru, "audit_results.db")
                        audit_db_path = audit_db_1 if os.path.exists(audit_db_1) else (audit_db_2 if os.path.exists(audit_db_2) else None)
                        if audit_db_path:
                            try:
                                conn_a = sqlite3.connect(audit_db_path)
                                cursor_a = conn_a.cursor()
                                cursor_a.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='report_details';")
                                if cursor_a.fetchone():
                                    cursor_a.execute("SELECT COUNT(DISTINCT report_id), COUNT(id) FROM report_details")
                                    res = cursor_a.fetchone()
                                    if res:
                                        rapor_sayisi += res[0] if res[0] else 0
                                        risk_sayisi += res[1] if res[1] else 0
                                conn_a.close()
                            except: pass

                        try:
                            import pyarrow.parquet as pq
                            kayit_sayisi += pq.read_metadata(d['yol']).num_rows
                        except:
                            try: kayit_sayisi += len(pd.read_parquet(d['yol'], columns=[]))
                            except: pass

                    if kayit_sayisi > max_k: max_k = kayit_sayisi
                    defter_tip = f"{ay_metni} (Aylık)"
                    dash_data.append({"unvan": unvan, "yil": str(yil), "defter_tip": defter_tip, "kayit": kayit_sayisi, "gelen": gelen_c, "giden": giden_c, "iptal": iptal_c, "rapor_sayisi": rapor_sayisi, "risk_sayisi": risk_sayisi,  "devam_not": pending_count})

                else:
                    dash_data.append({"unvan": unvan, "yil": str(yil), "defter_tip": "Yüklü Değil", "kayit": 0, "gelen": 0, "giden": 0, "iptal": 0, "rapor_sayisi": 0, "risk_sayisi": 0,  "devam_not": pending_count})
        
        return dash_data, (max_k if max_k > 0 else 1)