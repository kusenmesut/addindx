import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
import sqlite3
import pandas as pd
import numpy as np
import tkinter.font as tkfont
import webbrowser
import tempfile
import html

# Kendi bağımsız motorunu import ediyoruz (Bağlantı kopsa bile çalışsın diye)
from .engine import PivotEngine

# =============================================================================
# X BUTONLU VE SAĞ TIKLI ÖZEL NOTEBOOK SINIFI
# =============================================================================
class ClosableNotebook(ttk.Notebook):
    __initialized = False

    def __init__(self, *args, close_callback=None, close_all_callback=None, **kwargs):
        if not self.__initialized:
            self.__initialize_custom_style()
            ClosableNotebook.__initialized = True

        kwargs["style"] = "ClosableTablolar.TNotebook"
        super().__init__(*args, **kwargs)
        
        self.close_callback = close_callback
        self.close_all_callback = close_all_callback
        
        self.bind("<ButtonPress-1>", self.on_close_press, "+")
        self.bind("<ButtonRelease-1>", self.on_close_release, "+")
        
        # --- YENİ EKLENEN SAĞ TIK DİNLEYİCİSİ ---
        self.bind("<Button-3>", self.on_right_click, "+") 

    def __initialize_custom_style(self):
        style = ttk.Style()
        if 'clam' in style.theme_names(): style.theme_use('clam')
        
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        icon_path = os.path.join(base_dir, "kapat.ico")
        
        try:
            from PIL import Image, ImageTk
            img = Image.open(icon_path).resize((12, 12), Image.Resampling.LANCZOS)
            self.img_close = ImageTk.PhotoImage(img)
            self.img_closeactive = ImageTk.PhotoImage(img)    
            self.img_closepressed = ImageTk.PhotoImage(img)   
        except Exception:
            self.img_close = tk.PhotoImage(width=12, height=12)
            self.img_closeactive = tk.PhotoImage(width=12, height=12)
            self.img_closepressed = tk.PhotoImage(width=12, height=12)

        try:
            style.element_create("close_tablolar", "image", self.img_close,
                                ("active", "pressed", "!disabled", self.img_closepressed),
                                ("active", "!disabled", self.img_closeactive), border=8, sticky='')
        except tk.TclError: pass 

        style.layout("ClosableTablolar.TNotebook", [("ClosableTablolar.client", {"sticky": "nswe"})])
        style.layout("ClosableTablolar.TNotebook.Tab", [
            ("ClosableTablolar.tab", {
                "sticky": "nswe",
                "children": [
                    ("ClosableTablolar.padding", {
                        "side": "top",
                        "sticky": "nswe",
                        "children": [
                            ("ClosableTablolar.focus", {
                                "side": "top",
                                "sticky": "nswe",
                                "children": [
                                    ("ClosableTablolar.label", {"side": "left", "sticky": ""}),
                                    ("ClosableTablolar.close_tablolar", {"side": "left", "sticky": ""}),
                                ]
                            })
                        ]
                    })
                ]
            })
        ])
        
        TAB_BAR_BG, TAB_BG, TAB_ACTIVE_BG = "#ffffff", "#f8f9fa", "#0d6efd"
        TAB_FG, TAB_ACTIVE_FG = "#495057", "white"

        style.configure("ClosableTablolar.TNotebook", background=TAB_BAR_BG, borderwidth=0)
        style.configure("ClosableTablolar.TNotebook.Tab", background=TAB_BG, foreground=TAB_FG, padding=[15, 8], font=("Segoe UI", 10), borderwidth=0, focuscolor=TAB_ACTIVE_BG)
        style.map("ClosableTablolar.TNotebook.Tab", background=[("selected", TAB_ACTIVE_BG), ("active", "#e9ecef")], foreground=[("selected", TAB_ACTIVE_FG), ("active", "#212529")], expand=[("selected", [0, 0, 0, 0])])

    def on_close_press(self, event):
        element = self.identify(event.x, event.y)
        if "close" in element:
            index = self.index(f"@{event.x},{event.y}")
            self.state(['pressed'])
            self._active = index

    def on_close_release(self, event):
        if not self.instate(['pressed']): return
        element = self.identify(event.x, event.y)
        index = self.index(f"@{event.x},{event.y}")
        if "close" in element and self._active == index:
            self._close_single(index)
        self.state(['!pressed'])
        self._active = None

    # =========================================================
    # --- SAĞ TIK MENÜSÜ İŞLEMLERİ (YENİ EKLENDİ) ---
    # =========================================================
    def on_right_click(self, event):
        try:
            # Tıklanan sekmenin index'ini tespit et
            index = self.index(f"@{event.x},{event.y}")
            
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label="❌ Kapat", command=lambda: self._close_single(index))
            menu.add_separator()
            menu.add_command(label="🗑️ Tümünü Kapat", command=self._close_all)
            
            # Farenin bulunduğu yerde menüyü patlat
            menu.tk_popup(event.x_root, event.y_root)
        except tk.TclError:
            # Fare sekmelerin dışındayken sağ tıklandıysa pas geç
            pass

    def _close_single(self, index):
        if self.close_callback: self.close_callback(index)
        else: self.forget(index)

    def _close_all(self):
        if self.close_all_callback: self.close_all_callback()
        else:
            for tab in list(self.tabs()): self.forget(tab)

# =============================================================================
# ANA UI SINIFI
# =============================================================================
class TablolarUI(tk.Frame):
    def __init__(self, parent, pivot_frame_instance=None):
        super().__init__(parent, bg="#ffffff")
        
        self.pivot_frame = pivot_frame_instance 
        self.engine = self.pivot_frame.engine if self.pivot_frame else PivotEngine()
        self.json_path = os.path.join(os.path.dirname(__file__), "pivot_templates.json")
        self.tab_trees = {} 

        self.setup_ui()
        self.load_data()

    def setup_ui(self):
        # Ayırıcıyı daha kalın (sashwidth=6) ve belirgin (sashrelief) yapıyoruz
        self.paned = tk.PanedWindow(
            self, 
            orient=tk.HORIZONTAL, 
            sashwidth=6,              # 1 yerine 6 yaptık (Daha geniş tutma alanı)
            sashrelief=tk.RAISED,     # Çizgiye hafif bir derinlik/buton hissi verir
            bg="#dee2e6",
            bd=0
        )
        self.paned.pack(fill=tk.BOTH, expand=True)

        # =========================================================
        # --- SOL PANEL (ŞABLON MENÜSÜ) ---
        # =========================================================
        self.left_panel = tk.Frame(self.paned, bg="#f8f9fa", width=250)
        self.paned.add(self.left_panel, minsize=220)
        
        tk.Label(self.left_panel, text="Şablon Kütüphanesi", bg="#f8f9fa", fg="#212529", font=("Segoe UI", 12, "bold"), anchor="w").pack(fill=tk.X, padx=15, pady=(20, 10))
        
        style = ttk.Style()
        
        # --- WEB BUTONU TASARIMI ---
        # Satır yüksekliği artırıldı (40), font kalınlaştırıldı
        style.configure("Sidebar.Treeview", 
                        rowheight=40, 
                        font=("Segoe UI", 10, "bold"), 
                        background="#f8f9fa", 
                        fieldbackground="#f8f9fa", 
                        borderwidth=0, 
                        foreground="#495057")
        
        # Hover (üzerine gelme) ve Seçim efekti
        # Seçildiğinde mavi arka plan / beyaz yazı; üzerine gelindiğinde açık gri arka plan
        style.map("Sidebar.Treeview", 
                  background=[("selected", "#0d6efd"), ("active", "#e2e6ea")], 
                  foreground=[("selected", "white"), ("active", "#0d6efd")])
        
        # --- YATAY VE DİKEY SCROLL (KAYDIRMA) ÇUBUKLARI İÇİN TAŞIYICI KUTU ---
        tree_container = tk.Frame(self.left_panel, bg="#f8f9fa")
        tree_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        self.tree_menu = ttk.Treeview(tree_container, show="tree", style="Sidebar.Treeview")
        
        # Scroll çubuklarını oluştur ve Treeview'a bağla
        sb_y = ttk.Scrollbar(tree_container, orient="vertical", command=self.tree_menu.yview)
        sb_x = ttk.Scrollbar(tree_container, orient="horizontal", command=self.tree_menu.xview)
        self.tree_menu.configure(yscrollcommand=sb_y.set, xscrollcommand=sb_x.set)
        
        # Izgara (Grid) sistemiyle hepsini milimetrik yerleştir
        self.tree_menu.grid(row=0, column=0, sticky="nsew")
        sb_y.grid(row=0, column=1, sticky="ns")
        sb_x.grid(row=1, column=0, sticky="ew")
        
        # Kutu esnedikçe liste de esnesin
        tree_container.grid_rowconfigure(0, weight=1)
        tree_container.grid_columnconfigure(0, weight=1)

        self.tree_menu.bind("<Double-1>", self.on_menu_double_click) # Kullanıcı başlığa çift tıklar[cite: 1]

        # =========================================================
        # --- SAĞ PANEL (SEKMELİ ÇALIŞMA ALANI) ---
        # =========================================================
        self.right_panel = tk.Frame(self.paned, bg="#ffffff")
        self.paned.add(self.right_panel, minsize=450)
        
        self.header_frame = tk.Frame(self.right_panel, bg="#ffffff", pady=20, padx=20)
        self.header_frame.pack(fill=tk.X)
        
        # --- YENİ: SOL PANELİ AÇ/KAPAT (TOGGLE) BUTONU ---
        self.left_panel_visible = True
        self.btn_toggle = tk.Button(
            self.header_frame, 
            text="☰", 
            bg="#f8f9fa", 
            fg="#495057", 
            font=("Segoe UI", 14, "bold"), 
            bd=1, 
            relief="flat",
            cursor="hand2", 
            activebackground="#e2e6ea",
            command=self.toggle_left_panel
        )
        self.btn_toggle.pack(side=tk.LEFT, padx=(0, 15))

        self.lbl_title = tk.Label(self.header_frame, text="👈 Lütfen soldan bir şablon seçin", bg="#ffffff", fg="#6c757d", font=("Segoe UI", 16, "bold"))
        self.lbl_title.pack(side=tk.LEFT)
        # --- BOOTSTRAP BUTONLARI (Success ve Danger) ---
        self.btn_excel = tk.Button(self.header_frame, text="📥 Excel'e Aktar", bg="#198754", fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=15, pady=8, cursor="hand2", activebackground="#157347", activeforeground="white", command=self.export_to_excel)
        self.btn_pdf = tk.Button(self.header_frame, text="📄 PDF/Rapor Göster", bg="#dc3545", fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=15, pady=8, cursor="hand2", activebackground="#bb2d3b", activeforeground="white", command=self.export_to_pdf_html)
       
        # SEKMELER
        self.notebook = ClosableNotebook(self.right_panel, close_callback=self.close_tab_by_index, close_all_callback=self.close_all_tabs)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

        # --- TABLO TASARIM AYARLARI (Bootstrap Table) ---
        style.configure("Preview.Treeview", rowheight=32, font=("Segoe UI", 10), background="#ffffff", fieldbackground="#ffffff", borderwidth=0, foreground="#212529")
        # Başlıkları ferah ve modern yapıyoruz
        style.configure("Preview.Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#f8f9fa", foreground="#495057", borderwidth=1, relief="flat")
        style.map("Preview.Treeview.Heading", background=[("active", "#e2e6ea")])
        style.map("Preview.Treeview", background=[("selected", "#e7f1ff")], foreground=[("selected", "#0c63e4")]) # Seçimi mavi tonlu yapıyoruz

    def load_data(self):
        self.tree_menu.delete(*self.tree_menu.get_children())
        if not os.path.exists(self.json_path): return
            
        try:
            with open(self.json_path, "r", encoding="utf-8") as f:
                self.templates = json.load(f)
                
            groups = {}
            for t_name, t_data in self.templates.items():
                # Şablonları gruplarına göre ayırıyoruz
                if "|" in t_name.lower():
                    grp = t_data.get("group", "Genel") if isinstance(t_data, dict) and "group" in t_data else "Genel"
                    if grp not in groups: groups[grp] = []
                    groups[grp].append(t_name)
                
            if not groups:
                self.tree_menu.insert("", "end", text="🔍 Uygun tablo bulunamadı.")
                return

            # --- MODERN WEB RENK PALETİ (Her grup için sırayla kullanılacak) ---
            renk_paleti = [
                "#0d6efd", # Mavi (Primary)
                "#198754", # Yeşil (Success)
                "#6f42c1", # Mor (Purple)
                "#fd7e14", # Turuncu (Orange)
                "#dc3545", # Kırmızı (Danger)
                "#20c997", # Turkuaz (Teal)
                "#d63384", # Pembe (Pink)
            ]

            for idx, (grp, items) in enumerate(sorted(groups.items())):
                # Rengi belirle (Eğer grup sayısı paletten fazlaysa başa döner)
                secilen_renk = renk_paleti[idx % len(renk_paleti)]
                tag_adi = f"grup_renk_{idx}"
                
                # Bu gruba özel rengi ve hafif büyük fontu (11 punto) sisteme tanımla
                self.tree_menu.tag_configure(tag_adi, foreground=secilen_renk, font=("Segoe UI", 11, "bold"))
                
                # Grubu (Klasörü) eklerken özel renk etiketini (tags) ver
                grp_id = self.tree_menu.insert("", "end", text=f"📁 {grp}", open=False, tags=(tag_adi,))
                
                for item in sorted(items):
                    t_data = self.templates[item]
                    config = t_data.get("config", t_data) if isinstance(t_data, dict) else t_data
                    icon = "🐍" if config.get("is_script") else "📊"
                    
                    # Alt elemanları (şablonları) normal renkleriyle ekle
                    self.tree_menu.insert(grp_id, "end", iid=item, text=f"   {icon}  {item}")
                    
        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror("Hata", f"Şablonlar yüklenemedi:\n{e}")



    def toggle_left_panel(self):
        """Sol şablon panelini açıp kapatır."""
        if self.left_panel_visible:
            # Paneli gizle
            self.paned.forget(self.left_panel)
            self.left_panel_visible = False
            # Buton rengini aktif/kapalı olduğunu belli edecek şekilde değiştir
            self.btn_toggle.config(bg="#0d6efd", fg="white", text="☰") 
        else:
            # Paneli sağ panelin (right_panel) HEMEN ÖNCESİNE geri ekle
            self.paned.add(self.left_panel, before=self.right_panel, minsize=220)
            self.left_panel_visible = True
            # Buton rengini eski haline getir
            self.btn_toggle.config(bg="#f8f9fa", fg="#495057", text="☰")
    # =========================================================
    # --- SEKME YÖNETİMİ ---
    # =========================================================

    def on_tab_changed(self, event):
        """Sekme değiştiğinde başlığı günceller."""
        current_tab = self.notebook.select()
        if current_tab:
            tab_name = self.notebook.tab(current_tab, "text")
            self.lbl_title.config(text=tab_name, fg="#2c3e50")
            self.btn_pdf.pack(side=tk.RIGHT, padx=(10, 0))
            self.btn_excel.pack(side=tk.RIGHT, padx=(10, 0))
        else:
            self.lbl_title.config(text="👈 Lütfen soldan bir şablon seçin", fg="#7f8c8d")
            self.btn_pdf.pack_forget()
            self.btn_excel.pack_forget()

    def close_tab_by_index(self, index):
        """Belirtilen indexteki sekmeyi kapatır (ClosableNotebook'tan çağrılır)."""
        try:
            tab_id = self.notebook.tabs()[index]
            if tab_id in self.tab_trees:
                del self.tab_trees[tab_id]
            self.notebook.forget(tab_id)
            
            # Eğer sekme kalmadıysa görünümü sıfırla
            if not self.notebook.tabs():
                self.lbl_title.config(text="👈 Lütfen soldan bir şablon seçin", fg="#7f8c8d")
                self.btn_pdf.pack_forget()
                self.btn_excel.pack_forget()
        except Exception:
            pass

    def close_all_tabs(self):
        """Açık olan tüm sekmeleri tek seferde kapatır (Sağ Tık Menüsü)."""
        try:
            for tab_id in list(self.notebook.tabs()):
                if tab_id in self.tab_trees:
                    del self.tab_trees[tab_id]
                self.notebook.forget(tab_id)
                
            # Sekmelerin hepsi kapanınca arayüzü sıfırla
            self.lbl_title.config(text="👈 Lütfen soldan bir şablon seçin", fg="#7f8c8d")
            self.btn_pdf.pack_forget()
            self.btn_excel.pack_forget()
        except Exception:
            pass

    def get_active_tree(self):
        current_tab = self.notebook.select()
        if current_tab:
            return self.tab_trees.get(current_tab)
        return None

    def on_menu_double_click(self, event):
        # Tıklanan öğeyi (şablonu) tespit et
        item_id = self.tree_menu.identify_row(event.y)
        if not item_id or item_id not in self.templates:
            return

        # 1- Çift tıklama sonrası Evet/İptal Pop-up'ı[cite: 1]
        cevap = messagebox.askokcancel(
            "Sorguyu Çalıştır", 
            f"'{item_id}' başlıklı sorguyu çalıştırmak istiyor musunuz?"
        )
        if not cevap:
            return

        # 2- Animasyonlu Loading Penceresi Oluşturma[cite: 1]
        loading_popup = tk.Toplevel(self)
        loading_popup.title("İşleniyor")
        loading_popup.geometry("350x120")
        loading_popup.transient(self.winfo_toplevel())
        loading_popup.grab_set() # İşlem bitene kadar arka plana tıklanmasını engeller
        loading_popup.configure(bg="#f8f9fa")

        # Animasyon penceresini ana ekranın tam ortasına hizala
        main_window = self.winfo_toplevel()
        main_window.update_idletasks()
        x = main_window.winfo_x() + (main_window.winfo_width() // 2) - 175
        y = main_window.winfo_y() + (main_window.winfo_height() // 2) - 60
        loading_popup.geometry(f"+{x}+{y}")

        # Bilgilendirme etiketi
        lbl = tk.Label(
            loading_popup, 
            text=f"Veriler Çekiliyor:\n{item_id}\n\nLütfen bekleyin...", 
            bg="#f8f9fa", 
            font=("Segoe UI", 10, "bold"),
            fg="#0d6efd"
        )
        lbl.pack(pady=(15, 10))

        # İlerlemeyi gösteren tanımsız (indeterminate) animasyonlu bar
        progress = ttk.Progressbar(loading_popup, mode="indeterminate")
        progress.pack(fill=tk.X, padx=20)
        progress.start(15) 
        
        loading_popup.update()

        # Arayüzün tamamen donmaması ve animasyonun akması için işlemi hafif gecikmeli (after) başlat
        self.after(100, lambda: self.execute_template(item_id, loading_popup))

    def execute_template(self, item_id, loading_popup):
        # Eski on_menu_select içerisindeki ana çalışma ve tablo çizim mantığı
        t_data = self.templates[item_id]
        config = t_data.get("config", t_data) if isinstance(t_data, dict) else t_data
        
        # 1. Eğer açık bir sekmede varsa, o sekmeye odaklan
        for tab in self.notebook.tabs():
            if self.notebook.tab(tab, "text") == item_id:
                self.notebook.select(tab)
                loading_popup.destroy()
                messagebox.showinfo("Uyarı", "Bu tablo zaten açık, ilgili sekmeye geçildi.")
                return

        # 2. Yeni Sekme Oluştur
        tab_frame = tk.Frame(self.notebook, bg="#ffffff")
        self.notebook.add(tab_frame, text=item_id)
        self.notebook.select(tab_frame)

       # 3. Bu Sekmeye Özel Treeview Oluştur
        tree = ttk.Treeview(tab_frame, show="tree headings", style="Preview.Treeview")
        
        tree.tag_configure('even', background='#ffffff')
        tree.tag_configure('odd', background='#f8f9fa')
        tree.tag_configure("subtotal_row", font=("Segoe UI", 10, "bold"), background="#e9ecef", foreground="#0d6efd") 
        tree.tag_configure("gt_row", font=("Segoe UI", 11, "bold"), background="#cfe2ff", foreground="#084298")
        tree.tag_configure("danger_row", background="#f8d7da", foreground="#842029", font=("Segoe UI", 10, "bold"))

        vsb = ttk.Scrollbar(tab_frame, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(tab_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        tree.pack(fill=tk.BOTH, expand=True)

        tree.bind("<Double-1>", self.show_row_details)
        tree.bind("<Button-3>", self.enable_selection_and_menu)
        
        self.tab_trees[str(tab_frame)] = tree

        # Sekme içerisinde bekleme mesajı
        tree["columns"] = ["status"]
        tree.heading("status", text="DURUM", anchor="w")
        tree.column("status", width=500)
        tree.insert("", "end", values=["Tablo veritabanından çekiliyor ve hesaplanıyor... Lütfen bekleyin."])
        self.update() 
        
        try:
            if config.get("is_script"):
                source = config.get("script_source")
                code = config.get("script_code")
                
                def fetch_data(src_type):
                    df_temp = pd.DataFrame()
                    try:
                        if src_type == "Yevmiye":
                            from utils.session_db import get_last_session
                            from config import get_mukellefler_dir
                            
                            session = get_last_session()
                            if session:
                                vkn = session.get("vkn")
                                year = session.get("year", session.get("yil"))
                                
                                if vkn and str(vkn) != "---":
                                    base_dir = get_mukellefler_dir()
                                    target_folder = next((os.path.join(base_dir, f) for f in os.listdir(base_dir) if str(f).endswith(f"-{str(vkn).strip()}")), None)
                                    
                                    if target_folder:
                                        target_file = os.path.join(target_folder, str(year), f"{str(year)}_FULL.parquet")
                                        if os.path.exists(target_file):
                                            df_temp = pd.read_parquet(target_file)
                                            col_map = {
                                                "KayitTarihi": "Tarih", "YevmiyeNo": "Yevmiye No",
                                                "HesapKodu": "Hesap Kodu", "HesapAdi": "Hesap Adı",
                                                "FisAciklamasi": "Fiş Açıklama", "DetayAciklama": "Detay Açıklama",
                                                "Borc": "Borç", "Alacak": "Alacak"
                                            }
                                            df_temp.rename(columns=col_map, inplace=True)
                                            if hasattr(self.engine, 'y_map'):
                                                df_temp.rename(columns=self.engine.y_map, inplace=True)
                                                
                            if df_temp.empty and getattr(self.engine, 'yevmiye_db', None):
                                conn = sqlite3.connect(self.engine.yevmiye_db)
                                df_temp = pd.read_sql_query("SELECT * FROM yevmiye", conn)
                                if hasattr(self.engine, 'y_map'):
                                    df_temp.rename(columns=self.engine.y_map, inplace=True)
                                conn.close()
                                
                        elif src_type == "Faturalar" and getattr(self.engine, 'fatura_db', None):
                            conn = sqlite3.connect(self.engine.fatura_db)
                            c = conn.cursor()
                            c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
                            tbl = c.fetchone()
                            if tbl:
                                df_temp = pd.read_sql_query(f"SELECT * FROM {tbl[0]}", conn)
                                if hasattr(self.engine, 'f_map'):
                                    df_temp.rename(columns=self.engine.f_map, inplace=True)
                            conn.close()
                    except Exception as e:
                        print(f"Veri çekme hatası: {e}")
                    return df_temp

                if source == "Fatura + Yevmiye":
                    df_fatura = fetch_data("Faturalar")
                    df_yevmiye = fetch_data("Yevmiye")
                    local_vars = {'df_fatura': df_fatura, 'df_yevmiye': df_yevmiye, 'pd': pd, 'np': np}
                else:
                    raw_df = fetch_data(source)
                    local_vars = {'df': raw_df, 'pd': pd, 'np': np}
                
                exec(code, {}, local_vars)
                df_result = local_vars.get('df_result')
                
                if df_result is not None and isinstance(df_result, pd.DataFrame):
                    dummy_config = {"rows": [], "cols": [], "vals": [], "active_filters": {}}
                    self.render_preview(tree, df_result, dummy_config)
                else:
                    tree.insert("", "end", values=["Hata: df_result adında bir DataFrame bulunamadı!"])
            
            else:
                df_result = self.engine.calculate_pivot(
                    config.get("rows", []), 
                    config.get("cols", []), 
                    config.get("vals", []),
                    config.get("active_filters", {}), 
                    show_totals=config.get("show_totals", True),
                    date_format=config.get("date_format", "Normal")
                )
                
                if isinstance(df_result, str):
                    tree.insert("", "end", values=[f"Hata oluştu: {df_result}"])
                elif df_result.empty:
                    tree.insert("", "end", values=["Bu tablo için gösterilecek veri yok (Veritabanı boş olabilir)."])
                else:
                    self.render_preview(tree, df_result, config)

        except Exception as e:
            tree.delete(*tree.get_children())
            tree["columns"] = ["status"]
            tree.heading("status", text="DURUM", anchor="w")
            tree.insert("", "end", values=[f"Kritik Hata: {str(e)}"])
        finally:
            # 3- İşlem bittiğinde uyarı ver[cite: 1]
            if loading_popup.winfo_exists():
                loading_popup.destroy()
            messagebox.showinfo("İşlem Tamamlandı", f"'{item_id}' başlıklı sorgu başarıyla hesaplandı.")

    def render_preview(self, tree, df, config):
        # 1. Ağaç Modu Tespiti (Artık hem ↳ hem de ▶ simgelerini tanıyacak)
        is_tree_mode = False
        if not df.empty and len(df.columns) > 0:
            is_tree_mode = any("↳" in str(x) or "▶" in str(x) for x in df.iloc[:, 0])

        if self.pivot_frame and hasattr(self.pivot_frame, "_render_single_table") and not is_tree_mode:
            self.pivot_frame.cancel_flag = False
            self.pivot_frame._render_single_table(tree, df, config)
        else:
            tree.delete(*tree.get_children())
            cols = list(df.columns)

            if is_tree_mode:
                tree.configure(show="tree headings")
                tree["columns"] = cols[1:]
                tree.heading("#0", text=cols[0], anchor="w")
                tree.column("#0", width=350, stretch=tk.NO) # 3 kademe sığsın diye genişliği artırdık
                for c in cols[1:]:
                    tree.heading(c, text=c, anchor="w", command=lambda _col=c: self.treeview_sort_column(tree, _col, False))
            else:
                tree.configure(show="headings")
                tree["columns"] = cols
                tree.column("#0", width=0, stretch=tk.NO)
                for c in cols:
                    tree.heading(c, text=c, anchor="w", command=lambda _col=c: self.treeview_sort_column(tree, _col, False))

            level_1_id = "" # Ana Düğüm (Belge)
            level_2_id = "" # Alt Düğüm (Yevmiye)
            row_count = 0
            
            for _, row in df.iterrows():
                vals = []
                for col_name, v in zip(cols, row):
                    if pd.isna(v) or v == "":
                        vals.append("")
                    elif isinstance(v, (float, np.floating)):
                        f_val = "{:,.2f}".format(v).replace(",", "X").replace(".", ",").replace("X", ".")
                        vals.append(f_val)
                    elif isinstance(v, (int, np.integer)):
                        col_lower = str(col_name).lower()
                        if any(k in col_lower for k in ['tutar', 'borç', 'borc', 'alacak', 'bakiye', 'toplam', 'ödeme', 'tahsilat', 'meblağ']):
                            f_val = "{:,.2f}".format(v).replace(",", "X").replace(".", ",").replace("X", ".")
                            vals.append(f_val)
                        else:
                            vals.append(str(v))
                    else:
                        vals.append(str(v))
                        
                tag = "even" if row_count % 2 == 0 else "odd"
                if "GENEL TOPLAM" in str(row[cols[0]]):
                    tag = "gt_row"
# ŞU İKİ SATIRI EKLE: Eğer satır verilerinde 🔴 varsa arka planı komple kırmızı yap!
                if any("🔴" in str(x) for x in vals):
                    tag = "danger_row"


                if is_tree_mode:
                    first_val = str(vals[0])
                    rest_vals = vals[1:]
                    
                    if "↳" in first_val:
                        # 3. SEVİYE (FİŞ SATIRLARI): Varsa Level 2'ye, yoksa Level 1'e ekle
                        target_parent = level_2_id if level_2_id else level_1_id
                        tree.insert(target_parent, "end", text=first_val, values=rest_vals, tags=(tag,))
                    elif "▶" in first_val:
                        # 2. SEVİYE (YEVMİYE NO): Level 1'in altına ekle
                        clean_text = first_val.replace("▶", "").replace("▼", "").strip()
                        level_2_id = tree.insert(level_1_id, "end", text=f"  ▶ {clean_text}", open=False, values=rest_vals, tags=(tag,))
                    else:
                        # 1. SEVİYE (BELGE NO): Ana kök dizin
                        clean_text = first_val.replace("▼", "").strip()
                        level_1_id = tree.insert("", "end", text=f"▼ {clean_text}", open=False, values=rest_vals, tags=(tag,))
                        level_2_id = "" # Yeni ana belgeye geçince alt düğümü sıfırla
                else:
                    tree.insert("", "end", values=vals, tags=(tag,))
                    
                row_count += 1
                
        self.after(50, lambda: self.auto_fit_columns(tree))



    def _format_row_values(self, cols, row):
        vals = []
        for col_name, v in zip(cols, row):
            if pd.isna(v) or v == "":
                vals.append("")
            elif isinstance(v, (float, np.floating)):
                f_val = "{:,.2f}".format(v).replace(",", "X").replace(".", ",").replace("X", ".")
                vals.append(f_val)
            elif isinstance(v, (int, np.integer)):
                col_lower = str(col_name).lower()
                if any(k in col_lower for k in ['tutar', 'borç', 'borc', 'alacak', 'bakiye', 'toplam', 'ödeme', 'tahsilat', 'meblağ']):
                    f_val = "{:,.2f}".format(v).replace(",", "X").replace(".", ",").replace("X", ".")
                    vals.append(f_val)
                else:
                    vals.append(str(v))
            else:
                vals.append(str(v))
        return vals

    def treeview_sort_column(self, tv, col, reverse):
        l = [(tv.set(k, col), k) for k in tv.get_children('')]

        def sort_key(item):
            val = item[0]
            if not val or val == "-":
                return float('-inf') if not reverse else float('inf') 
            try:
                clean_val = val.replace(".", "").replace(",", ".")
                return float(clean_val)
            except ValueError:
                return str(val).lower()

        try:
            l.sort(key=sort_key, reverse=reverse)
        except Exception:
            l.sort(reverse=reverse)

        for index, (val, k) in enumerate(l):
            tv.move(k, '', index)
            tag = "even" if index % 2 == 0 else "odd"
            tv.item(k, tags=(tag,))

        for c in tv["columns"]:
            current_text = tv.heading(c, "text")
            clean_text = current_text.replace(" ▲", "").replace(" ▼", "")
            if c == col:
                icon = " ▼" if reverse else " ▲"
                tv.heading(c, text=clean_text + icon)
            else:
                tv.heading(c, text=clean_text)

        tv.heading(col, command=lambda: self.treeview_sort_column(tv, col, not reverse))


    def show_row_details(self, event):
        tree = event.widget
        selected_item = tree.selection()
        if not selected_item: return
            
        item_id = selected_item[0]
        columns = tree["columns"]
        
        if not columns or columns[0] in ["status", "msg"]: return
            
        values = tree.item(item_id, "values")
        
        popup = tk.Toplevel(self)
        popup.title("Satır Detayları")
        popup.geometry("450x550")
        popup.configure(bg="#f4f8fb")
        popup.transient(self) 
        popup.grab_set()      
        
        header = tk.Frame(popup, bg="#2980b9", pady=15)
        header.pack(fill=tk.X)
        tk.Label(header, text="📄 Detaylı Görünüm", bg="#2980b9", fg="white", font=("Segoe UI", 14, "bold")).pack()
                 
        container = tk.Frame(popup, bg="#f4f8fb")
        container.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)
        
        canvas = tk.Canvas(container, bg="#f4f8fb", highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg="#f4f8fb")
        
        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas_frame = canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        
        def configure_canvas_width(ev):
            canvas.itemconfig(canvas_frame, width=ev.width)
            
        canvas.bind("<Configure>", configure_canvas_width)
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        for col, val in zip(columns, values):
            row_frame = tk.Frame(scroll_frame, bg="#ffffff", pady=10, padx=10)
            row_frame.pack(fill=tk.X, pady=4)
            bottom_border = tk.Frame(row_frame, bg="#eaf2f8", height=1)
            bottom_border.pack(side=tk.BOTTOM, fill=tk.X)
            
            lbl_col = tk.Label(row_frame, text=f"{col}", bg="#ffffff", fg="#7f8c8d", font=("Segoe UI", 9, "bold"), anchor="w", width=18)
            lbl_col.pack(side=tk.LEFT, padx=(0, 10))
            
            val_text = str(val) if val != "" else "-"
            lbl_val = tk.Message(row_frame, text=val_text, bg="#ffffff", fg="#2c3e50", font=("Segoe UI", 10), width=220, anchor="w")
            lbl_val.pack(side=tk.LEFT, fill=tk.X, expand=True)
            
        btn_frame = tk.Frame(popup, bg="#f4f8fb", pady=10)
        btn_frame.pack(fill=tk.X)
        btn_close = tk.Button(btn_frame, text="Kapat", bg="#34495e", fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=25, pady=8, cursor="hand2", command=popup.destroy, activebackground="#2c3e50", activeforeground="white")
        btn_close.pack()


    def auto_fit_columns(self, tree):
        font_measure = tkfont.Font(family="Segoe UI", size=9)
        header_font = tkfont.Font(family="Segoe UI", size=9, weight="bold")

        cols = tree["columns"]
        if not cols or cols[0] in ["status", "msg"]: return

        display_cols = list(tree.cget("displaycolumns"))
        if display_cols == ['#all'] or not display_cols:
            display_cols = cols

        for col in display_cols:
            header_text = tree.heading(col, "text")
            max_w = header_font.measure(header_text) + 30

            for item in tree.get_children():
                val = tree.set(item, col)
                w = font_measure.measure(str(val)) + 20 
                if w > max_w:
                    max_w = w
            
            final_width = min(max_w, 400)
            tree.column(col, width=final_width, anchor="w")

    def export_to_excel(self):
        active_tree = self.get_active_tree()
        if not active_tree:
            messagebox.showwarning("Uyarı", "Aktif bir tablo bulunamadı!")
            return

        children = active_tree.get_children()
        
        if not children or active_tree["columns"][0] in ["status", "msg"]:
            messagebox.showwarning("Uyarı", "Dışa aktarılacak geçerli bir tablo yok!")
            return
            
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx", 
            filetypes=[("Excel Dosyası", "*.xlsx")],
            title="Excel Olarak Kaydet"
        )
        if not path: return
        
        try:
            is_tree_mode = "tree" in str(active_tree.cget("show"))
            
            original_cols = list(active_tree["columns"])
            display_cols = list(active_tree.cget("displaycolumns"))
            if display_cols == ['#all'] or not display_cols:
                display_cols = original_cols

            if is_tree_mode:
                tree_heading = active_tree.heading("#0", "text")
                all_headers = [tree_heading] + original_cols
                export_cols = [tree_heading] + display_cols
            else:
                all_headers = original_cols
                export_cols = display_cols

            data = []
            
            def get_all_rows(item_id):
                item = active_tree.item(item_id)
                vals = list(item.get("values", []))
                
                if len(vals) < len(original_cols):
                    vals += [""] * (len(original_cols) - len(vals))
                    
                if is_tree_mode:
                    row_data = [item.get("text", "")] + vals
                else:
                    row_data = vals
                    
                data.append(row_data)
                
                for child_id in active_tree.get_children(item_id):
                    get_all_rows(child_id)

            for child in children:
                get_all_rows(child)
                
            df_export = pd.DataFrame(data, columns=all_headers)
            df_export = df_export[export_cols] 
            
            df_export.to_excel(path, index=False)
            os.startfile(path)
            
        except Exception as e:
            messagebox.showerror("Hata", f"Excel'e aktarma başarısız oldu:\n{e}")

 
    def enable_selection_and_menu(self, event):
        """
        Sağ tıklandığında hem hücreyi seçilebilir bir metin kutusuna çevirir 
        hem de bağlam menüsünü anında gösterir.
        """
        tree = event.widget

        # Zaten açık bir kutu varsa önce onu yok et
        if hasattr(tree, "select_entry") and tree.select_entry.winfo_exists():
            tree.select_entry.destroy()

        region = tree.identify("region", event.x, event.y)
        if region not in ("cell", "tree"): return

        row_id = tree.identify_row(event.y)
        col_id = tree.identify_column(event.x)
        if not row_id: return

        # Satırı arkadan seçili hale getir
        tree.selection_set(row_id)

        bbox = tree.bbox(row_id, col_id)
        if not bbox: return

        # Değeri çek
        if col_id == "#0":
            val = tree.item(row_id, "text")
        else:
            col_idx = int(col_id.replace('#', '')) - 1
            vals = tree.item(row_id, "values")
            val = vals[col_idx] if 0 <= col_idx < len(vals) else ""

        val = str(val).strip()
        if not val or val == "-": return

        # --- 1. SEÇİLEBİLİR METİN KUTUSUNU YARAT ---
        entry = tk.Entry(tree, font=("Segoe UI", 10), bd=1, relief="solid")
        entry.insert(0, val)
        entry.config(state="normal") 
        entry.place(x=bbox[0], y=bbox[1], width=bbox[2], height=bbox[3])
        entry.focus_set()
        
        # Varsayılan olarak kutunun içindeki TÜM metni seçili (highlight) yap
        entry.selection_range(0, tk.END)

        def close_entry(e=None):
            if entry.winfo_exists():
                entry.destroy()

        entry.bind("<Return>", close_entry)
        entry.bind("<Escape>", close_entry)
        entry.bind("<FocusOut>", close_entry)

        # --- 2. DİNAMİK MENÜ MOTORU ---
        # --- 2. DİNAMİK MENÜ MOTORU ---
        def show_menu(e):
            try:
                selected_text = entry.selection_get().strip()
            except:
                selected_text = entry.get().strip()

            if not selected_text: return
            
            # --- YENİ VE KATI TEMİZLİK KURALI ---
            # 1. Önce görsel simgeleri sil
            for s in ["↳", "📄", "▼", "▶", "📁", "🔴"]:
                selected_text = selected_text.replace(s, "")
            
            # 2. Eğer ':' varsa sadece değer kısmını (sağ tarafı) al
            if ":" in selected_text:
                selected_text = selected_text.split(":")[-1]
                
            selected_text = selected_text.strip()
            # -----------------------------------

            display_val = f"{selected_text[:20]}..." if len(selected_text) > 20 else selected_text

            menu = tk.Menu(entry, tearoff=0)
            menu.add_command(label=f"📋 Kopyala: {display_val}", command=lambda: self.copy_to_clipboard(selected_text))
            menu.add_separator()
            menu.add_command(label=f"🔎 Fatura Listesinde Ara", command=lambda: self.search_in_invoice_list(selected_text))
            menu.add_command(label=f"🔍 Yevmiye'de Ara", command=lambda: self.search_in_yevmiye_only(selected_text))
            menu.add_command(label=f"📄 Yevmiye Fişini Aç", command=lambda: self.show_yevmiye_detail(selected_text))

            # Menü açılırken kutunun kaybolmasını engelle
            entry.unbind("<FocusOut>")
            menu.tk_popup(e.x_root, e.y_root)
            # Menü kapandıktan sonra kaybolma özelliğini geri ver
            self.after(200, lambda: entry.bind("<FocusOut>", close_entry) if entry.winfo_exists() else None)

        # --- 3. MENÜYÜ İLK TIKLAMADA ANINDA GÖSTER ---
        show_menu(event)

        # Eğer kullanıcı menüyü kapatıp, kutu içinde başka bir yeri seçip tekrar sağ tıklarsa:
        entry.bind("<Button-3>", show_menu)
        
        tree.select_entry = entry

    def copy_to_clipboard(self, value):
        self.clipboard_clear()
        self.clipboard_append(str(value))

    def fetch_invoice_from_db(self, search_val, row_context_text=""):
        try:
            import os, sqlite3
            import pandas as pd
            from utils.session_db import get_last_session
            from config import get_mukellefler_dir

            session = get_last_session()
            if not session or not session.get('vkn'): return None
            vkn = session.get('vkn')
            yil = session.get('yil')

            base_dir = get_mukellefler_dir()
            target_folder = None
            if os.path.exists(base_dir):
                for f in os.listdir(base_dir):
                    if f.endswith(f"-{vkn}") and os.path.isdir(os.path.join(base_dir, f)):
                        target_folder = os.path.join(base_dir, f)
                        break

            if not target_folder: return None

            db_path = os.path.join(target_folder, str(yil), f"fatura_data_{yil}.db")
            if not os.path.exists(db_path): return None

            conn = sqlite3.connect(db_path)
            c = conn.cursor()
            c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
            res = c.fetchone()
            if not res:
                conn.close()
                return None
            tbl_name = res[0]

            df_limit1 = pd.read_sql(f"SELECT * FROM {tbl_name} LIMIT 1", conn)
            col_name = "NO_FATURA" if "NO_FATURA" in df_limit1.columns else "FATURA_NO"

            aranacak_metin = f"{search_val} {row_context_text}".replace('i', 'İ').replace('ı', 'I').upper()
            search_val_upper = str(search_val).strip().upper()

            query = f"""
                SELECT * FROM {tbl_name} 
                WHERE {col_name} = ? 
                   OR (
                       {col_name} IS NOT NULL 
                       AND LENGTH({col_name}) > 4 
                       AND INSTR(?, UPPER({col_name})) > 0
                   )
            """
            
            df = pd.read_sql(query, conn, params=(search_val_upper, aranacak_metin))
            conn.close()
            
            if not df.empty:
                ilk_fatura_no = df.iloc[0][col_name]
                df = df[df[col_name] == ilk_fatura_no]
            
            return df
        except Exception as e:
            print(f"Fatura DB Sorgu Hatası: {e}")
            return None

    def show_invoice_document(self, search_val, row_context_text=""):
        try:
            from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
        except ImportError:
            from tkinter import messagebox
            messagebox.showerror("Hata", "Fatura görüntüleme modülü (ui_goruntule) yüklenemedi.")
            return

        search_val = str(search_val).strip()
        if search_val.endswith('.0'): search_val = search_val[:-2]

        df_fatura = self.fetch_invoice_from_db(search_val, row_context_text)

        if df_fatura is not None and not df_fatura.empty:
            try:
                target_master = self.winfo_toplevel()
                FaturaGoruntulePopup(target_master, df_fatura)
            except Exception as e:
                from tkinter import messagebox
                messagebox.showerror("Hata", f"Görüntüleyici açılırken hata oluştu:\n{e}")
        else:
            from tkinter import messagebox
            messagebox.showinfo("Bulunamadı", f"Tıkladığınız '{search_val}' veritabanında bulunamadı.")



    def show_yevmiye_detail(self, aranan_deger):
        """
        Ana modülü (sekme veya büyük ekran) AÇMADAN doğrudan Fiş Detay Popup'ını getirir.
        """
        # --- 1. Değer Temizliği ---
        aranan_deger = str(aranan_deger).replace("↳", "").replace("▼", "").replace("▶", "").strip()
        if aranan_deger.lower().startswith("yevmiye no:"):
            aranan_deger = aranan_deger.lower().replace("yevmiye no:", "").strip()
        if aranan_deger.endswith('.0'):
            aranan_deger = aranan_deger[:-2]
            
        if not aranan_deger or aranan_deger in ["", "-", "None"]:
            return

        main_app = self.winfo_toplevel()

        # --- 2. Açık Yevmiye Sekmesi Var Mı Kontrolü ---
        def find_yevmiye_frame(widget):
            if hasattr(self, 'tree_menu') and str(widget).startswith(str(self)): return None
            if hasattr(widget, 'open_fis_detail_popup'): return widget
            for child in widget.winfo_children():
                res = find_yevmiye_frame(child)
                if res: return res
            return None

        yevmiye_frame = find_yevmiye_frame(main_app)

        # --- 3. İşlem Aşaması ---
        if yevmiye_frame:
            try:
                # DÜZELTME: Attribute hatasını önlemek için güvenli df kontrolü
                if hasattr(yevmiye_frame, 'engine'):
                    engine = yevmiye_frame.engine
                    if hasattr(engine, 'df'):
                        if engine.df is None or engine.df.empty:
                            engine.load_data()
                    elif hasattr(engine, 'load_data'):
                        engine.load_data()
                
                # --- YENİ EKLENEN HATA YAKALAMA VE DÜZELTME BLOĞU ---
                try:
                    yevmiye_frame.open_fis_detail_popup(fis_no=aranan_deger)
                except TypeError as err:
                    if "items" in str(err):
                        # Eğer karşı modül 'items' parametresi bekliyorsa boş göndererek hatayı önleriz
                        yevmiye_frame.open_fis_detail_popup(fis_no=aranan_deger, items=[])
                    else:
                        raise err
                # ----------------------------------------------------

            except Exception as e:
                print("Popup Açma Hatası:", e)
        else:
            try:
                import tkinter as tk
                import sys, os
                
                current_dir = os.path.dirname(os.path.abspath(__file__))
                parent_dir = os.path.dirname(current_dir)
                if parent_dir not in sys.path: sys.path.append(parent_dir)
                
                # İhtiyata karşı modül path denemesi
                try:
                    from modules.yevmiye_analiz.ui import YevmiyeAnalizFrame
                except ImportError:
                    from yevmiye_analiz.ui import YevmiyeAnalizFrame
                
                hidden_top = tk.Toplevel(self)
                hidden_top.withdraw() 
                
                yevmiye_bagimsiz = YevmiyeAnalizFrame(hidden_top)
                
                # DÜZELTME: Gizli sekme için de güvenli df kontrolü
                if hasattr(yevmiye_bagimsiz, 'engine'):
                    engine = yevmiye_bagimsiz.engine
                    if hasattr(engine, 'df'):
                        if engine.df is None or engine.df.empty:
                            engine.load_data()
                    elif hasattr(engine, 'load_data'):
                        engine.load_data()
                    
                # --- YENİ EKLENEN HATA YAKALAMA (BAĞIMSIZ PENCERE İÇİN) ---
                def safe_open_bagimsiz():
                    try:
                        yevmiye_bagimsiz.open_fis_detail_popup(fis_no=aranan_deger)
                    except TypeError as err:
                        if "items" in str(err):
                            yevmiye_bagimsiz.open_fis_detail_popup(fis_no=aranan_deger, items=[])
                        else:
                            raise err

                self.after(200, safe_open_bagimsiz)
                # ----------------------------------------------------------
                
                def clean_hidden_window():
                    for child in hidden_top.winfo_children():
                        if isinstance(child, tk.Toplevel):
                            child.bind("<Destroy>", lambda e, w=child: hidden_top.destroy() if e.widget == w else None, "+")
                            return
                    hidden_top.after(500, clean_hidden_window)
                
                hidden_top.after(500, clean_hidden_window)
                
            except Exception as e:
                from tkinter import messagebox
                messagebox.showerror("Hata", f"Fiş detayı açılamadı.\n{e}")


    def search_in_invoice_list(self, aranan_deger):
        """
        ui_liste.py (TumFaturalarFrame) modülünü bulur, 
        Hızlı Arama kutusuna değeri yazar ve filtreler.
        Eğer açık değilse, pop-up olarak yeni bir pencerede açar.
        """
        aranan_deger = str(aranan_deger).replace("↳", "").replace("▼", "").replace("▶", "").strip()
        if aranan_deger.endswith('.0'): 
            aranan_deger = aranan_deger[:-2]
            
        if not aranan_deger or aranan_deger in ["", "-", "None"]:
            return

        main_app = self.winfo_toplevel()

        def find_fatura_frame(widget):
            if widget.__class__.__name__ == "TumFaturalarFrame":
                return widget
            for child in widget.winfo_children():
                res = find_fatura_frame(child)
                if res: return res
            return None

        fatura_frame = find_fatura_frame(main_app)

        if fatura_frame:
            hedef_pencere = fatura_frame.winfo_toplevel()
            hedef_pencere.lift()
            hedef_pencere.focus_force()
            
            current = fatura_frame
            while current and current.master:
                parent = current.master
                if "Notebook" in str(type(parent)):
                    try:
                        parent.select(current)
                        parent.event_generate("<<NotebookTabChanged>>")
                    except: pass
                    break
                current = parent
            
            # DÜZELTME: entry_vars ve arama fonksiyonu için esneklik
            if hasattr(fatura_frame, 'entry_vars'):
                if 'genel_ara' in fatura_frame.entry_vars:
                    fatura_frame.entry_vars['genel_ara'].set(aranan_deger)
                elif 'genel_arama' in fatura_frame.entry_vars:
                    fatura_frame.entry_vars['genel_arama'].set(aranan_deger)
            
            if hasattr(fatura_frame, 'apply_filters'):
                fatura_frame.apply_filters()
            elif hasattr(fatura_frame, 'filter_data'):
                fatura_frame.filter_data()
        else:
            try:
                import sys, os
                import tkinter as tk
                
                current_dir = os.path.dirname(os.path.abspath(__file__))
                parent_dir = os.path.dirname(current_dir)
                if parent_dir not in sys.path: 
                    sys.path.append(parent_dir)
                
                # Güvenli Import
                try:
                    from modules.fatura_yukle.ui_liste import TumFaturalarFrame
                except ImportError:
                    from fatura_yukle.ui_liste import TumFaturalarFrame
                
                top = tk.Toplevel(self)
                top.title(f"🔍 Fatura Listesinde Arama Sonucu: {aranan_deger}")
                top.geometry("1300x700")
                top.attributes('-topmost', True) 
                
                # DÜZELTME: Session'dan güvenli mükellef verisi çekimi
                from utils.session_db import get_last_session
                session = get_last_session()
                if session:
                    top.vkn = session.get("vkn")
                    top.unvan = session.get("unvan", "")
                    top.yil = session.get("yil", session.get("year"))
                elif hasattr(main_app, 'vkn'):
                    top.vkn = main_app.vkn
                    top.unvan = main_app.unvan
                    top.yil = main_app.yil
                
                fatura_bagimsiz = TumFaturalarFrame(top)
                fatura_bagimsiz.pack(fill=tk.BOTH, expand=True)
                
                def trigger_search():
                    if hasattr(fatura_bagimsiz, 'entry_vars'):
                        if 'genel_ara' in fatura_bagimsiz.entry_vars:
                            fatura_bagimsiz.entry_vars['genel_ara'].set(aranan_deger)
                        elif 'genel_arama' in fatura_bagimsiz.entry_vars:
                            fatura_bagimsiz.entry_vars['genel_arama'].set(aranan_deger)
                    
                    if hasattr(fatura_bagimsiz, 'apply_filters'):
                        fatura_bagimsiz.apply_filters()
                    elif hasattr(fatura_bagimsiz, 'filter_data'):
                        fatura_bagimsiz.filter_data()
                        
                self.after(600, trigger_search)
                
            except Exception as e:
                from tkinter import messagebox
                messagebox.showerror("Hata", f"Fatura Listesi bağımsız olarak açılamadı.\n{e}")

    def search_in_yevmiye_only(self, aranan_deger):
        """
        Ana programın Yevmiye ekranını bulur, değeri arama kutusuna yazar ve filtreler.
        (Popup açmaz, sadece listeyi süzer)
        """
        # Temizlik işlemleri
        aranan_deger = str(aranan_deger).replace("↳", "").replace("▼", "").replace("▶", "").strip()
        
        if aranan_deger.lower().startswith("yevmiye no:"):
            aranan_deger = aranan_deger.lower().replace("yevmiye no:", "").strip()
            
        if aranan_deger.endswith('.0'):
            aranan_deger = aranan_deger[:-2]
            
        if not aranan_deger or aranan_deger in ["", "-", "None"]:
            return

        main_app = self.winfo_toplevel()

        # Yevmiye Frame'ini arayan yardımcı fonksiyon
        def find_yevmiye_frame(widget):
            if hasattr(self, 'tree_menu') and str(widget).startswith(str(self)):
                return None
            if hasattr(widget, 'open_fis_detail_popup') and hasattr(widget, 'focus_on_record'): 
                return widget
            for child in widget.winfo_children():
                res = find_yevmiye_frame(child)
                if res: return res
            return None

        yevmiye_frame = find_yevmiye_frame(main_app)

        if not yevmiye_frame:
            # Modül kapalıysa açmayı dene
            app_ref = self
            while app_ref.master:
                app_ref = app_ref.master
                if hasattr(app_ref, 'open_module'):
                    break
                    
            if hasattr(app_ref, 'open_module'):
                try: app_ref.open_module("Yevmiye Defteri")
                except: 
                    try: app_ref.open_module("Yevmiye Analizi")
                    except: pass
                main_app.update()
            else:
                # Tab/Treeview üzerinden zorla gezinme (Fallback)
                def hack_navigation(widget):
                    if hasattr(self, 'tree_menu') and widget == self.tree_menu: return False
                    if "Treeview" in str(type(widget)):
                        def search_tree(node=""):
                            for item in widget.get_children(node):
                                text = str(widget.item(item, "text")).lower()
                                if "yevmiye" in text:
                                    widget.selection_set(item)
                                    widget.focus(item)
                                    widget.event_generate("<<TreeviewSelect>>")
                                    return True
                                if search_tree(item): return True
                            return False
                        if search_tree(""): return True
                    elif "Notebook" in str(type(widget)):
                        if hasattr(self, 'notebook') and widget == self.notebook: pass
                        else:
                            for tab_id in widget.tabs():
                                if "yevmiye" in str(widget.tab(tab_id, "text")).lower():
                                    widget.select(tab_id)
                                    widget.event_generate("<<NotebookTabChanged>>")
                                    return True
                    for child in widget.winfo_children():
                        if hack_navigation(child): return True
                    return False
                
                hack_navigation(main_app)
                
            # Modülün yüklenmesi için ufak bir gecikme verip tetikleyiciyi çağırıyoruz
            self.after(400, lambda: self._tetikleyici_arama_devam(main_app, aranan_deger, find_yevmiye_frame, deneme_sayisi=1))
        else:
            self._tetikleyici_arama_devam(main_app, aranan_deger, find_yevmiye_frame, deneme_sayisi=1)

    def _tetikleyici_arama_devam(self, main_app, aranan_deger, find_func, deneme_sayisi):
        yevmiye_frame = find_func(main_app)
        
        if yevmiye_frame:
            hedef_pencere = yevmiye_frame.winfo_toplevel()
            hedef_pencere.lift()
            hedef_pencere.focus_force()
            
            # --- EKSİK OLAN KISIM: SEKME (TAB) DEĞİŞTİRİCİ ---
            # Frame'in bulunduğu Notebook sekmesini bul ve aktif et
            current = yevmiye_frame
            while current and current.master:
                parent = current.master
                if "Notebook" in str(type(parent)):
                    try:
                        parent.select(current)
                        parent.event_generate("<<NotebookTabChanged>>")
                    except: pass
                    break
                current = parent
            # -------------------------------------------------
            
            try:
                yevmiye_frame.focus_on_record(aranan_deger)
            except Exception as e:
                print("Arama İşlem Hatası:", e)
        else:
            if deneme_sayisi < 3:
                self.after(500, lambda: self._tetikleyici_arama_devam(main_app, aranan_deger, find_func, deneme_sayisi + 1))
            else:
                try:
                    import tkinter as tk
                    import sys, os
                    current_dir = os.path.dirname(os.path.abspath(__file__))
                    parent_dir = os.path.dirname(current_dir)
                    if parent_dir not in sys.path: sys.path.append(parent_dir)
                    from yevmiye_analiz.ui import YevmiyeAnalizFrame
                    
                    top = tk.Toplevel(self)
                    top.title(f"🔍 Yevmiye Arama Sonuçları: {aranan_deger}")
                    top.geometry("1300x700")
                    top.attributes('-topmost', True) 
                    yevmiye_bagimsiz = YevmiyeAnalizFrame(top)
                    yevmiye_bagimsiz.pack(fill=tk.BOTH, expand=True)
                    self.after(400, lambda: yevmiye_bagimsiz.focus_on_record(aranan_deger))
                except Exception as e:
                    from tkinter import messagebox
                    messagebox.showerror("Kritik Hata", f"Yevmiye modülü bağımsız olarak açılamadı.\n{e}")

    def _tetikleyici_arama_devam(self, main_app, aranan_deger, find_func, deneme_sayisi):
        """Yevmiye ekranı hazır olunca sadece filtrelemeyi (focus_on_record) tetikler"""
        yevmiye_frame = find_func(main_app)
        
        if yevmiye_frame:
            # Sekme bulunduysa öne getir ve ara
            main_app.lift()
            main_app.focus_force()
            try:
                yevmiye_frame.focus_on_record(aranan_deger)
            except Exception as e:
                print("Arama İşlem Hatası:", e)
        else:
            if deneme_sayisi < 3:
                # Hala yüklenmediyse tekrar dene
                self.after(500, lambda: self._tetikleyici_arama_devam(main_app, aranan_deger, find_func, deneme_sayisi + 1))
            else:
                # MODÜL BULUNAMADIYSA: Hata vermek yerine Bağımsız Pencerede Aç (Fallback)
                try:
                    import tkinter as tk
                    import sys, os
                    
                    # Bulunduğumuz klasör (pivot_table) ve bir üst klasörü (ana dizin) yola ekle
                    current_dir = os.path.dirname(os.path.abspath(__file__))
                    parent_dir = os.path.dirname(current_dir)
                    if parent_dir not in sys.path: 
                        sys.path.append(parent_dir)
                    
                    # Klasör yapına uygun olarak import et
                    from yevmiye_analiz.ui import YevmiyeAnalizFrame
                    
                    top = tk.Toplevel(self)
                    top.title(f"🔍 Yevmiye Arama Sonuçları: {aranan_deger}")
                    top.geometry("1300x700")
                    top.attributes('-topmost', True) # Pencereyi en üste al
                    
                    # Yevmiye Analiz arayüzünü bu yeni pencerenin içine göm
                    yevmiye_bagimsiz = YevmiyeAnalizFrame(top)
                    yevmiye_bagimsiz.pack(fill=tk.BOTH, expand=True)
                    
                    # Modül yüklendikten kısa bir süre sonra sadece arama (focus) işlemini tetikle
                    self.after(400, lambda: yevmiye_bagimsiz.focus_on_record(aranan_deger))
                    
                except Exception as e:
                    from tkinter import messagebox
                    messagebox.showerror("Kritik Hata", f"Yevmiye modülü bağımsız olarak açılamadı.\n{e}")


    def load_to_main_screen(self):
        sel = self.tree_menu.selection()
        if not sel or sel[0] not in self.templates: return
        
        if self.pivot_frame and hasattr(self.pivot_frame, "apply_template"):
            self.pivot_frame.apply_template(sel[0])
            messagebox.showinfo("Başarılı", f"'{sel[0]}' şablonu yüklendi.\nYukarıdan ana sekmeye geçerek düzenleyebilirsiniz.")
        else:
            messagebox.showwarning("Bağlantı Hatası", "Ana Pivot ekranı bağlanmadığı için bu şablonu aktaramıyorum.")

    def export_to_pdf_html(self):
        active_tree = self.get_active_tree()
        if not active_tree:
            messagebox.showwarning("Uyarı", "Aktif bir tablo bulunamadı!")
            return

        children = active_tree.get_children()
        
        if not children or active_tree["columns"][0] in ["status", "msg"]:
            messagebox.showwarning("Uyarı", "Dışa aktarılacak geçerli bir tablo yok!")
            return
            
        is_tree_mode = "tree" in str(active_tree.cget("show"))
        original_cols = list(active_tree["columns"])
        display_cols = list(active_tree.cget("displaycolumns"))
        
        if display_cols == ['#all'] or not display_cols:
            display_cols = original_cols

        if is_tree_mode:
            tree_heading = active_tree.heading("#0", "text")
            all_headers = [tree_heading] + original_cols
            export_cols = [tree_heading] + display_cols
        else:
            all_headers = original_cols
            export_cols = display_cols

        col_indices = [all_headers.index(c) for c in export_cols]
        data = []

        def get_all_rows_for_html(item_id, depth=0):
            item = active_tree.item(item_id)
            vals = list(item.get("values", []))
            
            if len(vals) < len(original_cols):
                vals += [""] * (len(original_cols) - len(vals))
                
            if is_tree_mode:
                indent = "&nbsp;" * (depth * 5)
                first_val = indent + str(item.get("text", ""))
                row_data = [first_val] + vals
            else:
                row_data = vals
                
            filtered_row = [row_data[i] for i in col_indices]
            data.append(filtered_row)
            
            for child_id in active_tree.get_children(item_id):
                get_all_rows_for_html(child_id, depth + 1)

        for child in children:
            get_all_rows_for_html(child, depth=0)

        # Tablo başlığını artık temiz alabiliriz (Çünkü x hack'i yok)
        report_title = self.lbl_title.cget("text").replace("🐍 ", "").replace("📊 ", "")
        html_content = self.generate_bootstrap_html(export_cols, data, report_title)
        
        try:
            fd, path = tempfile.mkstemp(suffix=".html", prefix="Rapor_", text=True)
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            webbrowser.open(f"file://{os.path.abspath(path)}")
        except Exception as e:
            messagebox.showerror("Hata", f"HTML rapor oluşturulamadı:\n{e}")

    def generate_bootstrap_html(self, headers, data, title):
        thead_html = "".join([f'<th scope="col">{html.escape(str(h))}</th>' for h in headers])
        
        tbody_html = ""
        for row in data:
            tbody_html += "<tr>"
            for i, cell in enumerate(row):
                align = 'text-start' if i == 0 else 'text-end' if any(char.isdigit() for char in str(cell)) else 'text-start'
                if i == 0:
                     tbody_html += f'<td class="{align}">{cell}</td>'
                else:
                    tbody_html += f'<td class="{align}">{html.escape(str(cell))}</td>'
            tbody_html += "</tr>"

        html_template = f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} Raporu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        body {{ background-color: #f4f6f9; padding-top: 2rem; padding-bottom: 2rem; }}
        .report-card {{ background-color: white; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); padding: 2rem; margin-bottom: 2rem; }}
        .table th {{ background-color: #2c3e50; color: white; font-weight: bold; text-transform: uppercase; }}
        .table-striped>tbody>tr:nth-of-type(odd)>* {{ background-color: #f8f9fa; }}
        .table-hover>tbody>tr:hover>* {{ background-color: #eaf2f8; }}
        .table td:first-child {{ font-weight: bold; }}
        @media print {{
            .no-print {{ display: none !important; }}
            body {{ background-color: white; padding: 0; }}
            .report-card {{ box-shadow: none; padding: 0; }}
        }}
    </style>
</head>
<body>
    <div class="container-fluid px-4">
        <div class="report-card" id="report-container">
            <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom no-print">
                <div>
                    <h3 class="text-primary mb-0">{title}</h3>
                    <p class="text-muted mb-0 small">Bu rapor sistem tarafından dinamik olarak oluşturulmuştur.</p>
                </div>
                <button onclick="downloadPDF()" class="btn btn-danger btn-lg shadow-sm">
                    PDF Olarak Kaydet
                </button>
            </div>
            
            <div id="pdf-area" class="p-3">
                <h2 class="mb-4 text-center d-none d-print-block" style="display: none; color: #2c3e50;">{title}</h2>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered table-sm">
                        <thead>
                            <tr>
                                {thead_html}
                            </tr>
                        </thead>
                        <tbody>
                            {tbody_html}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        function downloadPDF() {{
            const element = document.getElementById('pdf-area');
            const titleElement = element.querySelector('h2');
            titleElement.style.display = 'block';
            titleElement.classList.remove('d-none');
            
            const opt = {{
                margin:       0.3,
                filename:     '{title}_Raporu.pdf',
                image:        {{ type: 'jpeg', quality: 0.98 }},
                html2canvas:  {{ scale: 2, useCORS: true }},
                jsPDF:        {{ unit: 'in', format: 'a4', orientation: 'landscape' }}
            }};
            
            html2pdf().set(opt).from(element).save().then(() => {{
                titleElement.style.display = 'none';
                titleElement.classList.add('d-none');
            }});
        }}
    </script>
</body>
</html>"""
        return html_template