import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
import threading
import sqlite3
import os
import sys
import json
from tkinter import simpledialog
import re # YENİ EKLENDİ: Formül çözümlemesi için gerekli
import traceback
# --- PROJE ANA DİZİNİNİ YOLA EKLE (İmport Hatasını Çözer) ---
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, '..', '..')) 
if root_dir not in sys.path:
    sys.path.append(root_dir)

from .engine import PivotEngine

# Fatura Görüntüleyici Modülünü İçe Aktarma
try:
    from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
except ImportError:
            FaturaGoruntulePopup = None
from config import get_mukellefler_dir
from utils.session_db import get_last_session

def verify_admin(parent_window):
    """Script (Geliştirici) moduna giriş için şifre sorar."""
    pwd = simpledialog.askstring(
        "Güvenlik Uyarısı", 
        "Bu işlem yönetici / geliştirici yetkisi gerektirir.\nLütfen şifreyi girin:", 
        show='*', # Şifreyi yıldızlı gösterir
        parent=parent_window
    )
    
    if pwd == "":  # <-- ŞİFREYİ BURADAN DEĞİŞTİREBİLİRSİN
        return True
    elif pwd is not None: # Kullanıcı iptal'e basmadıysa ve yanlış girdiyse
        messagebox.showerror("Erişim Reddedildi", "Hatalı şifre girdiniz. İşlem iptal edildi.", parent=parent_window)
    return False

# =============================================================================
# YARDIMCI FONKSİYON: KAYDIRILABİLİR ÇERÇEVE
# =============================================================================
def create_scrollable_frame(parent, bg_color="#ffffff"):
    container = tk.Frame(parent, bg=bg_color)
    container.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    canvas = tk.Canvas(container, bg=bg_color, highlightthickness=0)
    scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)

    inner_frame = tk.Frame(canvas, bg=bg_color)
    canvas_window = canvas.create_window((0, 0), window=inner_frame, anchor="nw")

    def configure_scroll_region(event):
        canvas.configure(scrollregion=canvas.bbox("all"))
    inner_frame.bind("<Configure>", configure_scroll_region)

    def configure_window_size(event):
        canvas.itemconfig(canvas_window, width=event.width)
    canvas.bind("<Configure>", configure_window_size)

    def _on_mousewheel(event):
        if event.delta:
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    def _bind_to_mousewheel(event):
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def _unbind_from_mousewheel(event):
        canvas.unbind_all("<MouseWheel>")

    canvas.bind('<Enter>', _bind_to_mousewheel)
    canvas.bind('<Leave>', _unbind_from_mousewheel)

    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    return inner_frame


# =============================================================================
# 1. FİLTRE POPUP PENCERESİ
# =============================================================================
class FilterModal(tk.Toplevel):
    def __init__(self, parent, engine, field_name, current_selection, callback):
        super().__init__(parent)
        self.title(field_name)
        self.geometry("300x400")
        self.configure(bg="white")
        self.transient(parent)
        self.grab_set() 
        
        self.engine = engine
        self.field = field_name
        self.selection = current_selection 
        self.callback = callback
        
        self.setup_ui()
        self.load_values()

    def setup_ui(self):
        top = tk.Frame(self, bg="white", pady=10, padx=10)
        top.pack(fill=tk.X)
        
        tk.Label(top, text=self.field, font=("Segoe UI", 11, "bold"), bg="white").pack(side=tk.LEFT)
        tk.Button(top, text="İPTAL", bg="#f8f9fa", bd=1, relief="solid", cursor="hand2", command=self.destroy).pack(side=tk.RIGHT)
        tk.Button(top, text="UYGULA", bg="#2F5597", fg="white", bd=0, padx=10, cursor="hand2", command=self.apply).pack(side=tk.RIGHT, padx=5)
        
        search_frame = tk.Frame(self, bg="white", padx=10, pady=10)
        search_frame.pack(fill=tk.X)
        self.entry = tk.Entry(search_frame, bg="#f1f3f4", bd=0, font=("Segoe UI", 10))
        self.entry.pack(fill=tk.X, ipady=4)
        self.entry.insert(0, " Ara...")
        self.entry.bind("<FocusIn>", lambda e: self.entry.delete(0, tk.END) if self.entry.get() == " Ara..." else None)
        self.entry.bind("<KeyRelease>", self.on_search)
        self.inner = create_scrollable_frame(self, bg_color="white")
        self.vars = {} 

    def load_values(self):
        values = self.engine.get_unique_values(self.field)
        
        self.f_all = tk.Frame(self.inner, bg="white")
        self.f_all.pack(fill=tk.X, pady=(0, 5))
        
        is_all_checked = 1 if not self.selection else 0
        self.var_all = tk.IntVar(value=is_all_checked)
        tk.Checkbutton(self.f_all, variable=self.var_all, bg="white", command=self.toggle_all).pack(side=tk.LEFT)
        tk.Label(self.f_all, text="(Tümünü Seç)", bg="white", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT)
        
        self.item_frames = {} # --- YENİ EKLENDİ: Satırları saklayacağımız liste ---

        for val in values:
            f = tk.Frame(self.inner, bg="white")
            f.pack(fill=tk.X)
            is_checked = 1 if (not self.selection or val in self.selection) else 0
            var = tk.IntVar(value=is_checked)
            self.vars[val] = var
            tk.Checkbutton(f, variable=var, bg="white").pack(side=tk.LEFT)
            tk.Label(f, text=str(val), bg="white").pack(side=tk.LEFT)
            
            self.item_frames[val] = f # --- YENİ EKLENDİ: Frame'i kaydet ---
    def on_search(self, event=None):
        query = self.entry.get().strip().lower()
        if query == "ara...": 
            query = ""
            
        # Eğer arama kutusu boşsa "Tümünü Seç" kutusunu göster, doluysa gizle
        if query == "":
            self.f_all.pack(fill=tk.X, pady=(0, 5))
        else:
            self.f_all.pack_forget()
            
        # Kaydedilen satırları kontrol et, metin uyuyorsa göster, uymuyorsa gizle
        for val, frame in self.item_frames.items():
            if query in str(val).lower():
                frame.pack(fill=tk.X)
            else:
                frame.pack_forget()

    def toggle_all(self):
        state = self.var_all.get()
        for var in self.vars.values(): var.set(state)

    def apply(self):
        selected = [val for val, var in self.vars.items() if var.get() == 1]
        if len(selected) == len(self.vars): selected = []
        self.callback(self.field, selected)
        self.destroy()
# =============================================================================
# =============================================================================
# PANDAS SCRIPT İLE ÖZEL TABLO (ŞABLON) OLUŞTURMA EKRANI
# =============================================================================


class PandasScriptModal(tk.Toplevel):
    # __init__ metoduna düzenleme modu parametreleri ekledik
    def __init__(self, parent, pivot_frame, edit_mode=False, tpl_name="", source="Faturalar", code=""):
        super().__init__(parent)
        self.edit_mode = edit_mode
        self.tpl_name = tpl_name
        self.existing_source = source
        self.existing_code = code
        
        self.title(f"🐍 Özel Pandas Script Modu {'(Düzenleniyor: ' + tpl_name + ')' if edit_mode else ''}")
        self.geometry("800x650")
        self.configure(bg="#f3f2f1")
        self.transient(parent)
        self.grab_set()
        
        self.pivot_frame = pivot_frame
        self.df_preview = pd.DataFrame()
        self.setup_ui()

    def setup_ui(self):
        # 1. ÜST PANEL: Veri Kaynağı Seçimi
        top_frame = tk.Frame(self, bg="white", pady=10, padx=15, bd=1, relief="solid")
        top_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(top_frame, text="Veri Kaynağı:", bg="white", font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT)
        self.cb_source = ttk.Combobox(top_frame, values=["Faturalar", "Yevmiye", "Fatura + Yevmiye"], state="readonly", font=("Segoe UI", 10))
        self.cb_source.pack(side=tk.LEFT, padx=10)
        
        # 2. ORTA PANEL: Kod Yazma Alanı
        mid_frame = tk.Frame(self, bg="#f3f2f1")
        mid_frame.pack(fill=tk.BOTH, expand=True, padx=10)
        
        self.lbl_info = tk.Label(mid_frame, text="Seçilen veri kaynağı 'df' değişkeni olarak hazır gelir.\nSonuç tablosunu 'df_result' değişkenine atamalısınız.", bg="#f3f2f1", fg="#2980b9", font=("Segoe UI", 9, "bold"), justify=tk.LEFT)
        self.lbl_info.pack(anchor="w", pady=(0, 5))
        
        def on_source_changed(event):
            if self.cb_source.get() == "Fatura + Yevmiye":
                self.lbl_info.config(text="Veri kaynakları 'df_fatura' ve 'df_yevmiye' olarak hazır gelir.\nSonuç tablosunu 'df_result' değişkenine atamalısınız.")
            else:
                self.lbl_info.config(text="Seçilen veri kaynağı 'df' değişkeni olarak hazır gelir.\nSonuç tablosunu 'df_result' değişkenine atamalısınız.")
        
        self.cb_source.bind("<<ComboboxSelected>>", on_source_changed)
        
        self.txt_code = tk.Text(mid_frame, height=12, font=("Consolas", 11), bg="#282c34", fg="#abb2bf", insertbackground="white", bd=0)
        self.txt_code.pack(fill=tk.BOTH, expand=True)
        
        # --- EĞER DÜZENLEME MODUNDAYSAK ESKİ KODU YÜKLE ---
        if self.edit_mode:
            self.cb_source.set(self.existing_source)
            self.txt_code.insert("1.0", self.existing_code)
        else:
            self.cb_source.current(0)
            default_code = "# Örnek: Cari bazlı toplam KDV analizi\n# df_result = df.groupby('(F) Alıcı VKN/TCKN')['(F) Toplam KDV'].sum().reset_index()\n\ndf_result = df.head(50) # İlk 50 satırı getir\n"
            self.txt_code.insert("1.0", default_code)
        
        # 3. ALT PANEL: Butonlar ve Önizleme
        bot_frame = tk.Frame(self, bg="#f3f2f1", pady=10)
        bot_frame.pack(fill=tk.X, padx=10)
        
        btn_run = tk.Button(bot_frame, text="▶️ Kodu Çalıştır & Test Et", bg="#e67e22", fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=15, pady=5, cursor="hand2", command=self.run_script)
        btn_run.pack(side=tk.LEFT)
        
        btn_save = tk.Button(bot_frame, text="💾 Şablon Olarak Kaydet", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=15, pady=5, cursor="hand2", command=self.save_as_template)
        btn_save.pack(side=tk.RIGHT)
        
        self.lbl_status = tk.Label(self, text="Durum: Bekliyor...", bg="#f3f2f1", fg="#7f8c8d", font=("Segoe UI", 9))
        self.lbl_status.pack(anchor="w", padx=15, pady=5)

    def get_raw_data(self, source):
        """Veritabanından/Parquet dosyasından Pandas ile saf veriyi çeker"""
        engine = self.pivot_frame.engine
        raw_df = pd.DataFrame()
        try:
            if source == "Yevmiye":
                session = get_last_session()
                if session:
                    vkn = session.get("vkn")
                    year = session.get("year", session.get("yil"))
                    
                    if vkn and str(vkn) != "---":
                        base_dir = get_mukellefler_dir()
                        target_folder = next((os.path.join(base_dir, f) for f in os.listdir(base_dir) if str(f).endswith(f"-{str(vkn).strip()}")), None)
                        
                        if target_folder:
                            target_file = os.path.join(target_folder, str(year), f"{str(year)}_FULL.parquet")
                            if os.path.exists(target_file):
                                raw_df = pd.read_parquet(target_file)
                                
                                col_map = {
                                    "KayitTarihi": "Tarih", "YevmiyeNo": "Yevmiye No",
                                    "HesapKodu": "Hesap Kodu", "HesapAdi": "Hesap Adı",
                                    "FisAciklamasi": "Fiş Açıklama", "DetayAciklama": "Detay Açıklama",
                                    "Borc": "Borç", "Alacak": "Alacak"
                                }
                                raw_df.rename(columns=col_map, inplace=True)
                                
                                if hasattr(engine, 'y_map'):
                                    raw_df.rename(columns=engine.y_map, inplace=True)
                                    
            elif source == "Faturalar" and hasattr(engine, 'fatura_db') and engine.fatura_db:
                conn = sqlite3.connect(engine.fatura_db)
                c = conn.cursor()
                c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
                tbl = c.fetchone()
                if tbl:
                    raw_df = pd.read_sql_query(f"SELECT * FROM {tbl[0]}", conn)
                    if hasattr(engine, 'f_map'):
                        raw_df.rename(columns=engine.f_map, inplace=True)
                conn.close()
        except Exception as e:
            # ---> DÜZELTME 1: Hata kutusu açıldığında kilitlenmemesi için parent=self eklendi <---
            messagebox.showerror("Veri Hatası", f"Veri çekilemedi: {e}", parent=self)
        return raw_df
    
    def run_script(self):
        source = self.cb_source.get()
        code = self.txt_code.get("1.0", tk.END).strip()
        
        if not code: return
        
        self.lbl_status.config(text="Durum: Veri çekiliyor ve kod çalıştırılıyor...", fg="#2980b9")
        self.update()
        
        if source == "Fatura + Yevmiye":
            df_fatura = self.get_raw_data("Faturalar")
            df_yevmiye = self.get_raw_data("Yevmiye")
            
            if df_fatura.empty and df_yevmiye.empty:
                self.lbl_status.config(text="Durum: İki veri kaynağı da boş veya bulunamadı!", fg="#c0392b")
                return
                
            local_vars = {'df_fatura': df_fatura, 'df_yevmiye': df_yevmiye, 'pd': pd, 'np': np}
        else:
            raw_df = self.get_raw_data(source)
            if raw_df.empty:
                self.lbl_status.config(text="Durum: Veri kaynağı boş veya bulunamadı!", fg="#c0392b")
                return
                
            local_vars = {'df': raw_df, 'pd': pd, 'np': np}
            
        try:
            exec(code, {}, local_vars)
            
            self.df_preview = local_vars.get('df_result')
            
            if self.df_preview is not None and isinstance(self.df_preview, pd.DataFrame):
                row_count = len(self.df_preview)
                self.lbl_status.config(text=f"Durum: Başarılı! Sonuç tablosu oluşturuldu ({row_count} satır).", fg="#27ae60")
                
                try:
                    if self.pivot_frame.var_dual_view.get():
                        self.pivot_frame.var_dual_view.set(False)
                        self.pivot_frame.cb_split.config(state="disabled")
                        self.pivot_frame.build_right_panel()

                    dummy_config = {
                        "rows": [], "cols": [], "vals": [],
                        "active_filters": {}, "calc_cols": {},
                        "hidden_cols": [], "column_order": []
                    }

                    self.pivot_frame._render_single_table(self.pivot_frame.tree_main, self.df_preview, dummy_config)
                    
                except Exception as render_err:
                    self.lbl_status.config(text=f"Durum: Veri oluştu ancak ekrana basılamadı: {render_err}", fg="#e67e22")

            else:
                self.lbl_status.config(text="Durum: HATA! Kodda 'df_result' adında bir DataFrame oluşturulmadı.", fg="#c0392b")
                self.df_preview = pd.DataFrame()
                
        except Exception as e:
            error_details = traceback.format_exc()
            self.lbl_status.config(text=f"Durum: Python Hatası! {str(e)}", fg="#c0392b")
            print(error_details)

    def save_as_template(self):
        if self.df_preview is None or self.df_preview.empty:
            messagebox.showwarning("Uyarı", "Önce kodu çalıştırıp başarılı bir tablo elde etmelisiniz.", parent=self)
            return
            
        initial_name = self.tpl_name if self.edit_mode else ""
        
        # ---> DÜZELTME 2: Girdi istemeden önce odak kilidini geçici olarak serbest bırakıyoruz <---
        self.grab_release()
        
        tpl_name = simpledialog.askstring("Şablon Kaydet", "Bu özel script şablonu için bir isim girin:", initialvalue=initial_name, parent=self)
        
        # İşlem bittiğinde (kullanıcı yazdı veya iptal etti) odağı pencereye geri veriyoruz
        self.grab_set()
        
        if not tpl_name or tpl_name.strip() == "": return
        
        source = self.cb_source.get()
        code = self.txt_code.get("1.0", tk.END).strip()
        
        script_config = {
            "is_script": True,
            "script_source": source,
            "script_code": code
        }
        
        templates = self.pivot_frame.load_all_templates()
        
        old_group = "🐍 Özel Python Raporları"
        if self.edit_mode and tpl_name in templates:
            old_data = templates[tpl_name]
            if isinstance(old_data, dict) and "group" in old_data:
                old_group = old_data["group"]
                
        templates[tpl_name] = {"group": old_group, "config": script_config}
        
        try:
            with open(self.pivot_frame.get_templates_file(), "w", encoding="utf-8") as f:
                json.dump(templates, f, ensure_ascii=False, indent=4)
            messagebox.showinfo("Başarılı", f"'{tpl_name}' şablonu kaydedildi!", parent=self)
            self.pivot_frame.refresh_template_menu()
            self.destroy()
        except Exception as e:
            messagebox.showerror("Hata", f"Kaydedilemedi: {e}", parent=self)


# FORMÜLLÜ SÜTUN (CALCULATED FIELD) POPUP EKRANI
# =============================================================================
class FormulaModal(tk.Toplevel):
    def __init__(self, parent, pivot_frame, columns, prefix, existing_name=None, existing_formula=None, old_full_name=None):
        super().__init__(parent)
        self.title("✏️ Formüllü Sütun Yönetimi" if existing_name else "➕ Formüllü Sütun Ekle")
        self.geometry("550x500")
        self.configure(bg="#f3f2f1")
        self.transient(parent)
        self.grab_set()
        
        self.pivot_frame = pivot_frame
        self.columns = columns
        self.prefix = prefix
        
        # Düzenleme modu için değişkenler
        self.existing_name = existing_name
        self.existing_formula = existing_formula
        self.old_full_name = old_full_name
        
        self.setup_ui()

    def setup_ui(self):
        # 1. Başlık ve Sütun Adı
        top_frame = tk.Frame(self, bg="#f3f2f1")
        top_frame.pack(fill=tk.X, padx=20, pady=15)
        
        tk.Label(top_frame, text="Sütun Adı:", bg="#f3f2f1", font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT)
        tk.Label(top_frame, text=f"{self.prefix} ", bg="#f3f2f1", font=("Segoe UI", 10, "bold"), fg="#c0392b").pack(side=tk.LEFT, padx=(10, 0))
        
        self.ent_name = tk.Entry(top_frame, font=("Segoe UI", 10))
        self.ent_name.pack(side=tk.LEFT, fill=tk.X, expand=True)
        if self.existing_name:
            self.ent_name.insert(0, self.existing_name)

        # 2. Orta Kısım: Sütun Listesi ve Hızlı Butonlar
        mid_frame = tk.Frame(self, bg="#f3f2f1")
        mid_frame.pack(fill=tk.BOTH, expand=True, padx=20)
        
        list_frame = tk.Frame(mid_frame, bg="white", bd=1, relief="solid")
        list_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        tk.Label(list_frame, text="Mevcut Sütunlar\n(Formüle eklemek için çift tıkla)", bg="#eaf2f8", font=("Segoe UI", 8, "bold")).pack(fill=tk.X)
        
        self.lst_cols = tk.Listbox(list_frame, font=("Segoe UI", 9), selectbackground="#2F5597")
        self.lst_cols.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        for col in self.columns:
            if col != "Genel Toplam" and col != "No":
                self.lst_cols.insert(tk.END, col)
                
        self.lst_cols.bind("<Double-Button-1>", self.insert_column)
        
        btn_frame = tk.Frame(mid_frame, bg="#f3f2f1")
        btn_frame.pack(side=tk.RIGHT, fill=tk.Y)
        
        ops = ["+", "-", "*", "/", "(", ")", "EGER(koşul, d, y)"]
        for op in ops:
            btn = tk.Button(btn_frame, text=op, font=("Segoe UI", 10, "bold"), bg="#bdc3c7", cursor="hand2", command=lambda o=op: self.insert_text(o))
            btn.pack(fill=tk.X, pady=2)

        # 3. Alt Kısım: Formül Alanı
        bot_frame = tk.Frame(self, bg="#f3f2f1")
        bot_frame.pack(fill=tk.X, padx=20, pady=15)
        
        tk.Label(bot_frame, text="Formül (Örn: [Sütun 1] * 0.20):", bg="#f3f2f1", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.txt_formula = tk.Text(bot_frame, height=5, font=("Consolas", 10), bd=1, relief="solid")
        self.txt_formula.pack(fill=tk.X, pady=5)
        if self.existing_formula:
            self.txt_formula.insert("1.0", self.existing_formula)
        
        btn_text = "🔄 Güncelle ve Hesapla" if self.existing_name else "💾 Sütunu Ekle ve Hesapla"
        tk.Button(self, text=btn_text, bg="#27ae60" if not self.existing_name else "#2980b9", fg="white", font=("Segoe UI", 10, "bold"), bd=0, pady=8, cursor="hand2", command=self.save_formula).pack(fill=tk.X, padx=20, pady=(0, 20))

    def insert_column(self, event):
        selection = self.lst_cols.curselection()
        if selection:
            col_name = self.lst_cols.get(selection[0])
            self.txt_formula.insert(tk.INSERT, f"[{col_name}]")

    def insert_text(self, text):
        if "EGER" in text:
            self.txt_formula.insert(tk.INSERT, "EGER( , , )")
        else:
            self.txt_formula.insert(tk.INSERT, f" {text} ")

    def save_formula(self):
        col_name = self.ent_name.get().strip()
        formula = self.txt_formula.get("1.0", tk.END).strip()
        
        if not col_name or not formula:
            messagebox.showwarning("Uyarı", "Sütun adı ve formül boş bırakılamaz!", parent=self)
            return
            
        full_name = f"{self.prefix} {col_name}"
        
        if "calc_cols" not in self.pivot_frame.pivot_config:
            self.pivot_frame.pivot_config["calc_cols"] = {}
            
        # Düzenleme modundaysa ve isim değiştirildiyse, eski ismi sözlükten sil
        if self.old_full_name and self.old_full_name != full_name:
            if self.old_full_name in self.pivot_frame.pivot_config["calc_cols"]:
                del self.pivot_frame.pivot_config["calc_cols"][self.old_full_name]
                
        self.pivot_frame.pivot_config["calc_cols"][full_name] = formula
        
        self.pivot_frame.calculate()
        self.destroy()





# 1.5. İÇERİYE GÖMÜLÜ DİLİMLEYİCİ (SLICER) KUTUSU
# =============================================================================
class SlicerWindow(tk.Frame): # Toplevel yerine Frame yapıyoruz!
    def __init__(self, parent, engine, field_name, current_config, apply_callback, close_callback):
        # parent artık Toplevel değil, doğrudan PivotTableFrame olacak
        super().__init__(parent, bg="#ffffff", highlightthickness=1, highlightbackground="#bdc3c7")
        
        self.engine = engine
        self.field = field_name
        self.config = current_config
        self.apply_callback = apply_callback
        self.close_callback = close_callback

        self._offsetx = 0
        self._offsety = 0

        self.setup_ui()
        self.load_items()

    

    def setup_ui(self):
        # --- SÜRÜKLENEBİLİR BAŞLIK (HEADER) ---
        self.header = tk.Frame(self, bg="#f3f2f1", height=32)
        self.header.pack(fill="x")
        self.header.pack_propagate(False)
        
        # Fare ile tutma olayları
        self.header.bind("<Button-1>", self.clickwin)
        self.header.bind("<B1-Motion>", self.dragwin)

        lbl_title = tk.Label(self.header, text=f"📊 {self.field}", bg="#f3f2f1", fg="#2c3e50", font=("Segoe UI", 9, "bold"))
        lbl_title.pack(side="left", padx=5)
        lbl_title.bind("<Button-1>", self.clickwin)
        lbl_title.bind("<B1-Motion>", self.dragwin)

        btn_close = tk.Label(self.header, text="✕", bg="#f3f2f1", fg="#c0392b", font=("Arial", 10, "bold"), cursor="hand2")
        btn_close.pack(side="right", padx=5)
        btn_close.bind("<Button-1>", lambda e: self.close())

        btn_clear = tk.Label(self.header, text="🧹", bg="#f3f2f1", fg="#2980b9", font=("Segoe UI", 10), cursor="hand2")
        btn_clear.pack(side="right", padx=2)
        btn_clear.bind("<Button-1>", lambda e: self.clear_filter())
        
        # --- BİLGİ ŞERİDİ ---
        info_frame = tk.Frame(self, bg="#eaf2f8")
        info_frame.pack(fill="x")
        tk.Label(info_frame, text="Çoklu seçim: CTRL + Tıkla", bg="#eaf2f8", fg="#7f8c8d", font=("Segoe UI", 7)).pack(pady=2)

        # --- BUTONLARIN LİSTELENDİĞİ GÖVDE ---
        # Sende var olan scrollable frame'i kullanır
        self.inner = create_scrollable_frame(self, bg_color="#ffffff")
        self.buttons = {}

    def load_items(self):
        values = self.engine.get_unique_values(self.field)
        self.selected_items = self.config["active_filters"].get(self.field, []).copy()

        for val in values:
            btn = tk.Label(self.inner, text=str(val), font=("Segoe UI", 9), pady=6, padx=8, anchor="w", cursor="hand2", bd=1, relief="solid")
            btn.pack(fill="x", padx=4, pady=2)
            
            # Sol tık: Tekli seçim | Ctrl+Sol tık: Çoklu seçim
            btn.bind("<Button-1>", lambda e, v=val: self.on_item_click(v, e))
            btn.bind("<Control-Button-1>", lambda e, v=val: self.on_item_ctrl_click(v, e))
            
            self.buttons[val] = btn

        self.refresh_visuals()

    def on_item_click(self, val, event):
        if self.selected_items == [val]: self.selected_items = [] # Tıklıyı geri al
        else: self.selected_items = [val] # Yeni seç
        self.trigger_apply()

    def on_item_ctrl_click(self, val, event):
        if val in self.selected_items: self.selected_items.remove(val)
        else: self.selected_items.append(val)
        self.trigger_apply()

    def clear_filter(self):
        self.selected_items = []
        self.trigger_apply()

    def trigger_apply(self):
        self.refresh_visuals()
        self.apply_callback(self.field, self.selected_items)

    def refresh_visuals(self):
        """Excel stili: Seçili butonlar lacivert, seçilmeyenler gri/beyaz olur"""
        for val, btn in self.buttons.items():
            if val in self.selected_items:
                # bordercolor parametresi silindi
                btn.config(bg="#2F5597", fg="white", font=("Segoe UI", 9, "bold"))
            else:
                # bordercolor parametresi silindi
                btn.config(bg="#f8f9fa", fg="#333333", font=("Segoe UI", 9, "normal"))

    def clickwin(self, event):
        # Farenin ekrandaki mutlak konumu ile kutunun konumu arasındaki farkı alıyoruz
        self._offsetx = self.winfo_pointerx() - self.winfo_x()
        self._offsety = self.winfo_pointery() - self.winfo_y()

    def dragwin(self, event):
        # Yeni konumu hesapla
        x = self.winfo_pointerx() - self._offsetx
        y = self.winfo_pointery() - self._offsety
        
        # geometry YERİNE place KULLANIYORUZ!
        self.place(x=x, y=y)

    def close(self):
        # Pencere kapatılmadan önce içindeki filtreleri tamamen temizler ve tabloyu günceller
        self.clear_filter() 
        
        # Slicer'ı bellekten siler ve pencereyi kapatır
        self.close_callback(self.field)
        self.destroy()
# =============================================================================
# ŞABLON YÖNETİCİSİ POP-UP PENCERESİ (YENİ)
# =============================================================================
# =============================================================================
# ŞABLON YÖNETİCİSİ POP-UP PENCERESİ (GÜNCELLENMİŞ TOPLU SEÇİM DESTEĞİYLE)
# =============================================================================
class TemplateManagerModal(tk.Toplevel):
    def __init__(self, parent, pivot_frame):
        super().__init__(parent)
        self.title("⚙ Şablon Yöneticisi")
        self.geometry("600x450")
        self.configure(bg="#f3f2f1")
        self.transient(parent)
        self.grab_set()
        
        self.pivot_frame = pivot_frame
        
        self.setup_ui()
        self.load_data()

    def setup_ui(self):
        # Üst Araç Çubuğu (Toolbar)
        tb = tk.Frame(self, bg="white", pady=8, padx=5, bd=1, relief="solid")
        tb.pack(fill=tk.X, padx=5, pady=5)
        
        tk.Button(tb, text="▶ Yükle", bg="#27ae60", fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=12, cursor="hand2", command=self.apply_selected).pack(side=tk.LEFT, padx=2)
        tk.Button(tb, text="🐍 Kodu Düzenle", bg="#f39c12", fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=10, cursor="hand2", command=self.edit_script).pack(side=tk.LEFT, padx=2)
        tk.Button(tb, text="✏ Yeniden Adlandır", bg="#2980b9", fg="white", font=("Segoe UI", 9), bd=0, padx=10, cursor="hand2", command=self.rename_selected).pack(side=tk.LEFT, padx=2)
        tk.Button(tb, text="📁 Grubu Değiştir", bg="#8e44ad", fg="white", font=("Segoe UI", 9), bd=0, padx=10, cursor="hand2", command=self.change_group).pack(side=tk.LEFT, padx=2)
        tk.Button(tb, text="🗑 Sil", bg="#c0392b", fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=12, cursor="hand2", command=self.delete_selected).pack(side=tk.RIGHT, padx=2)

        # Şablon Listesi (Treeview)
        tv_frame = tk.Frame(self, bg="white", bd=1, relief="solid")
        tv_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=(0,5))
        
        style = ttk.Style()
        style.configure("Tpl.Treeview", rowheight=28, font=("Segoe UI", 10))
        style.configure("Tpl.Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#f2f2f2")
        
        # --- TOPLU SEÇİM İÇİN YENİ TABLO YAPISI (Check Sütunu Eklendi) ---
        self.tree = ttk.Treeview(tv_frame, columns=("Check", "Tipi"), show="tree headings", style="Tpl.Treeview")
        
        self.tree.heading("#0", text="📁 Klasörler / 📄 Şablonlar")
        self.tree.column("#0", width=380, anchor="w")
        
        self.tree.heading("Check", text="☑")
        self.tree.column("Check", width=40, anchor="center")
        
        self.tree.heading("Tipi", text="Tür")
        self.tree.column("Tipi", width=100, anchor="center")
        
        vsb = ttk.Scrollbar(tv_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.tree.bind("<Double-1>", self.on_double_click)
        self.tree.bind("<<TreeviewOpen>>", self.on_tree_open)
        self.tree.bind("<ButtonRelease-1>", self.on_tree_click) # Checkbox Tıklaması

    def on_tree_open(self, event):
        item_id = self.tree.focus()
        item_text = self.tree.item(item_id, "text")
        
        if "python" in item_text.lower() or "phyton" in item_text.lower() or "script" in item_text.lower():
            if not verify_admin(self):
                self.tree.after(0, lambda: self.tree.item(item_id, open=False))

    def on_tree_click(self, event):
        """Checkbox sütununa tıklanıldığında işareti değiştirir."""
        region = self.tree.identify("region", event.x, event.y)
        if region == "cell":
            col = self.tree.identify_column(event.x)
            if col == "#1": # 1. Sütun (Check)
                item_id = self.tree.identify_row(event.y)
                if not item_id: return
                
                vals = list(self.tree.item(item_id, "values"))
                if not vals: return
                
                new_val = "☑" if vals[0] == "☐" else "☐"
                vals[0] = new_val
                self.tree.item(item_id, values=vals)

                # Eğer klasöre tıklandıysa altındaki her şeyi seç/kaldır
                if self.tree.parent(item_id) == "":
                    for child in self.tree.get_children(item_id):
                        c_vals = list(self.tree.item(child, "values"))
                        c_vals[0] = new_val
                        self.tree.item(child, values=c_vals)
                # Eğer alt dosyaya tıklandıysa, klasörün durumunu hepsi seçili mi diye kontrol et
                else:
                    parent_id = self.tree.parent(item_id)
                    siblings = self.tree.get_children(parent_id)
                    all_checked = all(self.tree.item(s, "values")[0] == "☑" for s in siblings)
                    p_vals = list(self.tree.item(parent_id, "values"))
                    p_vals[0] = "☑" if all_checked else "☐"
                    self.tree.item(parent_id, values=p_vals)

    def load_data(self):
        self.tree.delete(*self.tree.get_children())
        templates = self.pivot_frame.load_all_templates()
        
        groups = {}
        for t_name, t_data in templates.items():
            grp = t_data.get("group", "Genel") if isinstance(t_data, dict) and "group" in t_data else "Genel"
            
            if any(keyword in grp.lower() for keyword in ["python", "phyton", "script"]):
                grp = "🔒 Özel Python Scriptleri"
                
            if grp not in groups: groups[grp] = []
            groups[grp].append(t_name)
            
        for grp in sorted(groups.keys()):
            is_secure = "🔒" in grp
            icon = "🔒" if is_secure else "📁"
            
            # Ana Klasör (Başlangıçta ☐)
            grp_id = self.tree.insert("", "end", text=f"{icon} {grp}", values=("☐", "Klasör"), open=False)
            
            # İçindeki Dosyalar
            for t_name in sorted(groups[grp]):
                self.tree.insert(grp_id, "end", text=t_name, values=("☐", "Script" if is_secure else "Pivot"))

    def get_checked_items(self):
        """Tik atılmış olan şablonların listesini döndürür."""
        checked = []
        for grp_id in self.tree.get_children():
            for item_id in self.tree.get_children(grp_id):
                vals = self.tree.item(item_id, "values")
                if vals and vals[0] == "☑":
                    checked.append(self.tree.item(item_id, "text"))
        return checked

    def get_selected(self, show_warning=True):
        """Klasik mavi arkaplanla (vurgulu) seçili tekli öğeyi döndürür."""
        sel = self.tree.selection()
        if not sel:
            if show_warning: messagebox.showwarning("Uyarı", "Lütfen listeden bir şablon seçin.", parent=self)
            return None
            
        item_id = sel[0]
        if self.tree.parent(item_id) == "":
            if show_warning: messagebox.showwarning("Uyarı", "Lütfen bir klasör değil, içindeki şablonu seçin.", parent=self)
            return None
            
        return str(self.tree.item(item_id, "text"))

    def get_single_action_target(self):
        """Düzenle, Yeniden Adlandır, Yükle gibi tekil işlemler için yardımcı."""
        checked = self.get_checked_items()
        if len(checked) == 1:
            return checked[0]
        elif len(checked) > 1:
            messagebox.showwarning("Uyarı", "Bu işlem aynı anda sadece tek bir şablon için yapılabilir.", parent=self)
            return None
        return self.get_selected()

    def on_double_click(self, event):
        item_id = self.tree.focus()
        if not item_id: return
        if self.tree.parent(item_id) != "":
            # Çift tıklandığında hemen uygula
            self.pivot_frame.apply_template(str(self.tree.item(item_id, "text")))
            self.destroy()

    def save_and_refresh(self, templates):
        import json
        try:
            with open(self.pivot_frame.get_templates_file(), "w", encoding="utf-8") as f:
                json.dump(templates, f, ensure_ascii=False, indent=4)
            self.load_data()
            self.pivot_frame.refresh_template_menu()
        except Exception as e:
            messagebox.showerror("Hata", f"İşlem kaydedilemedi: {e}", parent=self)

    def apply_selected(self):
        name = self.get_single_action_target()
        if name:
            self.pivot_frame.apply_template(name)
            self.destroy()

    def edit_script(self):
        name = self.get_single_action_target()
        if not name: return

        templates = self.pivot_frame.load_all_templates()
        t_data = templates.get(name)
        config = t_data.get("config", t_data) if isinstance(t_data, dict) else t_data

        if not config.get("is_script"):
            messagebox.showwarning("Uyarı", "Seçtiğiniz şablon bir Python Script raporu değil.", parent=self)
            return

        if not verify_admin(self): return

        source = config.get("script_source", "Faturalar")
        code = config.get("script_code", "")

        PandasScriptModal(self.pivot_frame.winfo_toplevel(), self.pivot_frame, edit_mode=True, tpl_name=name, source=source, code=code)
        self.destroy()

    def rename_selected(self):
        old_name = self.get_single_action_target()
        if not old_name: return
        
        templates = self.pivot_frame.load_all_templates()
        if old_name in templates:
            data = templates[old_name]
            config = data.get("config", data) if isinstance(data, dict) else data
            if config.get("is_script") and not verify_admin(self): return

        from tkinter import simpledialog
        new_name = simpledialog.askstring("Yeniden Adlandır", "Yeni şablon adını girin:", initialvalue=old_name, parent=self)
        if not new_name or new_name.strip() == "" or new_name == old_name: return
        
        if new_name in templates:
            messagebox.showerror("Hata", "Bu isimde bir şablon zaten var!", parent=self)
            return
            
        templates[new_name] = templates.pop(old_name)
        self.save_and_refresh(templates)

    def change_group(self):
        # Toplu seçim varsa onları, yoksa standart seçili olanı al
        items_to_move = self.get_checked_items()
        if not items_to_move:
            single = self.get_selected(show_warning=False)
            if single: items_to_move = [single]
            else:
                messagebox.showwarning("Uyarı", "Lütfen işlemi yapmak istediğiniz şablonları tikleyerek seçin.", parent=self)
                return
        
        templates = self.pivot_frame.load_all_templates()
        
        # İçlerinde kilitli python scripti varsa admin doğrulaması iste
        needs_admin = any((isinstance(templates[name], dict) and templates[name].get("config", {}).get("is_script")) for name in items_to_move if name in templates)
        if needs_admin and not verify_admin(self): return
            
        first_item = templates[items_to_move[0]]
        old_group = first_item.get("group", "Genel") if isinstance(first_item, dict) and "group" in first_item else "Genel"
        
        # --- 1. MEVCUT GRUPLARI TOPLA (Kilitli script klasörlerini hariç tutarak) ---
        existing_groups = set(["Genel"])
        for t_data in templates.values():
            grp = t_data.get("group", "Genel") if isinstance(t_data, dict) and "group" in t_data else "Genel"
            if not any(k in grp.lower() for k in ["python", "phyton", "script"]):
                existing_groups.add(grp)
        
        # --- 2. ÖZEL GRUP SEÇİM POP-UP PENCERESİ OLUŞTUR ---
        dialog = tk.Toplevel(self)
        dialog.title("📁 Grubu Değiştir")
        dialog.geometry("380x200")
        dialog.configure(bg="#f3f2f1")
        dialog.transient(self)
        dialog.grab_set()

        tk.Label(dialog, text=f"{len(items_to_move)} şablon için yeni grup adını seçin\nveya kutuya yeni bir isim yazın:", bg="#f3f2f1", font=("Segoe UI", 10), pady=10).pack()

        # Combobox'ı "normal" modda açıyoruz ki kullanıcı listeyi açabilsin ama isterse kendi de yazabilsin
        cb_group = ttk.Combobox(dialog, values=sorted(list(existing_groups)), font=("Segoe UI", 10))
        cb_group.pack(fill=tk.X, padx=30, pady=10)
        cb_group.set(old_group) # Varsayılan olarak eski grubu seçili getir

        self.new_group_result = None

        def on_ok():
            val = cb_group.get().strip()
            if val:
                self.new_group_result = val
                dialog.destroy()
            else:
                messagebox.showwarning("Uyarı", "Grup adı boş olamaz!", parent=dialog)

        btn_frame = tk.Frame(dialog, bg="#f3f2f1")
        btn_frame.pack(pady=15)
        
        tk.Button(btn_frame, text="İptal", bg="#bdc3c7", fg="#333", font=("Segoe UI", 9, "bold"), bd=0, padx=15, pady=5, cursor="hand2", command=dialog.destroy).pack(side=tk.LEFT, padx=10)
        tk.Button(btn_frame, text="💾 Kaydet", bg="#8e44ad", fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=15, pady=5, cursor="hand2", command=on_ok).pack(side=tk.LEFT, padx=10)

        # Kullanıcı pop-up'ta işlem yapana kadar kodu burada bekletir
        self.wait_window(dialog) 

        new_group = self.new_group_result
        if not new_group: return # İptal edildiyse veya çarpıdan kapatıldıysa işlemi durdur
        # -----------------------------------------------------------
        
        for name in items_to_move:
            if name in templates:
                data = templates[name]
                if isinstance(data, dict) and "config" in data:
                    data["group"] = new_group.strip()
                else:
                    templates[name] = {"group": new_group.strip(), "config": data}
                    
        self.save_and_refresh(templates)

    def delete_selected(self):
        # Toplu silme
        items_to_delete = self.get_checked_items()
        if not items_to_delete:
            single = self.get_selected(show_warning=False)
            if single: items_to_delete = [single]
            else:
                messagebox.showwarning("Uyarı", "Lütfen silmek istediğiniz şablonları tikleyerek seçin.", parent=self)
                return
        
        templates = self.pivot_frame.load_all_templates()
        
        needs_admin = any((isinstance(templates[name], dict) and templates[name].get("config", {}).get("is_script")) for name in items_to_delete if name in templates)
        if needs_admin and not verify_admin(self): return
                
        msg = f"Seçili {len(items_to_delete)} şablonu silmek istediğinize emin misiniz?" if len(items_to_delete) > 1 else f"'{items_to_delete[0]}' şablonunu tamamen silmek istediğinize emin misiniz?"
        if messagebox.askyesno("Onay", msg, parent=self):
            for name in items_to_delete:
                if name in templates: del templates[name]
            self.save_and_refresh(templates)

# =============================================================================
# PRO ÖZELLİK: İKİ ŞABLON PİVOTUNU ORTAK ALANDAN BİRLEŞTİRME EKRANI
# =============================================================================


# 2. ANA PIVOT ARAYÜZÜ
# =============================================================================
class PivotTableFrame(tk.Frame):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, bg="#f3f2f1", *args, **kwargs)
        self.engine = PivotEngine()
        # Slicer takibi ve sağ tık menüsü (Eklemeler burası)
        self.active_slicers = {}
        self.slicer_context_menu = tk.Menu(self, tearoff=0, font=("Segoe UI", 10))
        self.slicer_context_menu.add_command(label="📊 Dilimleyici (Slicer) Olarak Ekle", command=self.add_slicer_from_menu)
        self._clicked_slicer_field = None
        
        self.pivot_config = {
            "filters": [], "cols": [], "rows": [], "vals": [],
            "active_filters": {}, "sort_col": None, "sort_asc": True, # <-- BURADAKİ VİRGÜLÜ UNUTMA
            "calc_cols": {},
            "hidden_cols": [],
            "column_order": []  # <-- YENİ EKLENDİ 
        }
        # YENİ EKLENDİ: Sütun Başlığı Sağ Tık Menüsü
        self.header_context_menu = tk.Menu(self, tearoff=0, font=("Segoe UI", 10))
        self.header_context_menu.add_command(label="➕ Formüllü Sütun Ekle", command=self.open_formula_modal)


        self.var_totals = tk.BooleanVar(value=True)    
        self.var_subtotals = tk.BooleanVar(value=True) 
        self.var_group = tk.BooleanVar(value=True) 
        self.var_date_fmt = tk.StringVar(value="Normal")
        
        self.drag_data = {"item": None, "source_list": None}
        self.all_fields = self.engine.get_columns() 
        self.prev_path = [] 
        self.clicked_cell_value = "" 
        
        self.calc_thread = None
        self.cancel_flag = False
        self.winfo_toplevel().bind("<Escape>", self.cancel_calculation)
        
        self.setup_toolbar()
        self.setup_main_layout()
        self.bind("<Destroy>", self.on_frame_destroy)

# PivotTableFrame sınıfının içine ekle (örneğin __init__ fonksiyonundan sonra)
    def on_frame_destroy(self, event):
        """Pivot ekranı (veya sekmesi) kapatıldığında Slicer'ları garantili temizler."""
        # Sadece bu frame yok ediliyorsa çalıştır (alt widget'ların kapanmasını filtrele)
        if event.widget == self:
            for slicer in list(self.active_slicers.values()):
                try: 
                    slicer.destroy()
                except: 
                    pass
            self.active_slicers.clear()

    def move_column_left(self):
        self._move_column(-1)

    def move_column_right(self):
        self._move_column(1)

    def _move_column(self, direction):
        """Sütunu görsel olarak sağa veya sola kaydırır ve şablon hafızasına yazar"""
        if not hasattr(self, 'clicked_col_name') or not self.clicked_col_name: return
        tree = getattr(self, 'clicked_tree', None)
        if not tree: return
        
        # Mevcut görsel sıralamayı al
        current_order = list(tree.cget("displaycolumns"))
        if current_order == ["#all"] or not current_order:
            current_order = list(tree.cget("columns"))
            
        col = self.clicked_col_name
        if col not in current_order: return
        
        idx = current_order.index(col)
        new_idx = idx + direction
        
        if 0 <= new_idx < len(current_order):
            # Listede yer değiştir
            current_order.insert(new_idx, current_order.pop(idx))
            
            # 1. Config'e kaydet (Şablon için)
            self.pivot_config["column_order"] = current_order
            
            # 2. Arayüzü anında güncelle
            tree.configure(displaycolumns=current_order)

    def cancel_calculation(self, event=None):
        if self.calc_thread and self.calc_thread.is_alive():
            self.cancel_flag = True 
            messagebox.showwarning("İptal Edildi", "Süzme ve Hesaplama ESC ile durduruldu!")
            trees = [t for t in [self.tree_main, self.tree_f, self.tree_y] if t]
            for tree in trees:
                tree.delete(*tree.get_children())
                tree.configure(displaycolumns="#all")
                tree["columns"] = ["status"]
                tree.heading("status", text="DURUM", anchor="w")
                tree.column("status", width=400)
                tree.insert("", "end", values=["İşlem iptal edildi."])


    def setup_toolbar(self):
        tb = tk.Frame(self, bg="#ffffff", height=45, bd=1, relief="solid")
        tb.pack(fill=tk.X, padx=5, pady=5)
        
        left_frame = tk.Frame(tb, bg="#ffffff")
        left_frame.pack(side=tk.LEFT)
        
        # --- PRO ÖZELLİK: ŞABLON BUTONLARI ---
        btn_new_pivot = tk.Label(left_frame, text="✨\nYeni Pivot", bg="#ffffff", fg="#d35400", font=("Segoe UI", 8, "bold"), padx=10, cursor="hand2")
        btn_new_pivot.pack(side=tk.LEFT)
        btn_new_pivot.bind("<Button-1>", lambda e: NewPivotModal(self.winfo_toplevel(), self))
        # ---> YENİ EKLENEN SCRIPT BUTONU <---
        btn_script = tk.Label(left_frame, text="🐍\nScript Modu", bg="#ffffff", fg="#16a085", font=("Segoe UI", 8, "bold"), padx=10, cursor="hand2")
        btn_script.pack(side=tk.LEFT)
        # Sadece şifre doğruysa Script Modu açılır
        def open_script_modal_secure(e):
            if verify_admin(self.winfo_toplevel()):
                PandasScriptModal(self.winfo_toplevel(), self)
                
        btn_script.bind("<Button-1>", open_script_modal_secure)
        # ------------------------------------
        
        
        btn_save_tpl = tk.Label(left_frame, text="💾\nŞablon Kaydet", bg="#ffffff", fg="#27ae60", font=("Segoe UI", 8, "bold"), padx=10, cursor="hand2")
        btn_save_tpl.pack(side=tk.LEFT)
        btn_save_tpl.bind("<Button-1>", lambda e: self.save_template())
        btn_merge = tk.Label(left_frame, text="🔀\nTablo Birleştir", bg="#ffffff", fg="#8e44ad", font=("Segoe UI", 8, "bold"), padx=10, cursor="hand2")
        btn_merge.pack(side=tk.LEFT)
        btn_merge.bind("<Button-1>", lambda e: ScenarioMergeModal(self.winfo_toplevel(), self))



        self.mb_templates = tk.Menubutton(left_frame, text="📂\nŞablonlarım", bg="#ffffff", fg="#2980b9", font=("Segoe UI", 8, "bold"), cursor="hand2")
        self.mb_templates.pack(side=tk.LEFT, padx=10)
        self.menu_templates = tk.Menu(self.mb_templates, tearoff=0, font=("Segoe UI", 9))
        self.mb_templates.config(menu=self.menu_templates)
        # -------------------------------------
        
        for txt, icon, cmd in [("Export", "📥", self.export_to_excel)]:
            btn = tk.Label(left_frame, text=f"{icon}\n{txt}", bg="#ffffff", fg="#6c757d", font=("Segoe UI", 8), padx=10, cursor="hand2")
            btn.pack(side=tk.LEFT)
            if cmd: btn.bind("<Button-1>", cmd)
        
        right_frame = tk.Frame(tb, bg="#ffffff")
        right_frame.pack(side=tk.RIGHT, padx=10)
        
        tk.Label(right_frame, text="Tarih:", bg="#ffffff", fg="#555").pack(side=tk.LEFT)
        cb_date = ttk.Combobox(right_frame, textvariable=self.var_date_fmt, values=["Normal", "Aylık", "3 Aylık", "Yıllık"], width=8, state="readonly")
        cb_date.pack(side=tk.LEFT, padx=(0, 10))
        cb_date.bind("<<ComboboxSelected>>", lambda e: self.calculate())

        tk.Checkbutton(right_frame, text="Grupla", variable=self.var_group, bg="#ffffff", cursor="hand2", command=self.calculate).pack(side=tk.LEFT, padx=5)
        tk.Checkbutton(right_frame, text="Alt Toplamlar", variable=self.var_subtotals, bg="#ffffff", cursor="hand2", command=self.calculate).pack(side=tk.LEFT, padx=5)
        tk.Checkbutton(right_frame, text="Genel Toplam", variable=self.var_totals, bg="#ffffff", cursor="hand2", command=self.calculate).pack(side=tk.LEFT, padx=5)
        
        # === YENİ EKLENEN: İKİLİ EKRAN VE YÖN (YAN YANA / ALT ÜST) AYARI ===
        # === YENİ EKLENEN: İKİLİ EKRAN VE YÖN (YAN YANA / ALT ÜST) AYARI ===
        self.var_dual_view = tk.BooleanVar(value=False)
        tk.Checkbutton(right_frame, text="İki Ekranda Çalış", variable=self.var_dual_view, bg="#ffffff", fg="#8e44ad", font=("Segoe UI", 9, "bold"), cursor="hand2", command=self.toggle_view_mode).pack(side=tk.LEFT, padx=(15, 2))
        
        self.var_split_orient = tk.StringVar(value="Alt / Üst")
        self.cb_split = ttk.Combobox(right_frame, textvariable=self.var_split_orient, values=["Alt / Üst", "Yan Yana"], width=10, state="disabled", font=("Segoe UI", 8))
        self.cb_split.pack(side=tk.LEFT, padx=(0, 10))
        
        # --- DÜZELTİLEN KISIM: Yön değiştiğinde verilerin kaybolmaması için yeniden hesaplatıyoruz ---
        self.cb_split.bind("<<ComboboxSelected>>", lambda e: self.on_orientation_changed())
        
        # Açılışta kayıtlı şablonları menüye yükle
        self.refresh_template_menu()

    def on_orientation_changed(self):
        """Ekran yönü değiştiğinde panelleri yeniden çizer ve verileri kaybetmemek için tabloları tekrar doldurur"""
        self.build_right_panel()
        self.calculate()

    def toggle_view_mode(self):
        """Kullanıcı İkili Ekran modunu açıp kapattığında sağ paneli yeniden çizer"""
        if not self.var_dual_view.get():
            all_items = self.pivot_config["rows"] + self.pivot_config["cols"] + self.pivot_config["vals"] + list(self.pivot_config["active_filters"].keys())
            has_y = any(x.startswith("(Y)") for x in all_items)
            has_f = any(x.startswith("(F)") for x in all_items)
            
            if has_y and has_f:
                messagebox.showwarning("Geçersiz İşlem", "Alanda hem Fatura hem de Yevmiye verileri mevcut.\nTekli ekrana geçmek için lütfen tablolardan birini temizleyin.")
                self.var_dual_view.set(True)
                return
            
            # Tekli ekranda yön seçimini kapat
            self.cb_split.config(state="disabled")
        else:
            # İkili ekranda yön seçimini aç
            self.cb_split.config(state="readonly")
            
        self.build_right_panel()
        self.calculate()
    
    def export_to_excel(self, event=None):
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Dosyası", "*.xlsx")])
        if not path: return
        try:
            writer = pd.ExcelWriter(path, engine='xlsxwriter')
            
            # --- YARDIMCI FONKSİYON: EKRANDAKİ GÖRÜNÜMÜ EXCEL'E AKTARIR ---
            def save_tree_to_sheet(tree_widget, sheet_name):
                if not tree_widget or not tree_widget.get_children(): return
                
                # Arka plandaki ham sütunlar ve veriler
                original_cols = list(tree_widget["columns"])
                data = [tree_widget.item(c)["values"] for c in tree_widget.get_children()]
                df = pd.DataFrame(data, columns=original_cols)
                
                # Ekranda görünen sütunlar ve SIRALAMASI
                display_cols = list(tree_widget.cget("displaycolumns"))
                if display_cols == ['#all'] or not display_cols:
                    display_cols = original_cols
                    
                # Sadece ekranda görünenleri, ekrandaki sırasıyla seç (Muazzam Pandas özelliği!)
                df = df[display_cols] 
                df.to_excel(writer, sheet_name=sheet_name, index=False)
            # -------------------------------------------------------------

            if self.var_dual_view.get():
                save_tree_to_sheet(self.tree_f, "Faturalar")
                save_tree_to_sheet(self.tree_y, "Yevmiye Defteri")
            else:
                save_tree_to_sheet(self.tree_main, "Pivot Tablo")
                
            writer.close()
            os.startfile(path) 
        except Exception as e: 
            messagebox.showerror("Hata", str(e))

    def setup_main_layout(self):
        self.main_container = tk.Frame(self, bg="#f3f2f1")
        self.main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=(0, 5))

        self.h_paned = tk.PanedWindow(self.main_container, orient=tk.HORIZONTAL, sashwidth=8, sashrelief="raised", bg="#c8c8c8", cursor="sb_h_double_arrow")
        self.h_paned.pack(fill=tk.BOTH, expand=True)

        self.left_panel = tk.Frame(self.h_paned, bg="#ffffff", bd=1, relief="solid")
        self.h_paned.add(self.left_panel, minsize=250, width=320) 
        
        tk.Label(self.left_panel, text="PivotTable Alanları", bg="#ffffff", fg="#333", font=("Segoe UI", 12, "bold"), anchor="w").pack(fill=tk.X, padx=10, pady=5)
        
        style = ttk.Style()
        style.configure("TNotebook", background="#ffffff")
        self.notebook = ttk.Notebook(self.left_panel)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        # === YENİ EKLENEN: SEKME DEĞİŞİMİNİ DİNLEME ===
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)
        # === 1. SEKME: YEVMİYE DEFTERİ (Sürükle-Bırak Alanları Kendi İçinde) ===
        self.tab_y = tk.Frame(self.notebook, bg="white")
        self.notebook.add(self.tab_y, text="📖 Yevmiye Defteri")
        
        self.v_paned_y = tk.PanedWindow(self.tab_y, orient=tk.VERTICAL, sashwidth=8, sashrelief="raised", bg="#c8c8c8", cursor="sb_v_double_arrow")
        self.v_paned_y.pack(fill=tk.BOTH, expand=True)
        
        self.top_list_y = tk.Frame(self.v_paned_y, bg="#ffffff")
        self.v_paned_y.add(self.top_list_y, minsize=150, height=250)
        self.fields_inner_y = create_scrollable_frame(self.top_list_y, bg_color="white")
        
        self.bottom_grid_y = tk.Frame(self.v_paned_y, bg="#ffffff")
        self.v_paned_y.add(self.bottom_grid_y, minsize=200)
        grid_wrapper_y = tk.Frame(self.bottom_grid_y, bg="#ffffff")
        grid_wrapper_y.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.zone_filters_y = self.create_drop_zone(grid_wrapper_y, "Filtreler (Y)", 0, 0, "filters")
        self.zone_cols_y = self.create_drop_zone(grid_wrapper_y, "Sütunlar (Y)", 0, 1, "cols")
        self.zone_rows_y = self.create_drop_zone(grid_wrapper_y, "Satırlar (Y)", 1, 0, "rows")
        self.zone_vals_y = self.create_drop_zone(grid_wrapper_y, "Değerler (Y)", 1, 1, "vals")

        # === 2. SEKME: FATURALAR (Sürükle-Bırak Alanları Kendi İçinde) ===
        self.tab_f = tk.Frame(self.notebook, bg="white")
        self.notebook.add(self.tab_f, text="🧾 Faturalar")

        self.v_paned_f = tk.PanedWindow(self.tab_f, orient=tk.VERTICAL, sashwidth=8, sashrelief="raised", bg="#c8c8c8", cursor="sb_v_double_arrow")
        self.v_paned_f.pack(fill=tk.BOTH, expand=True)

        self.top_list_f = tk.Frame(self.v_paned_f, bg="#ffffff")
        self.v_paned_f.add(self.top_list_f, minsize=150, height=250)
        self.fields_inner_f = create_scrollable_frame(self.top_list_f, bg_color="white")

        self.bottom_grid_f = tk.Frame(self.v_paned_f, bg="#ffffff")
        self.v_paned_f.add(self.bottom_grid_f, minsize=200)
        grid_wrapper_f = tk.Frame(self.bottom_grid_f, bg="#ffffff")
        grid_wrapper_f.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.zone_filters_f = self.create_drop_zone(grid_wrapper_f, "Filtreler (F)", 0, 0, "filters")
        self.zone_cols_f = self.create_drop_zone(grid_wrapper_f, "Sütunlar (F)", 0, 1, "cols")
        self.zone_rows_f = self.create_drop_zone(grid_wrapper_f, "Satırlar (F)", 1, 0, "rows")
        self.zone_vals_f = self.create_drop_zone(grid_wrapper_f, "Değerler (F)", 1, 1, "vals")

        # === SAĞ PANEL: İKİYE BÖLÜNMÜŞ TABLOLAR ===
        # === SAĞ PANEL (DİNAMİK YAPI İÇİN FONKSİYONA BAĞLANDI) ===
        self.right_panel = tk.Frame(self.h_paned, bg="#ffffff", bd=1, relief="solid")
        self.h_paned.add(self.right_panel, minsize=400)
        
        self.tree_main = None
        self.tree_f = None
        self.tree_y = None
        
        self.build_right_panel() # Ekranları Çizen Yeni Fonksiyon
        self.refresh_field_ui()

    # =========================================================================
    # OTOMATİK FATURA KURULUM SİHİRBAZI
    # =========================================================================
    def on_tab_changed(self, event):
        
        """Kullanıcı sekmeler arası geçiş yaptığında tetiklenir."""
        if getattr(self, '_is_programmatic_change', False): return
        current_tab = self.notebook.tab(self.notebook.select(), "text")
        
        # Eğer geçilen sekme Faturalar ise ve tablo tamamen boşsa sihirbazı çalıştır
        if "Faturalar" in current_tab:
            all_items = self.pivot_config["rows"] + self.pivot_config["cols"] + self.pivot_config["vals"] + list(self.pivot_config["active_filters"].keys())
            has_f = any(x.startswith("(F)") for x in all_items)
            
            if not has_f:
                self.prompt_fatura_wizard()

    def prompt_fatura_wizard(self):
        """Kullanıcıya Alış mı yoksa Satış mı analizi yapacağını soran Pop-up"""
        top = tk.Toplevel(self.winfo_toplevel())
        top.title("✨ Otomatik Tablo Sihirbazı")
        top.geometry("450x200")
        top.configure(bg="#f3f2f1")
        top.transient(self.winfo_toplevel())
        top.grab_set()

        tk.Label(top, text="Faturalar sekmesine geçtiniz.\nHızlı analiz için otomatik bir şablon oluşturmak ister misiniz?", bg="#f3f2f1", font=("Segoe UI", 10, "bold")).pack(pady=15)

        btn_frame = tk.Frame(top, bg="#f3f2f1")
        btn_frame.pack(fill=tk.X, padx=20, pady=10)

        def select_mode(mode):
            top.destroy()
            self.apply_fatura_wizard(mode)

        btn_satis = tk.Button(btn_frame, text="Satış Faturaları", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), cursor="hand2", command=lambda: select_mode("satis"))
        btn_satis.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5, pady=5)

        btn_alis = tk.Button(btn_frame, text="Alış Faturaları", bg="#2980b9", fg="white", font=("Segoe UI", 10, "bold"), cursor="hand2", command=lambda: select_mode("alis"))
        btn_alis.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=5, pady=5)
        
        tk.Button(top, text="İptal (Boş Tablo ile Başla)", bg="#bdc3c7", fg="#333", font=("Segoe UI", 9), bd=0, cursor="hand2", command=top.destroy).pack(pady=5)

    def apply_fatura_wizard(self, mode):
        """Seçilen senaryoya göre Pivot alanlarını otomatik doldurur"""
        # Mükellef VKN'sini al ve temizle (örneğin 1234.0 ise 1234 yap)
        vkn = str(self.engine.vkn).split('.')[0].strip() if self.engine.vkn else ""
        
        # Alıcı VKN listesindeki tüm değerleri veritabanından çek
        all_alici = self.engine.get_unique_values("(F) Alıcı VKN/TCKN")
        
        # 1. MANTIK: FİLTRELEME (Alış / Satış Algoritması)
        if mode == "satis":
            # Satış: Alıcının mükellef OLMADIĞI faturalar (VKN hariç hepsi seçilir)
            selected_alici = [v for v in all_alici if vkn not in str(v)]
            msg = f"✅ Satış Faturaları şablonu uygulandı!\n\nFiltre Kuralı: '(F) Alıcı VKN/TCKN' listesinden Mükellefe ait olan ({vkn}) HARİÇ TUTULDU."
        else:
            # Alış: Alıcının mükellef OLDUĞU faturalar (Sadece VKN seçilir)
            selected_alici = [v for v in all_alici if vkn in str(v)]
            msg = f"✅ Alış Faturaları şablonu uygulandı!\n\nFiltre Kuralı: '(F) Alıcı VKN/TCKN' listesinde SADECE Mükellefe ait olan ({vkn}) SEÇİLDİ."

        if "(F) Alıcı VKN/TCKN" not in self.pivot_config["filters"]:
            self.pivot_config["filters"].append("(F) Alıcı VKN/TCKN")
        self.pivot_config["active_filters"]["(F) Alıcı VKN/TCKN"] = selected_alici

        # 2. MANTIK: SATIRLAR VE TARİH FORMATI (Tarih eklendi ve Aylık süzüldü)
        if "(F) Tarih" not in self.pivot_config["rows"]:
            self.pivot_config["rows"].append("(F) Tarih")
        self.var_date_fmt.set("Aylık")

        # 3. MANTIK: DEĞERLER (İstediğin 3 kalem otomatik eklendi)
        vals_to_add = ["(F) Vergiler Dahil Toplam", "(F) KDV ÖTV Hariç Tutar", "(F) KDV Tutarı (Kalem)"]
        for v in vals_to_add:
            if v not in self.pivot_config["vals"]:
                self.pivot_config["vals"].append(v)

        # Tabloyu yenile ve hesapla
        self.refresh_field_ui()
        self.calculate()
        
        # Kullanıcıya işlemi bildir
        messagebox.showinfo("Kurulum Tamamlandı", msg)


    def build_right_panel(self):
        """İkili ekran seçimine göre sağdaki Pivot alanını Tek veya İkiye Bölünmüş olarak inşa eder"""
        for w in self.right_panel.winfo_children(): w.destroy()
        
        if self.var_dual_view.get():
            # İKİLİ EKRAN AKTİF (Kullanıcı seçimine göre Yan Yana veya Alt/Üst)
            is_horizontal = (self.var_split_orient.get() == "Yan Yana")
            p_orient = tk.HORIZONTAL if is_horizontal else tk.VERTICAL
            p_cursor = "sb_h_double_arrow" if is_horizontal else "sb_v_double_arrow"
            
            self.right_v_paned = tk.PanedWindow(self.right_panel, orient=p_orient, sashwidth=8, sashrelief="raised", bg="#c8c8c8", cursor=p_cursor)
            self.right_v_paned.pack(fill=tk.BOTH, expand=True)

            self.frame_f = tk.Frame(self.right_v_paned, bg="#ffffff")
            tk.Label(self.frame_f, text="🧾 FATURALAR PİVOTU", bg="#e67e22", fg="white", font=("Segoe UI", 9, "bold")).pack(fill=tk.X)
            self.tree_f = self.setup_table(self.frame_f)
            self.right_v_paned.add(self.frame_f, minsize=150)

            self.frame_y = tk.Frame(self.right_v_paned, bg="#ffffff")
            tk.Label(self.frame_y, text="📖 YEVMİYE DEFTERİ PİVOTU", bg="#2F5597", fg="white", font=("Segoe UI", 9, "bold")).pack(fill=tk.X)
            self.tree_y = self.setup_table(self.frame_y)
            self.right_v_paned.add(self.frame_y, minsize=150)
            self.tree_main = None
        else:
            # TEKLİ EKRAN AKTİF
            self.frame_main = tk.Frame(self.right_panel, bg="#ffffff")
            self.frame_main.pack(fill=tk.BOTH, expand=True)
            tk.Label(self.frame_main, text="📊 PİVOT TABLOSU", bg="#2F5597", fg="white", font=("Segoe UI", 9, "bold")).pack(fill=tk.X)
            self.tree_main = self.setup_table(self.frame_main)
            self.tree_f = None
            self.tree_y = None

    def create_drop_zone(self, parent, title, r, c, list_name):
        f = tk.Frame(parent, bg="#ffffff", bd=1, relief="solid")
        f.grid(row=r, column=c, padx=2, pady=2, sticky="nsew")
        parent.grid_columnconfigure(c, weight=1)
        parent.grid_rowconfigure(r, weight=1)
        
        bg_color = "#eaf2f8" if "(Y)" in title else "#fdf2e9"
        tk.Label(f, text=title, bg=bg_color, fg="#333", font=("Segoe UI", 8, "bold"), bd=1, relief="solid").pack(fill=tk.X)
        
        container = tk.Frame(f, bg="#ffffff")
        container.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        container.list_name = list_name
        return container

    def open_filter_modal(self, col_name):
        current_filter = self.pivot_config["active_filters"].get(col_name, [])
        FilterModal(self.winfo_toplevel(), self.engine, col_name, current_filter, self.on_filter_applied)

    def on_filter_applied(self, field, selected_items):
        self.pivot_config["active_filters"][field] = selected_items
        
        # Eğer bu alanın Slicer'ı açıksa onun da görüntüsünü eşitle
        if field in self.active_slicers:
            self.active_slicers[field].selected_items = selected_items
            self.active_slicers[field].refresh_visuals()
            
        self.calculate()


    def refresh_field_ui(self):
        for inner_frame, key in [(self.fields_inner_y, "Yevmiye"), (self.fields_inner_f, "Fatura")]:
            for w in inner_frame.winfo_children(): w.destroy()
            for f in self.all_fields.get(key, []):
                chip = tk.Frame(inner_frame, bg="#ffffff")
                chip.pack(fill=tk.X, padx=2, pady=1)
                
                is_used = any(f in self.pivot_config[z] for z in ["rows", "cols", "vals", "filters"])
                icon = "☑" if is_used else "☐"
                
                display_text = f.replace("(Y) ", "").replace("(F) ", "")
                prefix_color = "#0056b3" if "(Y)" in f else "#e67e22" 
                
                tk.Label(chip, text=icon, bg="#ffffff", fg="#000", font=("Segoe UI", 9)).pack(side=tk.LEFT)
                lbl = tk.Label(chip, text=display_text, bg="#ffffff", fg=prefix_color, font=("Segoe UI", 9, "bold"), cursor="hand2", anchor="w")
                lbl.pack(fill=tk.X)
                
                lbl.bind("<ButtonPress-1>", lambda e, t=f, s="all_fields": self.start_drag(e, t, s))
                lbl.bind("<B1-Motion>", self.do_drag)
                lbl.bind("<ButtonRelease-1>", self.stop_drag)
                lbl.bind("<Button-3>", lambda e, t=f: self.show_slicer_menu(e, t))
                if self.tk.call('tk', 'windowingsystem') == 'aqua': 
                    lbl.bind("<Button-2>", lambda e, t=f: self.show_slicer_menu(e, t))

        # Yevmiye ve Fatura Sürükle-Bırak alanlarını ait oldukları sekmelere ayrı ayrı doldurur
        zones_y = [(self.zone_filters_y, "filters"), (self.zone_cols_y, "cols"), (self.zone_rows_y, "rows"), (self.zone_vals_y, "vals")]
        zones_f = [(self.zone_filters_f, "filters"), (self.zone_cols_f, "cols"), (self.zone_rows_f, "rows"), (self.zone_vals_f, "vals")]

        for zone_list, prefix in [(zones_y, "(Y)"), (zones_f, "(F)")]:
            for zone, list_name in zone_list:
                for w in zone.winfo_children(): w.destroy()
                
                items = [item for item in self.pivot_config[list_name] if item.startswith(prefix)]
                for item in items:
                    display_text = f"Toplam {item}" if list_name == "vals" else item
                    
                    chip = tk.Frame(zone, bg="#ffffff", bd=1, relief="solid")
                    chip.pack(fill=tk.X, pady=1)
                    
                    if list_name == "filters":
                        btn_filter = tk.Label(chip, text="⚙", bg="#ffffff", fg="#0056b3", cursor="hand2", font=("Segoe UI", 10, "bold"))
                        btn_filter.pack(side=tk.LEFT, padx=4)
                        btn_filter.bind("<Button-1>", lambda e, t=item: self.open_filter_modal(t))
                    
                    lbl = tk.Label(chip, text=display_text, bg="#ffffff", font=("Segoe UI", 8), anchor="w", cursor="hand2")
                    lbl.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
                    lbl.bind("<ButtonPress-1>", lambda e, t=item, s=list_name: self.start_drag(e, t, s))
                    lbl.bind("<B1-Motion>", self.do_drag)
                    lbl.bind("<ButtonRelease-1>", self.stop_drag)
                    
                    btn_x = tk.Label(chip, text="✕", bg="#ffffff", fg="red", cursor="hand2", font=("Arial", 8))
                    btn_x.pack(side=tk.RIGHT, padx=2)
                    btn_x.bind("<Button-1>", lambda e, t=item, s=list_name: self.remove_field(t, s))

    def remove_field(self, text, source_list):
        if text in self.pivot_config[source_list]:
            self.pivot_config[source_list].remove(text)
            self.refresh_field_ui()
            self.calculate()

    def start_drag(self, event, text, source_list):
        self.drag_data["item"] = text; self.drag_data["source_list"] = source_list
        self.ghost = tk.Toplevel(self)
        self.ghost.overrideredirect(True)
        self.ghost.attributes("-alpha", 0.8)
        tk.Label(self.ghost, text=text, bg="#2F5597", fg="white", font=("Segoe UI", 9, "bold"), padx=10, pady=5).pack()
        self.ghost.geometry(f"+{event.x_root+10}+{event.y_root+10}")

    def do_drag(self, event):
        if hasattr(self, 'ghost'): self.ghost.geometry(f"+{event.x_root+10}+{event.y_root+10}")

    def stop_drag(self, event):
        if hasattr(self, 'ghost'): self.ghost.destroy(); del self.ghost
            
        x, y = self.winfo_pointerx(), self.winfo_pointery()
        item, src, target_list, target_type = self.drag_data["item"], self.drag_data["source_list"], None, None
        
        all_zones = [
            (self.zone_filters_y, "filters", "Y"), (self.zone_cols_y, "cols", "Y"), (self.zone_rows_y, "rows", "Y"), (self.zone_vals_y, "vals", "Y"),
            (self.zone_filters_f, "filters", "F"), (self.zone_cols_f, "cols", "F"), (self.zone_rows_f, "rows", "F"), (self.zone_vals_f, "vals", "F")
        ]

        for z, l_name, z_type in all_zones:
            if z.winfo_viewable(): 
                rx, ry, rw, rh = z.winfo_rootx(), z.winfo_rooty(), z.winfo_width(), z.winfo_height()
                if rx < x < rx+rw and ry < y < ry+rh:
                    target_list = l_name; target_type = z_type; break
                
        if target_list:
            is_y_item = item.startswith("(Y)")
            is_f_item = item.startswith("(F)")
            
            if is_y_item and target_type == "F":
                messagebox.showwarning("Geçersiz İşlem", "Yevmiye alanlarını Fatura kutularına sürükleyemezsiniz.")
                return
            if is_f_item and target_type == "Y":
                messagebox.showwarning("Geçersiz İşlem", "Fatura alanlarını Yevmiye kutularına sürükleyemezsiniz.")
                return

            # Kural: Eğer İkili Ekran kapalıysa, birbiriyle karışmalarını engelle
            if not self.var_dual_view.get():
                current_items = self.pivot_config["rows"] + self.pivot_config["cols"] + self.pivot_config["vals"] + list(self.pivot_config["active_filters"].keys())
                has_y = any(x.startswith("(Y)") for x in current_items if x != item)
                has_f = any(x.startswith("(F)") for x in current_items if x != item)
                
                if (is_y_item and has_f) or (is_f_item and has_y):
                    messagebox.showwarning("Geçersiz İşlem", "Tekli ekranda Fatura ve Yevmiye verileri birleştirilemez.\nLütfen yukarıdan 'İki Ekranda Çalış' modunu aktif edin.")
                    return

            if src != "all_fields" and item in self.pivot_config[src]: self.pivot_config[src].remove(item)
            if item not in self.pivot_config[target_list]: self.pivot_config[target_list].append(item)
            self.refresh_field_ui()
            self.calculate()

    # =========================================================================
    # =========================================================================
    # TABLO KURULUMU, FONT, İMLEÇ VE SAĞ TIK MENÜSÜ
    # =========================================================================
    def setup_table(self, container):
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
            
        # 1. MODERN VE FERAH TASARIM (Fatura Analizdeki gibi)
        style.configure("Modern.Treeview", rowheight=30, font=("Segoe UI", 9), background="#ffffff", fieldbackground="#ffffff", foreground="#212529", borderwidth=0)
        style.configure("Modern.Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#f8f9fa", foreground="#495057", relief="flat", borderwidth=1)
        style.map("Modern.Treeview", background=[("selected", "#e9ecef")], foreground=[("selected", "#212529")])

        # Tabloyu modern stille oluştur
        tree = ttk.Treeview(container, style="Modern.Treeview", show="headings")
        
        # 2. ZEBRA VE TOPLAM SATIRI RENKLERİ (Hata buradaydı, artık renkleri biliyor!)
        tree.tag_configure('even', background='#f8f9fa')  # Gri Satır
        tree.tag_configure('odd', background='#ffffff')   # Beyaz Satır
        
        # Alt toplamlar ve Genel Toplam renkleri
        tree.tag_configure("normal_row", font=("Segoe UI", 9))
        tree.tag_configure("subtotal_row", font=("Segoe UI", 9, "bold"), background="#eaf2f8", foreground="#2980b9") 
        tree.tag_configure("gt_row", font=("Segoe UI", 10, "bold"), background="#D9E1F2", foreground="#002060")

        # Scrollbar Ayarları
        vsb = ttk.Scrollbar(container, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(container, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        tree.pack(fill=tk.BOTH, expand=True)
        
        # Olay (Event) Bağlamaları
        tree.bind("<ButtonPress-1>", self.on_tree_header_press)
        tree.bind("<B1-Motion>", self.on_tree_header_drag)
        tree.bind("<ButtonRelease-1>", self.on_tree_header_release)
        tree.bind("<Double-1>", self.on_header_double_click) 

        tree.bind("<Button-3>", self.on_right_click)
        if self.tk.call('tk', 'windowingsystem') == 'aqua': 
            tree.bind("<Button-2>", self.on_right_click)
            
        return tree
    # TREEVIEW SÜTUN SÜRÜKLE - BIRAK FONKSİYONLARI
    # =========================================================================
    def on_tree_header_press(self, event):
        tree = event.widget
        region = tree.identify("region", event.x, event.y)
        if region == "heading":
            tree._drag_start_col = tree.identify_column(event.x)
            tree._drag_start_x = event.x
            tree._is_dragging_col = False
        else:
            tree._drag_start_col = None

    def on_tree_header_drag(self, event):
        tree = event.widget
        if getattr(tree, '_drag_start_col', None):
            if abs(event.x - getattr(tree, '_drag_start_x', event.x)) > 10:
                tree._is_dragging_col = True
                tree.config(cursor="sb_h_double_arrow")

    def on_tree_header_release(self, event):
        tree = event.widget
        tree.config(cursor="") 
        if not getattr(tree, '_drag_start_col', None): return

        region = tree.identify("region", event.x, event.y)
        if getattr(tree, '_is_dragging_col', False):
            if region == "heading":
                target_col = tree.identify_column(event.x)
                if target_col and target_col != tree._drag_start_col:
                    self.move_tree_column(tree, tree._drag_start_col, target_col)
            tree._is_dragging_col = False
            tree._drag_start_col = None
            return "break" 

        tree._is_dragging_col = False
        tree._drag_start_col = None
        self.on_header_click(event)

    def move_tree_column(self, tree, start_col, target_col):
        start_id = tree.column(start_col, "id")
        target_id = tree.column(target_col, "id")
        cols = list(tree.cget("displaycolumns"))
        
        if not cols or cols == ['#all'] or cols[0] == '#all':
            cols = list(tree.cget("columns"))
            
        if start_id in cols and target_id in cols:
            cols.remove(start_id)
            target_idx = cols.index(target_id)
            cols.insert(target_idx, start_id)
            tree.configure(displaycolumns=cols)

    def on_header_click(self, event):
        tree = event.widget
        region = tree.identify("region", event.x, event.y)
        if region == "heading":
            col_id = tree.identify_column(event.x)
            col_name_raw = tree.heading(col_id, "text")
            if not col_name_raw.strip(): return
            
            col_name = col_name_raw.replace(" ▲", "").replace(" ▼", "").replace(" ⚙", "")
            actual_col = col_name
            if col_name.startswith("Toplam "):
                base_col = col_name.replace("Toplam ", "")
                if base_col in self.pivot_config["vals"]: actual_col = base_col
            
            if actual_col == "Genel Toplam": return
            
            if self.pivot_config.get("sort_col") == actual_col:
                self.pivot_config["sort_asc"] = not self.pivot_config.get("sort_asc", True)
            else:
                self.pivot_config["sort_col"] = actual_col
                self.pivot_config["sort_asc"] = True
            self.calculate()

    def on_header_double_click(self, event):
        tree = event.widget
        region = tree.identify("region", event.x, event.y)
        if region == "heading":
            col_id = tree.identify_column(event.x)
            col_name_raw = tree.heading(col_id, "text")
            if not col_name_raw.strip(): return
            
            col_name = col_name_raw.replace(" ▲", "").replace(" ▼", "").replace(" ⚙", "")
            actual_col = col_name
            
            if col_name.startswith("Toplam "):
                base_col = col_name.replace("Toplam ", "")
                if base_col in self.pivot_config["vals"]: actual_col = base_col
            
            if actual_col == "Genel Toplam" or actual_col == "No": return
            self.open_filter_modal(actual_col)



    def hide_selected_column(self):
        """Sağ tıklanan sütunu gizler ve konfigürasyona kaydeder"""
        if not hasattr(self, 'clicked_col_name') or not self.clicked_col_name: return
        
        if "hidden_cols" not in self.pivot_config:
            self.pivot_config["hidden_cols"] = []
            
        if self.clicked_col_name not in self.pivot_config["hidden_cols"]:
            self.pivot_config["hidden_cols"].append(self.clicked_col_name)
            
        # Görünümü anında (hesaplama beklemeden) güncelle
        if hasattr(self, 'clicked_tree') and self.clicked_tree:
            all_cols = list(self.clicked_tree.cget("columns"))
            display_cols = [c for c in all_cols if c not in self.pivot_config["hidden_cols"]]
            if not display_cols: display_cols = ["#all"] # Hepsi gizlenirse tablo çökmesin
            self.clicked_tree.configure(displaycolumns=display_cols)

    def show_all_columns(self):
        """Gizlenmiş tüm sütunları tek tuşla geri getirir"""
        self.pivot_config["hidden_cols"] = []
        
        # Tüm tabloları tekrar tam görünür yap
        for tree in [self.tree_main, self.tree_f, self.tree_y]:
            if tree:
                tree.configure(displaycolumns="#all")


    def show_specific_column(self, col_name):
        """Sadece seçilen gizli sütunu tabloya geri getirir"""
        if col_name in self.pivot_config.get("hidden_cols", []):
            self.pivot_config["hidden_cols"].remove(col_name)
            
        if hasattr(self, 'clicked_tree') and self.clicked_tree:
            all_cols = list(self.clicked_tree.cget("columns"))
            hidden = self.pivot_config.get("hidden_cols", [])
            saved_order = self.pivot_config.get("column_order", [])
            
            display_cols = [c for c in all_cols if c not in hidden]
            
            if saved_order:
                ordered_display = [c for c in saved_order if c in display_cols]
                for c in display_cols:
                    if c not in ordered_display:
                        ordered_display.append(c)
                display_cols = ordered_display
                
            if not display_cols: display_cols = ["#all"]
            self.clicked_tree.configure(displaycolumns=display_cols)

    def on_right_click(self, event):
        tree = event.widget
        self.clicked_tree = tree 
        
        region = tree.identify("region", event.x, event.y)
        col_id = tree.identify_column(event.x)
        
        try:
            self.clicked_col_name = tree.column(col_id, "id")
        except:
            self.clicked_col_name = None

        # --- BAŞLIĞA (HEADER) SAĞ TIKLAMA ---
        if region == "heading":
            if not hasattr(self, 'header_context_menu'):
                self.header_context_menu = tk.Menu(self, tearoff=0, font=("Segoe UI", 10))
                
            self.header_context_menu.delete(0, tk.END)

            if self.clicked_col_name:
                self.header_context_menu.add_command(label="⬅️ Sütunu Sola Taşı", command=self.move_column_left)
                self.header_context_menu.add_command(label="➡️ Sütunu Sağa Taşı", command=self.move_column_right)
                self.header_context_menu.add_separator()
                self.header_context_menu.add_command(label="👁 Bu Sütunu Gizle", command=self.hide_selected_column)
            
            if self.pivot_config.get("hidden_cols"):
                show_sub_menu = tk.Menu(self.header_context_menu, tearoff=0, font=("Segoe UI", 10))
                for h_col in self.pivot_config["hidden_cols"]:
                    show_sub_menu.add_command(label=f"☑ {h_col}", command=lambda c=h_col: self.show_specific_column(c))
                show_sub_menu.add_separator()
                show_sub_menu.add_command(label="👁 Tümünü Göster", command=self.show_all_columns)
                self.header_context_menu.add_cascade(label="👁 Gizlenen Sütunları Göster", menu=show_sub_menu)
                
            self.header_context_menu.add_separator()
            self.header_context_menu.add_command(label="➕ Formüllü Sütun Ekle", command=self.open_formula_modal)

            if self.clicked_col_name in self.pivot_config.get("calc_cols", {}):
                self.clicked_header_name = self.clicked_col_name
                self.header_context_menu.add_separator()
                self.header_context_menu.add_command(label="✏️ Formülü Düzenle", command=self.edit_formula_modal)
                self.header_context_menu.add_command(label="🗑️ Formüllü Sütunu Sil", command=self.delete_formula_column)

            try:
                self.header_context_menu.post(event.x_root, event.y_root)
            finally:
                self.header_context_menu.grab_release()
            return

        # --- HÜCREYE (CELL) SAĞ TIKLAMA ---
        row_id = tree.identify_row(event.y)
        if not row_id: return 

        if row_id not in tree.selection():
            tree.selection_set(row_id)

        try:
            col_index = int(col_id.replace('#', '')) - 1
            vals = tree.item(row_id)['values']
            if 0 <= col_index < len(vals): 
                self.clicked_cell_value = str(vals[col_index])
            else: 
                self.clicked_cell_value = ""
        except:
            self.clicked_cell_value = ""

        if not hasattr(self, 'context_menu'):
            self.context_menu = tk.Menu(self, tearoff=0, bg="white", font=("Segoe UI", 9))
            
        self.context_menu.delete(0, tk.END)
        self.context_menu.add_command(label="📋 Hücreyi Kopyala", command=self.copy_cell_value)
        self.context_menu.add_separator()
        
        if self.clicked_col_name:
            self.context_menu.add_command(label="👁 Bu Sütunu Gizle", command=self.hide_selected_column)
            
        if self.pivot_config.get("hidden_cols"):
            show_sub_menu_cell = tk.Menu(self.context_menu, tearoff=0, bg="white", font=("Segoe UI", 9))
            for h_col in self.pivot_config["hidden_cols"]:
                show_sub_menu_cell.add_command(label=f"☑ {h_col}", command=lambda c=h_col: self.show_specific_column(c))
            show_sub_menu_cell.add_separator()
            show_sub_menu_cell.add_command(label="👁 Tümünü Göster", command=self.show_all_columns)
            self.context_menu.add_cascade(label="👁 Gizlenen Sütunları Göster", menu=show_sub_menu_cell)

        try:
            self.context_menu.post(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

    # =========================================================================
    # FORMÜL YÖNETİMİ VE HÜCRE İŞLEMLERİ (SİLİNEN KISIMLAR GERİ GELDİ)
    # =========================================================================
    def open_formula_modal(self):
        if not hasattr(self, 'clicked_tree') or not self.clicked_tree: return
        tree = self.clicked_tree
        cols = list(tree["columns"])
        
        prefix = "(F)"
        if tree == getattr(self, "tree_y", None): prefix = "(Y)"
        elif tree == getattr(self, "tree_main", None):
            if any(c.startswith("(Y)") for c in cols): prefix = "(Y)"
            
        FormulaModal(self.winfo_toplevel(), self, cols, prefix)

    def edit_formula_modal(self):
        if not hasattr(self, 'clicked_header_name') or not self.clicked_header_name: return
        
        col_name = self.clicked_header_name
        formula = self.pivot_config["calc_cols"].get(col_name, "")
        tree = self.clicked_tree
        cols = list(tree["columns"])
        
        prefix = "(F)" if "(F)" in col_name else "(Y)"
        clean_name = col_name.replace(prefix, "").strip()

        FormulaModal(self.winfo_toplevel(), self, cols, prefix, existing_name=clean_name, existing_formula=formula, old_full_name=col_name)

    def delete_formula_column(self):
        if not hasattr(self, 'clicked_header_name') or not self.clicked_header_name: return
        
        col_name = self.clicked_header_name
        if messagebox.askyesno("Onay", f"'{col_name}' sütununu silmek istediğinize emin misiniz?"):
            if col_name in self.pivot_config.get("calc_cols", {}):
                del self.pivot_config["calc_cols"][col_name]
                self.calculate()

    def copy_cell_value(self):
        if hasattr(self, 'clicked_cell_value') and self.clicked_cell_value:
            self.clipboard_clear()
            self.clipboard_append(self.clicked_cell_value)
            self.update()
    



    def show_yevmiye_fis(self):
        """Seçilen hücredeki veriyi doğrudan DB'de arar ve bulursa yevmiye detayını açar."""
        if not hasattr(self, 'clicked_cell_value') or not self.clicked_cell_value:
            messagebox.showwarning("Uyarı", "Lütfen açmak istediğiniz yevmiye veya belge numarasının üzerine sağ tıklayın.")
            return
            
        val = str(self.clicked_cell_value).replace("[-] ", "").replace("[+] ", "").strip()
        
        # Tıklanan hücrede .0 uzantısı kaldıysa sil (SQL'in bulabilmesi için)
        if val.endswith('.0'): 
            val = val[:-2]
            
        if not val or val in ["-", "None", "nan", ""]:
            messagebox.showwarning("Uyarı", "Geçerli bir hücre seçilmedi.")
            return
            
        if not self.engine.yevmiye_db:
            messagebox.showerror("Hata", "Yevmiye veritabanı bulunamadı.")
            return
            
        try:
            conn = sqlite3.connect(self.engine.yevmiye_db)
            query = "SELECT * FROM yevmiye WHERE YevmiyeNo = ? OR BelgeNo = ?"
            df = pd.read_sql_query(query, conn, params=(val, val))
            
            if df.empty:
                conn.close()
                messagebox.showinfo("Bulunamadı", f"'{val}' değerine ait bir Yevmiye Fişi veya Belge veritabanında bulunamadı.")
                return
                
            yev_no_raw = df.iloc[0]['YevmiyeNo']
            try:
                # Veritabanında 123.0 kaldıysa onu başlığa saf 123 olarak geçirmek için
                yev_no = str(int(float(yev_no_raw)))
            except:
                yev_no = str(yev_no_raw)
                
            df_full = pd.read_sql_query("SELECT * FROM yevmiye WHERE YevmiyeNo = ?", conn, params=(yev_no_raw,))
            conn.close()
            
            self.open_fis_detail_popup(yev_no, df_full.to_dict('records'))
            
        except Exception as e:
            messagebox.showerror("Hata", f"Fiş sorgulanırken hata oluştu: {e}")

    def show_fatura_belge(self):
        """Seçilen hücredeki veriyi doğrudan fatura DB'sinde arar ve açar."""
        if FaturaGoruntulePopup is None:
            messagebox.showerror("Hata", "Fatura görüntüleme modülü bulunamadı. Lütfen ilgili modülü yükleyin.")
            return

        if not hasattr(self, 'clicked_cell_value') or not self.clicked_cell_value:
            messagebox.showwarning("Uyarı", "Lütfen açmak istediğiniz fatura veya belge numarasının üzerine sağ tıklayın.")
            return
            
        val = str(self.clicked_cell_value).replace("[-] ", "").replace("[+] ", "").strip()
        
        if not val or val in ["-", "None", "nan", ""]:
            messagebox.showwarning("Uyarı", "Geçerli bir hücre seçilmedi.")
            return

        if not self.engine.fatura_db:
            messagebox.showerror("Hata", "Fatura veritabanı bulunamadı.")
            return

        try:
            conn = sqlite3.connect(self.engine.fatura_db)
            c = conn.cursor()
            c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
            tbl = c.fetchone()
            
            if not tbl:
                conn.close()
                messagebox.showerror("Hata", "Fatura tablosu veritabanında bulunamadı.")
                return
                
            table_name = tbl[0]
            
            # --- YENİ EKLENEN: Sütun İsimlerini Akıllı Bulma Sistemi ---
            c.execute(f'PRAGMA table_info("{table_name}")')
            db_columns = [row[1] for row in c.fetchall()]
            
            fatura_col = "FATURA_NO" # Varsayılan
            ettn_col = "ETTN"        # Varsayılan
            
            for col in db_columns:
                clean_col = str(col).upper().replace(" ", "").replace("_", "")
                if clean_col in ["FATURANO", "FATURANUMARASI"]:
                    fatura_col = col
                elif clean_col == "ETTN":
                    ettn_col = col
            # ------------------------------------------------------------
            
            # Sütun adlarını çift tırnak ile sarıyoruz ki boşluklu isimlerde hata vermesin
            query = f'SELECT * FROM "{table_name}" WHERE "{fatura_col}" = ? OR "{ettn_col}" = ?'
            df_invoice = pd.read_sql_query(query, conn, params=(val, val))
            conn.close()

            if df_invoice is not None and not df_invoice.empty:
                target_master = self.winfo_toplevel() 
                FaturaGoruntulePopup(target_master, df_invoice)
            else:
                messagebox.showinfo("Bulunamadı", f"'{val}' numarasına ait bir Fatura veya ETTN arşivde bulunamadı.")
        except Exception as e:
            messagebox.showerror("Hata", f"Görüntüleme sırasında bir hata oluştu: {e}")



    def open_fis_detail_popup(self, fis_no, items):
        # 1- BİRDEN FAZLA PENCERE AÇILMASINI ENGELLEME
        if hasattr(self, '_fis_popup') and self._fis_popup.winfo_exists():
            self._fis_popup.destroy()

        popup = tk.Toplevel(self)
        self._fis_popup = popup # Referansı sınıfa kaydet
        
        # 2- SİMGE DURUMUNDA KAYBOLMAYI VE KİLİTLENMEYİ ÖNLEME
        popup.transient(self.winfo_toplevel())
        
        popup.title(f"Fiş İnceleme - No: {fis_no}")
        popup.geometry("1200x550")
        popup.configure(bg="white")
        
        HEADER_BG = "#0b2b40"
        TEXT_WHITE = "white"
        
        date_str = str(items[0].get('KayitTarihi', '-')) if items else "-"
        
        header_frame = tk.Frame(popup, bg=HEADER_BG, height=60)
        header_frame.pack(fill="x")
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text=f"FİŞ NO: {fis_no}", bg=HEADER_BG, fg=TEXT_WHITE, font=("Segoe UI", 16, "bold")).pack(side="left", padx=20)
        tk.Label(header_frame, text=f"TARİH: {date_str}", bg=HEADER_BG, fg=TEXT_WHITE, font=("Segoe UI", 14, "bold")).pack(side="right", padx=20)

        cols = ("HesapKodu", "HesapAdi", "MuavinKodu", "MuavinAdi", "BelgeNo", "FisAciklamasi", "DetayAciklama", "Borc", "Alacak")
        tree_frame = tk.Frame(popup, bg="white")
        tree_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        style = ttk.Style()
        style.configure("Fis.Treeview", rowheight=28, font=('Segoe UI', 9))
        style.configure("Fis.Treeview.Heading", font=('Segoe UI', 9, 'bold'), background="#f2f2f2")
        
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", style="Fis.Treeview", selectmode="extended")
        
        # 3- İKİ YÖNLÜ SCROLL İÇİN GRID SİSTEMİNE GEÇİŞ YAPILDI
        ysb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        
        tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        tree.heading("HesapKodu", text="Hesap Kodu");      tree.column("HesapKodu", width=90, anchor="w")
        tree.heading("HesapAdi", text="Hesap Adı");        tree.column("HesapAdi", width=180, anchor="w")
        tree.heading("MuavinKodu", text="Muavin Kodu");    tree.column("MuavinKodu", width=90, anchor="w")
        tree.heading("MuavinAdi", text="Muavin Adı");      tree.column("MuavinAdi", width=180, anchor="w")
        tree.heading("BelgeNo", text="Belge No");          tree.column("BelgeNo", width=90, anchor="w")
        tree.heading("FisAciklamasi", text="Fiş Açıklama");tree.column("FisAciklamasi", width=150, anchor="w")
        tree.heading("DetayAciklama", text="Detay");       tree.column("DetayAciklama", width=150, anchor="w")
        tree.heading("Borc", text="Borç");                 tree.column("Borc", width=100, anchor="e")
        tree.heading("Alacak", text="Alacak");             tree.column("Alacak", width=100, anchor="e")

        tree.tag_configure('odd', background='#f9f9f9')
        tree.tag_configure('even', background='white')

        total_borc = 0.0
        total_alacak = 0.0
        
        for i, it in enumerate(items):
            try: b = float(it.get('Borc', 0))
            except: b = 0.0
            try: a = float(it.get('Alacak', 0))
            except: a = 0.0
            
            total_borc += b
            total_alacak += a
            
            b_no = str(it.get('BelgeNo', ''))
            if b_no.endswith('.0'): 
                b_no = b_no[:-2]
            
            vals = (
                it.get('HesapKodu', ''), 
                it.get('HesapAdi', ''), 
                it.get('MuavinKodu', ''), 
                it.get('MuavinAdi', ''), 
                b_no, 
                it.get('FisAciklamasi', ''), 
                it.get('DetayAciklama', ''), 
                f"{b:,.2f}", 
                f"{a:,.2f}"
            )
            tree.insert("", "end", values=vals, tags=('odd' if i % 2 == 0 else 'even',))
            
        footer_frame = tk.Frame(popup, bg="white", height=50)
        footer_frame.pack(fill="x", side="bottom")
        tk.Frame(footer_frame, bg="#bdc3c7", height=1).pack(fill="x", side="top")
        
        is_balanced = abs(total_borc - total_alacak) < 0.01
        status_text = "✅ FİŞ DENGEDE" if is_balanced else "❌ DENGESİZ"
        status_bg = "#27ae60" if is_balanced else "#c0392b"
        
        tk.Label(footer_frame, text=f"TOPLAM BORÇ: {total_borc:,.2f}", fg="#c0392b", bg="white", font=("Segoe UI", 11, "bold")).pack(side="left", padx=20, pady=15)
        tk.Label(footer_frame, text=f"TOPLAM ALACAK: {total_alacak:,.2f}", fg="#27ae60", bg="white", font=("Segoe UI", 11, "bold")).pack(side="left", padx=20, pady=15)
        tk.Label(footer_frame, text=status_text, fg="white", bg=status_bg, font=("Segoe UI", 10, "bold"), padx=10, pady=5).pack(side="right", padx=20, pady=10)

    def calculate(self):
        if self.calc_thread and self.calc_thread.is_alive(): return
        self.cancel_flag = False
        
        trees = [t for t in [self.tree_main, self.tree_f, self.tree_y] if t]
        for tree in trees:
            tree.delete(*tree.get_children())
            tree.configure(displaycolumns="#all")
            tree["columns"] = ["status"]
            tree.heading("status", text="DURUM", anchor="w")
            tree.column("status", width=400)
            tree.insert("", "end", values=["Hesaplanıyor... (İptal etmek için ESC)"])
        
        self.calc_thread = threading.Thread(target=self._run_calculation_thread, daemon=True)
        self.calc_thread.start()

    def _run_calculation_thread(self):
        if self.var_dual_view.get():
            f_config = {
                "rows": [x for x in self.pivot_config["rows"] if x.startswith("(F)")],
                "cols": [x for x in self.pivot_config["cols"] if x.startswith("(F)")],
                "vals": [x for x in self.pivot_config["vals"] if x.startswith("(F)")],
                "active_filters": {k: v for k, v in self.pivot_config["active_filters"].items() if k.startswith("(F)")},
                "sort_col": self.pivot_config.get("sort_col"),
                "sort_asc": self.pivot_config.get("sort_asc", True),
                "calc_cols": {k: v for k, v in self.pivot_config.get("calc_cols", {}).items() if k.startswith("(F)")},
                "hidden_cols": self.pivot_config.get("hidden_cols", [])
                
            }
            y_config = {
                "rows": [x for x in self.pivot_config["rows"] if x.startswith("(Y)")],
                "cols": [x for x in self.pivot_config["cols"] if x.startswith("(Y)")],
                "vals": [x for x in self.pivot_config["vals"] if x.startswith("(Y)")],
                "active_filters": {k: v for k, v in self.pivot_config["active_filters"].items() if k.startswith("(Y)")},
                "sort_col": self.pivot_config.get("sort_col"),
                "sort_asc": self.pivot_config.get("sort_asc", True),
                "calc_cols": {k: v for k, v in self.pivot_config.get("calc_cols", {}).items() if k.startswith("(Y)")},
                 "hidden_cols": self.pivot_config.get("hidden_cols", []) # EKLENDİ # YENİ
            }
            # ... geri kalanı aynı

            df_f = self.engine.calculate_pivot(f_config["rows"], f_config["cols"], f_config["vals"], f_config["active_filters"], show_totals=self.var_totals.get(), date_format=self.var_date_fmt.get())
            df_y = self.engine.calculate_pivot(y_config["rows"], y_config["cols"], y_config["vals"], y_config["active_filters"], show_totals=self.var_totals.get(), date_format=self.var_date_fmt.get())
            if self.cancel_flag: return 
            self.after(0, self._render_both_tables, df_f, df_y, f_config, y_config)
            
        else:
            # TEK EKRAN HESAPLAMASI
            df = self.engine.calculate_pivot(
                self.pivot_config["rows"], self.pivot_config["cols"], self.pivot_config["vals"],
                self.pivot_config["active_filters"], show_totals=self.var_totals.get(), date_format=self.var_date_fmt.get()
            )
            if self.cancel_flag: return
            self.after(0, self._render_single_table, self.tree_main, df, self.pivot_config)

    def _render_both_tables(self, df_f, df_y, f_config, y_config):
        if self.cancel_flag: return
        self._render_single_table(self.tree_f, df_f, f_config)
        self._render_single_table(self.tree_y, df_y, y_config)


    def _auto_format_columns(self, tree, data_cols=None):
        """Sütun genişliklerini SADECE BAŞLIĞA GÖRE daraltır ve her şeyi SOLA yaslar"""
        import tkinter.font as tkfont
        # Sadece başlık fontunu alıyoruz çünkü hücre içeriğiyle ilgilenmiyoruz
        hdr_font = tkfont.Font(family="Segoe UI", size=10, weight="bold")

        for col in tree["columns"]:
            # 1. Sadece başlık metnini ölç (Sıralama okları '▲' sığsın diye +30 piksel ekliyoruz)
            header_text = tree.heading(col)["text"]
            header_width = hdr_font.measure(header_text) + 30 
            
            # 2. KESİN HİZALAMA: Hem başlığı hem de hücreleri Sola (w = West) yasla
            # Sütunu başlık genişliğine sabitle
            tree.column(col, width=header_width, anchor="w")
            tree.heading(col, anchor="w")

    def _render_single_table(self, tree, df, config):
        tree.delete(*tree.get_children())
        tree.configure(displaycolumns="#all")
        
        if isinstance(df, str) or df.empty: 
            tree["columns"] = ["status"]
            tree.heading("status", text="BİLGİ", anchor="w")
            tree.insert("", "end", values=["Bu tablo için gösterilecek veri yok."])
            return

        sort_col = config.get("sort_col")
        sort_asc = config.get("sort_asc", True)
        
        if sort_col and sort_col in df.columns:
            try:
                mask = df.isin(["Genel Toplam"]).any(axis=1)
                df_main = df[~mask].sort_values(by=sort_col, ascending=sort_asc)
                df = pd.concat([df_main, df[mask]])
            except: pass
        # --- YENİ EKLENDİ: FORMÜLLÜ SÜTUNLARI HESAPLA ---
        def EGER(kosul, dogruysa, yanlissa):
            return dogruysa if kosul else yanlissa

        calc_cols = config.get("calc_cols", {})
        if calc_cols and not df.empty:
            for c_name, c_formula in calc_cols.items():
                def apply_dynamic_math(row):
                    f = c_formula
                    matches = re.findall(r'\[(.*?)\]', f)
                    eval_f = f
                    vars_dict = {"EGER": EGER}
                    
                    for m in matches:
                        if m in row.index:
                            var_key = "v_" + str(abs(hash(m))) 
                            eval_f = eval_f.replace(f"[{m}]", var_key)
                            
                            val = row[m]
                            try:
                                if pd.isna(val) or str(val).strip() == "":
                                    val = 0.0
                                elif isinstance(val, str) and "Genel Toplam" not in val:
                                    val = float(str(val).replace(".", "").replace(",", "."))
                                else:
                                    val = float(val)
                            except:
                                val = row[m] 
                                
                            vars_dict[var_key] = val
                        else:
                            # Sütun bulunamazsa sessizce 0 vermek yerine hücreye HATA yazdırıyoruz!
                            return f"HATA: [{m}] Yok" 
                            
                    try:
                        return eval(eval_f, {"__builtins__": None}, vars_dict)
                    except Exception as e:
                        # Formül dizilimi (virgül, parantez) hatalıysa hücrede göster
                        return "FORMÜL HATASI"
                        
                df[c_name] = df.apply(apply_dynamic_math, axis=1)
        # --- BİTİŞ ---

        row_cols = config["rows"] # <--- SENDE ZATEN BULUNAN SATIR

        
        data_cols = [c for c in df.columns if c not in row_cols and c != "Genel Toplam"]
        if "Genel Toplam" in df.columns: data_cols.append("Genel Toplam")

        tree["columns"] = row_cols + data_cols
        
        # --- GÜNCELLENDİ: GİZLİ SÜTUNLAR VE SÜTUN SIRALAMASI ---
        all_cols = list(tree.cget("columns"))
        hidden_cols = config.get("hidden_cols", [])
        saved_order = config.get("column_order", [])

        # 1. Önce gizli olmayan (görünür) sütunları tespit et
        display_cols = [c for c in all_cols if c not in hidden_cols]

        # 2. Eğer kayıtlı bir sıralama şablonu varsa uygula
        if saved_order:
            # Sadece mevcut tabloda var olan ve gizli olmayanları sıraya diz
            ordered_display = [c for c in saved_order if c in display_cols]
            
            # Şablonda olmayan YENİ bir sütun eklendiyse onları en sona at
            for c in display_cols:
                if c not in ordered_display:
                    ordered_display.append(c)
            display_cols = ordered_display

        if not display_cols: display_cols = ["#all"] # Tablo çökmesini önler
        tree.configure(displaycolumns=display_cols)
        # ---------------------------------------------------------
        # ------------------------------------------
        for col in row_cols:
            col_title = col 
            if config["active_filters"].get(col): col_title += " ⚙"
            if col == sort_col: col_title += " ▲" if sort_asc else " ▼"
            tree.heading(col, text=col_title, anchor="w")

        for col in data_cols:
            base_col = col
            if col != "Genel Toplam" and col in config["vals"]: col_title = f"Toplam {col}"
            else: col_title = col
                
            if config["active_filters"].get(base_col): col_title += " ⚙"
            if base_col == sort_col: col_title += " ▲" if sort_asc else " ▼"
            tree.heading(col, text=col_title, anchor="e")

        if not row_cols:
            row_count = 0
            for _, row in df.iterrows():
                if self.cancel_flag: return
                vals = [self.format_tr(v) if isinstance(v, (int, float)) else str(v) for v in row]
                zebra_tag = "even" if row_count % 2 == 0 else "odd"
                tree.insert("", "end", values=vals, tags=(zebra_tag,))
                row_count += 1
                self._auto_format_columns(tree, data_cols)
            return

        class Node:
            def __init__(self, name, depth):
                self.name = name; self.depth = depth; self.children = {}
                self.values = [0.0] * len(data_cols); self.is_leaf = False

        root_nodes = {}; gt_values = None

        for _, row in df.iterrows():
            if row_cols and str(row[row_cols[0]]) == "Genel Toplam":
                gt_values = [row[c] for c in data_cols]
                continue

            current_dict = root_nodes
            for i, r_col in enumerate(row_cols):
                raw_val = row[r_col]
                val = "(Boş)" if pd.isna(raw_val) or str(raw_val) == "nan" or str(raw_val) == "" else str(raw_val)
                if val not in current_dict: current_dict[val] = Node(val, depth=i)
                node = current_dict[val]
                
                if i == len(row_cols) - 1:
                    node.is_leaf = True
                    for j, c in enumerate(data_cols):
                        try:
                            if pd.notna(row[c]) and isinstance(row[c], (int, float)): node.values[j] += float(row[c])
                        except: pass
                current_dict = node.children

        def calculate_recursive_subtotals(node_dict):
            for name, node in node_dict.items():
                if not node.is_leaf:
                    calculate_recursive_subtotals(node.children)
                    for child in node.children.values():
                        for j in range(len(node.values)): node.values[j] += child.values[j]

        calculate_recursive_subtotals(root_nodes)

        self.prev_path = []
        def generate_flat_rows(node_dict, parent_path=()):
            if self.cancel_flag: return []
            rows = []
            for name, node in node_dict.items():
                current_path = parent_path + (name,)
                if node.is_leaf:
                    row_vals = []
                    for i, p in enumerate(current_path):
                        if self.var_group.get() and self.prev_path and i < len(self.prev_path) and p == self.prev_path[i]:
                            if all(current_path[k] == self.prev_path[k] for k in range(i)): row_vals.append("")
                            else: row_vals.append(p)
                        else: row_vals.append(p)
                    val_strs = [self.format_tr(v, hide_zero=True) for v in node.values]
                    rows.append( (row_vals + val_strs, "normal_row") )
                    self.prev_path = current_path
                else:
                    rows.extend(generate_flat_rows(node.children, current_path))
                    if self.var_subtotals.get():
                        sub_row = [""] * len(row_cols)
                        sub_row[node.depth] = f"Toplam {name}"
                        sub_val_strs = [self.format_tr(v, hide_zero=True) for v in node.values]
                        rows.append( (sub_row + sub_val_strs, "subtotal_row") )
                        self.prev_path = [] 
            return rows

        row_count = 0
        for row_vals, tag_type in generate_flat_rows(root_nodes):
            if self.cancel_flag: return
            final_tags = [tag_type]
            if tag_type == "normal_row":
                zebra_tag = "even" if row_count % 2 == 0 else "odd"
                final_tags.append(zebra_tag)
                row_count += 1
            tree.insert("", "end", values=row_vals, tags=tuple(final_tags))

        if self.var_totals.get() and gt_values and not self.cancel_flag:
            str_gt = [self.format_tr(v) if v else "" for v in gt_values]
            gt_row_vals = ["GENEL TOPLAM"] + [""] * (len(row_cols) - 1)
            tree.insert("", "end", values=gt_row_vals + str_gt, tags=("gt_row",))
            
            
            # --- YENİ EKLENDİ 2: TABLO BİTİNCE SÜTUNLARI OTOMATİK DARALT VE HİZALA ---
        self._auto_format_columns(tree, data_cols)
            # =========================================================================
    
    
    def format_tr(self, val, hide_zero=False):
        """Sayıları 100.000,00 TR formatına çevirir"""
        try:
            num = float(val)
            if hide_zero and num == 0:
                return ""
            # Önce standart formatta (100,000.00) oluştur
            us_format = f"{num:,.2f}"
            # Sonra virgül ve noktaları yer değiştir (100.000,00)
            return us_format.replace(",", "X").replace(".", ",").replace("X", ".")
        except:
            return str(val)
    
    
    # DİLİMLEYİCİ (SLICER) FONKSİYONLARI
    # =========================================================================
    def show_slicer_menu(self, event, field_name):
        """Sol panelde bir alana sağ tıklandığında dilimleyici menüsünü açar"""
        # "Toplam X" yazıyorsa gerçek alan ismini ayıkla
        clean_field = field_name.replace("Toplam ", "").replace(" ⚙", "")
        self._clicked_slicer_field = clean_field
        
        try:
            self.slicer_context_menu.post(event.x_root, event.y_root)
        finally:
            self.slicer_context_menu.grab_release()

    def add_slicer_from_menu(self):
        """Menüden seçilen alanı yüzen Dilimleyici olarak ekrana getirir"""
        field = self._clicked_slicer_field
        if not field: return
        
        if field in self.active_slicers:
            self.active_slicers[field].lift()
            return

        # Slicer'ı doğrudan 'self' (PivotTableFrame) içine ekliyoruz
        slicer = SlicerWindow(
            self, # winfo_toplevel() YERİNE self kullanıyoruz!
            self.engine, 
            field, 
            self.pivot_config, 
            self.on_filter_applied,
            self.on_slicer_closed
        )
        
        # Slicer kutusunu çerçevenin içinde belirli bir yere yerleştir (boyutları ile)
        slicer.place(x=350, y=100, width=200, height=260)
        slicer.lift()
        self.active_slicers[field] = slicer
    def on_slicer_closed(self, field):
        """Slicer penceresi kapatıldığında bellekten siler"""
        if field in self.active_slicers:
            del self.active_slicers[field]

            # =========================================================================
    # =========================================================================
    # PRO ÖZELLİK: ŞABLON KAYDETME, GRUPLAMA VE YÜKLEME SİSTEMİ
    # =========================================================================
    def get_templates_file(self):
        return os.path.join(os.path.dirname(__file__), "pivot_templates.json")

    def load_all_templates(self):
        import json
        path = self.get_templates_file()
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except: return {}
        return {}

    def refresh_template_menu(self):
        """Üst menüdeki 'Şablonlarım' listesini Klasör/Grup (Cascade) mantığıyla günceller"""
        self.menu_templates.delete(0, 'end')
        templates = self.load_all_templates()
        
        if not templates:
            self.menu_templates.add_command(label="Kayıtlı Şablon Yok", state="disabled")
        else:
            # Şablonları gruplarına göre ayrıştır
            groups = {}
            for t_name, t_data in templates.items():
                grp = t_data.get("group", "Genel") if isinstance(t_data, dict) and "group" in t_data else "Genel"
                
                # İçinde phyton, python veya script geçenleri ortak grupta topla
                if "python" in grp.lower() or "phyton" in grp.lower() or "script" in grp.lower():
                    grp = "🔒 Özel Python Scriptleri"
                    
                if grp not in groups: groups[grp] = []
                groups[grp].append(t_name)
                
            # Grupları (Klasörleri) menüye ekle
            for grp in sorted(groups.keys()):
                grp_menu = tk.Menu(self.menu_templates, tearoff=0, font=("Segoe UI", 9))
                
                # EĞER GİZLİ GRUPSA İÇİNİ GÖSTERME
                if "python" in grp.lower() or "phyton" in grp.lower() or "script" in grp.lower():
                    self.menu_templates.add_cascade(label=f"{grp}", menu=grp_menu)
                    # Alt menüye dosyaları eklemek yerine kilit açma butonu ekliyoruz
                    grp_menu.add_command(
                        label="🔑 Şablonları Görmek İçin Tıklayın", 
                        command=lambda g=grp, m=grp_menu, t_list=groups[grp]: self.unlock_menu_group(m, t_list)
                    )
                else:
                    self.menu_templates.add_cascade(label=f"📁 {grp}", menu=grp_menu)
                    for name in sorted(groups[grp]):
                        grp_menu.add_command(label=f"📄 {name}", command=lambda t=name: self.apply_template(t))
                    
        self.menu_templates.add_separator()
        self.menu_templates.add_command(label="⚙ Şablon Yöneticisi", command=self.open_template_manager, font=("Segoe UI", 9, "bold"))

    def unlock_menu_group(self, menu_widget, template_list):
        """Menüdeki kilitli klasöre tıklanınca şifre sorar ve doğruysa menüyü şablonlarla doldurur."""
        if verify_admin(self.winfo_toplevel()):
            menu_widget.delete(0, 'end') # "Tıklayın" butonunu sil
            
            for name in sorted(template_list):
                menu_widget.add_command(label=f"📄 {name}", command=lambda t=name: self.apply_template(t))
                
            messagebox.showinfo("Kilit Açıldı", "Python script şablonlarının kilidi açıldı!\n\nMenüye tekrar tıklayarak raporlarınıza erişebilirsiniz.", parent=self.winfo_toplevel())

    def save_template(self):
        if not any([self.pivot_config["rows"], self.pivot_config["cols"], self.pivot_config["vals"], self.pivot_config["filters"]]):
            messagebox.showwarning("Uyarı", "Kaydedilecek alan bulunamadı. Önce tabloyu oluşturun.")
            return

        templates = self.load_all_templates()
        existing_names = list(templates.keys())

        # --- ÖZEL KAYIT POPUP EKRANI ---
        top = tk.Toplevel(self)
        top.title("💾 Şablon Kaydet")
        top.geometry("380x250")
        top.configure(bg="#f3f2f1")
        top.transient(self.winfo_toplevel())
        top.grab_set() # Kullanıcı bu pencereyi kapatmadan arkaya tıklayamaz

        tk.Label(top, text="Kayıt Yöntemi Seçin", bg="#f3f2f1", font=("Segoe UI", 11, "bold")).pack(pady=(15, 5))

        var_choice = tk.StringVar(value="new")

        # 1. Yeni Şablon Seçeneği
        f_new = tk.Frame(top, bg="#f3f2f1")
        f_new.pack(fill="x", padx=20, pady=5)
        tk.Radiobutton(f_new, text="Yeni Şablon Olarak Kaydet:", variable=var_choice, value="new", bg="#f3f2f1", font=("Segoe UI", 9, "bold")).pack(side="top", anchor="w")
        ent_new = tk.Entry(f_new, font=("Segoe UI", 10))
        ent_new.pack(fill="x", padx=(25, 0), pady=2)
        ent_new.insert(0, "Yeni Şablon Adı...")
        ent_new.bind("<FocusIn>", lambda e: ent_new.delete(0, tk.END) if ent_new.get() == "Yeni Şablon Adı..." else None)

        # 2. Mevcut Şablonu Güncelle Seçeneği
        f_update = tk.Frame(top, bg="#f3f2f1")
        f_update.pack(fill="x", padx=20, pady=5)
        
        state_update = "normal" if existing_names else "disabled"
        tk.Radiobutton(f_update, text="Mevcut Şablonun Üzerine Yaz (Güncelle):", variable=var_choice, value="update", bg="#f3f2f1", font=("Segoe UI", 9, "bold"), state=state_update).pack(side="top", anchor="w")
        cb_update = ttk.Combobox(f_update, values=existing_names, state="readonly" if existing_names else "disabled", font=("Segoe UI", 10))
        cb_update.pack(fill="x", padx=(25, 0), pady=2)
        if existing_names: 
            cb_update.current(0)

        def on_save():
            choice = var_choice.get()
            
            if choice == "new":
                tpl_name = ent_new.get().strip()
                if not tpl_name or tpl_name == "Yeni Şablon Adı...":
                    messagebox.showwarning("Uyarı", "Lütfen yeni bir şablon adı girin.", parent=top)
                    return
                if tpl_name in templates:
                    if not messagebox.askyesno("Onay", "Bu isimde bir şablon zaten var. Üzerine yazılsın mı?", parent=top):
                        return
            else:
                tpl_name = cb_update.get()
                if not tpl_name:
                    messagebox.showwarning("Uyarı", "Lütfen güncellenecek şablonu seçin.", parent=top)
                    return

            # Arayüzdeki (Tarih, Slicer vb.) güncel durumları config'e aktar
            self.pivot_config["date_format"] = self.var_date_fmt.get()
            self.pivot_config["open_slicers"] = list(self.active_slicers.keys())
            self.pivot_config["show_group"] = self.var_group.get()
            self.pivot_config["show_subtotals"] = self.var_subtotals.get()
            self.pivot_config["show_totals"] = self.var_totals.get()
            
            # --- YENİ EKLENDİ: Ekran yönünü (Alt/Üst veya Yan Yana) kaydet ---
            self.pivot_config["split_orient"] = self.var_split_orient.get() 

            old_group = "Genel"
            if tpl_name in templates and isinstance(templates[tpl_name], dict):
                old_group = templates[tpl_name].get("group", "Genel")

            templates[tpl_name] = {"group": old_group, "config": self.pivot_config}

            import json
            try:
                with open(self.get_templates_file(), "w", encoding="utf-8") as f:
                    json.dump(templates, f, ensure_ascii=False, indent=4)
                messagebox.showinfo("Başarılı", f"'{tpl_name}' başarıyla kaydedildi!", parent=top)
                self.refresh_template_menu()
                top.destroy()
            except Exception as e:
                messagebox.showerror("Hata", f"Şablon kaydedilirken hata oluştu: {e}", parent=top)

        tk.Button(top, text="💾 Kaydet", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=20, pady=5, cursor="hand2", command=on_save).pack(pady=(15, 0))

    def apply_template(self, tpl_name):
        templates = self.load_all_templates()
        if tpl_name in templates:
            data = templates[tpl_name]
            self.pivot_config = data.get("config", data) if isinstance(data, dict) and "config" in data else data
            
            # ---> YENİ EKLENDİ: SCRIPT ŞABLONU İSE ÖNCE ŞİFRE SOR <---
            if self.pivot_config.get("is_script"):
                if not verify_admin(self.winfo_toplevel()):
                    return # Şifre yanlışsa veya iptal edildiyse yüklemeyi durdur
                    
                self.var_dual_view.set(False)
                self.cb_split.config(state="disabled")
                self.build_right_panel()
                self.execute_script_template()
                return
            
            # ... (Metodun geri kalanı aynı kalacak) ...
            
            self.var_date_fmt.set(self.pivot_config.get("date_format", "Normal"))
            self.var_group.set(self.pivot_config.get("show_group", True))
            self.var_subtotals.set(self.pivot_config.get("show_subtotals", True))
            self.var_totals.set(self.pivot_config.get("show_totals", True))
            
            # --- YENİ EKLENDİ: Ekran yönünü geri yükle ---
            self.var_split_orient.set(self.pivot_config.get("split_orient", "Alt / Üst"))

            all_items = self.pivot_config.get("rows", []) + self.pivot_config.get("cols", []) + self.pivot_config.get("vals", []) + list(self.pivot_config.get("active_filters", {}).keys())
            has_y = any(x.startswith("(Y)") for x in all_items)
            has_f = any(x.startswith("(F)") for x in all_items)
            
            if has_y and has_f:
                self.var_dual_view.set(True)
                self.cb_split.config(state="readonly")
            elif has_y or has_f:
                self.var_dual_view.set(False)
                self.cb_split.config(state="disabled")
                
            self.build_right_panel()

            for slicer in list(self.active_slicers.values()): slicer.destroy()
            self.active_slicers.clear()
            
            saved_slicers = self.pivot_config.get("open_slicers", [])
            offset = 0 
            for field in saved_slicers:
                slicer = SlicerWindow(self, self.engine, field, self.pivot_config, self.on_filter_applied, self.on_slicer_closed)
                slicer.place(x=350 + offset, y=100 + offset, width=200, height=260)
                self.active_slicers[field] = slicer
                offset += 30

            self.refresh_field_ui()
            self.calculate()


    def open_template_manager(self):
        """Şablon yöneticisi Pop-up'ını açar"""
        TemplateManagerModal(self.winfo_toplevel(), self)
    def apply_new_scenario(self, mode):
        """Kullanıcının seçtiği yeni pivot senaryosunu ekrana uygular."""
        # 1. Mevcut ekranı tamamen sıfırla
        self.pivot_config = {
            "filters": [], "cols": [], "rows": [], "vals": [],
            "active_filters": {}, "sort_col": None, "sort_asc": True
        }
        for slicer in list(self.active_slicers.values()): slicer.destroy()
        self.active_slicers.clear()
        
        self.var_date_fmt.set("Normal")
        self.var_group.set(True)
        self.var_subtotals.set(True)
        self.var_totals.set(True)

        self._is_programmatic_change = True # Sihirbaz tetiklenmesini engelle

        # 2. Seçime göre sekmeleri ve ekranı ayarla
        if mode == "alis" or mode == "satis":
            self.var_dual_view.set(False)
            self.cb_split.config(state="disabled")
            self.notebook.select(self.tab_f)
            self.build_right_panel()
            self.apply_fatura_wizard(mode) 
            self._is_programmatic_change = False
            return # Sihirbaz kendi içinde yenileme ve hesaplama yapıyor
            
        elif mode == "bos_f":
            self.var_dual_view.set(False)
            self.cb_split.config(state="disabled")
            self.notebook.select(self.tab_f)
            
        elif mode == "bos_y":
            self.var_dual_view.set(False)
            self.cb_split.config(state="disabled")
            self.notebook.select(self.tab_y)
            
        elif mode == "dual":
            self.var_dual_view.set(True)
            self.cb_split.config(state="readonly")
            
        self._is_programmatic_change = False
        
        # 3. Ekranı yenile ve boş tabloyu çiz
        self.build_right_panel()
        self.refresh_field_ui()
        self.calculate()
    # =============================================================================
# PRO ÖZELLİK: İKİ ŞABLON PİVOTUNU ORTAK ALANDAN BİRLEŞTİRME EKRANI
    def execute_script_template(self):
        """Kayıtlı Pandas scriptini çalıştırır ve tekli tablo ekranına basar"""
        source = self.pivot_config.get("script_source")
        code = self.pivot_config.get("script_code")
        
        self.tree_main.delete(*self.tree_main.get_children())
        self.tree_main["columns"] = ["status"]
        self.tree_main.heading("status", text="DURUM", anchor="w")
        self.tree_main.insert("", "end", values=["Rapor hesaplanıyor... (Özel Pandas Scripti Çalışıyor)"])
        self.update()
        
        try:
            # ---> YENİ: VERİ ÇEKME İŞLEMİNİ FONKSİYONLAŞTIRDIK <---
            def fetch_data(src_type):
                df_temp = pd.DataFrame()
                if src_type == "Yevmiye" and self.engine.yevmiye_db:
                    conn = sqlite3.connect(self.engine.yevmiye_db)
                    df_temp = pd.read_sql_query("SELECT * FROM yevmiye", conn)
                    df_temp.rename(columns=self.engine.y_map, inplace=True)
                    conn.close()
                elif src_type == "Faturalar" and self.engine.fatura_db:
                    conn = sqlite3.connect(self.engine.fatura_db)
                    c = conn.cursor()
                    c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
                    tbl = c.fetchone()
                    if tbl:
                        df_temp = pd.read_sql_query(f"SELECT * FROM {tbl[0]}", conn)
                        df_temp.rename(columns=self.engine.f_map, inplace=True)
                    conn.close()
                return df_temp

            # Çift veya Tek kaynak durumuna göre injection
            if source == "Fatura + Yevmiye":
                df_fatura = fetch_data("Faturalar")
                df_yevmiye = fetch_data("Yevmiye")
                local_vars = {'df_fatura': df_fatura, 'df_yevmiye': df_yevmiye, 'pd': pd, 'np': np}
            else:
                raw_df = fetch_data(source)
                local_vars = {'df': raw_df, 'pd': pd, 'np': np}
                
            # 2. Kullanıcı Scriptini Çalıştır
            exec(code, {}, local_vars)
            
            # 3. Sonucu Ekrana Bas
            df_result = local_vars.get('df_result')
            if df_result is not None and isinstance(df_result, pd.DataFrame):
# ... geri kalanı aynı kalacak ...
                # Zaten yazdığımız tablo basma sistemi pivot ayarları boş gönderilirse 
                # düz Excel tablosu gibi tüm DataFrame'i çizecek şekilde tasarlanmıştı :)
                dummy_config = {"rows": [], "cols": [], "vals": [], "active_filters": {}}
                self._render_single_table(self.tree_main, df_result, dummy_config)
            else:
                self.tree_main.insert("", "end", values=["Hata: df_result adında bir DataFrame bulunamadı!"])
                
        except Exception as e:
            self.tree_main.insert("", "end", values=[f"Script Çalışma Hatası: {str(e)}"])
# =============================================================================
# PRO ÖZELLİK: İKİ ŞABLON PİVOTUNU ORTAK ALANDAN BİRLEŞTİRME EKRANI
# =============================================================================
# PRO ÖZELLİK: İKİ ŞABLON PİVOTUNU ORTAK ALANDAN BİRLEŞTİRME EKRANI
# =============================================================================
import numpy as np

class ScenarioMergeModal(tk.Toplevel):
    def __init__(self, parent, pivot_frame):
        super().__init__(parent)
        self.title("🔀 Pivot Tablolarını Birleştir")
        self.geometry("650x350")
        self.configure(bg="#f3f2f1")
        self.transient(parent)
        self.grab_set()
        
        self.pivot_frame = pivot_frame
        self.df1 = pd.DataFrame()
        self.df2 = pd.DataFrame()
        
        # --- DOĞRU MANTIK: SADECE PİVOT ŞABLONLARINI FİLTRELE (SCRIPTLERİ GİZLE) ---
        self.templates = self.pivot_frame.load_all_templates()
        self.template_names = []
        for t_name, t_data in self.templates.items():
            cfg = t_data.get("config", t_data) if isinstance(t_data, dict) else t_data
            if not cfg.get("is_script", False): # Eğer script DEĞİLSE listeye ekle
                self.template_names.append(t_name)
        
        self.setup_ui()

    def setup_ui(self):
        # Üst Bilgi Alanı
        info_frame = tk.Frame(self, bg="#eaf2f8", pady=10, bd=1, relief="solid")
        info_frame.pack(fill=tk.X, padx=10, pady=10)
        tk.Label(info_frame, text="İki farklı Pivot şablonunu ortak bir sütun üzerinden birleştirin.\n(Not: Python Script şablonları burada listelenmez.)", bg="#eaf2f8", fg="#2980b9", font=("Segoe UI", 9, "bold")).pack()

        # Tablo 1 ve Tablo 2 Seçim Alanları (Yan Yana)
        main_frame = tk.Frame(self, bg="#f3f2f1")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10)

        # --- SOL PANEL: TABLO 1 ---
        left_frame = tk.Frame(main_frame, bg="white", bd=1, relief="solid", padx=10, pady=10)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        tk.Label(left_frame, text="1. Şablon (Ana Tablo)", bg="white", font=("Segoe UI", 10, "bold"), fg="#c0392b").pack(anchor="w", pady=(0, 5))
        self.cb_tpl1 = ttk.Combobox(left_frame, values=self.template_names, state="readonly", font=("Segoe UI", 10))
        self.cb_tpl1.pack(fill=tk.X, pady=(0, 10))
        self.cb_tpl1.bind("<<ComboboxSelected>>", lambda e: self.load_columns(1))
        
        tk.Label(left_frame, text="Ortak Sütun (Eşleşme Noktası):", bg="white", font=("Segoe UI", 9)).pack(anchor="w")
        self.cb_col1 = ttk.Combobox(left_frame, state="readonly", font=("Segoe UI", 10))
        self.cb_col1.pack(fill=tk.X, pady=(0, 10))
        
        self.lbl_status1 = tk.Label(left_frame, text="Şablon seçimi bekleniyor...", bg="white", fg="#7f8c8d", font=("Segoe UI", 8))
        self.lbl_status1.pack(anchor="w")

        # --- SAĞ PANEL: TABLO 2 ---
        right_frame = tk.Frame(main_frame, bg="white", bd=1, relief="solid", padx=10, pady=10)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        tk.Label(right_frame, text="2. Şablon (Eklenecek Tablo)", bg="white", font=("Segoe UI", 10, "bold"), fg="#2980b9").pack(anchor="w", pady=(0, 5))
        self.cb_tpl2 = ttk.Combobox(right_frame, values=self.template_names, state="readonly", font=("Segoe UI", 10))
        self.cb_tpl2.pack(fill=tk.X, pady=(0, 10))
        self.cb_tpl2.bind("<<ComboboxSelected>>", lambda e: self.load_columns(2))
        
        tk.Label(right_frame, text="Ortak Sütun (Eşleşme Noktası):", bg="white", font=("Segoe UI", 9)).pack(anchor="w")
        self.cb_col2 = ttk.Combobox(right_frame, state="readonly", font=("Segoe UI", 10))
        self.cb_col2.pack(fill=tk.X, pady=(0, 10))
        
        self.lbl_status2 = tk.Label(right_frame, text="Şablon seçimi bekleniyor...", bg="white", fg="#7f8c8d", font=("Segoe UI", 8))
        self.lbl_status2.pack(anchor="w")

        # Alt Buton Alanı
        bot_frame = tk.Frame(self, bg="#f3f2f1", pady=15)
        bot_frame.pack(fill=tk.X, padx=10)
        
        btn_merge = tk.Button(bot_frame, text="🔀 Tabloları Birleştir", bg="#8e44ad", fg="white", font=("Segoe UI", 11, "bold"), bd=0, padx=20, pady=8, cursor="hand2", command=self.merge_tables)
        btn_merge.pack()

    def load_columns(self, tab_index):
        if tab_index == 1:
            tpl_name = self.cb_tpl1.get()
            if not tpl_name: return
            
            t_data = self.templates[tpl_name]
            cfg = t_data.get("config", t_data) if isinstance(t_data, dict) else t_data
            
            all_fields = cfg.get("rows", []) + cfg.get("cols", []) + cfg.get("vals", []) + list(cfg.get("active_filters", {}).keys())
            has_f = any(f.startswith("(F)") for f in all_fields)
            has_y = any(f.startswith("(Y)") for f in all_fields)
            
            if has_f and has_y:
                self.lbl_status1.config(text="İkili Senaryo Algılandı...", fg="#f39c12")
                self.update()
                
                self.cb_tpl2.set("")
                self.cb_tpl2.config(state="disabled")
                self.cb_col2.set("")
                self.cb_col2.config(state="disabled")
                self.lbl_status2.config(text="Otomatik Yevmiye Tablosu", fg="#2980b9")
                
                f_cfg = {
                    "rows": [x for x in cfg.get("rows", []) if x.startswith("(F)")],
                    "cols": [x for x in cfg.get("cols", []) if x.startswith("(F)")],
                    "vals": [x for x in cfg.get("vals", []) if x.startswith("(F)")],
                    "active_filters": {k: v for k, v in cfg.get("active_filters", {}).items() if k.startswith("(F)")},
                }
                y_cfg = {
                    "rows": [x for x in cfg.get("rows", []) if x.startswith("(Y)")],
                    "cols": [x for x in cfg.get("cols", []) if x.startswith("(Y)")],
                    "vals": [x for x in cfg.get("vals", []) if x.startswith("(Y)")],
                    "active_filters": {k: v for k, v in cfg.get("active_filters", {}).items() if k.startswith("(Y)")},
                }
                
                df_f = self.pivot_frame.engine.calculate_pivot(f_cfg["rows"], f_cfg["cols"], f_cfg["vals"], f_cfg["active_filters"], show_totals=cfg.get("show_totals", True), date_format=cfg.get("date_format", "Normal"))
                df_y = self.pivot_frame.engine.calculate_pivot(y_cfg["rows"], y_cfg["cols"], y_cfg["vals"], y_cfg["active_filters"], show_totals=cfg.get("show_totals", True), date_format=cfg.get("date_format", "Normal"))
                
                if isinstance(df_f, str) or df_f.empty or isinstance(df_y, str) or df_y.empty:
                    self.lbl_status1.config(text="Hata: Tablolar oluşturulamadı!", fg="red")
                    return

                if "Genel Toplam" in df_f.values: df_f = df_f[~df_f.isin(["Genel Toplam"]).any(axis=1)]
                if "Genel Toplam" in df_y.values: df_y = df_y[~df_y.isin(["Genel Toplam"]).any(axis=1)]
                
                self.df1 = df_f
                self.df2 = df_y
                
                f_cols = list(df_f.columns)
                y_cols = list(df_y.columns)
                
                self.cb_col1.config(values=f_cols)
                self.cb_col2.config(values=y_cols, state="readonly") 
                
                for c in f_cols:
                    if "Tarih" in c or "Fatura No" in c: self.cb_col1.set(c); break
                if not self.cb_col1.get() and f_cols: self.cb_col1.current(0)
                
                for c in y_cols:
                    if "Tarih" in c or "Belge No" in c: self.cb_col2.set(c); break
                if not self.cb_col2.get() and y_cols: self.cb_col2.current(0)
                
                self.lbl_status1.config(text=f"Faturalar: {len(df_f)} Satır", fg="#27ae60")
                self.lbl_status2.config(text=f"Yevmiye: {len(df_y)} Satır", fg="#27ae60")
                return
            else:
                self.cb_tpl2.config(state="readonly")
                self.lbl_status2.config(text="Tablo bekleniyor...", fg="#7f8c8d")

        tpl_name = self.cb_tpl1.get() if tab_index == 1 else self.cb_tpl2.get()
        if not tpl_name: return
        
        lbl_status = self.lbl_status1 if tab_index == 1 else self.lbl_status2
        lbl_status.config(text="Hesaplanıyor...", fg="#f39c12")
        self.update()

        t_data = self.templates[tpl_name]
        cfg = t_data.get("config", t_data) if isinstance(t_data, dict) else t_data
        
        df = self.pivot_frame.engine.calculate_pivot(
            cfg.get("rows", []), cfg.get("cols", []), cfg.get("vals", []),
            cfg.get("active_filters", {}), show_totals=cfg.get("show_totals", True),
            date_format=cfg.get("date_format", "Normal")
        )
        
        if isinstance(df, str) or df.empty:
            lbl_status.config(text="Hata: Tablo oluşturulamadı!", fg="red")
            return

        if "Genel Toplam" in df.values:
            df = df[~df.isin(["Genel Toplam"]).any(axis=1)]

        cols = list(df.columns)
        if tab_index == 1:
            self.df1 = df
            self.cb_col1.config(values=cols)
            if cols: self.cb_col1.current(0)
            lbl_status.config(text=f"Başarılı: {len(df)} Satır", fg="#27ae60")
        else:
            self.df2 = df
            self.cb_col2.config(values=cols)
            if cols: self.cb_col2.current(0)
            lbl_status.config(text=f"Başarılı: {len(df)} Satır", fg="#27ae60")

    def merge_tables(self):
        col1 = self.cb_col1.get()
        col2 = self.cb_col2.get()
        
        if not col1 or not col2 or self.df1.empty or self.df2.empty:
            messagebox.showwarning("Uyarı", "Lütfen her iki tabloyu ve ortak alanları seçin.", parent=self)
            return

        try:
            df1_merge = self.df1.copy()
            df2_merge = self.df2.copy()

            def format_key(series, col_name):
                s = series.copy().astype(str).str.strip()
                if "tarih" in str(col_name).lower():
                    s = pd.to_datetime(s, errors='coerce', dayfirst=True).dt.strftime('%Y-%m-%d')
                else:
                    s = s.str.upper()
                return s.replace(["NAN", "NAT", "(BOŞ)", "", "NONE", "NULL"], np.nan)

            df1_merge[col1] = format_key(df1_merge[col1], col1)
            df2_merge[col2] = format_key(df2_merge[col2], col2)

            df1_merge = df1_merge.dropna(subset=[col1])
            df2_merge = df2_merge.dropna(subset=[col2])

            if df1_merge.empty and df2_merge.empty:
                messagebox.showwarning("Uyarı", "Seçilen sütunlarda eşleşebilecek geçerli bir veri/tarih bulunamadı.", parent=self)
                return

            if col1 == col2:
                merged_df = pd.merge(df1_merge, df2_merge, on=col1, how="outer", suffixes=(' (1. Tablo)', ' (2. Tablo)'))
                merged_df.rename(columns={col1: "Ortak Anahtar"}, inplace=True)
            else:
                merged_df = pd.merge(df1_merge, df2_merge, left_on=col1, right_on=col2, how="outer", suffixes=(' (1. Tablo)', ' (2. Tablo)'))
                merged_df["Ortak Anahtar"] = merged_df[col1].fillna(merged_df[col2])
                merged_df.drop(columns=[col1, col2], inplace=True)
            
            cols = ["Ortak Anahtar"] + [c for c in merged_df.columns if c != "Ortak Anahtar"]
            merged_df = merged_df[cols]
            
            main_app_window = self.pivot_frame.winfo_toplevel()
            MergedResultWindow(main_app_window, merged_df)
            
            self.destroy() 
        except Exception as e:
            messagebox.showerror("Hata", f"Birleştirme başarısız:\n{str(e)}", parent=self)

class MergedResultWindow(tk.Toplevel):
    def __init__(self, parent, df):
        super().__init__(parent)
        self.transient(parent)  # <--- EKSİK OLAN KİLİT KIRICI KOD
        self.title("🔀 Birleştirilmiş Çapraz Sonuç Tablosu")
        self.geometry("1100x600")
        self.configure(bg="#f3f2f1")
        self.df = df
        
        self.setup_ui()

    def setup_ui(self):
        tb = tk.Frame(self, bg="white", pady=8, padx=10)
        tb.pack(fill=tk.X)
        tk.Button(tb, text="📥 Excel'e Aktar", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=15, cursor="hand2", command=self.export_excel).pack(side=tk.LEFT)

        tree_frame = tk.Frame(self, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        style = ttk.Style()
        style.configure("Merge.Treeview", rowheight=28, font=("Segoe UI", 10))
        style.configure("Merge.Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#d9e1f2")
        
        self.tree = ttk.Treeview(tree_frame, columns=list(self.df.columns), show="headings", style="Merge.Treeview")
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(fill=tk.BOTH, expand=True)

        for col in self.df.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=150)

        for _, row in self.df.iterrows():
            vals = []
            for v in row:
                if pd.isna(v): 
                    vals.append("")
                elif isinstance(v, (float, np.floating)):
                    if float(v).is_integer(): vals.append(str(int(v)))
                    else: vals.append(f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
                else:
                    vals.append(str(v))
            self.tree.insert("", "end", values=vals)

    def export_excel(self):
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Dosyası", "*.xlsx")], parent=self)
        if path:
            self.df.to_excel(path, index=False)
            os.startfile(path)
# =============================================================================
# Yeni Pivot Ekranı Menüsü
# =============================================================================
class NewPivotModal(tk.Toplevel):
    def __init__(self, parent, pivot_frame):
        super().__init__(parent)
        self.title("✨ Yeni Pivot Oluştur")
        self.geometry("450x420")
        self.configure(bg="#f3f2f1")
        self.transient(parent)
        self.grab_set()
        
        self.pivot_frame = pivot_frame
        self.setup_ui()

    def setup_ui(self):
        # Ekranda kaydedilmemiş (aktif) veri var mı kontrol et
        p_cfg = self.pivot_frame.pivot_config
        has_data = any([p_cfg.get("rows"), p_cfg.get("cols"), p_cfg.get("vals"), p_cfg.get("filters")])
        
        if has_data:
            warn_frame = tk.Frame(self, bg="#fff3cd", bd=1, relief="solid")
            warn_frame.pack(fill=tk.X, padx=15, pady=(15, 5))
            tk.Label(warn_frame, text="⚠️ Ekrandaki mevcut tabloyu henüz kaydetmediniz.", bg="#fff3cd", fg="#856404", font=("Segoe UI", 9, "bold")).pack(pady=(5,0))
            tk.Label(warn_frame, text="Yeni bir pivot oluşturursanız mevcut veriler silinecektir.", bg="#fff3cd", fg="#856404", font=("Segoe UI", 8)).pack(pady=(0,5))
            
            btn_save = tk.Button(warn_frame, text="💾 Önce Şablon Olarak Kaydet", bg="#27ae60", fg="white", font=("Segoe UI", 9, "bold"), bd=0, cursor="hand2", command=self.save_and_close)
            btn_save.pack(pady=8, padx=10, fill=tk.X)
            
        tk.Label(self, text="Hangi senaryo ile yeni tablo oluşturmak istiyorsunuz?", bg="#f3f2f1", font=("Segoe UI", 10, "bold")).pack(pady=(15,5))
        
        # --- Senaryo Butonları ---
        f1 = tk.Frame(self, bg="#f3f2f1")
        f1.pack(fill=tk.X, padx=15, pady=5)
        
        tk.Button(f1, text="🛒 Alış Faturaları\n(Otomatik Filtre)", bg="#2980b9", fg="white", font=("Segoe UI", 10, "bold"), cursor="hand2", command=lambda: self.apply("alis")).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2, ipady=5)
        tk.Button(f1, text="💰 Satış Faturaları\n(Otomatik Filtre)", bg="#e67e22", fg="white", font=("Segoe UI", 10, "bold"), cursor="hand2", command=lambda: self.apply("satis")).pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=2, ipady=5)
        
        f2 = tk.Frame(self, bg="#f3f2f1")
        f2.pack(fill=tk.X, padx=15, pady=5)
        tk.Button(f2, text="🧾 Boş Fatura Pivotu", bg="#7f8c8d", fg="white", font=("Segoe UI", 9), cursor="hand2", command=lambda: self.apply("bos_f")).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2, ipady=3)
        tk.Button(f2, text="📖 Boş Yevmiye Pivotu", bg="#7f8c8d", fg="white", font=("Segoe UI", 9), cursor="hand2", command=lambda: self.apply("bos_y")).pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=2, ipady=3)
        
        tk.Button(self, text="🔀 İkili Çalışma Ekranı (Boş)", bg="#8e44ad", fg="white", font=("Segoe UI", 10, "bold"), cursor="hand2", command=lambda: self.apply("dual")).pack(fill=tk.X, padx=17, pady=10, ipady=5)

    def save_and_close(self):
        """Kullanıcı kaydetmek isterse bu menüyü kapatıp Kayıt Ekranını açar."""
        self.destroy()
        self.pivot_frame.save_template()

    def apply(self, mode):
        """Seçilen senaryoyu çalıştırır."""
        self.destroy()
        self.pivot_frame.apply_new_scenario(mode)



class MergedResultWindow(tk.Toplevel):
    def __init__(self, parent, df):
        super().__init__(parent)
        self.title("🔀 Birleştirilmiş Çapraz Sonuç Tablosu")
        self.geometry("1100x600")
        self.configure(bg="#f3f2f1")
        self.df = df
        
        self.setup_ui()

    def setup_ui(self):
        tb = tk.Frame(self, bg="white", pady=8)
        tb.pack(fill=tk.X)
        tk.Button(tb, text="📥 Excel'e Aktar", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=15, cursor="hand2", command=self.export_excel).pack(side=tk.LEFT, padx=10)

        tree_frame = tk.Frame(self, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        style = ttk.Style()
        style.configure("Merge.Treeview", rowheight=28, font=("Segoe UI", 10))
        style.configure("Merge.Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#d9e1f2")
        
        self.tree = ttk.Treeview(tree_frame, columns=list(self.df.columns), show="headings", style="Merge.Treeview")
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(fill=tk.BOTH, expand=True)

        for col in self.df.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=150)

        # NaN değerleri temizle ve sayıları düzenle
        for _, row in self.df.iterrows():
            vals = []
            for v in row:
                if pd.isna(v): 
                    vals.append("")
                elif isinstance(v, (float, np.floating)):
                    if float(v).is_integer(): vals.append(str(int(v)))
                    else: vals.append(f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
                else:
                    vals.append(str(v))
            self.tree.insert("", "end", values=vals)

    def export_excel(self):
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Dosyası", "*.xlsx")], parent=self)
        if path:
            self.df.to_excel(path, index=False)
            os.startfile(path)