import os
import sqlite3
import pandas as pd
import sys
import json
from tkinter import simpledialog
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
from config import get_mukellefler_dir
from utils.session_db import get_last_session

class PivotEngine:
    def __init__(self, vkn=None, yil=None):
        self.vkn = vkn
        self.yil = yil
        
        self.parquet_path = None
        self.yevmiye_db_path = None
        self.fatura_db_path = None
        
        self.yevmiye_db = None
        self.fatura_db = None
        
        self.status_msg = "Hazırlanıyor..."
        
        # === 1. YEVMİYE DEFTERİ ALANLARI ===
        self.y_map = {
            "VKN": "(Y) VKN",
            "Unvan": "(Y) Ünvan",
            "YevmiyeNo": "(Y) Yevmiye No",
            "SatirNo": "(Y) Satır No",
            "KayitTarihi": "(Y) Tarih",
            "BelgeNo": "(Y) Belge No",
            "FisAciklamasi": "(Y) Fiş Açıklama",
            "DetayAciklama": "(Y) Detay Açıklama",
            "HesapKodu": "(Y) Hesap Kodu",
            "HesapAdi": "(Y) Hesap Adı",
            "MuavinKodu": "(Y) Muavin Kodu",
            "MuavinAdi": "(Y) Muavin Adı",
            "Borc": "(Y) Borç",
            "Alacak": "(Y) Alacak",
            "KaynakDosya": "(Y) Kaynak Dosya",
            "GunlukBakiye": "(Y) Günlük Bakiye",
            "AdatTutar": "(Y) Adat Tutar",
            "KalanBakiye": "(Y) Kalan Bakiye",
            "GunSayisi": "(Y) Gün Sayısı",
            "FaizOrani": "(Y) Faiz Oranı",
            "AdatSiniri": "(Y) Adat Sınırı"
        }
        
        # === 2. FATURA ALANLARI (50 SÜTUNLUK YENİ YAPI) ===
        self.f_map = {
            "TUR_FATURA": "(F) Fatura Türü",
            "TIP_FATURA": "(F) Fatura Tipi",
            "NO_FATURA": "(F) Fatura No",
            "TARIH_FATURA": "(F) Tarih",
            "FaturaUUID": "(F) Fatura UUID",
            "SATICI_VKN_TCKN": "(F) Satıcı VKN/TCKN",
            "SATICI_KURUM": "(F) Satıcı Kurum",
            "SATICI_ŞAHIS": "(F) Satıcı Şahıs",
            "ALICI_VKN_TCKN": "(F) Alıcı VKN/TCKN",
            "ALICI_KURUM": "(F) Alıcı Kurum",
            "ALICI_ŞAHIS": "(F) Alıcı Şahıs",
            "MAL_HIZMET_CINSI": "(F) Mal/Hizmet Cinsi",
            "PARA_KODU": "(F) Para Birimi",
            "DOVIZ_KURU": "(F) Döviz Kuru",
            "FIYAT_BR": "(F) Birim Fiyat",
            "BR": "(F) Birim",
            "MIKTAR": "(F) Miktar",
            "TUTAR": "(F) Tutar (Matrah)",
            "MIKTAR_BEYAN": "(F) Miktar Beyan",
            "BR_BEYAN": "(F) Birim Beyan",
            "OTV_MATRAH_KLM": "(F) ÖTV Matrahı (Kalem)",
            "OTV_KLM": "(F) ÖTV Tutarı (Kalem)",
            "KDV_MATRAH_KLM": "(F) KDV Matrahı (Kalem)",
            "KDV_KLM": "(F) KDV Tutarı (Kalem)",
            "OTV_ORANI_KLM": "(F) ÖTV Oranı (Kalem)",
            "KDV_ORANI_KLM": "(F) KDV Oranı (Kalem)",
            "MAL_HIZMET_TOP": "(F) Mal Hizmet Toplamı",
            "TOP_KDV_OTV_HARIC_TUTAR": "(F) KDV ÖTV Hariç Tutar",
            "TOP_OTV_TUTAR": "(F) Toplam ÖTV",
            "TOP_OTV_MATRAHI": "(F) Toplam ÖTV Matrahı",
            "TOP_KDV_TUTAR": "(F) Toplam KDV",
            "TOP_TEVKIFAT_TUTAR": "(F) Toplam Tevkifat",
            "KalemNotUUID": "(F) Kalem Not UUID",
            "TOP_ÖİV_TUTAR": "(F) Toplam ÖİV",
            "TOP_ÖİV_MATRAHI": "(F) Toplam ÖİV Matrahı",
            "TOP_ELKHAVAGAZTÜKVER_TUTAR": "(F) Top. Elk/Havagaz Vergi",
            "TOP_ELKHAVAGAZTÜKVER_MATRAHI": "(F) Top. Elk/Havagaz Matrahı",
            "TOP_503ÖİV_TUTAR": "(F) Top. 503 ÖİV",
            "TOP_503ÖİV_MATRAHI": "(F) Top. 503 ÖİV Matrahı",
            "TOP_ELK_TUK_VER_TUTAR": "(F) Top. Elk. Tük. Vergisi",
            "TOP_ELK_TUK_VER_MATRAHI": "(F) Top. Elk. Tük. Matrahı",
            "TOP_TK_KULLANIM_TUTAR": "(F) Top. TK Kullanım",
            "TOP_TK_KULLANIM_MATRAHI": "(F) Top. TK Kull. Matrahı",
            "TOP_VERGI_TUTAR": "(F) Toplam Vergi",
            "TOP_VERGİLER_DAHIL_TUTAR": "(F) Vergiler Dahil Toplam",
            "ISKONTO": "(F) İskonto",
            "BINDIRIM": "(F) Bindirim",
            "TOPLAM_TUTAR": "(F) Ödenecek Tutar",
            "KalemNo": "(F) Kalem No",
            "T_DEF_INDEX": "(F) Tevkifat Kodu",
            "ETTN": "(F) ETTN",
            "DOSYA_YOLU": "(F) Dosya Yolu"
        }
        
        self.setup_paths()
        
        if self.parquet_path and self.yevmiye_db_path:
            self.ensure_yevmiye_db_exists()
            
        if self.yevmiye_db_path and os.path.exists(self.yevmiye_db_path):
            self.yevmiye_db = self.yevmiye_db_path
            
        if self.fatura_db_path and os.path.exists(self.fatura_db_path):
            self.fatura_db = self.fatura_db_path

    def setup_paths(self):
        if not self.vkn or not self.yil:
            session = get_last_session()
            if session:
                self.vkn = session.get('vkn')
                self.yil = session.get('yil')

        if not self.vkn or str(self.vkn) == "---":
            self.status_msg = "Mükellef seçilmedi."
            return

        base_dir = get_mukellefler_dir()
        target_folder = None
        
        if os.path.exists(base_dir):
            for f in os.listdir(base_dir):
                if str(f).endswith(f"-{str(self.vkn)}"):
                    target_folder = os.path.join(base_dir, f)
                    break
        
        if target_folder:
            yil_dir = os.path.join(target_folder, str(self.yil))
            self.parquet_path = os.path.join(yil_dir, f"{self.yil}_FULL.parquet")
            self.yevmiye_db_path = os.path.join(yil_dir, f"{self.yil}_YEVMIYE.db")
            self.fatura_db_path = os.path.join(yil_dir, f"fatura_data_{self.yil}.db")
            self.status_msg = "Yollar ayarlandı."
        else:
            self.status_msg = "Mükellef klasörü bulunamadı."

    def ensure_yevmiye_db_exists(self):
        if os.path.exists(self.yevmiye_db_path): return
        if not os.path.exists(self.parquet_path):
            self.status_msg = "Kaynak Parquet dosyası yok, DB oluşturulamadı."
            return

        try:
            self.status_msg = "Yevmiye veritabanı oluşturuluyor..."
            df = pd.read_parquet(self.parquet_path)
            df.columns = [c.replace(" ", "") for c in df.columns]
            
            conn = sqlite3.connect(self.yevmiye_db_path)
            df.to_sql('yevmiye', conn, if_exists='replace', index=False)
            conn.commit()
            conn.close()
            self.status_msg = "Yevmiye Veritabanı Oluşturuldu."
        except Exception as e:
            self.status_msg = f"DB Oluşturma Hatası: {e}"

    def get_columns(self):
        cols = {"Yevmiye": [], "Fatura": []}
        
        if self.yevmiye_db:
            try:
                conn = sqlite3.connect(self.yevmiye_db)
                cur = conn.cursor()
                cur.execute("SELECT * FROM yevmiye LIMIT 1")
                db_cols = [desc[0] for desc in cur.description]
                conn.close()
                cols["Yevmiye"] = [self.y_map[c] for c in db_cols if c in self.y_map]
            except:
                cols["Yevmiye"] = list(self.y_map.values())
                
        if self.fatura_db:
            try:
                conn = sqlite3.connect(self.fatura_db)
                cur = conn.cursor()
                cur.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
                res = cur.fetchone()
                if res:
                    tbl = res[0]
                    cur.execute(f"SELECT * FROM {tbl} LIMIT 1")
                    db_cols = [desc[0] for desc in cur.description]
                    cols["Fatura"] = [self.f_map[c] for c in db_cols if c in self.f_map]
                conn.close()
            except:
                cols["Fatura"] = list(self.f_map.values())
                
        return cols

    def get_unique_values(self, column_name):
        try:
            if column_name.startswith("(Y)"):
                if not self.yevmiye_db: return []
                db_col = [k for k, v in self.y_map.items() if v == column_name][0]
                conn = sqlite3.connect(self.yevmiye_db)
                query = f'SELECT DISTINCT "{db_col}" FROM yevmiye ORDER BY "{db_col}" LIMIT 1000'
            elif column_name.startswith("(F)"):
                if not self.fatura_db: return []
                db_col = [k for k, v in self.f_map.items() if v == column_name][0]
                conn = sqlite3.connect(self.fatura_db)
                c = conn.cursor()
                c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
                res = c.fetchone()
                if not res: return []
                tbl = res[0]
                query = f'SELECT DISTINCT "{db_col}" FROM {tbl} ORDER BY "{db_col}" LIMIT 1000'
            else: return []
            
            cursor = conn.cursor()
            cursor.execute(query)
            values = [row[0] for row in cursor.fetchall() if row[0] is not None]
            conn.close()
            return values
        except: return []

    def calculate_pivot(self, rows, cols, values, filters={}, agg_func='Toplam', show_totals=True, date_format="Normal"):
        if not values and not rows and not cols: return pd.DataFrame() 

        all_req = rows + cols + values + list(filters.keys())
        # Sadece hangisine ihtiyaç varsa onu bul
        needs_y = any(c.startswith("(Y)") for c in all_req)
        needs_f = any(c.startswith("(F)") for c in all_req)

        df = pd.DataFrame()

        try:
            # === SADECE YEVMİYE İŞLEMİ ===
            if needs_y and self.yevmiye_db:
                y_filters = {k: v for k, v in filters.items() if k.startswith("(Y)") and v}
                where_clauses = []
                for ui_col, vals in y_filters.items():
                    db_col = [k for k, v in self.y_map.items() if v == ui_col][0]
                    vals_str = ", ".join([f"'{str(v)}'" for v in vals])
                    where_clauses.append(f'"{db_col}" IN ({vals_str})')
                
                where_str = " WHERE " + " AND ".join(where_clauses) if where_clauses else ""
                conn = sqlite3.connect(self.yevmiye_db)
                df = pd.read_sql_query(f"SELECT * FROM yevmiye{where_str}", conn)
                conn.close()
                
                df.rename(columns=self.y_map, inplace=True)
                df = df[[c for c in df.columns if c in self.y_map.values()]]

            # === SADECE FATURA İŞLEMİ ===
            elif needs_f and self.fatura_db:
                f_filters = {k: v for k, v in filters.items() if k.startswith("(F)") and v}
                conn = sqlite3.connect(self.fatura_db)
                c = conn.cursor()
                c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
                tbl = c.fetchone()
                if tbl:
                    where_clauses = []
                    for ui_col, vals in f_filters.items():
                        db_col = [k for k, v in self.f_map.items() if v == ui_col][0]
                        vals_str = ", ".join([f"'{str(v)}'" for v in vals])
                        where_clauses.append(f'"{db_col}" IN ({vals_str})')
                    
                    where_str = " WHERE " + " AND ".join(where_clauses) if where_clauses else ""
                    df = pd.read_sql_query(f"SELECT * FROM {tbl[0]}{where_str}", conn)
                    df.rename(columns=self.f_map, inplace=True)
                    df = df[[c for c in df.columns if c in self.f_map.values()]]

                    # Fatura başlık toplamlarını çoklama sorunu çözümü
                    df['rn'] = df.groupby('(F) Fatura No').cumcount()
                    header_num_cols = [
                        '(F) Mal Hizmet Toplamı', '(F) KDV ÖTV Hariç Tutar', '(F) Toplam ÖTV',
                        '(F) Toplam KDV', '(F) Vergiler Dahil Toplam', '(F) Ödenecek Tutar'
                    ]
                    for col in header_num_cols:
                        if col in df.columns: df.loc[df['rn'] > 0, col] = 0.0
                    df.drop(columns=['rn'], inplace=True)
                conn.close()
            else:
                return pd.DataFrame()

            if df.empty: return pd.DataFrame()

            # --- Tarih Formatlama ve Boşluk Doldurma (Aynı Mantık) ---
            # --- Tarih Formatlama ve Boşluk Doldurma ---
            for col in df.columns:
                if "Tarih" in col:
                    df[col] = pd.to_datetime(df[col], errors="coerce")
                    if date_format == "Aylık": 
                        df[col] = df[col].dt.strftime('%Y-%m') 
                    elif date_format == "3 Aylık":
                        # Çeyreklik (Quarter) formatı: 2024Q1, 2024Q2 şeklinde dönüştürür
                        df[col] = df[col].dt.to_period("Q").astype(str).replace("NaT", "(Boş)")
                    elif date_format == "Yıllık": 
                        df[col] = df[col].dt.strftime('%Y')
                    else: 
                        df[col] = df[col].dt.strftime('%d.%m.%Y')
            
            if rows or cols:
                for dim in (rows + cols):
                    if dim in df.columns: df[dim] = df[dim].fillna("(Boş)")
            if values:
                for v_col in values:
                    if v_col in df.columns: df[v_col] = pd.to_numeric(df[v_col], errors='coerce').fillna(0.0)

            # --- PİVOT HESAPLAMA ---
            pivot_df = pd.pivot_table(
                df, index=rows if rows else None, columns=cols if cols else None, 
                values=values if values else None, aggfunc='sum', fill_value=0,
                margins=show_totals, margins_name='Genel Toplam'
            )
            
            if isinstance(pivot_df.columns, pd.MultiIndex):
                pivot_df.columns = [col[0] if col[1] == '' else f"{col[1]} ({col[0]})" for col in pivot_df.columns]

            return pivot_df.reset_index()
            
        except Exception as e:
            return str(e)