import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
import sqlite3
import pandas as pd
import numpy as np
import tkinter.font as tkfont
import re

# Matplotlib Entegrasyonu
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Kendi bağımsız motorunu import ediyoruz
from .engine import PivotEngine

class DegisimAnaliziUI(tk.Frame):
    def __init__(self, parent, pivot_frame_instance=None):
        super().__init__(parent, bg="#f0f4f8")
        
        self.pivot_frame = pivot_frame_instance 
        self.engine = self.pivot_frame.engine if self.pivot_frame else PivotEngine()
        self.json_path = os.path.join(os.path.dirname(__file__), "pivot_templates.json")
        
        self.current_df = None
        self.global_vars = {} 
        self.rows_data = []
        self.mevcut_deger_float = 0.0
        
        self.setup_ui()
        self.load_templates_to_combo1()

    def setup_ui(self):
        self.paned = tk.PanedWindow(self, orient=tk.HORIZONTAL, sashwidth=4, bg="#dcdde1")
        self.paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # =========================================================
        # --- SOL PANEL (KONTROL VE SLIDER MERKEZİ) ---
        # =========================================================
        self.left_panel = tk.Frame(self.paned, bg="#ffffff", width=320, highlightbackground="#e1e8ed", highlightthickness=1)
        self.paned.add(self.left_panel, minsize=300)
        
        header_lbl = tk.Label(self.left_panel, text="Simülasyon Paneli", bg="#3498db", fg="white", font=("Segoe UI", 12, "bold"), pady=10)
        header_lbl.pack(fill=tk.X)
        
        # 1. Tablo Seçimi
        frame_tablo = tk.Frame(self.left_panel, bg="#ffffff", padx=15, pady=10)
        frame_tablo.pack(fill=tk.X)
        tk.Label(frame_tablo, text="Tablo Seçiniz", bg="#ffffff", fg="black", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.combo_tablo_var = tk.StringVar()
        self.combo_tablo = ttk.Combobox(frame_tablo, textvariable=self.combo_tablo_var, state="readonly", font=("Segoe UI", 9))
        self.combo_tablo.pack(fill=tk.X, pady=5)
        self.combo_tablo.bind("<<ComboboxSelected>>", self.on_tablo_select)

        ttk.Separator(self.left_panel, orient="horizontal").pack(fill=tk.X, padx=15)

        # 2. Değişim Tipi
        frame_tip = tk.Frame(self.left_panel, bg="#ffffff", padx=15, pady=10)
        frame_tip.pack(fill=tk.X)
        self.degisim_tipi = tk.StringVar(value="Oran")
        
        rb_oran = tk.Radiobutton(frame_tip, text="Oransal Değişim (%)", variable=self.degisim_tipi, value="Oran", bg="#ffffff", fg="black", font=("Segoe UI", 9), command=self.on_tip_degisimi)
        rb_oran.pack(anchor="w")
        rb_tutar = tk.Radiobutton(frame_tip, text="Tutar (Net Değer)", variable=self.degisim_tipi, value="Tutar", bg="#ffffff", fg="black", font=("Segoe UI", 9), command=self.on_tip_degisimi)
        rb_tutar.pack(anchor="w")

        # 3. Hesap Kodu Seçimi
        frame_degisken = tk.Frame(self.left_panel, bg="#ffffff", padx=15, pady=10)
        frame_degisken.pack(fill=tk.X)
        tk.Label(frame_degisken, text="Hesap Kodu Seçiniz", bg="#ffffff", fg="black", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.combo_degisken_var = tk.StringVar()
        self.combo_degisken = ttk.Combobox(frame_degisken, textvariable=self.combo_degisken_var, state="readonly", font=("Segoe UI", 9))
        self.combo_degisken.pack(fill=tk.X, pady=5)
        self.combo_degisken.bind("<<ComboboxSelected>>", self.on_degisken_select)
        
        self.lbl_mevcut_deger = tk.Label(frame_degisken, text="Mevcut: 0,00", bg="#ffffff", fg="black", font=("Segoe UI", 8))
        self.lbl_mevcut_deger.pack(anchor="w")

        # 4. Slider ve Limitler
        frame_slider = tk.Frame(self.left_panel, bg="#ffffff", padx=15, pady=10)
        frame_slider.pack(fill=tk.X)
        
        limits_frame = tk.Frame(frame_slider, bg="#ffffff")
        limits_frame.pack(fill=tk.X)
        
        tk.Label(limits_frame, text="Alt Limit", bg="#ffffff", fg="black", font=("Segoe UI", 8)).pack(side=tk.LEFT)
        self.entry_alt_limit = tk.Entry(limits_frame, width=8, font=("Segoe UI", 9), justify="center", bg="#f4f8fb", fg="black")
        self.entry_alt_limit.pack(side=tk.LEFT, padx=5)
        self.entry_alt_limit.insert(0, "-100")
        self.entry_alt_limit.bind("<KeyRelease>", self.on_limit_change)
        
        self.entry_ust_limit = tk.Entry(limits_frame, width=8, font=("Segoe UI", 9), justify="center", bg="#f4f8fb", fg="black")
        self.entry_ust_limit.pack(side=tk.RIGHT, padx=5)
        self.entry_ust_limit.insert(0, "100")
        self.entry_ust_limit.bind("<KeyRelease>", self.on_limit_change)
        tk.Label(limits_frame, text="Üst Limit", bg="#ffffff", fg="black", font=("Segoe UI", 8)).pack(side=tk.RIGHT)
        
        self.slider_var = tk.DoubleVar()
        self.slider = ttk.Scale(frame_slider, from_=-100, to=100, orient="horizontal", variable=self.slider_var, command=self.on_slider_move)
        self.slider.pack(fill=tk.X, pady=10)

        # 5. Değer Giriş Alanı
        frame_girdi = tk.Frame(self.left_panel, bg="#ffffff", padx=15, pady=5)
        frame_girdi.pack(fill=tk.X)
        tk.Label(frame_girdi, text="Değer / Yüzde:", bg="#ffffff", fg="black", font=("Segoe UI", 9)).pack(side=tk.LEFT)
        self.entry_yeni = tk.Entry(frame_girdi, font=("Segoe UI", 10, "bold"), fg="black", width=12, justify="right")
        self.entry_yeni.pack(side=tk.RIGHT)
        self.entry_yeni.bind("<KeyRelease>", self.on_entry_type)

        # 6. Uygula ve Sıfırla Butonları
        frame_btn = tk.Frame(self.left_panel, bg="#ffffff", padx=15, pady=10)
        frame_btn.pack(fill=tk.X)
        self.btn_uygula = tk.Button(frame_btn, text="Uygula", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=5, pady=8, cursor="hand2", command=self.hesapla_global_senaryo)
        self.btn_uygula.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        self.btn_sifirla = tk.Button(frame_btn, text="Sıfırla", bg="#e74c3c", fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=5, pady=8, cursor="hand2", command=self.sifirla)
        self.btn_sifirla.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(5, 0))

        # 7. Görünüm Tipi (Sade / Detaylı)
        frame_gorunum = tk.Frame(self.left_panel, bg="#f8f9fa", highlightbackground="#e1e8ed", highlightthickness=1, padx=10, pady=5)
        frame_gorunum.pack(fill=tk.X, padx=15, pady=5)
        tk.Label(frame_gorunum, text="Tablo Görünümü:", bg="#f8f9fa", fg="black", font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0,5))
        
        self.gorunum_tipi = tk.StringVar(value="Sade")
        tk.Radiobutton(frame_gorunum, text="Sadece Sonuçları Göster", variable=self.gorunum_tipi, value="Sade", bg="#f8f9fa", fg="black", font=("Segoe UI", 9), command=self.on_gorunum_degisimi).pack(anchor="w")
        tk.Radiobutton(frame_gorunum, text="Tüm Hesaplama Detayları", variable=self.gorunum_tipi, value="Detayli", bg="#f8f9fa", fg="black", font=("Segoe UI", 9), command=self.on_gorunum_degisimi).pack(anchor="w")

        # =========================================================
        # --- SAĞ PANEL (GRAFİK VE TABLO GÖRÜNÜMÜ) ---
        # =========================================================
        self.right_panel = tk.Frame(self.paned, bg="#f0f4f8")
        self.paned.add(self.right_panel, minsize=600)
        
        # --- GRAFİK ALANI ---
        self.chart_frame = tk.Frame(self.right_panel, bg="#ffffff", highlightbackground="#e1e8ed", highlightthickness=1)
        self.chart_frame.pack(fill=tk.BOTH, expand=True, padx=(10, 0), pady=(0, 5))
        
        chart_header = tk.Frame(self.chart_frame, bg="#ffffff", pady=10, padx=15)
        chart_header.pack(fill=tk.X)
        tk.Label(chart_header, text="Duyarlılık Analizi", bg="#ffffff", fg="black", font=("Segoe UI", 12, "bold")).pack(side=tk.LEFT)
        
        # --- DIŞA AKTAR BUTONLARI ---
        export_frame = tk.Frame(chart_header, bg="#ffffff")
        export_frame.pack(side=tk.RIGHT, padx=(20, 0))

        self.btn_pdf = tk.Button(export_frame, text="📄 PDF Çıktısı", bg="#c0392b", fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=10, pady=3, cursor="hand2", command=self.export_to_pdf)
        self.btn_pdf.pack(side=tk.RIGHT, padx=5)

        self.btn_excel = tk.Button(export_frame, text="📊 Excel'e Aktar", bg="#27ae60", fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=10, pady=3, cursor="hand2", command=self.export_to_excel)
        self.btn_excel.pack(side=tk.RIGHT, padx=5)

        # Lejant
        legend_frame = tk.Frame(chart_header, bg="#ffffff")
        legend_frame.pack(side=tk.RIGHT)
        tk.Label(legend_frame, text="■", fg="#2ecc71", bg="#ffffff", font=("Segoe UI", 12)).pack(side=tk.LEFT)
        tk.Label(legend_frame, text="Pozitif Etki", bg="#ffffff", fg="black", font=("Segoe UI", 8)).pack(side=tk.LEFT, padx=(0,10))
        tk.Label(legend_frame, text="■", fg="#f1c40f", bg="#ffffff", font=("Segoe UI", 12)).pack(side=tk.LEFT)
        tk.Label(legend_frame, text="Nötr Etki", bg="#ffffff", fg="black", font=("Segoe UI", 8)).pack(side=tk.LEFT, padx=(0,10))
        tk.Label(legend_frame, text="■", fg="#e74c3c", bg="#ffffff", font=("Segoe UI", 12)).pack(side=tk.LEFT)
        tk.Label(legend_frame, text="Negatif Etki", bg="#ffffff", fg="black", font=("Segoe UI", 8)).pack(side=tk.LEFT)

        self.fig = Figure(figsize=(8, 3), dpi=100)
        self.fig.patch.set_facecolor('#ffffff')
        self.ax = self.fig.add_subplot(111)
        self.ax.spines['top'].set_visible(False)
        self.ax.spines['right'].set_visible(False)
        self.ax.tick_params(axis='x', colors='black')
        self.ax.tick_params(axis='y', colors='black')
        self.ax.axvline(0, color='#bdc3c7', linewidth=1)
        
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.chart_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # --- TABLO ALANI ---
        self.table_frame = tk.Frame(self.right_panel, bg="#ffffff", highlightbackground="#e1e8ed", highlightthickness=1)
        self.table_frame.pack(fill=tk.BOTH, expand=True, padx=(10, 0), pady=(5, 0))
        
        style = ttk.Style()
        style.configure("Modern.Treeview", rowheight=30, font=("Segoe UI", 9), background="#ffffff", fieldbackground="#ffffff", borderwidth=0, foreground="black")
        style.configure("Modern.Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#f8f9fa", foreground="black")
        
        columns = ("Oran Adı", "Formül", "Değişkenlerin Açılımı", "Sayısal Değerler (Mevcut)", "Formüldeki Sayısal Değerler", "Mevcut Durum", "Yeni Durum", "Değişim Etkisi")
        self.preview_tree = ttk.Treeview(self.table_frame, show="headings", columns=columns, style="Modern.Treeview")
        
        for col in columns:
            self.preview_tree.heading(col, text=col)
            
        self.preview_tree.configure(displaycolumns=("Oran Adı", "Mevcut Durum", "Yeni Durum", "Değişim Etkisi"))
        
        self.preview_tree.column("Oran Adı", width=150, anchor="w")
        self.preview_tree.column("Formül", width=150, anchor="w")
        self.preview_tree.column("Değişkenlerin Açılımı", width=200, anchor="w")
        self.preview_tree.column("Sayısal Değerler (Mevcut)", width=250, anchor="w")
        self.preview_tree.column("Formüldeki Sayısal Değerler", width=150, anchor="w")
        self.preview_tree.column("Mevcut Durum", width=100, anchor="center")
        self.preview_tree.column("Yeni Durum", width=100, anchor="center")
        self.preview_tree.column("Değişim Etkisi", width=100, anchor="center")
        
        self.preview_tree.tag_configure('even', background='#ffffff')
        self.preview_tree.tag_configure('odd', background='#f8f9fa')
        self.preview_tree.tag_configure('positive', background='#e8f8f5', foreground='#27ae60') 
        self.preview_tree.tag_configure('negative', background='#fdedec', foreground='#c0392b') 
        self.preview_tree.tag_configure('neutral', background='#fef9e7', foreground='#d35400') 

       # Dikey Kaydırma Çubuğu (Mevcut)
        self.vsb = ttk.Scrollbar(self.table_frame, orient="vertical", command=self.preview_tree.yview)
        self.vsb.pack(side=tk.RIGHT, fill=tk.Y)

        # Yatay Kaydırma Çubuğu (Yeni)
        self.hsb = ttk.Scrollbar(self.table_frame, orient="horizontal", command=self.preview_tree.xview)
        self.hsb.pack(side=tk.BOTTOM, fill=tk.X)

        # İki scrollbar'ı da Treeview'a bağlama
        self.preview_tree.configure(yscrollcommand=self.vsb.set, xscrollcommand=self.hsb.set)
        self.preview_tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    # =========================================================================
    # KONTROL VE SLIDER MANTIĞI
    # =========================================================================

    def on_gorunum_degisimi(self):
        tip = self.gorunum_tipi.get()
        if tip == "Sade":
            self.preview_tree.configure(displaycolumns=("Oran Adı", "Mevcut Durum", "Yeni Durum", "Değişim Etkisi"))
        else:
            self.preview_tree.configure(displaycolumns="#all")

    def on_limit_change(self, event=None):
        try:
            alt = float(self.entry_alt_limit.get().replace(',', '.'))
            ust = float(self.entry_ust_limit.get().replace(',', '.'))
            if alt < ust:
                self.slider.config(from_=alt, to=ust)
        except ValueError:
            pass

    def to_float(self, tr_str):
        try:
            return float(str(tr_str).replace('.', '').replace(',', '.'))
        except:
            return 0.0

    def format_tr_number(self, number):
        return f"{number:,.2f}".translate(str.maketrans(',.', '.,'))

    def on_tip_degisimi(self):
        tip = self.degisim_tipi.get()
        if tip == "Oran":
            self.entry_alt_limit.delete(0, tk.END)
            self.entry_alt_limit.insert(0, "-100")
            self.entry_ust_limit.delete(0, tk.END)
            self.entry_ust_limit.insert(0, "100")
            self.slider.config(from_=-100, to=100)
            self.slider_var.set(0)
            self.entry_yeni.delete(0, tk.END)
            self.entry_yeni.insert(0, "0")
        else:
            max_val = self.mevcut_deger_float * 2 if self.mevcut_deger_float > 0 else 1000000
            self.entry_alt_limit.delete(0, tk.END)
            self.entry_alt_limit.insert(0, "0")
            self.entry_ust_limit.delete(0, tk.END)
            self.entry_ust_limit.insert(0, str(int(max_val)))
            self.slider.config(from_=0, to=max_val)
            self.slider_var.set(self.mevcut_deger_float)
            self.entry_yeni.delete(0, tk.END)
            self.entry_yeni.insert(0, self.format_tr_number(self.mevcut_deger_float))
        
        self.hesapla_global_senaryo()

    def on_slider_move(self, val):
        tip = self.degisim_tipi.get()
        v = float(val)
        self.entry_yeni.delete(0, tk.END)
        if tip == "Oran":
            self.entry_yeni.insert(0, f"{v:.1f}")
        else:
            self.entry_yeni.insert(0, self.format_tr_number(v))
        
        self.hesapla_global_senaryo() 

    def on_entry_type(self, event):
        tip = self.degisim_tipi.get()
        val_str = self.entry_yeni.get()
        if not val_str: return
        
        if tip == "Oran":
            try:
                v = float(val_str.replace(',', '.'))
                if -100 <= v <= 100: self.slider_var.set(v)
            except: pass
        else:
            v = self.to_float(val_str)
            self.slider_var.set(v)
            
        self.hesapla_global_senaryo() 

    def on_degisken_select(self, event=None):
        degisken = self.combo_degisken_var.get()
        if not degisken or degisken not in self.global_vars: return
        
        guncel_deger_str = self.global_vars[degisken]
        self.mevcut_deger_float = self.to_float(guncel_deger_str)
        self.lbl_mevcut_deger.config(text=f"Mevcut Değer: {guncel_deger_str} TL")
        
        self.on_tip_degisimi() 

    # =========================================================================
    # VERİ YÜKLEME VE PARSE İŞLEMLERİ
    # =========================================================================

    def load_templates_to_combo1(self):
        self.combo_tablo['values'] = []
        if not os.path.exists(self.json_path): return
        try:
            with open(self.json_path, "r", encoding="utf-8") as f:
                self.templates = json.load(f)
            
            # Sadece adında "Duyarlilik Analizi" veya "Duyarlılık Analizi" geçenleri filtrele
            t_names = sorted([
                isim for isim in self.templates.keys() 
                if "duyarlilik analizi" in isim.lower() or "duyarlılık analizi" in isim.lower()
            ])
            
            self.combo_tablo['values'] = t_names
            
            if t_names: 
                self.combo_tablo.set("Bir tablo seçin...")
            else:
                self.combo_tablo.set("Uygun tablo bulunamadı.") # Eğer kriteri sağlayan tablo yoksa
        except Exception as e: 
            print(f"Tablolar yüklenirken hata oluştu: {e}")

    def on_tablo_select(self, event=None):
        item_id = self.combo_tablo_var.get()
        if not item_id or item_id not in self.templates: return
        t_data = self.templates[item_id]
        config = t_data.get("config", t_data) if isinstance(t_data, dict) else t_data
        
        try:
            if config.get("is_script"):
                source = config.get("script_source")
                code = config.get("script_code")
                raw_df = pd.DataFrame()
                
                if source == "Yevmiye" and self.engine.yevmiye_db:
                    conn = sqlite3.connect(self.engine.yevmiye_db)
                    raw_df = pd.read_sql_query("SELECT * FROM yevmiye", conn)
                    raw_df.rename(columns=self.engine.y_map, inplace=True)
                    conn.close()
                elif source == "Faturalar" and self.engine.fatura_db:
                    conn = sqlite3.connect(self.engine.fatura_db)
                    c = conn.cursor()
                    c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
                    tbl = c.fetchone()
                    if tbl:
                        raw_df = pd.read_sql_query(f"SELECT * FROM {tbl[0]}", conn)
                        raw_df.rename(columns=self.engine.f_map, inplace=True)
                    conn.close()
                    
                local_vars = {'df': raw_df, 'pd': pd, 'np': np}
                exec(code, {}, local_vars)
                df_result = local_vars.get('df_result')
                
                if df_result is not None:
                    self.current_df = df_result.copy()
                    self.parse_variables_from_df(df_result)
            else:
                df_result = self.engine.calculate_pivot(
                    config.get("rows", []), config.get("cols", []), config.get("vals", []),
                    config.get("active_filters", {}), show_totals=config.get("show_totals", True)
                )
                if not isinstance(df_result, str) and not df_result.empty:
                    self.current_df = df_result.copy()
                    self.parse_variables_from_df(df_result)
        except Exception as e:
            messagebox.showerror("Hata", str(e))

    def _get_cleaned_tokens(self, text):
        c = text.replace("(-)", "___MINUS___")
        headers = ["KVYK", "UVYK", "Yab. Kaynak", "Özkaynaklar", "Gelirler", "Giderler", "Net Kar", "Kar Yedekleri", "Geç. Karları"]
        for h in headers: c = c.replace(h, "")
        for ch in ['[', ']', '(', ')', '{', '}']: c = c.replace(ch, '|')
        for op in [' + ', ' - ', ' / ', ' * ']: c = c.replace(op, '|')
        return [t.strip().replace("___MINUS___", "(-)") for t in c.split('|') if t.strip()]


    def parse_variables_from_df(self, df):
        self.global_vars.clear()
        self.rows_data.clear()
        self.combo_degisken.set('')
        self.combo_degisken['values'] = []
        
        self.preview_tree.delete(*self.preview_tree.get_children())
        self.ax.clear()
        self.canvas.draw()
        
        col_isim = next((c for c in df.columns if "AÇILIMI" in c.upper() or "İSİM" in c.upper()), None)
        col_sayi = next((c for c in df.columns if "SAYISAL DEĞERİ" in c.upper() or ("AÇILIM" in c.upper() and "SAYI" in c.upper())), None)
        col_hesap = next((c for c in df.columns if "FORMÜLDEKİ" in c.upper()), None)
        col_sonuc = next((c for c in df.columns if "ORAN" in c.upper() and "/" in c.upper()), None)
        col_ad = next((c for c in df.columns if "AD" in c.upper()), None)
        col_formul = next((c for c in df.columns if "FORMÜL" in c.upper() and "DEĞER" not in c.upper()), None)

        if not (col_isim and col_sayi): return

        # 1. AŞAMA: HAVUZU DOLDUR (Kusursuz satırlardan değişken isimlerini ve değerlerini topluyoruz)
        for i, row in df.iterrows():
            isim_str = str(row.get(col_isim, ""))
            sayi_str = str(row.get(col_sayi, ""))
            if not isim_str or not sayi_str or isim_str == "nan": continue
            
            tkns = self._get_cleaned_tokens(isim_str)
            matches = list(re.finditer(r'\d{1,3}(?:\.\d{3})*,\d{2}', sayi_str))
            
            if len(tkns) == len(matches):
                for j, m in enumerate(matches):
                    if tkns[j] not in self.global_vars:
                        self.global_vars[tkns[j]] = m.group()

        # 2. AŞAMA: TABLOYU ÇİZ VE ŞABLONLARI OLUŞTUR
        for i, row in df.iterrows():
            isim_str = str(row.get(col_isim, ""))
            sayi_str = str(row.get(col_sayi, ""))
            oran_adi = str(row.get(col_ad, f"Oran {i+1}"))
            formul_metni = str(row.get(col_formul, ""))
            hesap_str = str(row.get(col_hesap, ""))
            orj_sonuc = str(row.get(col_sonuc, ""))
            
            if not isim_str or not sayi_str or isim_str == "nan": continue

            # ---> KRİTİK DÜZELTME: Veriyi HİÇBİR KOŞULA BAĞLAMADAN önce tabloya çiziyoruz! (Veri kaybı önlendi)
            iid = self.preview_tree.insert("", "end", values=(oran_adi, formul_metni, isim_str, sayi_str, hesap_str, orj_sonuc, "-", "-"), tags=("even" if i%2==0 else "odd",))

            tkns = self._get_cleaned_tokens(isim_str)
            matches = list(re.finditer(r'\d{1,3}(?:\.\d{3})*,\d{2}', sayi_str))

            row_map = {}
            eval_template_disp = sayi_str
            variables_in_row = []

            # A. Eğer Sıralı Eşleşme Varsa (Kusursuz Satırlar)
            if len(tkns) == len(matches):
                for j in reversed(range(len(matches))):
                    m = matches[j]
                    var_name = tkns[j]
                    start, end = m.span()
                    safe_key = f"var_{j}"
                    row_map[safe_key] = var_name
                    variables_in_row.append(var_name)
                    eval_template_disp = eval_template_disp[:start] + f"{{{safe_key}}}" + eval_template_disp[end:]
            
            # B. Eğer Eşleşme Yoksa (Karmaşık Satırlar için Yedek Plan)
            else:
                for j in reversed(range(len(matches))):
                    m = matches[j]
                    val_str = m.group()
                    # Rakamın kendisinden değişkeni bulmaya çalış
                    matched_var = next((k for k, v in self.global_vars.items() if v == val_str), None)
                    if matched_var:
                        start, end = m.span()
                        safe_key = f"var_{j}"
                        row_map[safe_key] = matched_var
                        variables_in_row.append(matched_var)
                        eval_template_disp = eval_template_disp[:start] + f"{{{safe_key}}}" + eval_template_disp[end:]

            # Hesaplanabilir değişken varsa hafızaya al
            if row_map:
                self.rows_data.append({
                    "iid": iid,
                    "oran_adi": oran_adi,
                    "variables": variables_in_row,
                    "eval_template_disp": eval_template_disp,
                    "row_map": row_map,
                    "orj_sonuc_str": orj_sonuc,
                    "orj_sonuc_float": self.to_float(orj_sonuc.replace('%', '').strip()),
                    "is_percent": "%" in orj_sonuc
                })

        if self.global_vars:
            self.combo_degisken['values'] = sorted(list(self.global_vars.keys()))
    
   # =========================================================================
    # HESAPLAMA VE GRAFİK ÇİZİMİ
    # =========================================================================

    def hesapla_global_senaryo(self):
        degisken = self.combo_degisken_var.get()
        girdi_str = self.entry_yeni.get()
        tip = self.degisim_tipi.get()
        
        if not degisken or not girdi_str or not self.rows_data: return
        
        if tip == "Oran":
            try:
                oran_val = float(girdi_str.replace(',', '.'))
            except:
                oran_val = 0.0
            nihai_deger_float = self.mevcut_deger_float * (1 + (oran_val / 100))
            yeni_deger_str = self.format_tr_number(nihai_deger_float)
        else:
            yeni_deger_str = girdi_str
        
        self.global_vars[degisken] = yeni_deger_str 
        grafik_datalari = []

        for row in self.rows_data:
            if degisken not in row['variables']: continue
                
            row_disp_kwargs = {}
            row_math_kwargs = {}
            
            for safe_key, var_name in row["row_map"].items():
                val_tr = self.global_vars[var_name]
                if var_name == degisken:
                    row_disp_kwargs[safe_key] = f">{val_tr}<" 
                else:
                    row_disp_kwargs[safe_key] = val_tr
                    
                row_math_kwargs[safe_key] = val_tr.replace('.', '').replace(',', '.')

            yeni_sayi_ekrani = row["eval_template_disp"].format(**row_disp_kwargs)
            
            math_str = row["eval_template_disp"].format(**row_math_kwargs)
            math_str = math_str.replace('[', '(').replace(']', ')') 
            
            yeni_hesap = "" 
            
            try:
                if "/" in math_str:
                    parts = math_str.split("/")
                    pay = eval(parts[0])
                    payda = eval(parts[1])
                    sonuc = pay / payda if payda != 0 else 0
                    yeni_hesap = f"{self.format_tr_number(pay)} / {self.format_tr_number(payda)}"
                else:
                    sonuc = eval(math_str)
                    yeni_hesap = f"{self.format_tr_number(sonuc)}"
                
                yeni_oran_str = f"% {self.format_tr_number(sonuc * 100)}" if row["is_percent"] else f"{self.format_tr_number(sonuc)}"
                
                sonuc_carpan = 100 if row["is_percent"] else 1
                fark_float = (sonuc * sonuc_carpan) - row["orj_sonuc_float"]
                
                if fark_float > 0.001:
                    etki_str = f"▲ +{self.format_tr_number(fark_float)}"
                    tag = "positive"
                elif fark_float < -0.001:
                    etki_str = f"▼ {self.format_tr_number(fark_float)}"
                    tag = "negative"
                else:
                    etki_str = "► Değişim Yok"
                    tag = "neutral"

                current_values = list(self.preview_tree.item(row["iid"], "values"))
                
                if len(current_values) >= 8: 
                    current_values[3] = yeni_sayi_ekrani 
                    current_values[4] = yeni_hesap       
                    current_values[6] = yeni_oran_str    
                    current_values[7] = etki_str         
                    
                    self.preview_tree.item(row["iid"], values=current_values, tags=(tag,))
                
                grafik_datalari.append({
                    "isim": row["oran_adi"],
                    "fark": fark_float
                })
                
            except Exception as e:
                pass
                
        self.ciz_duyarlilik_grafigi(grafik_datalari)

    def ciz_duyarlilik_grafigi(self, data):
        self.ax.clear()
        
        self.ax.spines['top'].set_visible(False)
        self.ax.spines['right'].set_visible(False)
        self.ax.axvline(0, color='#bdc3c7', linewidth=1) 
        
        if not data:
            self.canvas.draw()
            return
            
        isimler = []
        degerler = []
        renkler = []
        
        for d in reversed(data):
            isim = d["isim"].split(". ")[-1] if ". " in d["isim"] else d["isim"]
            isim = isim[:20] + ".." if len(isim) > 20 else isim
            isimler.append(isim)
            
            val = d["fark"]
            degerler.append(val)
            
            if val > 0: renkler.append('#2ecc71') 
            elif val < 0: renkler.append('#e74c3c') 
            else: renkler.append('#f1c40f') 
            
        bars = self.ax.barh(isimler, degerler, color=renkler, height=0.5)
        
        for bar in bars:
            xval = bar.get_width()
            txt = f"+{xval:.2f}" if xval > 0 else f"{xval:.2f}"
            
            x_offset = 0.05 if xval > 0 else -0.05
            ha_align = 'left' if xval > 0 else 'right'
            
            self.ax.text(xval + x_offset, bar.get_y() + bar.get_height()/2.0, txt, va='center', ha=ha_align, color='black', fontsize=9, fontweight='bold')

        self.fig.tight_layout()
        self.canvas.draw()

    def sifirla(self):
        """Tüm senaryoyu sıfırlar ve tabloyu orijinal haline döndürür."""
        if self.combo_tablo_var.get():
            self.on_tablo_select() 
            self.combo_degisken_var.set('')
            self.entry_yeni.delete(0, tk.END)
            self.slider_var.set(0)
            self.lbl_mevcut_deger.config(text="Mevcut: 0,00")
            self.mevcut_deger_float = 0.0
            
            self.ax.clear()
            self.ax.spines['top'].set_visible(False)
            self.ax.spines['right'].set_visible(False)
            self.ax.axvline(0, color='#bdc3c7', linewidth=1)
            self.canvas.draw()

    # =========================================================================
    # DIŞA AKTARIM İŞLEMLERİ (EXCEL & PDF)
    # =========================================================================

    def export_to_excel(self):
        """Ekranda görünen tabloyu (hangi sütunlar açıksa) Excel'e aktarır."""
        if not self.preview_tree.get_children():
            messagebox.showwarning("Uyarı", "Dışa aktarılacak tablo verisi yok!")
            return
            
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Dosyası", "*.xlsx")])
        if not path: return
        
        try:
            original_cols = list(self.preview_tree["columns"])
            display_cols = list(self.preview_tree.cget("displaycolumns"))
            if display_cols == ['#all'] or not display_cols:
                display_cols = original_cols
                
            data = []
            for child in self.preview_tree.get_children():
                data.append(self.preview_tree.item(child)["values"])
                
            df_export = pd.DataFrame(data, columns=original_cols)
            df_export = df_export[display_cols] 
            
            df_export.to_excel(path, index=False)
            os.startfile(path)
        except Exception as e:
            messagebox.showerror("Hata", f"Excel oluşturulamadı:\n{e}")

    def _safe_str(self, text):
        """ReportLab'ın temel fontlarının hata vermemesi için karakterleri güvenceye alır."""
        tr_map = str.maketrans("ğĞıİöÖüÜşŞçÇ", "gGiIoOuUsScC")
        t = str(text).translate(tr_map)
        return t.replace("►", ">").replace("▼", "[-]").replace("▲", "[+]")

    def export_to_pdf(self):
        """Grafiği ve ekranda açık olan sütunları tek bir PDF raporu haline getirir."""
        if not self.preview_tree.get_children():
            messagebox.showwarning("Uyarı", "Dışa aktarılacak simülasyon verisi yok!")
            return
            
        path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF Dosyası", "*.pdf")])
        if not path: return

        try:
            from reportlab.lib.pagesizes import landscape, A4
            from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Image, Spacer, Paragraph
            from reportlab.lib import colors
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            import tempfile

            # 1. Grafiği geçici resim olarak kaydet
            temp_img = tempfile.NamedTemporaryFile(delete=False, suffix=".png").name
            self.fig.savefig(temp_img, bbox_inches='tight', dpi=150)

            # 2. Rapor Şablonunu Hazırla (Yatay A4)
            doc = SimpleDocTemplate(path, pagesize=landscape(A4), rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
            elements = []

            styles = getSampleStyleSheet()
            
            # Başlık Stili
            title_style = ParagraphStyle('TitleStyle', parent=styles['Title'], fontName='Helvetica-Bold')
            elements.append(Paragraph("Finansal Simülasyon Raporu", title_style))
            elements.append(Spacer(1, 10))

            # 3. Grafiği PDF'e yerleştir
            img = Image(temp_img)
            # Sayfa genişliğine göre orantılı büyüt/küçült
            img.drawWidth = 750
            img.drawHeight = img.drawWidth * (self.fig.get_figheight() / self.fig.get_figwidth())
            elements.append(img)
            elements.append(Spacer(1, 20))

            # 4. Tablo Stillerini Hazırla (RENK HATASI BURADA ÇÖZÜLDÜ)
            style_header = ParagraphStyle(
                'HeaderStyle',
                parent=styles['Normal'],
                fontName='Helvetica-Bold',
                textColor=colors.whitesmoke, # Başlıklar koyu lacivert üzerine beyaz
                fontSize=8,
                alignment=1 # Orta
            )

            style_cell = ParagraphStyle(
                'CellStyle',
                parent=styles['Normal'],
                fontName='Helvetica',
                textColor=colors.black, # Normal hücreler beyaz arka plana kesin SİYAH
                fontSize=7,
                alignment=1 # Orta
            )

            # 5. Ekranda aktif olan sütunları bul
            display_cols = list(self.preview_tree.cget("displaycolumns"))
            if display_cols == ['#all'] or not display_cols:
                display_cols = list(self.preview_tree["columns"])

            all_cols = list(self.preview_tree["columns"])
            col_indices = [all_cols.index(c) for c in display_cols]

            # Tabloya verileri eklerken Paragraph kullanıyoruz (Uzun yazılar alt satıra kırılsın diye)
            table_data = []
            header_row = [Paragraph(self._safe_str(c), style_header) for c in display_cols]
            table_data.append(header_row)

            for child in self.preview_tree.get_children():
                row_vals = self.preview_tree.item(child)["values"]
                row_data = [Paragraph(self._safe_str(row_vals[i]), style_cell) for i in col_indices]
                table_data.append(row_data)

            # Sütun genişliklerini dinamik olarak hesapla
            page_width = landscape(A4)[0] - 60 
            col_width = page_width / len(display_cols)

            pdf_table = Table(table_data, colWidths=[col_width] * len(display_cols))
            pdf_table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#2c3e50")), # Koyu Lacivert Başlık
                ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
                ('INNERGRID', (0,0), (-1,-1), 0.25, colors.grey),
                ('BOX', (0,0), (-1,-1), 1, colors.black),
                ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.whitesmoke, colors.white]) # Zebra satırlar
            ]))

            elements.append(pdf_table)

            # 6. PDF'i Yarat ve Geçici Resmi Sil
            doc.build(elements)
            try: os.remove(temp_img) 
            except: pass

            # Oluşan PDF'i Otomatik Aç
            os.startfile(path)

        except ImportError:
            messagebox.showerror("Kütüphane Eksik", "PDF aktarımı için reportlab kütüphanesi gerekiyor.\n\nTerminalde şu komutu çalıştırın:\npip install reportlab")
        except Exception as e:
            messagebox.showerror("Hata", f"PDF dışa aktarılamadı:\n{e}")