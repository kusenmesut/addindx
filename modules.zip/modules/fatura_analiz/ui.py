import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
import math
import tempfile
import webbrowser
import os
from .engine import FaturaAnalizEngine

try:
    from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
except ImportError:
    try:
        from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
    except ImportError:
        FaturaGoruntulePopup = None
# -----------------------------

class FaturaAnalizFrame(tk.Frame):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, bg="#ffffff", *args, **kwargs)
        self.master = master
        self.engine = FaturaAnalizEngine()
        
        self.full_df = pd.DataFrame()     
        self.filtered_df = pd.DataFrame() 
        self.page_size_var = tk.IntVar(value=15)               
        self.current_page = 1
        self.total_pages = 1
        
        self.col_vars = {} 
        self.visible_cols = []
        
        self._apply_modern_styles()
        self.create_context_menu() # Sağ tık menüsünü oluştur
        self.setup_ui()
        self.load_all_data()

    def _apply_modern_styles(self):
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
            
        style.configure("Modern.Treeview", background="#ffffff", foreground="#212529", rowheight=35, fieldbackground="#ffffff", borderwidth=0, font=("Segoe UI", 9))
        style.map("Modern.Treeview", background=[('selected', '#e9ecef')], foreground=[('selected', '#212529')])
        style.configure("Modern.Treeview.Heading", background="#f8f9fa", foreground="#495057", font=("Segoe UI", 10, "bold"), borderwidth=1, relief="flat")
        style.map("Modern.Treeview.Heading", background=[('active', '#e2e6ea')])
        style.configure("Modern.TCombobox", padding=5)

    def setup_ui(self):
        top_bar = tk.Frame(self, bg="#ffffff")
        top_bar.pack(fill=tk.X, padx=30, pady=(20, 10))
        
        btn_bg, btn_fg = "#6c757d", "white"
        left_actions = tk.Frame(top_bar, bg="#ffffff")
        left_actions.pack(side=tk.LEFT)
        
        self.btn_sutunlar = tk.Button(left_actions, text="👁️ Sütunları Yönet ▼", bg="#f8f9fa", fg="#212529", font=("Segoe UI", 9, "bold"),
                                      relief="flat", cursor="hand2", padx=10, pady=4, command=self._open_column_manager)
        self.btn_sutunlar.pack(side=tk.LEFT, padx=(0, 15))

        tk.Button(left_actions, text="📋 Copy", command=self.export_copy, bg=btn_bg, fg=btn_fg, font=("Segoe UI", 9), relief="flat", cursor="hand2", padx=10, pady=4).pack(side=tk.LEFT, padx=(0, 2))
        tk.Button(left_actions, text="📊 Excel", command=self.export_excel, bg="#198754", fg=btn_fg, font=("Segoe UI", 9), relief="flat", cursor="hand2", padx=10, pady=4).pack(side=tk.LEFT, padx=(0, 2))
        tk.Button(left_actions, text="🖨️ Print / PDF", command=self.export_print, bg="#0dcaf0", fg="black", font=("Segoe UI", 9), relief="flat", cursor="hand2", padx=10, pady=4).pack(side=tk.LEFT, padx=(0, 2))

        right_actions = tk.Frame(top_bar, bg="#ffffff")
        right_actions.pack(side=tk.RIGHT)
        
        self.islem_var = tk.StringVar(value="Tüm Faturaları Getir")
        islem_menu = ttk.Combobox(right_actions, textvariable=self.islem_var, 
                                  values=["Tüm Faturaları Getir", "Alış Faturaları", "Satış Faturaları"],
                                  state="readonly", width=20, style="Modern.TCombobox", font=("Segoe UI", 10))
        islem_menu.pack(side=tk.LEFT, padx=(0, 20))
        islem_menu.bind("<<ComboboxSelected>>", self._handle_menu_selection)

        tk.Label(right_actions, text="Arama Sütunu:", bg="#ffffff", fg="#495057", font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=(0, 5))
        self.search_col_var = tk.StringVar(value="Tüm Sütunlar")
        self.cb_search_col = ttk.Combobox(right_actions, textvariable=self.search_col_var, state="readonly", width=15, style="Modern.TCombobox")
        self.cb_search_col.pack(side=tk.LEFT, padx=(0, 10))

        tk.Label(right_actions, text="Ara:", bg="#ffffff", fg="#495057", font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=(0, 5))
        self.ent_search = tk.Entry(right_actions, font=("Segoe UI", 10), width=20, highlightthickness=1, highlightbackground="#ced4da", relief="solid")
        self.ent_search.pack(side=tk.LEFT)
        self.ent_search.bind("<KeyRelease>", self._on_search)

        table_frame = tk.Frame(self, bg="#ffffff", highlightthickness=1, highlightbackground="#dee2e6")
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=5)
        
        scroll_y = ttk.Scrollbar(table_frame, orient="vertical")
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        scroll_x = ttk.Scrollbar(table_frame, orient="horizontal")
        scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.tree = ttk.Treeview(table_frame, style="Modern.Treeview", show="headings", yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        scroll_y.config(command=self.tree.yview)
        scroll_x.config(command=self.tree.xview)
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        self.tree.tag_configure('evenrow', background='#f8f9fa')
        self.tree.tag_configure('oddrow', background='#ffffff')

        # --- ÇİFT TIK VE SAĞ TIK OLAYLARI EKLENDİ ---
        self.tree.bind("<Double-1>", self.on_row_double_click)
        self.tree.bind("<Button-3>", self.show_context_menu)

        # --- ALT BAR (Sayfalama ve Sayfa Boyutu) ---
        bottom_bar = tk.Frame(self, bg="#ffffff")
        bottom_bar.pack(fill=tk.X, padx=30, pady=15)
        
        size_frame = tk.Frame(bottom_bar, bg="#ffffff")
        size_frame.pack(side=tk.LEFT, padx=(0, 20))
        tk.Label(size_frame, text="Sayfa Boyutu:", bg="#ffffff", fg="#495057", font=("Segoe UI", 9)).pack(side=tk.LEFT)
        cb_size = ttk.Combobox(size_frame, textvariable=self.page_size_var, values=[15, 30, 50, 100, 500, 1000], state="readonly", width=5)
        cb_size.pack(side=tk.LEFT, padx=(5, 0))
        cb_size.bind("<<ComboboxSelected>>", self._on_page_size_change)
        
        self.lbl_info = tk.Label(bottom_bar, text="Kayıt bulunamadı", bg="#ffffff", fg="#495057", font=("Segoe UI", 9))
        self.lbl_info.pack(side=tk.LEFT)
        
        self.pagination_frame = tk.Frame(bottom_bar, bg="#ffffff")
        self.pagination_frame.pack(side=tk.RIGHT)

    # ================= GÖRÜNTÜLEYİCİ VE SAĞ TIK MENÜSÜ =================
    def create_context_menu(self):
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="👁️ Faturayı Görüntüle", command=self.open_invoice_viewer_btn)

    def show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)

    def open_invoice_viewer_btn(self):
        self.on_row_double_click(None)

    def on_row_double_click(self, event):
        # 1. SPAM TIKLAMA KİLİDİ: 500ms (Yarım saniye) içinde art arda açılmaları engeller
        if getattr(self, '_popup_lock', False):
            return
        self._popup_lock = True
        self.after(500, lambda: setattr(self, '_popup_lock', False))

        sel = self.tree.selection()
        if not sel: 
            if event is None: messagebox.showwarning("Seçim Yok", "Listeden bir fatura seçiniz.")
            return

        if FaturaGoruntulePopup is None:
            messagebox.showerror("Eksik Modül", "ui_goruntule.py modülü bulunamadı. Lütfen ilgili dizinde olduğundan emin olun.")
            return

        vals = self.tree.item(sel[0])['values']
        cols = list(self.tree["columns"])
        
        # Dinamik Fatura Numarası Kolon Tespiti
        fat_col_name = "NO_FATURA"
        if fat_col_name not in cols:
            fat_col_name = next((c for c in cols if 'FATURA' in str(c).upper() and 'NO' in str(c).upper()), None)
            
        if not fat_col_name:
            messagebox.showwarning("Uyarı", "Tabloda Fatura Numarası sütunu bulunamadı!")
            return

        try:
            idx_fat = cols.index(fat_col_name)
            fatura_no = str(vals[idx_fat])
            
            # Seçilen faturanın tüm kalemlerini bul
            df_invoice_rows = self.full_df[self.full_df[fat_col_name].astype(str) == fatura_no]

            if df_invoice_rows.empty:
                messagebox.showwarning("Veri Hatası", "Veritabanında bu faturaya ait detay bulunamadı.")
                return

            # 2. ESKİ PENCEREYİ KAPATMA KONTROLÜ (Aynı anda sadece 1 fatura ekranı açık kalsın)
            if hasattr(self, 'active_popup') and hasattr(self.active_popup, 'winfo_exists'):
                try:
                    if self.active_popup.winfo_exists():
                        self.active_popup.destroy()
                except Exception:
                    pass

            # Yeni ekranı aç ve referansını tut
            self.active_popup = FaturaGoruntulePopup(self.master, df_invoice_rows)

        except Exception as e:
            messagebox.showerror("Hata", f"Görüntüleyici açılırken bir hata oluştu:\n{e}")

    # ================= DİĞER FONKSİYONLAR =================
    def _on_page_size_change(self, event=None):
        self.current_page = 1
        self._render_page()
    
    def _handle_menu_selection(self, event=None):
        secim = self.islem_var.get()
        self.ent_search.delete(0, 'end')
        
        if secim == "Tüm Faturaları Getir": self.load_all_data()
        elif secim == "Alış Faturaları": self.load_alis_data()
        elif secim == "Satış Faturaları": self.load_satis_data()
        elif secim == "Tipe Göre Özet Analiz": self.load_analysis()

    def load_all_data(self):
        df, error = self.engine.faturalari_cek()
        if error: messagebox.showerror("Hata", error); return
        self._init_data(df)

    def load_alis_data(self):
        df, error = self.engine.alis_faturalarini_getir()
        if error: messagebox.showerror("Hata", error); return
        self._init_data(df)

    def load_satis_data(self):
        df, error = self.engine.satis_faturalarini_getir()
        if error: messagebox.showerror("Hata", error); return
        self._init_data(df)

    def load_analysis(self):
        df, error = self.engine.ozet_analiz_yap()
        if error: messagebox.showerror("Hata", error); return
        self._init_data(df)

    def _init_data(self, df):
        self.full_df = df.copy()
        self.full_df.fillna("", inplace=True)
        self.filtered_df = self.full_df.copy()
        self.current_page = 1
        
        cols = list(self.full_df.columns)
        self.cb_search_col['values'] = ["Tüm Sütunlar"] + cols
        self.search_col_var.set("Tüm Sütunlar")
        
        self._setup_columns() 
        self._render_page()

    # ================= SÜTUN YÖNETİCİSİ (POPUP) =================
    def _setup_columns(self):
        cols = list(self.filtered_df.columns)
        self.tree["columns"] = cols
        
        saved_cols = self.engine.load_column_prefs()
        if saved_cols:
            self.visible_cols = [c for c in saved_cols if c in cols]
        else:
            self.visible_cols = cols.copy()
            
        self.col_vars.clear()
        
        for col in cols:
            self.tree.heading(col, text=f"{str(col).replace('_', ' ').title()} ↕")
            self.tree.column(col, width=130, anchor="w")
            self.col_vars[col] = tk.BooleanVar(value=(col in self.visible_cols))
            
        self._apply_column_visibility()

    def _open_column_manager(self):
        if hasattr(self, 'col_popup') and self.col_popup.winfo_exists():
            self.col_popup.destroy()
            return

        self.col_popup = tk.Toplevel(self)
        self.col_popup.overrideredirect(True) 
        self.col_popup.config(bg="#ffffff", highlightthickness=1, highlightbackground="#adb5bd")
        
        x = self.btn_sutunlar.winfo_rootx()
        y = self.btn_sutunlar.winfo_rooty() + self.btn_sutunlar.winfo_height() + 2
        self.col_popup.geometry(f"260x350+{x}+{y}")
        
        top_frame = tk.Frame(self.col_popup, bg="#f8f9fa", pady=5)
        top_frame.pack(fill=tk.X)
        tk.Button(top_frame, text="✓ Tümünü Seç", command=self._select_all_cols, bg="#e9ecef", relief="flat", cursor="hand2", font=("Segoe UI", 8)).pack(side=tk.LEFT, padx=5)
        tk.Button(top_frame, text="✗ Temizle", command=self._clear_all_cols, bg="#e9ecef", relief="flat", cursor="hand2", font=("Segoe UI", 8)).pack(side=tk.RIGHT, padx=5)

        mid_frame = tk.Frame(self.col_popup, bg="#ffffff")
        mid_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        canvas = tk.Canvas(mid_frame, bg="#ffffff", highlightthickness=0)
        scroll = ttk.Scrollbar(mid_frame, orient="vertical", command=canvas.yview)
        chk_frame = tk.Frame(canvas, bg="#ffffff")
        
        chk_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=chk_frame, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            
        self.col_popup.bind("<Enter>", lambda e: self.col_popup.bind_all("<MouseWheel>", _on_mousewheel))
        self.col_popup.bind("<Leave>", lambda e: self.col_popup.unbind_all("<MouseWheel>"))

        for col, var in self.col_vars.items():
            cb = tk.Checkbutton(chk_frame, text=str(col).replace('_', ' ').title(), variable=var, bg="#ffffff", activebackground="#f8f9fa", cursor="hand2", font=("Segoe UI", 9))
            cb.pack(anchor="w", padx=5, pady=2)

        bot_frame = tk.Frame(self.col_popup, bg="#f8f9fa", pady=8)
        bot_frame.pack(fill=tk.X, side=tk.BOTTOM)
        tk.Button(bot_frame, text="Kapat", command=self.col_popup.destroy, bg="#6c757d", fg="white", relief="flat", cursor="hand2", font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=10)
        tk.Button(bot_frame, text="Uygula", command=self._apply_and_close_popup, bg="#0d6efd", fg="white", relief="flat", cursor="hand2", font=("Segoe UI", 9, "bold"), padx=15).pack(side=tk.RIGHT, padx=10)

    def _select_all_cols(self):
        for var in self.col_vars.values(): var.set(True)

    def _clear_all_cols(self):
        for var in self.col_vars.values(): var.set(False)

    def _apply_and_close_popup(self):
        active_cols = [col for col, var in self.col_vars.items() if var.get()]
        if not active_cols:
            messagebox.showwarning("Uyarı", "Tabloda göstermek için en az 1 sütun seçmelisiniz!")
            return
        self.visible_cols = active_cols
        self._apply_column_visibility()
        self.engine.save_column_prefs(self.visible_cols)
        self.col_popup.destroy() 

    def _apply_column_visibility(self):
        if self.visible_cols:
            self.tree["displaycolumns"] = self.visible_cols

    # ================= DIŞA AKTARIM VE ARAMA =================
    def export_copy(self):
        if self.filtered_df.empty:
            messagebox.showwarning("Uyarı", "Kopyalanacak veri yok!")
            return
        try:
            self.filtered_df[self.visible_cols].to_clipboard(index=False)
            messagebox.showinfo("Başarılı", "Görünen veriler panoya kopyalandı!")
        except Exception as e:
            messagebox.showerror("Hata", f"Kopyalama başarısız: {e}")

    def export_excel(self):
        if self.filtered_df.empty:
            messagebox.showwarning("Uyarı", "Dışa aktarılacak aktif filtreli veri bulunamadı!")
            return
            
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Dosyası", "*.xlsx")], title="Filtrelenmiş Veriyi Kaydet")
        if path:
            try:
                self.filtered_df[self.visible_cols].to_excel(path, index=False)
                messagebox.showinfo("Başarılı", f"{len(self.filtered_df)} kayıt Excel'e başarıyla aktarıldı!")
            except Exception as e:
                messagebox.showerror("Hata", f"Excel oluşturulurken hata: {e}")

    def export_print(self):
        if self.filtered_df.empty:
            messagebox.showwarning("Uyarı", "Yazdırılacak veri bulunamadı!")
            return

        arama_metni = self.ent_search.get()
        sutun = self.search_col_var.get()
        islem_turu = self.islem_var.get()
        filtre_bilgisi = f"(Kategori: {islem_turu} | Aktif Arama: {sutun} - '{arama_metni}')" if arama_metni else f"(Kategori: {islem_turu})"
            
        html_table = self.filtered_df[self.visible_cols].to_html(index=False, classes="modern-table", justify="left")
        
        html_content = f"""
        <html>
        <head>
            <meta charset="utf-8">
            <title>Fatura Analiz Raporu</title>
            <style>
                body {{ font-family: 'Segoe UI', Arial, sans-serif; padding: 20px; color: #333; }}
                h2 {{ color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 5px; margin-bottom: 5px; }}
                h4 {{ color: #7f8c8d; margin-top: 0px; margin-bottom: 20px; font-weight: normal; font-size: 14px; }}
                .modern-table {{ border-collapse: collapse; width: 100%; font-size: 11px; }}
                .modern-table th, .modern-table td {{ border: 1px solid #ddd; padding: 6px; text-align: left; }}
                .modern-table th {{ background-color: #f8f9fa; color: #495057; font-weight: bold; }}
                .modern-table tr:nth-child(even) {{ background-color: #f9f9f9; }}
                @media print {{ .no-print {{ display: none; }} body {{ padding: 0; }} }}
            </style>
        </head>
        <body>
            <div class="no-print" style="margin-bottom: 20px; background-color: #f8f9fa; padding: 15px; border-radius: 5px; border: 1px solid #dee2e6;">
                <button onclick="window.print()" style="padding:10px 20px; background:#0dcaf0; color:black; border:none; border-radius:5px; cursor:pointer; font-weight:bold;">
                    🖨️ Şimdi Yazdır veya PDF Olarak Kaydet
                </button>
            </div>
            <h2>Fatura Analiz Raporu</h2>
            <h4>{filtre_bilgisi} | Toplam Kayıt: {len(self.filtered_df)}</h4>
            {html_table}
        </body>
        </html>
        """
        try:
            with tempfile.NamedTemporaryFile('w', delete=False, suffix='.html', encoding='utf-8') as f:
                f.write(html_content)
                tmp_path = f.name
            webbrowser.open(f'file://{os.path.abspath(tmp_path)}')
        except Exception as e:
            messagebox.showerror("Hata", f"Yazdırma ekranı oluşturulamadı: {e}")

    def _on_search(self, event=None):
        search_term = self.ent_search.get().lower()
        target_col = self.search_col_var.get()
        
        if not search_term:
            self.filtered_df = self.full_df.copy()
        else:
            if target_col == "Tüm Sütunlar":
                mask = self.full_df.astype(str).apply(lambda x: x.str.lower().str.contains(search_term)).any(axis=1)
            else:
                mask = self.full_df[target_col].astype(str).str.lower().str.contains(search_term)
            self.filtered_df = self.full_df[mask]
            
        self.current_page = 1
        self._render_page()

    def _render_page(self):
        self.tree.delete(*self.tree.get_children())
        total_records = len(self.filtered_df)
        page_size = self.page_size_var.get()
        self.total_pages = math.ceil(total_records / page_size) if total_records > 0 else 1
        
        if total_records == 0:
            self.lbl_info.config(text="Kayıt bulunamadı")
            self._update_pagination_ui()
            return
            
        start_idx = (self.current_page - 1) * page_size
        end_idx = start_idx + page_size
        page_df = self.filtered_df.iloc[start_idx:end_idx]
        
        for i, (_, row) in enumerate(page_df.iterrows()):
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            self.tree.insert("", "end", values=list(row), tags=(tag,))
            
        actual_end = min(end_idx, total_records)
        self.lbl_info.config(text=f"Gösterilen: {start_idx + 1} - {actual_end} (Toplam: {total_records} Kayıt)")
        self._update_pagination_ui()

    def _update_pagination_ui(self):
        for widget in self.pagination_frame.winfo_children(): widget.destroy()
            
        btn_style_normal = {"bg": "#ffffff", "fg": "#0d6efd", "relief": "solid", "borderwidth": 1, "font": ("Segoe UI", 9)}
        btn_style_active = {"bg": "#0d6efd", "fg": "#ffffff", "relief": "solid", "borderwidth": 1, "font": ("Segoe UI", 9, "bold")}
        btn_style_disabled = {"bg": "#ffffff", "fg": "#6c757d", "relief": "solid", "borderwidth": 1, "font": ("Segoe UI", 9), "state": tk.DISABLED}

        prev_btn = tk.Button(self.pagination_frame, text="Önceki", padx=10, pady=2, cursor="hand2", command=lambda: self._change_page(self.current_page - 1))
        prev_btn.config(**(btn_style_normal if self.current_page > 1 else btn_style_disabled))
        prev_btn.pack(side=tk.LEFT, padx=1)

        start_p = max(1, self.current_page - 2)
        end_p = min(self.total_pages, self.current_page + 2)
        
        for p in range(start_p, end_p + 1):
            btn = tk.Button(self.pagination_frame, text=str(p), padx=8, pady=2, cursor="hand2", command=lambda page=p: self._change_page(page))
            if p == self.current_page: btn.config(**btn_style_active)
            else: btn.config(**btn_style_normal)
            btn.pack(side=tk.LEFT, padx=1)

        next_btn = tk.Button(self.pagination_frame, text="Sonraki", padx=10, pady=2, cursor="hand2", command=lambda: self._change_page(self.current_page + 1))
        next_btn.config(**(btn_style_normal if self.current_page < self.total_pages else btn_style_disabled))
        next_btn.pack(side=tk.LEFT, padx=1)

    def _change_page(self, new_page):
        if 1 <= new_page <= self.total_pages:
            self.current_page = new_page
            self._render_page()