import pandas as pd
from .iade_engine  import IadeListesiEngine, clean_gib_text

class KarsitIncelemeEngine(IadeListesiEngine):
    def __init__(self):
        super().__init__()

    def karsit_inceleme_raporu_hazirla(self, limit_tl=65000.0, riskli_vkn_list=None, muaf_vkn_list=None):
        if riskli_vkn_list is None: riskli_vkn_list = []
        if muaf_vkn_list is None: muaf_vkn_list = []

        df_alis, error = self.alis_faturalarini_getir()
        if error: return pd.DataFrame(), error
        if df_alis.empty: return pd.DataFrame(), "Bu döneme ait alış faturası bulunamadı."

        df_alis['KDV_MATRAH_KLM'] = pd.to_numeric(df_alis['KDV_MATRAH_KLM'], errors='coerce').fillna(0.0)
        df_alis['KDV_KLM'] = pd.to_numeric(df_alis['KDV_KLM'], errors='coerce').fillna(0.0)
        df_alis['SATICI_VKN_TCKN'] = df_alis['SATICI_VKN_TCKN'].astype(str).str.strip().str.replace(r'\D', '', regex=True)

        # Hata vermemesi için olası eksik sütunları güvene al
        for col in ['SATICI_IL', 'SATICI_ILCE', 'SATICI_ADRES', 'SATICI_TELEFON', 'SATICI_EPOSTA']:
            if col not in df_alis.columns: df_alis[col] = ""

        # --- GÜNCELLEME: İLETİŞİM BİLGİLERİNİ GRUPLAMAYA DAHİL ET ---
        agg_funcs = {
            'NO_FATURA': 'nunique', 
            'SATICI_KURUM': 'first',
            'SATICI_ŞAHIS': 'first',
            'SATICI_IL': 'first',        # YENİ
            'SATICI_ILCE': 'first',      # YENİ
            'SATICI_ADRES': 'first',     # YENİ
            'SATICI_TELEFON': 'first',   # YENİ
            'SATICI_EPOSTA': 'first',    # YENİ
            'KDV_MATRAH_KLM': 'sum',
            'KDV_KLM': 'sum'
        }
        
        df_g = df_alis.groupby('SATICI_VKN_TCKN', as_index=False).agg(agg_funcs)
        df_g.rename(columns={'NO_FATURA': 'FATURA_SAYISI', 'KDV_MATRAH_KLM': 'TOPLAM_MATRAH', 'KDV_KLM': 'TOPLAM_KDV'}, inplace=True)

        df_g['UNVAN'] = df_g['SATICI_KURUM'].fillna("")
        mask_bos = df_g['UNVAN'].str.strip() == ""
        df_g.loc[mask_bos, 'UNVAN'] = df_g['SATICI_ŞAHIS'][mask_bos]
        df_g['UNVAN'] = df_g['UNVAN'].apply(clean_gib_text)

        df_g['DURUM'] = "Kapsam Dışı"
        df_g['SECILME_NEDENI'] = "-"
        
        genel_toplam_kdv = df_g['TOPLAM_KDV'].sum()
        hedef_kdv_80 = genel_toplam_kdv * 0.80

        had_alti_mask = df_g['TOPLAM_MATRAH'] < limit_tl
        had_alti_toplam_kdv = df_g.loc[had_alti_mask, 'TOPLAM_KDV'].sum()
        
        yarisi_kurali_aktif = False
        if had_alti_toplam_kdv >= (genel_toplam_kdv / 3.0):
            yarisi_kurali_aktif = True

        df_g = df_g.sort_values(by='TOPLAM_KDV', ascending=False).reset_index(drop=True)

        incelenen_toplam_kdv = 0.0
        had_alti_incelenen_kdv = 0.0
        hedef_had_alti_kdv = had_alti_toplam_kdv / 2.0 if yarisi_kurali_aktif else 0.0

        for idx, row in df_g.iterrows():
            vkn = str(row['SATICI_VKN_TCKN'])
            matrah = row['TOPLAM_MATRAH']
            kdv = row['TOPLAM_KDV']

            if vkn in muaf_vkn_list:
                df_g.at[idx, 'SECILME_NEDENI'] = "Muafiyet Kapsamında"
                df_g.at[idx, 'DURUM'] = "İncelenmeyecek"
                continue

            if vkn in riskli_vkn_list:
                df_g.at[idx, 'SECILME_NEDENI'] = "KDVİRA / Riskli VKN"
                df_g.at[idx, 'DURUM'] = "Zorunlu İnceleme (K.İ.T)"
                incelenen_toplam_kdv += kdv
                continue

            if matrah >= limit_tl:
                df_g.at[idx, 'SECILME_NEDENI'] = "Had Üstü (Zorunlu)"
                df_g.at[idx, 'DURUM'] = "İnceleme Yapılacak (K.İ.T)"
                incelenen_toplam_kdv += kdv
            else:
                if yarisi_kurali_aktif:
                    if had_alti_incelenen_kdv < hedef_had_alti_kdv:
                        df_g.at[idx, 'SECILME_NEDENI'] = "Had Altı (%50 Yarısı Kuralı)"
                        df_g.at[idx, 'DURUM'] = "İnceleme Yapılacak"
                        had_alti_incelenen_kdv += kdv
                        incelenen_toplam_kdv += kdv
                    else:
                        df_g.at[idx, 'SECILME_NEDENI'] = "Had Altı (Sınır Aşıldı)"
                        df_g.at[idx, 'DURUM'] = "İncelenmeyecek"
                else:
                    if incelenen_toplam_kdv < hedef_kdv_80:
                        df_g.at[idx, 'SECILME_NEDENI'] = "Had Altı (%80'i Tamamlama)"
                        df_g.at[idx, 'DURUM'] = "İnceleme Yapılacak"
                        incelenen_toplam_kdv += kdv
                    else:
                        df_g.at[idx, 'SECILME_NEDENI'] = "Had Altı (Kapsam Dışı)"
                        df_g.at[idx, 'DURUM'] = "İncelenmeyecek"

        # --- GÜNCELLEME: YENİ SÜTUNLARI NİHAİ TABLOYA EKLE ---
        df_sonuc = pd.DataFrame()
        df_sonuc['S.No'] = range(1, len(df_g) + 1)
        df_sonuc['Tedarikçi Unvanı'] = df_g['UNVAN']
        df_sonuc['VKN / TCKN'] = df_g['SATICI_VKN_TCKN']
        df_sonuc['Fatura Sayısı'] = df_g['FATURA_SAYISI']
        df_sonuc['Toplam Matrah'] = df_g['TOPLAM_MATRAH'].round(2)
        df_sonuc['Toplam KDV'] = df_g['TOPLAM_KDV'].round(2)
        df_sonuc['İl'] = df_g['SATICI_IL'].fillna('')
        df_sonuc['İlçe'] = df_g['SATICI_ILCE'].fillna('')
        df_sonuc['Adres'] = df_g['SATICI_ADRES'].fillna('')
        df_sonuc['Telefon'] = df_g['SATICI_TELEFON'].fillna('')
        df_sonuc['E-Posta'] = df_g['SATICI_EPOSTA'].fillna('')
        df_sonuc['Seçilme Nedeni'] = df_g['SECILME_NEDENI']
        df_sonuc['İnceleme Durumu'] = df_g['DURUM']

        stats = {
            'genel_toplam_kdv': genel_toplam_kdv,
            'incelenen_toplam_kdv': incelenen_toplam_kdv,
            'kapsanan_oran': (incelenen_toplam_kdv / genel_toplam_kdv * 100) if genel_toplam_kdv > 0 else 0,
            'yarisi_kurali_aktif': yarisi_kurali_aktif
        }

        return df_sonuc, stats, None