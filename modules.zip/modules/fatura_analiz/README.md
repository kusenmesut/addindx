# eDenetimPRO — Karşıt İnceleme / Karşıt Tespit Modülü

Bu paket, mevcut Tkinter uygulamasındaki `ui_karsit.py` çağrısını koruyup Bootstrap tabanlı modern arayüzü yerel tarayıcıda açar. Veri kaynağı mevcut mükellef klasöründeki `fatura_data_{yil}.db` (`FATURALAR`) ve varsa `{yil}_FULL.parquet` dosyasıdır.

## Dosyalar

**Mevcut dosyaların yerine konulacaklar**

- `ui_karsit.py` — eski `KarsitParametreFrame` çağrısını korur, yerel paneli başlatır.
- `karsit_engine.py` — alış faturalarını tedarikçi/fatura/ay düzeyinde işler; had ve kapsam seçim motorudur.
- `word_bas.py` — önceki tedarikçi bazlı Word talep yazısı üretimini korur.

**Yeni eklenecekler**

- `karsit_documents.py` — örneklerdeki düzene göre Bilgi İsteme Yazısı ve Karşıt Tespit Tutanağı DOCX belgelerini üretir.
- `karsit_service.py` — analiz, cevap yükleme, mutabakat, Word ve Excel servisleri.
- `karsit_store.py` — süreç kayıtları, belgeler, mutabakat ve işlem günlüğü için ayrı SQLite deposu.
- `karsit_web.py` — localhost HTTP sunucusu ve API.
- `ymm_portal.py` — GİB giriş ayarlarını Windows DPAPI ile saklar; e-YMM listesini görünür tarayıcıda, CAPTCHA kullanıcıya bırakılarak okur.
- `templates/ymm_dashboard.html` — canlı liste dashboard’u ve bağlantı ayarları.
- `templates/karsit_dashboard.html` — Bootstrap arayüzü.
- `static/karsit.css` — responsive tasarım ve geçiş animasyonları.
- `static/karsit.js` — analiz, tedarikçi detayları, belge yükleme ve mutabakat etkileşimleri.

## Kurulum

1. Mevcut modül klasörünüzün yedeğini alın.
2. Paketteki üç mevcut dosyayı (`ui_karsit.py`, `karsit_engine.py`, `word_bas.py`) projenizde aynı isimli dosyaların üzerine yazın.
3. Yeni Python dosyalarını (`karsit_documents.py`, `karsit_service.py`, `karsit_store.py`, `karsit_web.py`) aynı klasöre ekleyin.
4. `templates` ve `static` klasörlerini, `ui_karsit.py` ile aynı modül klasörüne kopyalayın.
5. Ana uygulamanızın mevcut `KarsitParametreFrame` import/çağrısını değiştirmeyin. Launcher ve ana pencere dosyası bu pakette değiştirilmemiştir.

Örnek klasör düzeni:

```text
modules/<mevcut_karşıt_modülünüz>/
    ui_karsit.py
    karsit_engine.py
    word_bas.py
    karsit_documents.py
    karsit_service.py
    karsit_store.py
    karsit_web.py
    templates/
        karsit_dashboard.html
    static/
        karsit.css
        karsit.js
```

## Bağımlılıklar

Projede zaten bulunan `pandas`, `openpyxl`, `pyarrow` ve `python-docx` paketleri kullanılır. `.xls` cevap dosyalarını okumak için ayrıca `xlrd` gerekir.

```bash
pip install -r requirements.txt
python -m playwright install chromium
```

İlk eşitleme doğrudan `https://dijital.gib.gov.tr/portal/login` adresinde başlar; e‑YMM `/redirect` adresine ön gezinme yapılmaz. Ayarlar sayfasından GİB kullanıcı kodu/VKN ve parola girilir; parola Windows DPAPI ile mevcut Windows hesabına bağlı şifreli dosyada saklanır. CAPTCHA gerekiyorsa uygulama görünür, ayrı Chromium profilli tarayıcıyı açar, kullanıcı kodu ve parolayı doldurur ve CAPTCHA metninin tamamlanmasını bekler. Giriş düğmesi GİB formundaki tek submit düğmesi olarak seçilir. CAPTCHA tamamlanınca uygulama GİB girişini gönderir; portal ana sayfası algılanınca yeni Chromium sekmesinde doğrudan `https://eymm.gib.gov.tr/portal/karsitIncelemeTutanagi` adresini açar, **Gönderilen ve Cevap Alınan Tutanaklar** listesini okuyup sayfalar boyunca ilerleyerek yerel SQLite deposuna kaydeder. Kullanıcı etkileşimiyle tutanak oluşturma, yanıt gönderme, onaylama veya iptal işlemi yapılmaz.

Eşitleme, e-YMM ekranındaki tablo DOM'una bağlı kalmamak için oturum açıldıktan sonra portalın gözlenen `POST /apigateway/ymm/karsit-isteme-yazisi/gonderilen-listele` liste yanıtını kullanır; aynı doğrulanmış liste isteği sayfaları almak için tarayıcı oturumu içinde tekrarlanır. Bu kullanım yalnızca liste okur; giriş, onay, gönderim veya başka işlem uçları çağrılmaz. Oturum yetkilendirme başlığı ve yanıt içeriği sadece eşitleme belleğinde tutulur ve işlem bitince temizlenir.

Endpoint manifestine yalnızca GİB host adı, sorgusuz yol, HTTP yöntemi, kaynak türü ve yanıt durumu `%LOCALAPPDATA%\eDenetimPRO\ymm_portal\endpoint_manifest.json` dosyasına yazılır. URL sorguları, başlıklar, çerezler, istek gövdeleri ve yanıt içerikleri kaydedilmez. Zamanlı eşitleme, ayardaki aralıkta aynı görünür portal akışını tekrarlar. Uç nokta özeti Ayarlar sayfasında görünür.

Tarayıcı oturumu uygulamaya özel `%LOCALAPPDATA%\eDenetimPRO\ymm_portal\browser_profile` klasöründe tutulur; normal Chrome profilini kullanmaz. Oturum sona ererse eşitleme yeniden CAPTCHA bekleme aşamasına geçer. Otomatik eşitleme varsayılan olarak kapalıdır ve Ayarlar sayfasından açılır.

Bootstrap 5.3.8 ve Bootstrap Icons CDN üzerinden yüklenir; görsel arayüzün tam görünümü için istemci bilgisayarın internete erişmesi gerekir. Python HTTP sunucusu ve API tarafı Flask gerektirmez; standart kütüphane kullanır.

## Nuitka / tek dosya derleme

`templates` ve `static` klasörlerini derlemeye veri olarak ekleyin. Örnek (modül klasörü adını projenize göre değiştirin):

```bash
--include-data-dir=modules/<mevcut_karşıt_modülünüz>/templates=modules/<mevcut_karşıt_modülünüz>/templates
--include-data-dir=modules/<mevcut_karşıt_modülünüz>/static=modules/<mevcut_karşıt_modülünüz>/static
```

## İş akışı

1. Tkinter'daki karşıt inceleme sekmesi açılınca yerel Bootstrap paneli varsayılan tarayıcıda açılır.
2. Analiz tarihi aralığı ve hadlar seçilir; tedarikçi listesi, fatura detayı ve yevmiye eşleşme sayısı hesaplanır.
3. Riskli VKN ve inceleme dışı VKN listeleri uygulanır. Riskli VKN işaretlemesi inceleme zorunluluğu olarak seçime dahil edilir; risk bayrakları ise uzman kontrolü için ön uyarıdır.
4. Belge hazırlamak için tedarikçi listesinden yalnızca bir firma seçilir. **Bilgi isteme yazısı** düğmesi, muhatap YMM, yazı numarası/tarihi, YMM kimlik/oda/mühür/iletişim bilgileri, sözleşmeli mükellef ve dönem bilgilerini popup formda ister. Seçilen tedarikçi ve analiz dönemindeki alış faturaları otomatik doldurulur; düzenlenebilir.
5. **Karşıt tespit tutanağı** düğmesi ayrı popup form açar. YMM ve taraf bilgileri yanında defter tasdikleri, e-Defter beratları, ortaklar, fatura/yevmiye/ödeme bilgileri, alt tedarikçiler, KDV beyanname özetleri, çalışan/muhtasar bilgileri ve şirket temsilcisi girilebilir. Alış faturaları ve varsa yevmiye eşleşmeleri otomatik doldurulur.
6. Her iki formdan ayrı DOCX dosyası üretilir. Bilgi isteme yazısı örnekteki 12 bilgi talebi maddesini ve teyit faturaları tablosunu içerir; karşıt tespit tutanağı örnekteki bölüm ve tablo sırasını takip eder. İki belge de üretilmeden önce kullanıcı tarafından tamamlanmalı ve imza/tebliğ öncesi YMM tarafından kontrol edilmelidir.
7. Tedarikçi dosyasından durum/not güncellenir. Gelen satış fatura listesi XLSX/XLS/CSV olarak yüklenir; fatura numarası eşleşmesine göre matrah, KDV ve tarih kontrolü yapılır.
8. PDF/DOCX/TXT gibi ekler dosya olarak saklanır ve indirilebilir; bu sürüm bunlardan otomatik fatura tablosu çıkarmaya çalışmaz.
9. Sonuçlar Excel olarak dışa aktarılır. Süreç/cevap/mutabakat kayıtları ayrı `karsit_inceleme_<VKN>_<YIL>.db` dosyasına yazılır.

## Belge popup formları

- Bilgi isteme yazısı örnek `AK SEDEF... bilgi isteme` belgesindeki akışı izler: muhatap YMM, yazı sayı/tarih/şehir, YMM kimlik tablosu, tasdik sözleşmesi yapılan mükellef, nezdinde bilgi istenilen mükellef, dönem açıklaması, 12 bilgi talebi maddesi ve teyidi talep edilen faturalar tablosu.
- Karşıt tespit tutanağı örnek `FMS ALÜMİNYUM... Karşıt Tespit Tutanağı` belgesindeki bölümleri izler: YMM/şirket/karşı taraf kimlikleri, oda/sicil, üç yasal defterin tasdik bilgileri, e-Defter beratları, ortaklar, fatura-yevmiye-ödeme tablosu, dönem bazlı alt tedarikçiler, KDV beyannamesi dönem karşılaştırması, çalışan/muhtasar bilgileri ve taraf imzaları.
- Formlarda yıldızlı alanlar zorunludur. Diğer tablo satırları `Satır ekle` düğmeleriyle çoğaltılabilir, çarpı düğmesiyle silinebilir. Fatura satırları analiz verisinden başlangıç değeri olarak gelir; formda düzeltilebilir.
- Bilgi isteme yazısı ve tespit tutanağı ayrı ayrı DOCX indirilir. Üretilen belgeler taslaktır; otomatik gönderim, tebligat veya e-imza yapılmaz.

## Veri ve hesaplama notları

- Ana `fatura_data_{yil}.db` salt-okunur açılır. Cevap belgeleri ve süreç verileri ayrı bir SQLite dosyasında tutulur.
- Fatura satırları fatura numarası/UUID, satıcı ve tarih bilgisine göre fatura bazında özetlenir. `TOP_KDV_OTV_HARIC_TUTAR` varsa KDV hariç fatura tutarı olarak, yoksa `KDV_MATRAH_KLM` satır toplamı kullanılır.
- 2026 için varsayılan belge haddi 150.000 TL, aylık tedarikçi haddi 450.000 TL'dir. 2023–2025 için 65.000 TL / 195.000 TL varsayımı bulunur. Parametreler arayüzden değiştirilebilir.
- Aylık had, satıcı VKN + takvim ayı toplamı üzerinden ve seçilen tarih aralığının dışındaki aynı ay faturaları da dikkate alınarak kontrol edilir; belge haddi ise fatura KDV hariç tutarı üzerinden kontrol edilir.
- 1/3 ve %50 kuralı, had nedeniyle zorunlu olmayan alış faturalarının KDV tutarları üzerinden ön hesaplanır. Kullanıcı tarafından inceleme dışı işaretlenen firmalar bu had altı KDV paydasında gösterilir ancak seçilebilir firma havuzundan çıkarılır; hedefe erişilemiyorsa sonuçta görünür. Genel kapsam seçimi alış faturaları KDV toplamının %80'i üzerinden ön hesaplanır.
- Analiz tarih aralığı, aktif oturumdaki veri yılı ile sınırlıdır. Farklı yılın analizi için ana uygulamada ilgili yıl seçilmelidir. Yıl geneli analizde tarihi okunamayan faturalar manuel kontrol için listeye alınır; kısmi dönem analizinde tarihsiz kayıtlar yanlış bir aya yazılmamak için dönem hesabına katılmaz ve uyarı verilir.
- 2022 ve önceki yıllara ait karşıt inceleme hadleri bu sürümde otomatik tanımlı değildir; bu yıllarda ekranda hadleri uzman belirlemeden analiz yapmayınız.
- Bu paket KDV-1 beyannamesini içeri alıp indirilecek KDV toplamıyla henüz çapraz mutabakat yapmaz. Bu nedenle kapsam oranı fatura havuzu üzerinden ön hesap niteliğindedir; nihai YMM kontrolünde KDV-1 indirilecek KDV toplamıyla mutabakat yapılmalıdır.
- Mücbir sebep, zayi belge, faaliyet/il istisnası ve özel durumlar için otomatik hukuki karar verilmez. Bunlar tedarikçi dosyasında uzman tarafından incelenmelidir.
- VKN/TCKN normalizasyonu `.0` kaynaklı fazladan sıfır üretmez. Eksik tarihli faturalar aylık had kontrolü yapılamadığı için manuel kontrole zorunlu işaretlenir.
- Aynı satırın veritabanında birebir tekrarı saptanırsa otomatik silinmez; olası mükerrer uyarısı üretilir.

## Cevap dosyası mutabakatı

Excel/CSV başlıklarında fatura no, tarih, matrah ve KDV alanları Türkçe/İngilizce yaygın adlarla tanınır. Fatura numarası sütunu zorunludur. Matrah/KDV sütunları yoksa dosya ek olarak kaydedilir fakat tutar karşılaştırması yapılamaz. Otomatik karşılaştırma fatura numarası eşleşmesi ve 1 TL toleransına dayanır; farklılıklar uzman tarafından incelenmelidir.

## Önemli

Word yazısındaki YMM adı, sayı, cevap süresi ve hukuki metinler taslaktır. Belge gönderilmeden önce YMM tarafından dönem ve somut olaya göre kontrol edilmelidir. Sistem kendiliğinden GİB'e, tedarikçiye veya e-posta adresine gönderim yapmaz.
