import os
from datetime import datetime
try:
    from docx import Document
    from docx.shared import Pt, Cm
    from docx.enum.text import WD_ALIGN_PARAGRAPH
except ImportError:
    pass # Uygulama tarafında kullanıcıya uyarı vereceğiz

def karsit_tutanak_olustur(df_secilenler, mukellef_bilgileri, cikti_klasoru):
    """
    Seçilen firmalar için otomatik Word dilekçeleri üretir.
    df_secilenler: ui_karsit.py'den gelen dataframe (sadece seçili/zorunlu satırlar)
    """
    if not os.path.exists(cikti_klasoru):
        os.makedirs(cikti_klasoru)

    uretilen_dosyalar = []
    bugun = datetime.now().strftime("%d.%m.%Y")

    for index, row in df_secilenler.iterrows():
        doc = Document()

        # Varsayılan font ayarı (Modern ve Resmi)
        style = doc.styles['Normal']
        font = style.font
        font.name = 'Arial'
        font.size = Pt(11)

        # 1. TARİH VE SAYI (Sağ Üst)
        p_tarih = doc.add_paragraph()
        p_tarih.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p_tarih.add_run(f"Tarih: {bugun}\n").bold = True
        p_tarih.add_run("Sayı: YMM-2026/....")

        doc.add_paragraph("\n") # Boşluk

        # 2. MUHATAP (Satıcı Unvanı ve Adresi - Kalın ve Ortalanmış)
        p_muhatap = doc.add_paragraph()
        p_muhatap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        unvan_run = p_muhatap.add_run(f"Sayın {row['Tedarikçi Unvanı']}\n")
        unvan_run.bold = True
        unvan_run.font.size = Pt(12)
        
        # Temizlenmiş adres bilgisi
        adres_metni = f"{row.get('Adres', '')} {row.get('İlçe', '')} / {row.get('İl', '')}".strip()
        if adres_metni == "/": adres_metni = "Adres Bilgisi GİB Kayıtlarından Temin Edilemedi."
        
        p_muhatap.add_run(f"{adres_metni}\n")
        p_muhatap.add_run(f"VKN: {row['VKN / TCKN']}")

        doc.add_paragraph("\n")

        # 3. KONU
        p_konu = doc.add_paragraph()
        p_konu.add_run("Konu: ").bold = True
        p_konu.add_run("3065 Sayılı KDV Kanunu Kapsamında Karşıt İnceleme Bilgi ve Belge Talebi hk.")

        doc.add_paragraph()

        # 4. GİRİŞ PARAGRAFI
        p_giris = doc.add_paragraph("Sayın Yetkili,\n\n")
        p_giris.add_run(f"Yeminli Mali Müşavirliğimiz ile KDV İadesi Tasdik Sözleşmesi bulunan ")
        p_giris.add_run(f"{mukellef_bilgileri['unvan']} (VKN: {mukellef_bilgileri['vkn']}) ").bold = True
        p_giris.add_run(f"firmasının, {mukellef_bilgileri['donem']} vergilendirme dönemine ait KDV iadesi işlemleri tarafımızca yürütülmektedir.")
        p_giris.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

        # 5. MATRAH VE TUTAR BİLGİSİ
        p_detay = doc.add_paragraph()
        p_detay.add_run("Kayıtlarımıza göre ilgili dönemde firmanızdan ")
        p_detay.add_run(f"{row['Fatura Sayısı']} adet ").bold = True
        p_detay.add_run("fatura karşılığında, toplam ")
        p_detay.add_run(f"{row['Toplam Matrah']:,.2f} TL ".replace(',', 'X').replace('.', ',').replace('X', '.')).bold = True
        p_detay.add_run("(KDV Hariç) tutarında alım yapılmış ve ")
        p_detay.add_run(f"{row['Toplam KDV']:,.2f} TL ".replace(',', 'X').replace('.', ',').replace('X', '.')).bold = True
        p_detay.add_run("KDV yüklenilmiştir.")
        p_detay.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

        # 6. YASAL DAYANAK VE TALEPLER
        p_talep = doc.add_paragraph(
            "KDV Genel Uygulama Tebliği hükümleri gereğince yapılacak \"Karşıt İnceleme\" çalışmalarına "
            "esas olmak üzere, aşağıdaki belgelerin aslı gibidir onaylı veya e-imzalı suretlerinin tebliğ tarihinden itibaren "
            "en geç 15 (on beş) gün içerisinde tarafımıza ibraz edilmesini rica ederiz."
        )
        p_talep.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

        # Maddeler
        maddeler = [
            "İlgili döneme ait KDV-1 Beyannamesi, Tahakkuk Fişi ve ödeme dekontu/alındısı.",
            "Mükellefimize düzenlenen satış faturalarının dökümü.",
            "Satışlara ilişkin Yevmiye, Kebir ve Muavin defter (Müşteri Cari) dökümleri.",
            "Satış bedellerinin tahsilatına ilişkin banka dekontları veya tahsilat makbuzları."
        ]
        
        for madde in maddeler:
            p_madde = doc.add_paragraph(madde, style='List Bullet')
            p_madde.paragraph_format.left_indent = Cm(1)

        doc.add_paragraph("\nBilgi verilmemesi veya eksik belge ibrazı durumunda yasal sorumlulukların doğabileceğini hatırlatır, iyi çalışmalar dileriz.\n")

        # 7. İMZA ALANI
        p_imza = doc.add_paragraph()
        p_imza.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p_imza.add_run("Saygılarımızla,\n\n").bold = True
        p_imza.add_run("[YMM ADI SOYADI]\n")
        p_imza.add_run("Yeminli Mali Müşavir")

        # Dosyayı Kaydetme (Geçersiz dosya ismi karakterlerini temizle)
        guvenli_unvan = "".join([c for c in row['Tedarikçi Unvanı'] if c.isalpha() or c.isdigit() or c==' ']).rstrip()
        dosya_adi = f"Karsi_Inceleme_{guvenli_unvan}_{row['VKN / TCKN']}.docx"
        dosya_yolu = os.path.join(cikti_klasoru, dosya_adi)
        
        doc.save(dosya_yolu)
        uretilen_dosyalar.append(dosya_adi)

    return uretilen_dosyalar