(() => {
  "use strict";
  const TOKEN = window.KARSIT_TOKEN || "";
  const $ = (id) => document.getElementById(id);
  const state = { suppliers: [], invoices: [], stats: {}, selected: new Set(), currentSupplier: null, lastResult: null, limitTouched: false, context: null, documentSupplier: null, documentInvoices: [] };
  const toast = window.bootstrap ? new bootstrap.Toast($("appToast"), { delay: 4500 }) : null;
  const supplierModal = () => bootstrap.Modal.getOrCreateInstance($("supplierModal"));
  const infoRequestModal = () => bootstrap.Modal.getOrCreateInstance($("infoRequestModal"));
  const findingRecordModal = () => bootstrap.Modal.getOrCreateInstance($("findingRecordModal"));

  function money(value, decimals = 2) {
    const n = Number(value || 0);
    return new Intl.NumberFormat("tr-TR", { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(Number.isFinite(n) ? n : 0);
  }
  function number(value) { return new Intl.NumberFormat("tr-TR").format(Number(value || 0)); }
  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  function showToast(message, title = "Bilgi", isError = false) {
    $("toastTitle").textContent = title;
    $("toastBody").textContent = message;
    $("appToast").querySelector(".toast-mark").style.background = isError ? "#d94b5b" : "#2f6fed";
    toast?.show();
  }
  async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    headers.set("X-Karsit-Token", TOKEN);
    if (options.body && !(options.body instanceof FormData) && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
    const response = await fetch(path, { ...options, headers, cache: "no-store" });
    const contentType = response.headers.get("content-type") || "";
    if (!response.ok) {
      let detail = "İstek başarısız.";
      try { const body = await response.json(); detail = body.error || detail; } catch (_) {}
      throw new Error(detail);
    }
    if (contentType.includes("application/json")) return response.json();
    return response;
  }
  function setBusy(button, busy, label = "İşlem yapılıyor…") {
    if (!button) return;
    button.disabled = busy;
    const spinner = button.querySelector(".spinner-border");
    const text = button.querySelector(".btn-label");
    if (spinner) spinner.classList.toggle("d-none", !busy);
    if (text && busy) { button.dataset.oldLabel = text.innerHTML; text.textContent = label; }
    if (text && !busy && button.dataset.oldLabel) { text.innerHTML = button.dataset.oldLabel; delete button.dataset.oldLabel; }
  }
  function parseVknList(value) { return String(value || "").split(/[;,\n]+/).map(x => x.replace(/\D/g, "")).filter(Boolean); }

  async function bootstrapApp() {
    try {
      const data = await api("/api/bootstrap");
      state.context = data;
      $("taxpayerName").textContent = data.taxpayer?.unvan || "Aktif Mükellef";
      $("taxpayerVkn").textContent = data.taxpayer?.vkn || "";
      const year = data.taxpayer?.year || new Date().getFullYear();
      $("startDate").value = `${year}-01-01`;
      $("endDate").value = `${year}-12-31`;
      $("startDate").min = `${year}-01-01`;
      $("startDate").max = `${year}-12-31`;
      $("endDate").min = `${year}-01-01`;
      $("endDate").max = `${year}-12-31`;
      $("documentLimit").value = data.thresholds?.document_limit ?? 150000;
      $("monthlyLimit").value = data.thresholds?.monthly_limit ?? 450000;
      await runAnalysis();
    } catch (error) {
      showToast(error.message, "Başlangıç hatası", true);
    }
  }

  function analysisPayload() {
    return {
      start_date: $("startDate").value,
      end_date: $("endDate").value,
      document_limit: $("startDate").value.slice(0, 4) !== $("endDate").value.slice(0, 4) ? null : Number($("documentLimit").value || 0),
      monthly_limit: $("startDate").value.slice(0, 4) !== $("endDate").value.slice(0, 4) ? null : Number($("monthlyLimit").value || 0),
      risk_vkns: parseVknList($("riskVkns").value),
      excluded_vkns: parseVknList($("excludedVkns").value),
    };
  }
  async function runAnalysis() {
    const btn = $("analyzeBtn");
    setBusy(btn, true);
    try {
      const result = await api("/api/analyze", { method: "POST", body: JSON.stringify(analysisPayload()) });
      state.lastResult = result;
      state.suppliers = result.suppliers || [];
      state.invoices = result.invoices || [];
      state.stats = result.stats || {};
      state.selected.clear();
      renderStats();
      renderSuppliers();
      fillSupplierSelect();
      await refreshDocuments();
      await refreshReconciliations();
      await refreshActivity();
      const warnings = result.warnings || [];
      if (warnings.length) showToast(warnings.join(" "), "Veri kaynağı uyarısı");
    } catch (error) {
      showToast(error.message, "Analiz hatası", true);
    } finally {
      setBusy(btn, false);
    }
  }

  function renderStats() {
    const s = state.stats;
    $("kpiInvoices").textContent = number(s.invoice_count);
    $("kpiSuppliers").textContent = number(s.supplier_count);
    $("kpiTotalVat").textContent = `${money(s.total_vat)} ₺`;
    $("kpiCoverage").textContent = `%${money(s.coverage_percent, 2)}`;
    $("kpiTarget").textContent = `${s.target_label || "Kapsam hedefi"}: ${money(s.target_vat)} ₺${s.target_reached ? " · hedef sağlandı" : " · hedef kontrol edilmeli"}`;
    $("periodCaption").textContent = `${s.start_date || "—"} / ${s.end_date || "—"} · ${number(s.selected_supplier_count)} incelemeye alınan tedarikçi · ${number(s.mandatory_supplier_count)} zorunlu tedarikçi`;
    $("supplierTabCount").textContent = number(s.supplier_count);
    $("documentTabCount").textContent = "—";
    $("reconcileTabCount").textContent = "—";
  }

  function badgeForSupplier(row) {
    const status = row.selection_status || "Kapsam Dışı";
    if (status === "Zorunlu") return '<span class="status-pill status-mandatory"><i class="bi bi-exclamation-circle"></i> Zorunlu</span>';
    if (status === "İncelenecek") return '<span class="status-pill status-selected"><i class="bi bi-check-circle"></i> İncelenecek</span>';
    if (status === "Hariç") return '<span class="status-pill status-excluded">Hariç</span>';
    return '<span class="status-pill status-excluded">Kapsam dışı</span>';
  }
  function responseBadge(status) {
    if (["Mutabakat Tamamlandı", "Cevap Geldi"].includes(status)) return `<span class="status-pill status-ok">${escapeHtml(status)}</span>`;
    if (status === "Fark Var") return `<span class="status-pill status-diff">${escapeHtml(status)}</span>`;
    return `<span class="status-pill status-wait">${escapeHtml(status || "Cevap Bekleniyor")}</span>`;
  }
  function filteredSuppliers() {
    const term = $("supplierSearch").value.trim().toLocaleLowerCase("tr-TR");
    const filter = $("supplierFilter").value;
    return state.suppliers.filter(row => {
      const haystack = `${row.supplier_name || ""} ${row.supplier_vkn || ""}`.toLocaleLowerCase("tr-TR");
      const termOk = !term || haystack.includes(term);
      const filterOk = filter === "all" || row.selection_status === filter;
      return termOk && filterOk;
    });
  }
  function renderSuppliers() {
    const rows = filteredSuppliers();
    if (!rows.length) {
      $("supplierRows").innerHTML = '<tr><td colspan="10" class="empty-state">Filtreye uygun tedarikçi bulunamadı.</td></tr>';
    } else {
      $("supplierRows").innerHTML = rows.map(row => {
        const vkn = escapeHtml(row.supplier_vkn);
        const checked = state.selected.has(row.supplier_vkn) ? "checked" : "";
        const risks = (row.risk_flags || []).slice(0, 2).map(escapeHtml).join(" · ");
        const ledger = `${number(row.ledger_matched_invoice_count || 0)} / ${number(row.invoice_count || 0)}`;
        return `<tr>
          <td><input class="form-check-input supplier-check" type="checkbox" data-vkn="${vkn}" ${checked} ${row.excluded ? "disabled" : ""}></td>
          <td><span class="supplier-name">${escapeHtml(row.supplier_name || "Unvan bulunamadı")}</span><span class="supplier-meta">${escapeHtml([row.city, row.district].filter(Boolean).join(" / "))}</span>${risks ? `<span class="risk-mini"><i class="bi bi-flag me-1"></i>${risks}</span>` : ""}</td>
          <td class="mono">${vkn}</td>
          <td class="text-end">${number(row.invoice_count)}</td>
          <td class="text-end mono">${money(row.total_base)}</td>
          <td class="text-end mono fw-bold">${money(row.total_vat)}</td>
          <td>${badgeForSupplier(row)}<span class="supplier-meta">${escapeHtml(row.selection_reason || "")}</span></td>
          <td>${responseBadge(row.response_status)}</td>
          <td class="mono small">${ledger}</td>
          <td><button class="row-action detail-btn" title="Dosyayı aç" data-vkn="${vkn}"><i class="bi bi-chevron-right"></i></button></td>
        </tr>`;
      }).join("");
    }
    $("supplierFooter").textContent = `${rows.length} tedarikçi gösteriliyor · ${state.suppliers.length} toplam kayıt`;
    $("selectedSummary").textContent = `${state.selected.size} firma seçildi`;
    $("selectAll").checked = rows.length > 0 && rows.every(r => state.selected.has(r.supplier_vkn));
    $("uploadSupplier").value = state.currentSupplier || "";
    $("reconcileTabCount").textContent = number(state.lastResult?.reconciliation_count || 0);
  }
  function fillSupplierSelect() {
    const select = $("uploadSupplier");
    const previous = select.value || state.currentSupplier || "";
    select.innerHTML = '<option value="">Tedarikçi seçin…</option>' + state.suppliers.map(row =>
      `<option value="${escapeHtml(row.supplier_vkn)}">${escapeHtml(row.supplier_name)} · ${escapeHtml(row.supplier_vkn)}</option>`
    ).join("");
    if (state.suppliers.some(x => x.supplier_vkn === previous)) select.value = previous;
  }

  async function openSupplier(vkn) {
    try {
      const data = await api(`/api/supplier/${encodeURIComponent(vkn)}`);
      const supplier = data.supplier || {};
      state.currentSupplier = vkn;
      $("supplierModalTitle").textContent = supplier.supplier_name || "Tedarikçi dosyası";
      $("supplierModalVkn").textContent = supplier.supplier_vkn || vkn;
      $("supplierDetailKpis").innerHTML = [
        ["Fatura sayısı", number(supplier.invoice_count)], ["Toplam matrah", `${money(supplier.total_base)} ₺`], ["Toplam KDV", `${money(supplier.total_vat)} ₺`],
      ].map(x => `<div class="col-4"><div class="detail-kpi"><span>${x[0]}</span><strong>${x[1]}</strong></div></div>`).join("");
      const invoices = data.invoices || [];
      $("supplierInvoiceCount").textContent = `${invoices.length} fatura`;
      $("supplierInvoiceRows").innerHTML = invoices.length ? invoices.map(inv => {
        let control = inv.mandatory_reason ? `<span class="status-pill status-mandatory">Had üstü</span><div class="supplier-meta">${escapeHtml(inv.mandatory_reason)}</div>` : '<span class="status-pill status-selected">Had altı</span>';
        return `<tr><td>${escapeHtml(inv.invoice_date || "-")}</td><td class="mono">${escapeHtml(inv.invoice_no || "-")}</td><td>${escapeHtml(inv.description || "-")}</td><td class="text-end mono">${money(inv.net_base)}</td><td class="text-end mono">${money(inv.vat)}</td><td class="mono">${escapeHtml(inv.ledger_entry_no || "Eşleşme yok")}</td><td>${control}</td></tr>`;
      }).join("") : '<tr><td colspan="7" class="empty-state">Bu tedarikçi için fatura bulunamadı.</td></tr>';
      $("caseStatus").value = supplier.process_status || (supplier.selected ? "İncelenecek" : "Kapsam Dışı");
      $("responseStatus").value = supplier.response_status || "Cevap Bekleniyor";
      $("caseNotes").value = supplier.notes || "";
      $("uploadSupplier").value = vkn;
      supplierModal().show();
    } catch (error) { showToast(error.message, "Tedarikçi dosyası", true); }
  }

  async function saveCase() {
    if (!state.currentSupplier) return;
    try {
      await api("/api/case", { method: "POST", body: JSON.stringify({
        supplier_vkn: state.currentSupplier,
        period_start: state.stats.start_date, period_end: state.stats.end_date,
        status: $("caseStatus").value, response_status: $("responseStatus").value,
        notes: $("caseNotes").value,
      }) });
      const row = state.suppliers.find(x => x.supplier_vkn === state.currentSupplier);
      if (row) { row.process_status = $("caseStatus").value; row.response_status = $("responseStatus").value; row.notes = $("caseNotes").value; }
      renderSuppliers();
      supplierModal().hide();
      showToast("Tedarikçi süreç bilgileri kaydedildi.");
      await refreshActivity();
    } catch (error) { showToast(error.message, "Kayıt hatası", true); }
  }

  async function uploadResponse() {
    const vkn = $("uploadSupplier").value;
    const file = $("responseFile").files[0];
    if (!vkn || !file) return showToast("Tedarikçiyi ve yüklenecek dosyayı seçiniz.", "Eksik bilgi", true);
    const form = new FormData();
    form.append("supplier_vkn", vkn);
    form.append("document_type", $("documentType").value);
    form.append("file", file);
    const btn = $("uploadBtn"); btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Yükleniyor…';
    try {
      const result = await api("/api/upload", { method: "POST", body: form });
      showToast(result.document?.parse_message || result.document?.parse_status || "Belge dosyaya eklendi.", "Belge yüklendi");
      $("responseFile").value = "";
      await refreshDocuments(); await refreshActivity();
      bootstrap.Tab.getOrCreateInstance(document.querySelector('[data-bs-target="#documentsPane"]')).show();
    } catch (error) { showToast(error.message, "Yükleme hatası", true); }
    finally { btn.disabled = false; btn.innerHTML = '<i class="bi bi-upload me-1"></i> Dosyayı yükle ve kaydet'; }
  }

  async function refreshDocuments() {
    try {
      const data = await api("/api/documents");
      const documents = data.documents || [];
      $("documentTabCount").textContent = number(documents.length);
      $("documentsList").innerHTML = documents.length ? documents.map(doc => {
        const parsed = Number(doc.parsed_row_count || 0);
        const typeIcon = [".xlsx", ".xls", ".csv"].includes(doc.extension) ? "bi-file-earmark-spreadsheet" : ".pdf" === doc.extension ? "bi-file-earmark-pdf" : "bi-file-earmark-text";
        return `<div class="document-item"><div class="document-icon"><i class="bi ${typeIcon}"></i></div><div class="document-main"><div class="document-title">${escapeHtml(doc.original_name)}</div><div class="document-sub">${escapeHtml(doc.supplier_vkn)} · ${escapeHtml(doc.document_type)} · ${parsed} tablo satırı · ${escapeHtml(doc.uploaded_at || "")}</div></div><div class="document-actions"><span class="status-pill ${parsed ? "status-ok" : "status-wait"}">${parsed ? "Mutabakata hazır" : "Ek belge"}</span><button class="row-action download-doc-btn" data-id="${escapeHtml(doc.id)}" title="Belgeyi indir"><i class="bi bi-download"></i></button>${parsed ? `<button class="row-action reconcile-btn" data-id="${escapeHtml(doc.id)}" title="Mutabakat yap"><i class="bi bi-arrow-left-right"></i></button>` : ""}</div></div>`;
      }).join("") : '<div class="empty-state">Henüz cevap belgesi yüklenmedi.</div>';
    } catch (error) { showToast(error.message, "Belge listesi", true); }
  }

  async function runReconciliation(documentId) {
    try {
      const result = await api("/api/reconcile", { method: "POST", body: JSON.stringify({ document_id: documentId }) });
      showToast(`${result.row_count} satır kontrol edildi. ${result.difference_count} fark/eksik kayıt bulundu.`, "Mutabakat tamamlandı");
      await refreshReconciliations(); await refreshDocuments(); await refreshActivity();
      bootstrap.Tab.getOrCreateInstance(document.querySelector('[data-bs-target="#reconcilePane"]')).show();
    } catch (error) { showToast(error.message, "Mutabakat hatası", true); }
  }


  async function downloadDocument(documentId) {
    try {
      const response = await api(`/api/document/${encodeURIComponent(documentId)}/download`);
      const blob = await response.blob();
      const disposition = response.headers.get("content-disposition") || "";
      const match = disposition.match(/filename="?([^";]+)"?/i);
      downloadBlob(blob, match?.[1] || "karsit_cevap_belgesi");
    } catch (error) { showToast(error.message, "Belge indirme", true); }
  }

  async function refreshReconciliations() {
    try {
      const data = await api("/api/reconciliation");
      const rows = data.results || [];
      $("reconcileTabCount").textContent = number(rows.length);
      const vknName = new Map(state.suppliers.map(x => [x.supplier_vkn, x.supplier_name]));
      $("reconcileRows").innerHTML = rows.length ? rows.map(r => {
        const status = r.match_status || "Kontrol";
        const ok = status === "UYUMLU";
        return `<tr><td><span class="supplier-name">${escapeHtml(vknName.get(r.supplier_vkn) || r.supplier_vkn)}</span><span class="supplier-meta mono">${escapeHtml(r.supplier_vkn)}</span></td><td class="mono">${escapeHtml(r.source_invoice_no || "-")}</td><td class="mono">${escapeHtml(r.response_invoice_no || "-")}</td><td class="text-end mono">${r.base_difference == null ? "-" : money(r.base_difference)}</td><td class="text-end mono">${r.vat_difference == null ? "-" : money(r.vat_difference)}</td><td>${ok ? '<span class="status-pill status-ok">UYUMLU</span>' : `<span class="status-pill status-diff">${escapeHtml(status)}</span>`}</td></tr>`;
      }).join("") : '<tr><td colspan="6" class="empty-state">Henüz mutabakat yapılmadı.</td></tr>';
    } catch (error) { showToast(error.message, "Mutabakat listesi", true); }
  }

  async function refreshActivity() {
    try {
      const data = await api("/api/activity");
      const items = data.activities || [];
      $("activityList").innerHTML = items.length ? items.map(item => `<div class="activity-item"><div class="activity-dot"><i class="bi bi-clock-history"></i></div><div class="activity-text"><strong>${escapeHtml(item.event_type)}</strong> · ${escapeHtml(item.description)}<div class="activity-date">${escapeHtml(item.supplier_vkn || "")} · ${escapeHtml(item.created_at || "")}</div></div></div>`).join("") : '<div class="empty-state">Henüz işlem kaydı yok.</div>';
    } catch (_) { /* İşlem günlüğü yardımcı alandır. */ }
  }

  async function downloadExcel() {
    try {
      const response = await api("/api/export");
      const blob = await response.blob();
      downloadBlob(blob, "karsit_inceleme_analiz.xlsx");
    } catch (error) { showToast(error.message, "Excel dışa aktarma", true); }
  }
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }


  // ================= BELGE POPUP FORMLARI =================
  function localIsoDate() {
    const now = new Date();
    const offset = now.getTimezoneOffset() * 60000;
    return new Date(now.getTime() - offset).toISOString().slice(0, 10);
  }
  function dateInputValue(value) {
    const text = String(value ?? "").trim();
    if (!text) return "";
    if (/^\d{4}-\d{2}-\d{2}/.test(text)) return text.slice(0, 10);
    const tr = text.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/);
    if (tr) return `${tr[3]}-${String(tr[2]).padStart(2, "0")}-${String(tr[1]).padStart(2, "0")}`;
    return "";
  }
  function periodText() {
    return [state.stats.start_date, state.stats.end_date].filter(Boolean).join(" - ");
  }
  function setField(id, value) {
    const element = $(id);
    if (element && value !== undefined && value !== null) element.value = String(value);
  }
  function setText(id, value) {
    const element = $(id);
    if (element) element.textContent = String(value ?? "");
  }
  function setInputFromMaybeDate(id, value) {
    setField(id, dateInputValue(value));
  }
  function clearTable(id) {
    const body = $(id);
    if (body) body.replaceChildren();
  }
  function addGridRow(tbodyId, specs, values = {}) {
    const body = $(tbodyId);
    if (!body) return null;
    const tr = document.createElement("tr");
    tr.dataset.gridRow = "true";
    specs.forEach((spec) => {
      const td = document.createElement("td");
      const input = document.createElement("input");
      input.className = "form-control form-control-sm";
      input.type = spec.type || "text";
      input.dataset.field = spec.key;
      if (spec.type === "number") {
        input.step = "0.01";
        input.inputMode = "decimal";
      }
      if (spec.wide) input.style.minWidth = "150px";
      if (spec.placeholder) input.placeholder = spec.placeholder;
      const value = values[spec.key];
      if (value !== undefined && value !== null) {
        input.value = spec.type === "date" ? dateInputValue(value) : String(value);
      }
      td.appendChild(input);
      tr.appendChild(td);
    });
    const removeCell = document.createElement("td");
    removeCell.className = "text-end";
    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "btn btn-sm btn-outline-danger remove-grid-row";
    removeButton.title = "Satırı kaldır";
    removeButton.innerHTML = '<i class="bi bi-x-lg"></i>';
    removeCell.appendChild(removeButton);
    tr.appendChild(removeCell);
    body.appendChild(tr);
    return tr;
  }
  function setGridRows(tbodyId, specs, rows) {
    clearTable(tbodyId);
    (rows || []).forEach((row) => addGridRow(tbodyId, specs, row));
  }
  function collectGridRows(tbodyId) {
    const body = $(tbodyId);
    if (!body) return [];
    return [...body.querySelectorAll("tr[data-grid-row='true']")].map((tr) => {
      const row = {};
      tr.querySelectorAll("[data-field]").forEach((input) => {
        row[input.dataset.field] = input.value.trim();
      });
      return row;
    }).filter((row) => Object.values(row).some((value) => value !== ""));
  }
  function bindAddRowButton(buttonId, tbodyId, specs) {
    const button = $(buttonId);
    if (!button) return;
    button.addEventListener("click", () => addGridRow(tbodyId, specs));
  }
  function addRemoveEvents() {
    document.addEventListener("click", (event) => {
      const button = event.target.closest(".remove-grid-row");
      if (button) button.closest("tr")?.remove();
    });
  }
  function documentInvoiceSpecs() {
    return [
      { key: "invoice_date", type: "date" },
      { key: "invoice_no", wide: true },
      { key: "base", type: "number" },
      { key: "vat", type: "number" },
    ];
  }
  const findingBeratSpecs = [
    { key: "period" }, { key: "type" }, { key: "created_at", type: "date" }, { key: "ettn", wide: true },
  ];
  const findingShareSpecs = [
    { key: "name", wide: true }, { key: "vkn_tckn" }, { key: "share_ratio" },
  ];
  const findingInvoiceSpecs = [
    { key: "invoice_date", type: "date" }, { key: "invoice_no", wide: true }, { key: "base", type: "number" },
    { key: "vat", type: "number" }, { key: "ledger_date", type: "date" }, { key: "ledger_no", wide: true }, { key: "payment_method", wide: true },
  ];
  const findingSubsupplierSpecs = [
    { key: "period" }, { key: "invoice_date", type: "date" }, { key: "invoice_no", wide: true },
    { key: "gross", type: "number" }, { key: "name", wide: true }, { key: "tax_office" }, { key: "vkn_tckn" },
  ];
  const findingVatSpecs = [
    { key: "period" }, { key: "sales_services", type: "number" }, { key: "exemption", type: "number" },
    { key: "base_total", type: "number" }, { key: "calculated_vat", type: "number" }, { key: "additional_vat", type: "number" },
    { key: "total_calculated_vat", type: "number" }, { key: "previous_carryover", type: "number" },
    { key: "total_deductions", type: "number" }, { key: "payable_vat", type: "number" },
    { key: "next_carryover", type: "number" }, { key: "accrual_no" },
  ];
  const findingPayrollSpecs = [
    { key: "period" }, { key: "employee_count", type: "number" }, { key: "tax_office" },
  ];
  function buildBookRows(year) {
    const body = $("findingBookRows");
    body.replaceChildren();
    ["Yevmiye", "Envanter", "Defter-i Kebir"].forEach((bookType) => {
      const tr = document.createElement("tr");
      tr.dataset.bookType = bookType;
      const title = document.createElement("td");
      title.textContent = bookType;
      tr.appendChild(title);
      [
        { key: "authority", type: "text" },
        { key: "date", type: "date" },
        { key: "journal_no", type: "text" },
        { key: "year", type: "number" },
      ].forEach((spec) => {
        const td = document.createElement("td");
        const input = document.createElement("input");
        input.className = "form-control form-control-sm";
        input.type = spec.type;
        input.dataset.field = spec.key;
        if (spec.key === "year") input.value = String(year || "");
        if (spec.type === "date") input.style.minWidth = "135px";
        td.appendChild(input);
        tr.appendChild(td);
      });
      body.appendChild(tr);
    });
  }
  function collectBookRows() {
    return [...$("findingBookRows").querySelectorAll("tr[data-book-type]")].map((tr) => {
      const row = { book_type: tr.dataset.bookType };
      tr.querySelectorAll("[data-field]").forEach((input) => { row[input.dataset.field] = input.value.trim(); });
      return row;
    });
  }
  async function getSingleSelectedSupplier() {
    if (state.selected.size !== 1) {
      showToast("Belge hazırlamak için listeden yalnızca bir tedarikçi seçiniz.", "Tedarikçi seçimi", true);
      return null;
    }
    const vkn = [...state.selected][0];
    try {
      const result = await api(`/api/supplier/${encodeURIComponent(vkn)}`);
      state.documentSupplier = result.supplier || {};
      state.documentInvoices = result.invoices || [];
      return vkn;
    } catch (error) {
      showToast(error.message, "Tedarikçi bilgisi alınamadı", true);
      return null;
    }
  }
  function setSharedDocumentFields(prefix, supplier) {
    const context = state.context || {};
    const taxpayer = context.taxpayer || {};
    const selectedSupplier = supplier || {};
    const p = periodText();
    const today = localIsoDate();
    setField(`${prefix}DocNumber`, "");
    setField(`${prefix}DocDate`, today);
    setField(`${prefix}DocCity`, "ANKARA");
    setField(`${prefix}YmmName`, "");
    setField(`${prefix}YmmChamber`, "");
    setField(`${prefix}YmmSeal`, "");
    setField(`${prefix}YmmTax`, "");
    setField(`${prefix}YmmAddress`, "");
    setField(`${prefix}YmmPhone`, "");
    setField(`${prefix}ClientName`, taxpayer.unvan || "");
    setField(`${prefix}ClientTax`, taxpayer.vkn || "");
    setField(`${prefix}ClientAddress`, "");
    setField(`${prefix}ClientPhone`, "");
    setField(`${prefix}ClientContract`, "");
    setField(`${prefix}ClientContractDateNo`, "");
    return { period: p, today, selectedSupplier };
  }
  async function openInfoRequestForm() {
    const vkn = await getSingleSelectedSupplier();
    if (!vkn) return;
    const supplier = state.documentSupplier || {};
    const common = setSharedDocumentFields("info", supplier);
    setText("infoSupplierCaption", `${supplier.supplier_name || "Tedarikçi"} · ${vkn}`);
    setField("infoRecipientName", "");
    setField("infoRecipientTitle", "Yeminli Mali Müşavir");
    setField("infoRecipientAddress", "");
    setField("infoRespondentName", supplier.supplier_name || "");
    setField("infoRespondentTax", supplier.supplier_vkn || vkn);
    setField("infoRespondentAddress", supplier.address || "");
    setField("infoRespondentPhone", supplier.phone || "");
    setField("infoPeriod", common.period);
    const invoices = state.documentInvoices.map((invoice) => ({
      invoice_date: invoice.invoice_date || "", invoice_no: invoice.invoice_no || "",
      base: invoice.net_base ?? invoice.total_base ?? "", vat: invoice.vat ?? invoice.total_vat ?? "",
    }));
    setGridRows("infoInvoiceRows", documentInvoiceSpecs(), invoices);
    setField("infoInvoiceCount", invoices.length);
    infoRequestModal().show();
  }
  async function openFindingRecordForm() {
    const vkn = await getSingleSelectedSupplier();
    if (!vkn) return;
    const supplier = state.documentSupplier || {};
    const common = setSharedDocumentFields("finding", supplier);
    setText("findingSupplierCaption", `${supplier.supplier_name || "Tedarikçi"} · ${vkn}`);
    setField("findingSignatureDate", common.today);
    setField("findingInspectedName", supplier.supplier_name || "");
    setField("findingInspectedTax", supplier.supplier_vkn || vkn);
    setField("findingInspectedAddress", supplier.address || "");
    setField("findingInspectedPhone", supplier.phone || "");
    setField("findingTradeRegistry", "");
    setField("findingPeriodText", common.period);
    setField("findingRepresentative", "");
    buildBookRows(state.context?.taxpayer?.year || new Date().getFullYear());
    const invoices = state.documentInvoices.map((invoice) => ({
      invoice_date: invoice.invoice_date || "", invoice_no: invoice.invoice_no || "",
      base: invoice.net_base ?? invoice.total_base ?? "", vat: invoice.vat ?? invoice.total_vat ?? "",
      ledger_date: invoice.ledger_date || "", ledger_no: invoice.ledger_entry_no || "", payment_method: "",
    }));
    setGridRows("findingInvoiceRows", findingInvoiceSpecs, invoices);
    setGridRows("findingBeratRows", findingBeratSpecs, []);
    setGridRows("findingShareRows", findingShareSpecs, []);
    setGridRows("findingSubsupplierRows", findingSubsupplierSpecs, []);
    setGridRows("findingVatRows", findingVatSpecs, []);
    setGridRows("findingPayrollRows", findingPayrollSpecs, []);
    findingRecordModal().show();
  }
  function readYmm(prefix) {
    return {
      name: $(`${prefix}YmmName`).value.trim(),
      chamber_registry: $(`${prefix}YmmChamber`).value.trim(),
      seal_no: $(`${prefix}YmmSeal`).value.trim(),
      tax_office_identity: $(`${prefix}YmmTax`).value.trim(),
      address: $(`${prefix}YmmAddress`).value.trim(),
      phone_email: $(`${prefix}YmmPhone`).value.trim(),
      letter_contact: $(`${prefix}YmmPhone`).value.trim(),
    };
  }
  function readContractTaxpayer(prefix) {
    return {
      name: $(`${prefix}ClientName`).value.trim(),
      tax_office_vkn: $(`${prefix}ClientTax`).value.trim(),
      address: $(`${prefix}ClientAddress`).value.trim(),
      phone: $(`${prefix}ClientPhone`).value.trim(),
      contract_type_period: $(`${prefix}ClientContract`).value.trim(),
      contract_date_no: $(`${prefix}ClientContractDateNo`).value.trim(),
    };
  }
  function collectInfoPayload() {
    return {
      supplier_vkn: state.documentSupplier?.supplier_vkn || "",
      document: { number: $("infoDocNumber").value.trim(), date: $("infoDocDate").value, city: $("infoDocCity").value.trim() },
      recipient_ymm: { name: $("infoRecipientName").value.trim(), title: $("infoRecipientTitle").value.trim(), address: $("infoRecipientAddress").value.trim() },
      ymm: readYmm("info"),
      contract_taxpayer: readContractTaxpayer("info"),
      respondent: {
        name: $("infoRespondentName").value.trim(), tax_office_vkn: $("infoRespondentTax").value.trim(),
        address: $("infoRespondentAddress").value.trim(), phone: $("infoRespondentPhone").value.trim(),
      },
      period_text: $("infoPeriod").value.trim(),
      invoices: collectGridRows("infoInvoiceRows"),
    };
  }
  function collectFindingPayload() {
    const contextYear = state.context?.taxpayer?.year || new Date().getFullYear();
    return {
      supplier_vkn: state.documentSupplier?.supplier_vkn || "",
      document: {
        number: $("findingDocNumber").value.trim(), date: $("findingDocDate").value,
        city: $("findingDocCity").value.trim(), signature_date: $("findingSignatureDate").value, year: contextYear,
      },
      ymm: readYmm("finding"),
      contract_taxpayer: readContractTaxpayer("finding"),
      examined_taxpayer: {
        name: $("findingInspectedName").value.trim(), tax_office_vkn: $("findingInspectedTax").value.trim(),
        address: $("findingInspectedAddress").value.trim(), phone: $("findingInspectedPhone").value.trim(),
      },
      chambers: { trade_chamber_registry: $("findingTradeRegistry").value.trim() },
      book_certifications: collectBookRows(),
      e_ledger_berats: collectGridRows("findingBeratRows"),
      shareholders: collectGridRows("findingShareRows"),
      invoices: collectGridRows("findingInvoiceRows"),
      subsuppliers: collectGridRows("findingSubsupplierRows"),
      vat_declarations: collectGridRows("findingVatRows"),
      payroll: collectGridRows("findingPayrollRows"),
      company_representative: $("findingRepresentative").value.trim(),
    };
  }
  async function downloadGeneratedDocument(endpoint, payload, filename, buttonId, modalFactory) {
    const button = $(buttonId);
    setBusy(button, true, "Word hazırlanıyor…");
    try {
      const response = await api(endpoint, { method: "POST", body: JSON.stringify(payload) });
      const blob = await response.blob();
      downloadBlob(blob, filename);
      modalFactory().hide();
      showToast("Word belgesi oluşturuldu ve indirildi.", "Belge hazır");
      await refreshActivity();
    } catch (error) {
      showToast(error.message, "Belge üretilemedi", true);
    } finally {
      setBusy(button, false);
    }
  }

  // UI events
  $("documentLimit").addEventListener("input", () => { state.limitTouched = true; });
  $("monthlyLimit").addEventListener("input", () => { state.limitTouched = true; });
  $("startDate").addEventListener("change", () => {
    if (state.limitTouched) return;
    const year = Number($("startDate").value.slice(0, 4));
    if (year && year < 2026) { $("documentLimit").value = 65000; $("monthlyLimit").value = 195000; }
    else if (year) { $("documentLimit").value = 150000; $("monthlyLimit").value = 450000; }
  });
  $("analyzeBtn").addEventListener("click", runAnalysis);
  $("refreshBtn").addEventListener("click", runAnalysis);
  $("supplierSearch").addEventListener("input", renderSuppliers);
  $("supplierFilter").addEventListener("change", renderSuppliers);
  $("supplierRows").addEventListener("change", (event) => {
    if (!event.target.classList.contains("supplier-check")) return;
    const vkn = event.target.dataset.vkn;
    if (event.target.checked) state.selected.add(vkn); else state.selected.delete(vkn);
    renderSuppliers();
  });
  $("supplierRows").addEventListener("click", (event) => {
    const button = event.target.closest(".detail-btn");
    if (button) openSupplier(button.dataset.vkn);
  });
  $("selectAll").addEventListener("change", (event) => {
    filteredSuppliers().forEach(row => { if (!row.excluded) event.target.checked ? state.selected.add(row.supplier_vkn) : state.selected.delete(row.supplier_vkn); });
    renderSuppliers();
  });
  $("saveCaseBtn").addEventListener("click", saveCase);
  $("uploadBtn").addEventListener("click", uploadResponse);
  $("refreshDocsBtn").addEventListener("click", refreshDocuments);
  $("documentsList").addEventListener("click", (event) => {
    const button = event.target.closest(".reconcile-btn");
    if (button) runReconciliation(button.dataset.id);
    const downloadButton = event.target.closest(".download-doc-btn");
    if (downloadButton) downloadDocument(downloadButton.dataset.id);
  });
  $("refreshActivityBtn").addEventListener("click", refreshActivity);
  $("exportBtn").addEventListener("click", downloadExcel);
  $("lettersBtn").addEventListener("click", openInfoRequestForm);
  $("findingRecordBtn").addEventListener("click", openFindingRecordForm);
  $("generateInfoRequestBtn").addEventListener("click", () => {
    const form = $("infoRequestForm");
    if (!form.reportValidity()) return;
    const payload = collectInfoPayload();
    downloadGeneratedDocument("/api/information-request", payload, "bilgi_isteme_yazisi.docx", "generateInfoRequestBtn", infoRequestModal);
  });
  $("generateFindingRecordBtn").addEventListener("click", () => {
    const form = $("findingRecordForm");
    if (!form.reportValidity()) return;
    const payload = collectFindingPayload();
    downloadGeneratedDocument("/api/finding-record", payload, "karsit_tespit_tutanagi.docx", "generateFindingRecordBtn", findingRecordModal);
  });
  bindAddRowButton("addInfoInvoiceRow", "infoInvoiceRows", [
    { key: "invoice_date", type: "date" }, { key: "invoice_no", wide: true }, { key: "base", type: "number" }, { key: "vat", type: "number" }
  ]);
  bindAddRowButton("addBeratRow", "findingBeratRows", [{ key: "period" }, { key: "type" }, { key: "created_at", type: "date" }, { key: "ettn", wide: true }]);
  bindAddRowButton("addShareRow", "findingShareRows", [{ key: "name", wide: true }, { key: "vkn_tckn" }, { key: "share_ratio" }]);
  bindAddRowButton("addFindingInvoiceRow", "findingInvoiceRows", [
    { key: "invoice_date", type: "date" }, { key: "invoice_no", wide: true }, { key: "base", type: "number" },
    { key: "vat", type: "number" }, { key: "ledger_date", type: "date" }, { key: "ledger_no", wide: true }, { key: "payment_method", wide: true }
  ]);
  bindAddRowButton("addSubsupplierRow", "findingSubsupplierRows", [
    { key: "period" }, { key: "invoice_date", type: "date" }, { key: "invoice_no", wide: true },
    { key: "gross", type: "number" }, { key: "name", wide: true }, { key: "tax_office" }, { key: "vkn_tckn" }
  ]);
  bindAddRowButton("addVatPeriodRow", "findingVatRows", [
    { key: "period" }, { key: "sales_services", type: "number" }, { key: "exemption", type: "number" },
    { key: "base_total", type: "number" }, { key: "calculated_vat", type: "number" }, { key: "additional_vat", type: "number" },
    { key: "total_calculated_vat", type: "number" }, { key: "previous_carryover", type: "number" },
    { key: "total_deductions", type: "number" }, { key: "payable_vat", type: "number" },
    { key: "next_carryover", type: "number" }, { key: "accrual_no" }
  ]);
  bindAddRowButton("addPayrollRow", "findingPayrollRows", [{ key: "period" }, { key: "employee_count", type: "number" }, { key: "tax_office" }]);
  addRemoveEvents();

  bootstrapApp();
})();
