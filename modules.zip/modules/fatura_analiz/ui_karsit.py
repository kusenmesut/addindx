import tkinter as tk
import os
from tkinter import filedialog
from tkinter import ttk, messagebox
import pandas as pd
from .word_bas import karsit_tutanak_olustur

from .karsit_engine import KarsitIncelemeEngine

class KarsitParametreFrame(tk.Frame):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, bg="#ffffff", *args, **kwargs)
        self.master = master
        self.engine = KarsitIncelemeEngine()
        self.df_sonuc = pd.DataFrame()
        
        self._apply_modern_styles()
        self.setup_ui()

    def _apply_modern_styles(self):
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Karsit.Treeview", background="#ffffff", rowheight=30, borderwidth=0, font=("Segoe UI", 9))
        style.configure("Karsit.Treeview.Heading", background="#f8f9fa", font=("Segoe UI", 9, "bold"))

    def setup_ui(self):
        # 1. BAŞLIK VE PARAMETRELER ALANI
        header_frame = tk.Frame(self, bg="#ffffff")
        header_frame.pack(fill=tk.X, padx=30, pady=(20, 10))
        tk.Label(header_frame, text="🔍 YMM Karşıt İnceleme Listesi (Risk Analizi)", font=("Segoe UI", 16, "bold"), bg="#ffffff", fg="#2c3e50").pack(side=tk.LEFT)

        param_frame = tk.LabelFrame(self, text="⚙️ Denetim Parametreleri", bg="#f8f9fa", font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        param_frame.pack(fill=tk.X, padx=30, pady=5)

        tk.Label(param_frame, text="Yasal Karşıt İnceleme Had Tutarı (TL):", bg="#f8f9fa").grid(row=0, column=0, sticky="w", pady=5)
        self.ent_limit = tk.Entry(param_frame, width=15, font=("Segoe UI", 10))
        self.ent_limit.insert(0, "65000") 
        self.ent_limit.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(param_frame, text="Riskli (KDVİRA) VKN'ler (Virgülle ayırın):", bg="#f8f9fa").grid(row=1, column=0, sticky="w", pady=5)
        self.ent_risk = tk.Entry(param_frame, width=50, font=("Segoe UI", 10))
        self.ent_risk.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(param_frame, text="Muaf VKN'ler (Virgülle ayırın):", bg="#f8f9fa").grid(row=2, column=0, sticky="w", pady=5)
        self.ent_muaf = tk.Entry(param_frame, width=50, font=("Segoe UI", 10))
        self.ent_muaf.grid(row=2, column=1, padx=10, pady=5)

        tk.Button(param_frame, text="🚀 Karşıt İnceleme Listesini Oluştur", command=self.hesapla, bg="#198754", fg="white", font=("Segoe UI", 10, "bold"), padx=15).grid(row=1, column=2, rowspan=2, padx=20)

        # 2. BİLGİ VE İSTATİSTİK ALANI
        self.lbl_istatistik = tk.Label(self, text="Kapsam Oranı: Bekleniyor...", font=("Segoe UI", 10, "italic"), bg="#ffffff", fg="#d35400")
        self.lbl_istatistik.pack(fill=tk.X, padx=30, pady=5)

        # 3. TABLO ALANI (YATAY KAYDIRMA EKLENDİ)
        table_frame = tk.Frame(self, bg="#ffffff", highlightthickness=1, highlightbackground="#dee2e6")
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=5)
        
        scroll_y = ttk.Scrollbar(table_frame, orient="vertical")
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        
        # --- YENİ EKLENTİ: Yatay Kaydırma Çubuğu ---
        scroll_x = ttk.Scrollbar(table_frame, orient="horizontal")
        scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.tree = ttk.Treeview(table_frame, style="Karsit.Treeview", show="headings", yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        scroll_y.config(command=self.tree.yview)
        scroll_x.config(command=self.tree.xview)
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        # Renklendirme Tagları
        self.tree.tag_configure('zorunlu', background='#ffeeba') 
        self.tree.tag_configure('kapsam_disi', background='#f8f9fa', foreground="#adb5bd") 
        self.tree.tag_configure('incele', background='#d1e7dd') 
        # --- 4. YENİ EKLENTİ: İŞLEM BUTONLARI ALANI ---
        action_frame = tk.Frame(self, bg="#ffffff")
        action_frame.pack(fill=tk.X, padx=30, pady=(0, 15))

        self.btn_word = tk.Button(action_frame, text="📄 Seçili Firmalar İçin Word Dilekçeleri Üret",
                                  command=self.word_uret_tetikle, bg="#0d6efd", fg="white",
                                  font=("Segoe UI", 11, "bold"), padx=15, pady=8, cursor="hand2")
        self.btn_word.pack(side=tk.RIGHT)
        
        tk.Label(action_frame, text="💡 İpucu: Tablodan CTRL veya SHIFT tuşu ile birden fazla firma seçebilirsiniz.", 
                 bg="#ffffff", fg="#6c757d", font=("Segoe UI", 9)).pack(side=tk.RIGHT, padx=15)
    def hesapla(self):
        try:
            limit_val = float(self.ent_limit.get().strip().replace(',', '.'))
        except ValueError:
            messagebox.showerror("Hata", "Lütfen geçerli bir limit tutarı giriniz.")
            return

        riskli_list = [vkn.strip() for vkn in self.ent_risk.get().split(',') if vkn.strip()]
        muaf_list = [vkn.strip() for vkn in self.ent_muaf.get().split(',') if vkn.strip()]

        df, stats, err = self.engine.karsit_inceleme_raporu_hazirla(
            limit_tl=limit_val, 
            riskli_vkn_list=riskli_list, 
            muaf_vkn_list=muaf_list
        )

        if err:
            messagebox.showerror("Hata", err)
            return

        self.df_sonuc = df
        self.guncelle_ui(stats)
    
    def guncelle_ui(self, stats):
        self.tree.delete(*self.tree.get_children())
        if self.df_sonuc.empty: return

        cols = list(self.df_sonuc.columns)
        self.tree["columns"] = cols
        
        for col in cols:
            self.tree.heading(col, text=col)
            
            # --- GÜNCELLEME: Sütun genişliklerini yeni alanlara göre ayarla ---
            if col == "S.No": width = 40
            elif col == "Tedarikçi Unvanı": width = 250
            elif col == "Adres": width = 300
            elif col in ["Toplam Matrah", "Toplam KDV", "İnceleme Durumu", "Seçilme Nedeni"]: width = 140
            elif col in ["Telefon", "E-Posta"]: width = 120
            elif col in ["İl", "İlçe", "Fatura Sayısı"]: width = 80
            else: width = 100
            
            # stretch=False sayesinde tablo taşıp scroll bar devreye girer
            self.tree.column(col, width=width, anchor="w", stretch=False)

        for _, row in self.df_sonuc.iterrows():
            vals = list(row.values)
            durum = str(row['İnceleme Durumu']).lower()
            neden = str(row['Seçilme Nedeni']).lower()

            tag = ""
            if "zorunlu" in durum or "kdvira" in neden: tag = "zorunlu"
            elif "yapılacak" in durum: tag = "incele"
            elif "incelenmeyecek" in durum: tag = "kapsam_disi"

            self.tree.insert("", "end", values=vals, tags=(tag,))

        bilgi_metni = (
            f"📊 Toplam Yüklenilen KDV: {stats['genel_toplam_kdv']:,.2f} TL | "
            f"İncelenen KDV: {stats['incelenen_toplam_kdv']:,.2f} TL | "
            f"Kapsanan Oran: %{stats['kapsanan_oran']:.2f}"
        )
        if stats['yarisi_kurali_aktif']:
            bilgi_metni += " ⚠️ (1/3 ve %50 Yarısı Kuralı İşletildi!)"
        else:
            bilgi_metni += " ✅ (%80 Genel Kural İşletildi)"

        self.lbl_istatistik.config(text=bilgi_metni, fg="#0f5132" if stats['kapsanan_oran'] >= 80 or stats['yarisi_kurali_aktif'] else "#842029")

    def word_uret_tetikle(self):
        if self.df_sonuc.empty:
            messagebox.showwarning("Uyarı", "Önce Karşıt İnceleme Listesini oluşturmalısınız.")
            return

        # Kullanıcının tablodan seçtiği satırları al
        secilenler = self.tree.selection()
        
        if not secilenler:
            # Eğer seçim yoksa kullanıcıya soralım: Sadece zorunlu olanları mı basalım?
            cevap = messagebox.askyesno("Seçim Yok", "Tablodan herhangi bir firma seçmediniz.\n\nSadece 'İnceleme Yapılacak' ve 'Zorunlu' durumunda olan TÜM firmalar için otomatik dilekçe üretilsin mi?")
            if not cevap:
                return
            # Filtreleme yap (İçinde 'inceleme' veya 'zorunlu' kelimesi geçenleri al)
            mask = self.df_sonuc['İnceleme Durumu'].str.contains('İnceleme|Zorunlu', na=False, case=False)
            df_basilacak = self.df_sonuc[mask].copy()
        else:
            # Sadece tablodan seçilen satırların VKN'lerini alıp DataFrame'den süz
            vkn_listesi = [str(self.tree.item(item)['values'][2]) for item in secilenler] 
            df_basilacak = self.df_sonuc[self.df_sonuc['VKN / TCKN'].astype(str).isin(vkn_listesi)].copy()

        if df_basilacak.empty:
            messagebox.showinfo("Bilgi", "Üretilecek uygun firma bulunamadı.")
            return

        # Çıktı klasörünü seçtir
        cikti_klasoru = filedialog.askdirectory(title="Word Dilekçelerinin Kaydedileceği Klasörü Seçin")
        if not cikti_klasoru:
            return

        # Ana ekrandan aktif Mükellef Bilgilerini Topla
        root = self.winfo_toplevel()
        vkn = str(getattr(root, 'vkn', 'Belirtilmedi'))
        unvan = str(getattr(root, 'unvan', 'MÜKELLEF FİRMA'))
        yil = str(getattr(root, 'yil', '2026'))
        
        mukellef_bilgileri = {
            'vkn': vkn,
            'unvan': unvan,
            'donem': f"{yil} Yılı" 
        }

        # Üretim Motorunu Çalıştır
        try:
            uretilenler = karsit_tutanak_olustur(df_basilacak, mukellef_bilgileri, cikti_klasoru)
            messagebox.showinfo("Başarılı", f"✅ {len(uretilenler)} adet Word dilekçesi başarıyla üretildi!\n\nKlasör: {cikti_klasoru}")
            
            # İşlem bitince Windows'ta klasörü otomatik aç
            try:
                os.startfile(cikti_klasoru)
            except:
                pass # MacOS/Linux için es geçilir
                
        except Exception as e:
            messagebox.showerror("Hata", f"Word dosyaları üretilirken bir hata oluştu:\n{e}")