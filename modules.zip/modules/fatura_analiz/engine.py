import os
import sqlite3
import pandas as pd
from config import get_mukellefler_dir
try:
    from config import get_base_dir
except ImportError:
    def get_base_dir(): return os.getcwd()
from utils.session_db import get_last_session

class FaturaAnalizEngine:
    def __init__(self):
        self.vkn = None
        self.yil = None
        self.target_folder = None
        self.db_path = None

    def _aktif_veriyi_bul(self):
        session = get_last_session()
        if not session:
            raise ValueError("Aktif oturum bulunamadı. Lütfen mükellef seçiniz.")
        
        self.vkn = str(session.get('vkn')).strip() # Karşılaştırma için string'e çevirip boşlukları siliyoruz
        self.yil = session.get('yil')
        
        base_dir = get_mukellefler_dir()
        self.target_folder = None
        
        if os.path.exists(base_dir):
            for f in os.listdir(base_dir):
                if f.endswith(f"-{self.vkn}"):
                    self.target_folder = os.path.join(base_dir, f)
                    break
                    
        if not self.target_folder:
            raise FileNotFoundError(f"Sistemde VKN: {self.vkn} ile biten bir klasör bulunamadı.")
            
        self.db_path = os.path.join(self.target_folder, str(self.yil), f"fatura_data_{self.yil}.db")

    def faturalari_cek(self):
        try:
            self._aktif_veriyi_bul()
            if not os.path.exists(self.db_path):
                return pd.DataFrame(), f"Bu döneme ait fatura veritabanı bulunamadı:\n{self.db_path}"
                
            conn = sqlite3.connect(self.db_path)
            df = pd.read_sql("SELECT * FROM FATURALAR", conn)
            conn.close()
            return df, None
        except Exception as e:
            return pd.DataFrame(), str(e)

    # ================= YENİ: ALIŞ VE SATIŞ FİLTRELERİ =================
    def alis_faturalarini_getir(self):
        """ALICI VKN'si aktif mükellefin VKN'si ile aynı olanları (Alışlar) getirir."""
        df, error = self.faturalari_cek()
        if error or df.empty: return df, error
        
        try:
            if 'ALICI_VKN_TCKN' in df.columns:
                # Güvenli karşılaştırma (Boşlukları sil, string yap)
                alici_vkn_serisi = df['ALICI_VKN_TCKN'].fillna('').astype(str).str.strip()
                df_alis = df[alici_vkn_serisi == self.vkn].copy()
                return df_alis, None
            return df, "Veri setinde ALICI_VKN_TCKN sütunu bulunamadı."
        except Exception as e:
            return pd.DataFrame(), f"Alış faturaları ayrıştırılırken hata: {str(e)}"

    def satis_faturalarini_getir(self):
        """ALICI VKN'si aktif mükellefin VKN'sinden FARKLI olanları (Satışlar) getirir."""
        df, error = self.faturalari_cek()
        if error or df.empty: return df, error
        
        try:
            if 'ALICI_VKN_TCKN' in df.columns:
                alici_vkn_serisi = df['ALICI_VKN_TCKN'].fillna('').astype(str).str.strip()
                df_satis = df[alici_vkn_serisi != self.vkn].copy()
                return df_satis, None
            return df, "Veri setinde ALICI_VKN_TCKN sütunu bulunamadı."
        except Exception as e:
            return pd.DataFrame(), f"Satış faturaları ayrıştırılırken hata: {str(e)}"

    def ozet_analiz_yap(self):
        df, error = self.faturalari_cek()
        if error or df.empty: return df, error
        try:
            if 'TIP_FATURA' in df.columns and 'TOPLAM_TUTAR' in df.columns:
                ozet_df = df.groupby('TIP_FATURA', as_index=False).agg(
                    Fatura_Sayisi=('NO_FATURA', 'count'), Toplam_Tutar=('TOPLAM_TUTAR', 'sum')
                )
                ozet_df['Toplam_Tutar'] = ozet_df['Toplam_Tutar'].round(2)
                return ozet_df, None
            return df, None
        except Exception as e:
            return pd.DataFrame(), f"Analiz sırasında hata: {str(e)}"

    # ================= SÜTUN AYARLARI (KALICI HAFIZA) =================
    def get_settings_db_path(self):
        return os.path.join(get_base_dir(), "ui_settings.db")

    def load_column_prefs(self):
        try:
            conn = sqlite3.connect(self.get_settings_db_path())
            c = conn.cursor()
            c.execute("CREATE TABLE IF NOT EXISTS FATURA_SUTUNLAR (id INTEGER PRIMARY KEY, visible_cols TEXT)")
            c.execute("SELECT visible_cols FROM FATURA_SUTUNLAR ORDER BY id DESC LIMIT 1")
            row = c.fetchone()
            conn.close()
            if row and row[0]: return row[0].split(',')
        except: pass
        return None

    def save_column_prefs(self, visible_cols):
        try:
            conn = sqlite3.connect(self.get_settings_db_path())
            c = conn.cursor()
            c.execute("CREATE TABLE IF NOT EXISTS FATURA_SUTUNLAR (id INTEGER PRIMARY KEY, visible_cols TEXT)")
            c.execute("DELETE FROM FATURA_SUTUNLAR") 
            c.execute("INSERT INTO FATURA_SUTUNLAR (visible_cols) VALUES (?)", (','.join(visible_cols),))
            conn.commit()
            conn.close()
        except Exception as e: print(f"Sütun ayarları kaydedilemedi: {e}")