import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
import math
import tempfile
import webbrowser
import os

from .iade_engine import IadeListesiEngine

# --- FATURA GÖRÜNTÜLEYİCİ İMPORTU ---
try:
    from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
except ImportError:
    
        FaturaGoruntulePopup = None

class LongDescriptionResolverPopup(tk.Toplevel):
    def __init__(self, parent, details_df, callback):
        super().__init__(parent)
        
        # --- İSTEDİĞİN SINIRI BURADAN BELİRLE ---
        self.char_limit = 70 
        # ----------------------------------------
        
        self.title(f"⚠️ {self.char_limit} Karakter Sınırı - Akıllı Gruplama ve Adlandırma Paneli")
        self.geometry("1100x700")
        self.config(bg="#f8f9fa")
        self.grab_set() 
        
        self.w_df = details_df.copy().reset_index(drop=True)
        self.callback = callback
        
        self.setup_ui()
        self.refresh_tree()

    def setup_ui(self):
        left_frame = tk.Frame(self, bg="#ffffff", bd=1, relief="solid")
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        tk.Label(left_frame, text="Faturalar ve Kalemler (Tutara Göre Sıralı)", bg="#343a40", fg="white", font=("Segoe UI", 10, "bold")).pack(fill=tk.X)
        
        tree_scroll_y = ttk.Scrollbar(left_frame, orient="vertical")
        tree_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.tree = ttk.Treeview(left_frame, columns=("Miktar", "Birim", "Tutar"), selectmode="extended", yscrollcommand=tree_scroll_y.set)
        self.tree.heading("#0", text="Fatura No / Mal-Hizmet Cinsi")
        self.tree.heading("Miktar", text="Miktar")
        self.tree.heading("Birim", text="Birim")
        self.tree.heading("Tutar", text="Tutar (Matrah)")
        
        self.tree.column("#0", width=350, stretch=True)
        self.tree.column("Miktar", width=80, anchor="center")
        self.tree.column("Birim", width=80, anchor="center")
        self.tree.column("Tutar", width=120, anchor="e")
        
        self.tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        tree_scroll_y.config(command=self.tree.yview)
        
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)
        
        self.tree.tag_configure("error_parent", background="#f8d7da", foreground="#721c24") 
        self.tree.tag_configure("ok_parent", background="#d4edda", foreground="#155724")   
        self.tree.tag_configure("child_row", background="#ffffff", foreground="#212529")

        right_frame = tk.Frame(self, bg="#f8f9fa", width=350)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 10), pady=10)
        right_frame.pack_propagate(False)

        edit_frame = tk.LabelFrame(right_frame, text="⚙️ Gruplama / Yeniden Adlandırma", bg="#f8f9fa", font=("Segoe UI", 10, "bold"), padx=15, pady=15)
        edit_frame.pack(fill=tk.X, pady=10)

        self.lbl_secim_bilgi = tk.Label(edit_frame, text="Lütfen sol taraftan birleştirilecek veya\nadlandırılacak kalemleri seçin.", bg="#f8f9fa", fg="#6c757d", justify="left")
        self.lbl_secim_bilgi.pack(anchor="w", pady=(0, 15))

        tk.Label(edit_frame, text=f"Yeni Mal Cinsi (Maks {self.char_limit} Kr.):", bg="#f8f9fa", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.ent_name = tk.Entry(edit_frame, width=40, font=("Segoe UI", 10))
        self.ent_name.pack(fill=tk.X, pady=(2, 5))
        
        # Dinamik sayaç başlangıcı
        self.lbl_char_count = tk.Label(edit_frame, text=f"0 / {self.char_limit}", bg="#f8f9fa", fg="black", font=("Segoe UI", 9, "bold"))
        self.lbl_char_count.pack(anchor="e")
        self.ent_name.bind("<KeyRelease>", self.update_char_count)

        self.btn_group = tk.Button(edit_frame, text="🔄 Seçilenleri Grupla / Adlandır", bg="#0d6efd", fg="white", font=("Segoe UI", 10, "bold"), state=tk.DISABLED, command=self.apply_grouping)
        self.btn_group.pack(fill=tk.X, pady=15, ipady=5)

        tk.Label(right_frame, text="💡 İpucu: Birden fazla satır seçmek için\nCTRL veya SHIFT tuşunu basılı tutun.", bg="#f8f9fa", fg="#17a2b8", justify="center").pack(pady=20)

        self.btn_finish = tk.Button(right_frame, text="🚀 Listeyi Tamamla ve Çıkar", bg="#198754", fg="white", font=("Segoe UI", 12, "bold"), pady=10, command=self.finish)
        self.btn_finish.pack(side=tk.BOTTOM, fill=tk.X)

    def refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        self.btn_group.config(state=tk.DISABLED)
        self.ent_name.delete(0, tk.END)
        self.lbl_secim_bilgi.config(text="Lütfen kalemleri seçin.", fg="#6c757d")
        
        faturas = self.w_df['NO_FATURA'].unique()
        
        for f_no in faturas:
            f_rows = self.w_df[self.w_df['NO_FATURA'] == f_no].sort_values(by='KDV_MATRAH_KLM', ascending=False)
            
            simulated_str = ", ".join([str(x) for x in f_rows['MAL_HIZMET_CINSI_CLEAN'] if str(x).strip() != ""])
            is_valid = len(simulated_str) <= self.char_limit # Dinamik kontrol
            
            tag = "ok_parent" if is_valid else "error_parent"
            durum_metni = f" [✓ OK - {len(simulated_str)} Kr.]" if is_valid else f" [⚠️ HATA - {len(simulated_str)} Kr.]"
            parent_id = self.tree.insert("", "end", text=f"Fatura: {f_no}{durum_metni}", tags=(tag,))
            
            for idx, row in f_rows.iterrows():
                self.tree.insert(parent_id, "end", iid=str(idx), text=str(row['MAL_HIZMET_CINSI_CLEAN']), 
                                 values=(f"{row['MIKTAR']:g}", str(row['BR']), f"{row['KDV_MATRAH_KLM']:,.2f}"), tags=("child_row",))
            
            if not is_valid:
                self.tree.item(parent_id, open=True)

    def on_tree_select(self, event):
        selections = self.tree.selection()
        if not selections:
            self.btn_group.config(state=tk.DISABLED)
            return

        valid_selections = [s for s in selections if self.tree.parent(s) != ""]
        if len(valid_selections) == 0:
            self.btn_group.config(state=tk.DISABLED)
            self.lbl_secim_bilgi.config(text="Fatura başlığı değil, altındaki\nürün kalemlerini seçmelisiniz.", fg="red")
            return

        parent_id = self.tree.parent(valid_selections[0])
        for s in valid_selections:
            if self.tree.parent(s) != parent_id:
                self.btn_group.config(state=tk.DISABLED)
                self.lbl_secim_bilgi.config(text="Farklı faturalardaki kalemleri\naynı anda gruplayamazsınız!", fg="red")
                return

        indices = [int(s) for s in valid_selections]
        selected_rows = self.w_df.loc[indices]
        
        birimler = selected_rows['BR'].str.strip().unique()
        birimler = [b for b in birimler if b != ""]
        
        if len(birimler) > 1:
            self.btn_group.config(state=tk.DISABLED)
            self.lbl_secim_bilgi.config(text=f"HATA: Farklı birimler tespit edildi!\n({', '.join(birimler)})\nSadece aynı birimlileri gruplayabilirsiniz.", fg="red")
            return

        self.btn_group.config(state=tk.NORMAL)
        adet = len(selected_rows)
        
        top_item = str(selected_rows.iloc[0]['MAL_HIZMET_CINSI_CLEAN'])
        if adet > 1:
            sugg_name = f"{top_item} vb."
            self.lbl_secim_bilgi.config(text=f"✓ {adet} adet kalem seçildi.\nBunlar tek kalemde toplanacak.", fg="green")
        else:
            sugg_name = top_item
            self.lbl_secim_bilgi.config(text="✓ 1 adet kalem seçildi.\nYeni isim verebilirsiniz.", fg="green")
            
        # Dinamik uzunluğa göre "vb." ekleme payı ayarlandı
        if len(sugg_name) > self.char_limit: sugg_name = sugg_name[:(self.char_limit - 5)] + " vb."
        
        self.ent_name.delete(0, tk.END)
        self.ent_name.insert(0, sugg_name)
        self.update_char_count(None)

    def apply_grouping(self):
        selections = self.tree.selection()
        valid_selections = [s for s in selections if self.tree.parent(s) != ""]
        indices = [int(s) for s in valid_selections]
        
        new_name = self.ent_name.get().strip()
        if len(new_name) > self.char_limit:
            messagebox.showwarning("Hata", f"Mal Cinsi {self.char_limit} karakteri aşamaz!")
            return
            
        selected_rows = self.w_df.loc[indices]
        new_row = selected_rows.iloc[0].copy()
        new_row['MAL_HIZMET_CINSI_CLEAN'] = new_name
        new_row['MIKTAR'] = selected_rows['MIKTAR'].sum()
        new_row['KDV_MATRAH_KLM'] = selected_rows['KDV_MATRAH_KLM'].sum()
        new_row['KDV_KLM'] = selected_rows['KDV_KLM'].sum()
        
        self.w_df = self.w_df.drop(indices)
        self.w_df = pd.concat([self.w_df, pd.DataFrame([new_row])], ignore_index=True)
        self.refresh_tree()

    def update_char_count(self, event):
        c_len = len(self.ent_name.get())
        self.lbl_char_count.config(text=f"{c_len} / {self.char_limit}", fg="red" if c_len > self.char_limit else "green")

    def finish(self):
        overrides = {}
        faturas = self.w_df['NO_FATURA'].unique()
        has_error = False
        
        for f_no in faturas:
            f_rows = self.w_df[self.w_df['NO_FATURA'] == f_no]
            cins_str = ", ".join([str(x) for x in f_rows['MAL_HIZMET_CINSI_CLEAN'] if str(x).strip() != ""])
            
            def m_b(row):
                m = str(row.get('MIKTAR', '0'))
                try: m = f"{float(m):g}"
                except: pass
                b = str(row.get('BR', '')).strip()
                return f"{m} {b}".strip()
                
            mik_str = ", ".join([m_b(row) for _, row in f_rows.iterrows() if m_b(row) != ""])
            
            if len(cins_str) > self.char_limit:
                has_error = True
            
            overrides[f_no] = {'name': cins_str, 'miktar': mik_str}

        if has_error:
            if not messagebox.askyesno("Uyarı", f"Hala {self.char_limit} karakter sınırını aşan faturalar var.\nDevam etmek istiyor musunuz?"):
                return
                
        self.destroy()
        self.callback(overrides)

class IadeListesiFrame(tk.Frame):
    def __init__(self, master, *args, **kwargs):
        super().__init__(master, bg="#ffffff", *args, **kwargs)
        self.master = master
        
        self.engine = IadeListesiEngine() 
        
        self.full_df = pd.DataFrame()
        self.page_size_var = tk.IntVar(value=15)               
        self.current_page = 1
        self.total_pages = 1
        self.aktif_liste_adi = "Henüz Seçim Yapılmadı"
        
        self.create_context_menu() # Sağ tık menüsünü oluştur
        
        self._apply_modern_styles()
        self.setup_ui()

    def _apply_modern_styles(self):
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
            
        style.configure("Iade.Treeview", background="#ffffff", foreground="#212529", 
                        rowheight=35, fieldbackground="#ffffff", borderwidth=0, font=("Segoe UI", 9))
        style.map("Iade.Treeview", background=[('selected', '#e9ecef')], foreground=[('selected', '#212529')])
        
        style.configure("Iade.Treeview.Heading", background="#f8f9fa", foreground="#495057", 
                        font=("Segoe UI", 9, "bold"), borderwidth=1, relief="flat")
        style.map("Iade.Treeview.Heading", background=[('active', '#e2e6ea')])
        style.configure("Iade.TCombobox", padding=5)

    def setup_ui(self):
        header_frame = tk.Frame(self, bg="#ffffff")
        header_frame.pack(fill=tk.X, padx=30, pady=(20, 0))
        tk.Label(header_frame, text="📑 KDV İade ve İndirim Listeleri", font=("Segoe UI", 16, "bold"), fg="#2c3e50", bg="#ffffff").pack(side=tk.LEFT)

        top_bar = tk.Frame(self, bg="#ffffff")
        top_bar.pack(fill=tk.X, padx=30, pady=(15, 10))
        
        left_actions = tk.Frame(top_bar, bg="#ffffff")
        left_actions.pack(side=tk.LEFT)
        
        tk.Button(left_actions, text="📋 Copy", command=self.export_copy, bg="#6c757d", fg="white", font=("Segoe UI", 9), relief="flat", cursor="hand2", padx=10, pady=4).pack(side=tk.LEFT, padx=(0, 2))
        tk.Button(left_actions, text="📊 Excel", command=self.export_excel, bg="#198754", fg="white", font=("Segoe UI", 9), relief="flat", cursor="hand2", padx=10, pady=4).pack(side=tk.LEFT, padx=(0, 2))
        tk.Button(left_actions, text="🖨️ Print / PDF", command=self.export_print, bg="#0dcaf0", fg="black", font=("Segoe UI", 9), relief="flat", cursor="hand2", padx=10, pady=4).pack(side=tk.LEFT, padx=(0, 2))

        right_actions = tk.Frame(top_bar, bg="#ffffff")
        right_actions.pack(side=tk.RIGHT)
        
        tk.Button(right_actions, text="📝 İndirilecek KDV Listesi Hazırla", command=self.load_indirilecek_kdv, bg="#6f42c1", fg="white", font=("Segoe UI", 10, "bold"), relief="flat", cursor="hand2", padx=15, pady=5).pack(side=tk.LEFT, padx=(0, 15))
        
        # 2. YENİ TEVKİFATLI SATIŞLAR BUTONU
        tk.Button(right_actions, text="✂️ Tevkifatlı Satışlar Listesi", command=self.load_tevkifatli_satislar, bg="#fd7e14", fg="white", font=("Segoe UI", 10, "bold"), relief="flat", cursor="hand2", padx=15, pady=5).pack(side=tk.LEFT)


        table_frame = tk.Frame(self, bg="#ffffff", highlightthickness=1, highlightbackground="#dee2e6")
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=5)
        scroll_y = ttk.Scrollbar(table_frame, orient="vertical")
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        scroll_x = ttk.Scrollbar(table_frame, orient="horizontal")
        scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree = ttk.Treeview(table_frame, style="Iade.Treeview", show="headings", yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        scroll_y.config(command=self.tree.yview)
        scroll_x.config(command=self.tree.xview)
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        # --- YENİ EKLENTİ: Hata satırı (Yevmiye Boş) için Kırmızı arka plan etiketi ---
        self.tree.tag_configure('evenrow', background='#f8f9fa')
        self.tree.tag_configure('oddrow', background='#ffffff')
        self.tree.tag_configure('missing_yev', background='#ffe6e6', foreground='#c0392b') # Kırmızı uyarı

        self.tree.bind("<Double-1>", self.on_row_double_click)
        self.tree.bind("<Button-3>", self.show_context_menu)

        bottom_bar = tk.Frame(self, bg="#ffffff")
        bottom_bar.pack(fill=tk.X, padx=30, pady=15)
        size_frame = tk.Frame(bottom_bar, bg="#ffffff")
        size_frame.pack(side=tk.LEFT, padx=(0, 20))
        tk.Label(size_frame, text="Sayfa Boyutu:", bg="#ffffff", fg="#495057", font=("Segoe UI", 9)).pack(side=tk.LEFT)
        cb_size = ttk.Combobox(size_frame, textvariable=self.page_size_var, values=[15, 30, 50, 100, 500, 1000], state="readonly", width=5, style="Iade.TCombobox")
        cb_size.pack(side=tk.LEFT, padx=(5, 0))
        cb_size.bind("<<ComboboxSelected>>", self._on_page_size_change)
        self.lbl_info = tk.Label(bottom_bar, text="Kayıt bulunamadı", bg="#ffffff", fg="#495057", font=("Segoe UI", 9))
        self.lbl_info.pack(side=tk.LEFT)
        self.pagination_frame = tk.Frame(bottom_bar, bg="#ffffff")
        self.pagination_frame.pack(side=tk.RIGHT)

    

    # ================= CONTEXT MENU VE GÖRÜNTÜLEYİCİ FONKSİYONLARI =================

    def create_context_menu(self):
        """Sağ tık menüsünü oluşturur."""
        self.context_menu = tk.Menu(self, tearoff=0, font=("Segoe UI", 9))
        self.context_menu.add_command(label="📄 Muhasebe Fişini Bul (Yevmiye)", command=self.jump_to_accounting)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="👁️ Orijinal Faturayı Görüntüle", command=self.open_invoice_viewer_btn)

    def show_context_menu(self, event):
        """Sağ tıkladığında faturayı seçer ve menüyü açar."""
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)

    def get_selected_fatura_no(self):
        """Seçili satırdaki Seri ve Sıra No'yu birleştirip gerçek Fatura Numarasını bulur."""
        sel = self.tree.selection()
        if not sel: return None
        
        vals = self.tree.item(sel[0])['values']
        cols = list(self.full_df.columns)
        
        try:
            idx_seri = cols.index("Alış Faturasının Serisi")
            idx_no = cols.index("Alış Faturasının Sıra No'su")
            
            seri = str(vals[idx_seri]).strip() if vals[idx_seri] else ""
            sira = str(vals[idx_no]).strip() if vals[idx_no] else ""
            
            # None veya 'nan' stringi kontrolü
            if seri.lower() == 'nan': seri = ""
            if sira.lower() == 'nan': sira = ""
            
            fatura_no = seri + sira
            return fatura_no
        except ValueError:
            return None

    def jump_to_accounting(self):
        """Fatura numarasını alıp Yevmiye modülünde aratır."""
        fatura_no = self.get_selected_fatura_no()
        if not fatura_no:
            messagebox.showerror("Hata", "Fatura numarası okunamadı.")
            return

        root = self.winfo_toplevel()
        yevmiye_frame = self.find_frame_by_class_name(root, "YevmiyeAnalizFrame")
        
        if yevmiye_frame:
            yevmiye_frame.show_fis_popup_by_doc_no(fatura_no)
        else:
            try:
                from modules.yevmiye_analiz.ui import YevmiyeAnalizFrame
                temp_window = tk.Toplevel(root)
                temp_window.withdraw() 
                
                # Mükellef bilgilerini geçici pencereye aktar
                if hasattr(root, 'vkn'):
                    temp_window.vkn = root.vkn
                    temp_window.unvan = getattr(root, 'unvan', '')
                    temp_window.yil = root.yil
                
                temp_yevmiye = YevmiyeAnalizFrame(temp_window)
                temp_yevmiye.show_fis_popup_by_doc_no(fatura_no)
            except Exception as e:
                messagebox.showerror("Hata", f"Yevmiye modülü başlatılamadı:\n{e}")

    def find_frame_by_class_name(self, parent, class_name):
        children = parent.winfo_children()
        for child in children:
            if child.__class__.__name__ == class_name: return child
        for child in children:
            res = self.find_frame_by_class_name(child, class_name)
            if res: return res
        return None

    def open_invoice_viewer_btn(self):
        self.on_row_double_click(None)

    def on_row_double_click(self, event):
        """Fatura veritabanından orijinal veriyi bulup görselleştiriciye gönderir."""
        if FaturaGoruntulePopup is None:
            messagebox.showerror("Eksik Modül", "Fatura görüntüleme kütüphaneleri (ui_goruntule.py) bulunamadı.")
            return

        fatura_no = self.get_selected_fatura_no()
        if not fatura_no:
            if event is None: messagebox.showwarning("Seçim Yok", "Listeden bir fatura seçiniz.")
            return

        try:
            # Motor üzerinden asıl veritabanı kayıtlarını çek
            df_all, error = self.engine.faturalari_cek()
            if error or df_all.empty:
                messagebox.showerror("Hata", "Veritabanına ulaşılamadı. Lütfen verilerinizi kontrol edin.")
                return

            # Birleştirdiğimiz fatura numarasını asıl veritabanında ara
            df_invoice_rows = df_all[df_all['NO_FATURA'].astype(str) == fatura_no]

            if df_invoice_rows.empty:
                messagebox.showwarning("Bulunamadı", f"{fatura_no} numaralı faturanın orijinal verisi veritabanında bulunamadı.")
                return

            # Görüntüleyiciyi Başlat
            FaturaGoruntulePopup(self.master, df_invoice_rows)

        except Exception as e:
            messagebox.showerror("Hata", f"Görüntüleyici hatası: {e}")

   # ================= RAPOR YÜKLEME METOTLARI =================
    # ================= RAPOR YÜKLEME METOTLARI =================
    def load_indirilecek_kdv(self, overrides=None):
        self.aktif_liste_adi = "Genel İndirilecek KDV Listesi"
        df, error, details = self.engine.indirilecek_kdv_listesi_getir(overrides)
        self._handle_engine_response(df, error, details, self.load_indirilecek_kdv)

    def load_tevkifatli_satislar(self, overrides=None):
        self.aktif_liste_adi = "Tevkifatlı Satışlar Listesi (KDV İade)"
        df, error, details = self.engine.tevkifatli_satislar_listesi_getir(overrides)
        self._handle_engine_response(df, error, details, self.load_tevkifatli_satislar)

    def _handle_engine_response(self, df, error, details, callback_func):
        if error == "OVERLIMIT":
            LongDescriptionResolverPopup(self, details, callback_func)
            return
        elif error: 
            messagebox.showerror("Hata", error)
            return
        self._init_data(df)

        
    def _init_data(self, df):
        self.full_df = df.copy()
        self.full_df = self.full_df.astype(object)
        self.full_df.fillna("", inplace=True)
        
        # Yevmiye No ve Sıra No temizliği (Sadece tam sayı)
        def clean_integer(val):
            try:
                val_str = str(val).strip()
                if pd.isna(val) or val_str == "" or val_str.lower() == "nan" or val_str.lower() == "none":
                    return ""
                return str(int(float(val))) # .0 ve küsüratları siler
            except:
                return str(val)
                
        for col in ["Yevmiye No", "Sıra No"]:
            if col in self.full_df.columns:
                self.full_df[col] = self.full_df[col].apply(clean_integer)
        
        self.current_page = 1
        self._setup_columns() 
        self._render_page()

    def _setup_columns(self):
        cols = list(self.full_df.columns)
        self.tree["columns"] = cols
        
        for col in cols:
            self.tree.heading(col, text=f"{str(col)}")
            width = 80 if col == "Sıra No" else 160
            self.tree.column(col, width=width, anchor="w")

    # ================= SAYFALAMA MANTIĞI =================
    
    def _on_page_size_change(self, event=None):
        self.current_page = 1
        self._render_page()

    def _render_page(self):
        self.tree.delete(*self.tree.get_children())
        total_records = len(self.full_df)
        page_size = self.page_size_var.get()
        
        self.total_pages = math.ceil(total_records / page_size) if total_records > 0 else 1
        if total_records == 0:
            self.lbl_info.config(text=f"[{self.aktif_liste_adi}] Kayıt bulunamadı")
            self._update_pagination_ui()
            return
            
        start_idx = (self.current_page - 1) * page_size
        end_idx = start_idx + page_size
        page_df = self.full_df.iloc[start_idx:end_idx]
        cols = list(self.full_df.columns)
        
        for i, (_, row) in enumerate(page_df.iterrows()):
            # --- YENİ EKLENTİ: Yevmiye No boşsa satırı kırmızı yap ---
            yev_no = str(row.get("Yevmiye No", "")).strip()
            if yev_no == "" or yev_no.lower() == "nan":
                tag = 'missing_yev'
            else:
                tag = 'evenrow' if i % 2 == 0 else 'oddrow'
                
            vals = []
            for col in cols:
                val = row.get(col, "")
                if any(k in col for k in ["Tutar", "KDV'si", "Hariç"]):
                    try:
                        if pd.notna(val) and str(val).strip() != "":
                            f_val = float(val)
                            formatted = f"{f_val:,.2f}"
                            val = formatted.replace(",", "X").replace(".", ",").replace("X", ".")
                    except: pass
                vals.append(val)
            self.tree.insert("", "end", values=vals, tags=(tag,))
            
        actual_end = min(end_idx, total_records)
        self.lbl_info.config(text=f"Rapor: {self.aktif_liste_adi} | Gösterilen: {start_idx + 1} - {actual_end} (Toplam: {total_records} Kayıt)")
        self._update_pagination_ui()

    def _update_pagination_ui(self):
        for widget in self.pagination_frame.winfo_children(): widget.destroy()
            
        btn_style_normal = {"bg": "#ffffff", "fg": "#0d6efd", "relief": "solid", "borderwidth": 1, "font": ("Segoe UI", 9)}
        btn_style_active = {"bg": "#0d6efd", "fg": "#ffffff", "relief": "solid", "borderwidth": 1, "font": ("Segoe UI", 9, "bold")}
        btn_style_disabled = {"bg": "#ffffff", "fg": "#6c757d", "relief": "solid", "borderwidth": 1, "font": ("Segoe UI", 9), "state": tk.DISABLED}

        prev_btn = tk.Button(self.pagination_frame, text="Önceki", padx=10, pady=2, cursor="hand2", command=lambda: self._change_page(self.current_page - 1))
        prev_btn.config(**(btn_style_normal if self.current_page > 1 else btn_style_disabled))
        prev_btn.pack(side=tk.LEFT, padx=1)

        start_p = max(1, self.current_page - 2)
        end_p = min(self.total_pages, self.current_page + 2)
        
        for p in range(start_p, end_p + 1):
            btn = tk.Button(self.pagination_frame, text=str(p), padx=8, pady=2, cursor="hand2", command=lambda page=p: self._change_page(page))
            if p == self.current_page: btn.config(**btn_style_active)
            else: btn.config(**btn_style_normal)
            btn.pack(side=tk.LEFT, padx=1)

        next_btn = tk.Button(self.pagination_frame, text="Sonraki", padx=10, pady=2, cursor="hand2", command=lambda: self._change_page(self.current_page + 1))
        next_btn.config(**(btn_style_normal if self.current_page < self.total_pages else btn_style_disabled))
        next_btn.pack(side=tk.LEFT, padx=1)

    def _change_page(self, new_page):
        if 1 <= new_page <= self.total_pages:
            self.current_page = new_page
            self._render_page()

    # ================= DIŞA AKTARIM (EXPORT) =================
    
    def export_copy(self):
        if self.full_df.empty: messagebox.showwarning("Uyarı", "Kopyalanacak veri yok!"); return
        try:
            self.full_df.to_clipboard(index=False)
            messagebox.showinfo("Başarılı", f"{self.aktif_liste_adi} panoya kopyalandı!")
        except Exception as e: messagebox.showerror("Hata", f"Kopyalama başarısız: {e}")

    def export_excel(self):
        if self.full_df.empty: messagebox.showwarning("Uyarı", "Dışa aktarılacak veri bulunamadı!"); return
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Dosyası", "*.xlsx")], title=f"{self.aktif_liste_adi} Kaydet")
        if path:
            try:
                self.full_df.to_excel(path, index=False)
                messagebox.showinfo("Başarılı", f"{len(self.full_df)} kayıt Excel'e başarıyla aktarıldı!")
            except Exception as e: messagebox.showerror("Hata", f"Excel oluşturulurken hata: {e}")

    def export_print(self):
        if self.full_df.empty: messagebox.showwarning("Uyarı", "Yazdırılacak veri bulunamadı!"); return
        df_print = self.full_df.copy()
        
        def format_money(val):
            try:
                if pd.notna(val) and str(val).strip() != "":
                    f_val = float(val)
                    return f"{f_val:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
                return val
            except: return str(val)

        for col in df_print.columns:
            if any(k in col for k in ["Tutar", "KDV'si", "Hariç"]):
                df_print[col] = df_print[col].apply(format_money)

        # --- YENİ EKLENTİ: PDF Raporunda Hücre İçi Kırmızı Renklendirme ---
        if "Yevmiye No" in df_print.columns:
            df_print["Yevmiye No"] = df_print["Yevmiye No"].apply(
                lambda x: x if str(x).strip() else '<div style="background-color: #ffcccc; color: #c0392b; font-weight: bold; text-align: center; border-radius: 3px; padding: 2px;">EKSİK</div>'
            )

        # "escape=False" parametresi HTML kodlarının (kırmızı div) tabloya işlenmesini sağlar
        html_table = df_print.to_html(index=False, classes="modern-table", justify="left", escape=False)
        
        html_content = f"""
        <html>
        <head>
            <meta charset="utf-8"><title>{self.aktif_liste_adi}</title>
            <style>
                body {{ font-family: 'Segoe UI', Arial, sans-serif; padding: 20px; color: #333; }}
                h2 {{ color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 5px; margin-bottom: 5px; }}
                h4 {{ color: #7f8c8d; margin-top: 0px; margin-bottom: 20px; font-weight: normal; font-size: 14px; }}
                .modern-table {{ border-collapse: collapse; width: 100%; font-size: 11px; }}
                .modern-table th, .modern-table td {{ border: 1px solid #ddd; padding: 6px; text-align: left; vertical-align: middle; }}
                .modern-table th {{ background-color: #f8f9fa; color: #495057; font-weight: bold; }}
                .modern-table tr:nth-child(even) {{ background-color: #f9f9f9; }}
                td {{ text-align: left; }}
                @media print {{ .no-print {{ display: none; }} body {{ padding: 0; }} }}
            </style>
        </head>
        <body>
            <div class="no-print" style="margin-bottom: 20px; background-color: #f8f9fa; padding: 15px; border-radius: 5px; border: 1px solid #dee2e6;">
                <button onclick="window.print()" style="padding:10px 20px; background:#0dcaf0; color:black; border:none; border-radius:5px; cursor:pointer; font-weight:bold;">
                    🖨️ Şimdi Yazdır veya PDF Olarak Kaydet
                </button>
            </div>
            <h2>{self.aktif_liste_adi}</h2>
            <h4>Toplam Kayıt: {len(self.full_df)}</h4>
            {html_table}
        </body>
        </html>
        """
        try:
            with tempfile.NamedTemporaryFile('w', delete=False, suffix='.html', encoding='utf-8') as f:
                f.write(html_content)
                tmp_path = f.name
            webbrowser.open(f'file://{os.path.abspath(tmp_path)}')
        except Exception as e: messagebox.showerror("Hata", f"Yazdırma ekranı oluşturulamadı: {e}")