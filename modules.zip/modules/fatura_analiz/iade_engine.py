import os
import sqlite3
import pandas as pd
import re
from config import get_mukellefler_dir
try:
    from config import get_base_dir
except ImportError:
    def get_base_dir(): return os.getcwd()
from utils.session_db import get_last_session

# ================= GİB GÜVENLİK KALKANI =================
def clean_gib_text(text):
    """GİB XML ayrıştırıcısını bozan yasaklı karakterleri temizler."""
    if pd.isna(text): return ""
    t = str(text)
    t = t.replace("&", " ve ")
    t = t.replace("<", "")
    t = t.replace(">", "")
    t = t.replace('"', "")
    t = t.replace("'", "")
    return t.strip()
# ========================================================

class IadeListesiEngine:
    def __init__(self):
        self.vkn = None
        self.yil = None
        self.target_folder = None
        self.db_path = None
        self.parquet_path = None

    def _aktif_veriyi_bul(self):
        """Aktif klasörü VKN son ekine göre tarayarak bulur."""
        session = get_last_session()
        if not session:
            raise ValueError("Aktif oturum bulunamadı. Lütfen mükellef seçiniz.")
        
        self.vkn = str(session.get('vkn')).strip()
        self.yil = session.get('yil')
        
        base_dir = get_mukellefler_dir()
        self.target_folder = None
        
        if os.path.exists(base_dir):
            for f in os.listdir(base_dir):
                if f.endswith(f"-{self.vkn}"):
                    self.target_folder = os.path.join(base_dir, f)
                    break
                    
        if not self.target_folder:
            raise FileNotFoundError(f"Sistemde VKN: {self.vkn} ile biten bir klasör bulunamadı.")
            
        self.db_path = os.path.join(self.target_folder, str(self.yil), f"fatura_data_{self.yil}.db")
        self.parquet_path = os.path.join(self.target_folder, str(self.yil), f"{self.yil}_FULL.parquet")

    def faturalari_cek(self):
        try:
            self._aktif_veriyi_bul()
            if not os.path.exists(self.db_path):
                return pd.DataFrame(), f"Bu döneme ait fatura veritabanı bulunamadı:\n{self.db_path}"
                
            conn = sqlite3.connect(self.db_path)
            df = pd.read_sql("SELECT * FROM FATURALAR", conn)
            conn.close()
            return df, None
        except Exception as e:
            return pd.DataFrame(), str(e)

    def _yevmiye_tarihlerini_ekle(self, df):
        if df.empty: return df
        try:
            if not self.parquet_path or not os.path.exists(self.parquet_path):
                return df 
                
            df_yevmiye = pd.read_parquet(self.parquet_path)
            
            gerekli_sutunlar = {'BelgeNo', 'KayitTarihi', 'YevmiyeNo'}
            if not gerekli_sutunlar.issubset(df_yevmiye.columns):
                return df
                
            df_yevmiye = df_yevmiye[['BelgeNo', 'KayitTarihi', 'YevmiyeNo']].copy()
            df_yevmiye = df_yevmiye.dropna(subset=['BelgeNo'])
            df_yevmiye = df_yevmiye[df_yevmiye['BelgeNo'].astype(str).str.strip() != '']
            
            df_yevmiye['Match_BelgeNo'] = df_yevmiye['BelgeNo'].astype(str).str.strip()
            df_yevmiye['Match_BelgeNo'] = df_yevmiye['Match_BelgeNo'].apply(lambda x: x[:-2] if x.endswith('.0') else x)
            df['Match_NoFatura'] = df['NO_FATURA'].astype(str).str.strip()
            
            df_yevmiye = df_yevmiye.drop_duplicates(subset=['Match_BelgeNo'], keep='first')
            df = df.merge(df_yevmiye, how='left', left_on='Match_NoFatura', right_on='Match_BelgeNo')
            df.drop(columns=['Match_NoFatura', 'Match_BelgeNo', 'BelgeNo'], inplace=True, errors='ignore')
            
        except Exception as e:
            pass
            
        return df

    def alis_faturalarini_getir(self):
        df, error = self.faturalari_cek()
        if error or df.empty: return df, error
        
        try:
            if 'ALICI_VKN_TCKN' in df.columns:
                alici_vkn_serisi = df['ALICI_VKN_TCKN'].fillna('').astype(str).str.strip()
                df_alis = df[alici_vkn_serisi == self.vkn].copy()
                df_alis = self._yevmiye_tarihlerini_ekle(df_alis)
                return df_alis, None
            return df, "Veri setinde ALICI_VKN_TCKN sütunu bulunamadı."
        except Exception as e:
            return pd.DataFrame(), f"Alış faturaları ayrıştırılırken hata: {str(e)}"

    def _gib_indirilecek_kdv_formati(self, df, overrides=None):
        if df.empty:
            return pd.DataFrame(), None, None

        df = df.reset_index(drop=True)
        
        for col in ['KDV_MATRAH_KLM', 'KDV_KLM', 'KDV_ORANI_KLM', 'MIKTAR']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0.0)

        for c in ['NO_FATURA', 'SATICI_VKN_TCKN', 'TARIH_FATURA', 'SATICI_KURUM', 'SATICI_ŞAHIS', 'MAL_HIZMET_CINSI', 'KayitTarihi', 'YevmiyeNo', 'BR']:
            if c not in df.columns: df[c] = ""
            
        df['BR'] = df['BR'].astype(str).str.strip()

        # ================= AŞAMA 1: AYNI ÜRÜNLERİ TOPLA =================
        df['MAL_HIZMET_CINSI_CLEAN'] = df['MAL_HIZMET_CINSI'].apply(clean_gib_text).fillna('')
        df['SATICI_VKN_TCKN'] = df['SATICI_VKN_TCKN'].fillna('')
        df['NO_FATURA'] = df['NO_FATURA'].fillna('')
        
        agg_step1 = {
            'TARIH_FATURA': 'first', 'SATICI_KURUM': 'first', 'SATICI_ŞAHIS': 'first',
            'MIKTAR': 'sum', 'KDV_MATRAH_KLM': 'sum', 'KDV_KLM': 'sum',
            'KayitTarihi': 'first', 'YevmiyeNo': 'first'
        }
        df_step1 = df.groupby(['NO_FATURA', 'SATICI_VKN_TCKN', 'KDV_ORANI_KLM', 'MAL_HIZMET_CINSI_CLEAN', 'BR'], dropna=False, as_index=False).agg(agg_step1)
        
        def miktar_birim_birlestir(row):
            m = str(row.get('MIKTAR', '0'))
            try: m = f"{float(m):g}"
            except: pass
            b = str(row.get('BR', '')).strip()
            return f"{m} {b}".strip()
            
        df_step1['MIKTAR_BIRIM_METIN'] = df_step1.apply(miktar_birim_birlestir, axis=1)

        # ================= AŞAMA 2: FATURA BAZINDA YAN YANA YAZ =================
        agg_step2 = {
            'TARIH_FATURA': 'first', 'SATICI_KURUM': 'first', 'SATICI_ŞAHIS': 'first',
            'MAL_HIZMET_CINSI_CLEAN': lambda x: ', '.join(str(i) for i in x if str(i).strip() != ""),
            'MIKTAR_BIRIM_METIN': lambda x: ', '.join(str(i) for i in x if str(i).strip() != ""),
            'KDV_MATRAH_KLM': 'sum', 'KDV_KLM': 'sum', 'KayitTarihi': 'first', 'YevmiyeNo': 'first'
        }
        df_grouped = df_step1.groupby(['NO_FATURA', 'SATICI_VKN_TCKN', 'KDV_ORANI_KLM'], dropna=False, as_index=False).agg(agg_step2)
        df_grouped.rename(columns={'MAL_HIZMET_CINSI_CLEAN': 'MAL_HIZMET_CINSI'}, inplace=True)

        # ================= KULLANICI MÜDAHALESİ (OVERRIDE) UYGULAMASI =================
        if overrides:
            for f_no, ov_data in overrides.items():
                # KRİTİK DÜZELTME: Fatura numaralarını kusursuz eşleşmesi için metne çevirip boşlukları siliyoruz
                mask = df_grouped['NO_FATURA'].astype(str).str.strip() == str(f_no).strip()
                if mask.any():
                    df_grouped.loc[mask, 'MAL_HIZMET_CINSI'] = ov_data['name']
                    df_grouped.loc[mask, 'MIKTAR_BIRIM_METIN'] = ov_data['miktar']

        # ================= 100 KARAKTER GİB SINIRI KONTROLÜ =================
        # KRİTİK DÜZELTME: Sadece ilk listelemede (overrides yoksa) sınırı kontrol et. 
        # Pop-up'tan dönen veriyi tekrar engele takma, doğrudan ana listeye gönder!
        if not overrides: 
            overlimit_mask = df_grouped['MAL_HIZMET_CINSI'].str.len() > 70
            if overlimit_mask.any():
                over_faturas = df_grouped.loc[overlimit_mask, 'NO_FATURA'].unique()
                raw_details = df_step1[df_step1['NO_FATURA'].isin(over_faturas)].copy()
                return None, "OVERLIMIT", raw_details
        # ====================================================================

        df_iade = pd.DataFrame()
        df_iade["Sıra No"] = range(1, len(df_grouped) + 1)
        
        def format_tarih(t):
            try:
                if pd.notna(t) and str(t).strip() != "":
                    return pd.to_datetime(t).strftime('%d.%m.%Y')
            except: pass
            return str(t)
            
        df_iade["Alış Faturasının Tarihi"] = df_grouped["TARIH_FATURA"].apply(format_tarih)
        df_iade["Alış Faturasının Serisi"] = "" 
        df_iade["Alış Faturasının Sıra No'su"] = df_grouped["NO_FATURA"].astype(str).str.strip().str[:20]

        kurum = df_grouped["SATICI_KURUM"].fillna("")
        sahis = df_grouped["SATICI_ŞAHIS"].fillna("")
        unvan_serisi = kurum.copy()
        mask_bos = unvan_serisi.str.strip() == ""
        unvan_serisi.loc[mask_bos] = sahis[mask_bos]
        df_iade["Satıcının Adı-Soyadı / Ünvanı"] = unvan_serisi.apply(clean_gib_text)

        vkn_serisi = df_grouped["SATICI_VKN_TCKN"].astype(str)
        df_iade["Satıcının Vergi Kimlik Numarası / TC Kimlik Numarası"] = vkn_serisi.str.replace(r'\D', '', regex=True)

        df_iade["Alınan Mal ve/veya Hizmetin Cinsi"] = df_grouped["MAL_HIZMET_CINSI"]
        df_iade["Alınan Mal ve/veya Hizmetin Miktarı"] = df_grouped["MIKTAR_BIRIM_METIN"]

        df_iade["Alınan Mal ve/veya Hizmetin KDV Hariç Tutarı"] = df_grouped["KDV_MATRAH_KLM"].astype(float).round(2)
        df_iade["KDV'si"] = df_grouped["KDV_KLM"].astype(float).round(2)
        df_iade["Tevkifata Tabi Olmayan Ve Bu Dönemde İndirilen Kdv Tutarı"] = df_grouped["KDV_KLM"].astype(float).round(2)
        df_iade["2 Nolu Beyannamede Ödenen Kdv Tutarı"] = 0.0  
        df_iade["Toplam İndirilecek KDV Tutarı"] = df_grouped["KDV_KLM"].astype(float).round(2)
        df_iade["GGB Tescil No'su (Alış İthalat İse)"] = ""

        def format_donem(t):
            try:
                if pd.notna(t) and str(t).strip() != "":
                    return pd.to_datetime(t).strftime('%Y/%m')
            except: pass
            return ""
            
        tarih_serisi_donem = df_grouped['KayitTarihi'].fillna(df_grouped['TARIH_FATURA'])
        df_iade["Belgenin İndirim Hakkının Kullanıldığı KDV Dönemi"] = tarih_serisi_donem.apply(format_donem)
        df_iade["Yevmiye No"] = df_grouped["YevmiyeNo"]

        return df_iade, None, None

    # ================= UI TARAFINDAN ÇAĞRILACAK ANA FONKSİYONLAR =================
    
    def indirilecek_kdv_listesi_getir(self, overrides=None):
        df_alis, error = self.alis_faturalarini_getir()
        if error: return None, error, None
        return self._gib_indirilecek_kdv_formati(df_alis, overrides)

    # ================= YENİ: SATIŞ FATURALARI VE TEVKİFAT MOTORU =================

    def satis_faturalarini_getir(self):
        """Sadece Aktif Mükellefin Satıcı Olduğu (Satış) Faturalarını Filtreler."""
        df, error = self.faturalari_cek()
        if error or df.empty: return df, error
        
        try:
            if 'SATICI_VKN_TCKN' in df.columns:
                satici_vkn_serisi = df['SATICI_VKN_TCKN'].fillna('').astype(str).str.strip()
                df_satis = df[satici_vkn_serisi == self.vkn].copy()
                
                # Yevmiye kayıt tarihlerini ve fiş numarasını bağla
                df_satis = self._yevmiye_tarihlerini_ekle(df_satis)
                return df_satis, None
            return df, "Veri setinde SATICI_VKN_TCKN sütunu bulunamadı."
        except Exception as e:
            return pd.DataFrame(), f"Satış faturaları ayrıştırılırken hata: {str(e)}"

    def tevkifatli_satislar_listesi_getir(self, overrides=None):
        """Satış faturalarından sadece tevkifatlı olanları süzer ve GİB formatına dönüştürür."""
        df_satis, error = self.satis_faturalarini_getir()
        if error: return None, error, None
        
        if df_satis.empty:
            return pd.DataFrame(), None, None

        df = df_satis.reset_index(drop=True)
        
        # Sayısal değerleri güvene al
        for col in ['KDV_MATRAH_KLM', 'KDV_KLM', 'KDV_ORANI_KLM', 'MIKTAR', 'TOP_TEVKIFAT_TUTAR']:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0.0)

        # Eksik sütunları güvene al (GİB İşlem Türü kodu genelde T_DEF_INDEX içinde tutulur)
        for c in ['NO_FATURA', 'ALICI_VKN_TCKN', 'TARIH_FATURA', 'ALICI_KURUM', 'ALICI_ŞAHIS', 'MAL_HIZMET_CINSI', 'KayitTarihi', 'YevmiyeNo', 'BR', 'T_DEF_INDEX']:
            if c not in df.columns: df[c] = ""
            
        df['BR'] = df['BR'].astype(str).str.strip()

        # ================= SADECE TEVKİFATLILARI SÜZ =================
        # Faturada tevkifat kesintisi varsa veya GİB işlem kodu (T_DEF_INDEX) yazılmışsa al.
        mask = (df.get('TOP_TEVKIFAT_TUTAR', 0) > 0) | (df['T_DEF_INDEX'].astype(str).str.strip() != "")
        df = df[mask].copy()
        
        if df.empty:
            return pd.DataFrame(), "Bu döneme ait Tevkifatlı Satış Faturası bulunamadı.", None

        # ================= AŞAMA 1: AYNI ÜRÜNLERİ TOPLA =================
        df['MAL_HIZMET_CINSI_CLEAN'] = df['MAL_HIZMET_CINSI'].apply(clean_gib_text).fillna('')
        df['ALICI_VKN_TCKN'] = df['ALICI_VKN_TCKN'].fillna('')
        df['NO_FATURA'] = df['NO_FATURA'].fillna('')
        
        agg_step1 = {
            'TARIH_FATURA': 'first', 'ALICI_KURUM': 'first', 'ALICI_ŞAHIS': 'first',
            'MIKTAR': 'sum', 'KDV_MATRAH_KLM': 'sum', 'KDV_KLM': 'sum',
            'KayitTarihi': 'first', 'YevmiyeNo': 'first', 
            'TOP_TEVKIFAT_TUTAR': 'first', 'T_DEF_INDEX': 'first' # Fatura bazında tevkifat bilgileri
        }
        df_step1 = df.groupby(['NO_FATURA', 'ALICI_VKN_TCKN', 'KDV_ORANI_KLM', 'MAL_HIZMET_CINSI_CLEAN', 'BR'], dropna=False, as_index=False).agg(agg_step1)
        
        def miktar_birim_birlestir(row):
            m = str(row.get('MIKTAR', '0'))
            try: m = f"{float(m):g}"
            except: pass
            b = str(row.get('BR', '')).strip()
            return f"{m} {b}".strip()
            
        df_step1['MIKTAR_BIRIM_METIN'] = df_step1.apply(miktar_birim_birlestir, axis=1)

        # ================= AŞAMA 2: FATURA BAZINDA YAN YANA YAZ =================
        agg_step2 = {
            'TARIH_FATURA': 'first', 'ALICI_KURUM': 'first', 'ALICI_ŞAHIS': 'first',
            'MAL_HIZMET_CINSI_CLEAN': lambda x: ', '.join(str(i) for i in x if str(i).strip() != ""),
            'MIKTAR_BIRIM_METIN': lambda x: ', '.join(str(i) for i in x if str(i).strip() != ""),
            'KDV_MATRAH_KLM': 'sum', 'KDV_KLM': 'sum', 'KayitTarihi': 'first', 'YevmiyeNo': 'first',
            'TOP_TEVKIFAT_TUTAR': 'first', 'T_DEF_INDEX': 'first'
        }
        df_grouped = df_step1.groupby(['NO_FATURA', 'ALICI_VKN_TCKN', 'KDV_ORANI_KLM'], dropna=False, as_index=False).agg(agg_step2)
        df_grouped.rename(columns={'MAL_HIZMET_CINSI_CLEAN': 'MAL_HIZMET_CINSI'}, inplace=True)

        # ================= KULLANICI MÜDAHALESİ (OVERRIDE) UYGULAMASI =================
        if overrides:
            for f_no, ov_data in overrides.items():
                mask = df_grouped['NO_FATURA'].astype(str).str.strip() == str(f_no).strip()
                if mask.any():
                    df_grouped.loc[mask, 'MAL_HIZMET_CINSI'] = ov_data['name']
                    df_grouped.loc[mask, 'MIKTAR_BIRIM_METIN'] = ov_data['miktar']

        # ================= KARAKTER GİB SINIRI KONTROLÜ =================
        KARAKTER_SINIRI = 75  # Hata çıkmaması için güvenli sınır

        if not overrides: 
            overlimit_mask = df_grouped['MAL_HIZMET_CINSI'].str.len() > KARAKTER_SINIRI
            if overlimit_mask.any():
                over_faturas = df_grouped.loc[overlimit_mask, 'NO_FATURA'].unique()
                raw_details = df_step1[df_step1['NO_FATURA'].isin(over_faturas)].copy()
                return None, "OVERLIMIT", raw_details

        # ================= YENİ GİB TEVKİFATLI SATIŞLAR FORMATINA DÖNÜŞTÜR =================
        df_iade = pd.DataFrame()
        df_iade["Sıra No"] = range(1, len(df_grouped) + 1)
        
        def format_tarih(t):
            try:
                if pd.notna(t) and str(t).strip() != "":
                    return pd.to_datetime(t).strftime('%d.%m.%Y')
            except: pass
            return str(t)
            
        df_iade["Satış Faturasının Tarihi"] = df_grouped["TARIH_FATURA"].apply(format_tarih)
        df_iade["Satış Faturasının Serisi"] = "" 
        df_iade["Satış Faturasının Sıra No'su"] = df_grouped["NO_FATURA"].astype(str).str.strip().str[:20]

        # Alıcı unvanı tespiti ve yasaklı karakter temizliği
        kurum = df_grouped["ALICI_KURUM"].fillna("")
        sahis = df_grouped["ALICI_ŞAHIS"].fillna("")
        unvan_serisi = kurum.copy()
        mask_bos = unvan_serisi.str.strip() == ""
        unvan_serisi.loc[mask_bos] = sahis[mask_bos]
        df_iade["Alıcının Adı-Soyadı / Ünvanı"] = unvan_serisi.apply(clean_gib_text)

        # Alıcı VKN (Sadece rakam)
        vkn_serisi = df_grouped["ALICI_VKN_TCKN"].astype(str)
        df_iade["Alıcının Vergi Kimlik Numarası / TC Kimlik Numarası"] = vkn_serisi.str.replace(r'\D', '', regex=True)

        df_iade["Satılan Mal ve/veya Hizmetin Cinsi"] = df_grouped["MAL_HIZMET_CINSI"]
        df_iade["Satılan Mal ve/veya Hizmetin Miktarı"] = df_grouped["MIKTAR_BIRIM_METIN"]

        # Matematiksel kontroller ve Tevkifat Oranları
        df_iade["Satılan Mal ve/veya Hizmetin KDV Hariç Tutarı"] = df_grouped["KDV_MATRAH_KLM"].astype(float).round(2)
        df_iade["KDV'si"] = df_grouped["KDV_KLM"].astype(float).round(2)
        df_iade["Yapılan Tevkifat Tutarı"] = df_grouped["TOP_TEVKIFAT_TUTAR"].astype(float).round(2)
        
        # İşlem Türü Kodu (Örn: 601, 604 vb.)
        df_iade["İade Hakkı Doğuran İşlem Türü"] = df_grouped["T_DEF_INDEX"]

        # Ek Denetim Sütunları
        df_iade["Yevmiye No"] = df_grouped["YevmiyeNo"]
        df_iade["Kayıt Tarihi"] = df_grouped["KayitTarihi"].apply(format_tarih)

        return df_iade, None, None