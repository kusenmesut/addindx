import tkinter as tk
from tkinter import ttk
from .engine import IstatistikEngine

class StatsCard(tk.Frame):
    """Tek bir istatistik kartını temsil eden widget"""
    def __init__(self, parent, title, value, icon, bg_color, text_color="white"):
        super().__init__(parent, bg=bg_color, padx=20, pady=20)
        
        # Kart Gölge Efekti (Basit border ile)
        self.configure(highlightbackground="#dfe6e9", highlightthickness=1)

        # İkon (Solda)
        lbl_icon = tk.Label(self, text=icon, font=("Segoe UI Symbol", 24), bg=bg_color, fg=text_color)
        lbl_icon.pack(side="left", padx=(0, 15))

        # Metin Alanı (Sağda)
        text_frame = tk.Frame(self, bg=bg_color)
        text_frame.pack(side="left", fill="both", expand=True)

        # Değer (Büyük)
        tk.Label(text_frame, text=value, font=("Segoe UI", 20, "bold"), bg=bg_color, fg=text_color, anchor="w").pack(fill="x")
        
        # Başlık (Küçük)
        tk.Label(text_frame, text=title, font=("Segoe UI", 10), bg=bg_color, fg=text_color, anchor="w").pack(fill="x")

class StatisticsPanel(tk.Frame):
    def __init__(self, parent, controller=None):
        super().__init__(parent, bg="#f0f2f5") # Ana arka plan rengi
        self.controller = controller
        self.engine = IstatistikEngine()
        
        self.setup_ui()
        self.refresh_stats()

    def setup_ui(self):
        # Konteyner
        self.container = tk.Frame(self, bg="#f0f2f5")
        self.container.pack(fill="x", pady=20, padx=20)
        
        # Grid Sistemi (4 Sütun)
        for i in range(4):
            self.container.columnconfigure(i, weight=1, uniform="card")

    def refresh_stats(self):
        # Mevcut kartları temizle
        for widget in self.container.winfo_children():
            widget.destroy()

        # Verileri Çek
        data = self.engine.get_summary_stats()
        
        # Kart Tanımları (Başlık, Değer, İkon, Renk)
        cards = [
            ("Kayıtlı Mükellef", str(data["mukellef_sayisi"]), "👥", "#3498db"), # Mavi
            ("Toplam Veri", f"{data['toplam_boyut_mb']} MB", "💾", "#9b59b6"),   # Mor
            ("İşlenen Dosya", str(data["toplam_dosya"]), "📄", "#e67e22"),       # Turuncu
            ("Aktif Çalışma", data["aktif_donem"], "🚀", "#2ecc71")             # Yeşil
        ]

        # Kartları Oluştur
        for idx, (title, val, icon, color) in enumerate(cards):
            card = StatsCard(self.container, title, val, icon, color)
            card.grid(row=0, column=idx, padx=10, sticky="ew")