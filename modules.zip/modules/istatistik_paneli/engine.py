import os
from config import get_mukellefler_dir
from utils.session_db import get_last_session

class IstatistikEngine:
    def __init__(self):
        self.root_dir = get_mukellefler_dir()

    def get_summary_stats(self):
        """
        Sistemdeki genel istatistikleri hesaplar.
        """
        stats = {
            "mukellef_sayisi": 0,
            "toplam_dosya": 0,
            "toplam_boyut_mb": 0.0,
            "aktif_donem": "Seçilmedi"
        }

        # 1. Aktif Oturum Bilgisi
        session = get_last_session()
        if session and session.get('vkn') != '---':
            stats["aktif_donem"] = f"{session.get('yil')} - {session.get('unvan')[:15]}..."
        
        # 2. Klasör Taraması (Mükellef ve Dosya Sayıları)
        if os.path.exists(self.root_dir):
            # Sadece VKN içeren klasörleri mükellef say
            mukellefler = [d for d in os.listdir(self.root_dir) if os.path.isdir(os.path.join(self.root_dir, d)) and '-' in d]
            stats["mukellef_sayisi"] = len(mukellefler)

            # Derinlemesine tarama (Dosya sayısı ve Boyut)
            total_size = 0
            file_count = 0
            for dirpath, _, filenames in os.walk(self.root_dir):
                file_count += len(filenames)
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    if os.path.exists(fp):
                        total_size += os.path.getsize(fp)
            
            stats["toplam_dosya"] = file_count
            stats["toplam_boyut_mb"] = round(total_size / (1024 * 1024), 2)

        return stats