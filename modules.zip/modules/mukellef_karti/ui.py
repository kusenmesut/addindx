import tkinter as tk
from tkinter import ttk, messagebox
from config import CLR_BODY_BG, CLR_ACCENT, CLR_BTN_BG, CLR_BTN_FG
from .engine import mukellef_meta_yukle, mukellef_meta_kaydet

# Tasarım Renkleri (Referans Görsele Uygun)
CLR_CARD_BG = "#ffffff"       # Kartın Beyaz Rengi
CLR_HEADER_TEXT = "#2c3e50"   # Koyu Gri/Mavi Başlıklar
CLR_SECTION_TEXT = "#3498db"  # Mavi Alt Başlıklar (Referanstaki gibi)
CLR_LABEL_TEXT = "#7f8c8d"    # Gri Input Etiketleri
CLR_BORDER = "#bdc3c7"        # Input Çerçeveleri

class MukellefBilgiKartiUI(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.main_app = master.winfo_toplevel()
        
        # VKN Kontrolü
        self.vkn = getattr(self.main_app, 'vkn', '0000000000')
        if self.vkn == '---': self.vkn = '0000000000'
        
        self.data = self._get_data()
        self.entry_vars = {} 
        self.setup_ui()

    def _get_data(self):
        if self.vkn != '0000000000':
            res = mukellef_meta_yukle(self.vkn)
            if res: return res
        return {
            "vkn": self.vkn, "unvan": getattr(self.main_app, 'unvan', 'Yeni Mükellef'),
            "telefon": "", "email": "", "fax": "", "web": "",
            "adres_cadde": "", "adres_ilce": "", "adres_sehir": "", "adres_pk": "",
            "vergi_dairesi": "", "muh_ad_soyad": "", "muh_telefon": "", "muh_email": ""
        }

    def setup_ui(self):
        # Ana Scrollable Canvas (Form uzun olabilir)
        canvas = tk.Canvas(self, bg=CLR_BODY_BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=CLR_BODY_BG)

        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="n") # Ortada durması için 'n' (north) ve pack ayarı
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # --- BEYAZ KART ALANI (Card UI) ---
        # Referans görseldeki beyaz kağıt efekti
        card = tk.Frame(scrollable_frame, bg=CLR_CARD_BG, padx=40, pady=40, bd=1, relief="solid")
        card.pack(pady=30, padx=20, ipadx=10) # Sayfada ortala

        # 1. FORM BAŞLIĞI
        tk.Label(card, text="MÜKELLEF BİLGİ FORMU", font=("Segoe UI", 18, "bold"), 
                 bg=CLR_CARD_BG, fg="#2980b9").pack(pady=(0, 20))

        self.draw_dashed_line(card) # Kesikli Çizgi

        # 2. ŞİRKET BİLGİLERİ (COMPANY INFORMATION)
        self.create_section_header(card, "MÜKELLEF KİMLİK BİLGİLERİ")
        
        frm_kimlik = tk.Frame(card, bg=CLR_CARD_BG)
        frm_kimlik.pack(fill=tk.X, pady=10)
        
        # Tam Genişlik: Ünvan
        self.create_input_field(frm_kimlik, "Ünvan / Ad Soyad", "unvan", row=0, col=0, colspan=2)
        
        # Yarı Genişlik: VKN ve Vergi Dairesi
        self.create_input_field(frm_kimlik, "Vergi Kimlik No (VKN)", "vkn", row=1, col=0)
        self.create_input_field(frm_kimlik, "Vergi Dairesi", "vergi_dairesi", row=1, col=1)

        # 3. İLETİŞİM BİLGİLERİ (CONTACT)
        self.create_section_header(card, "İLETİŞİM VE ADRES")
        
        frm_iletisim = tk.Frame(card, bg=CLR_CARD_BG)
        frm_iletisim.pack(fill=tk.X, pady=10)

        # Telefon ve Email
        self.create_input_field(frm_iletisim, "Telefon", "telefon", row=0, col=0)
        self.create_input_field(frm_iletisim, "E-Posta Adresi", "email", row=0, col=1)
        
        # Adres Satırı (Tam)
        self.create_input_field(frm_iletisim, "Cadde / Sokak / No", "adres_cadde", row=1, col=0, colspan=2)
        
        # Şehir / İlçe
        self.create_input_field(frm_iletisim, "İlçe", "adres_ilce", row=2, col=0)
        self.create_input_field(frm_iletisim, "Şehir (İl)", "adres_sehir", row=2, col=1)

        # 4. MUHASEBECİ / TEMSİLCİ (REMITTANCE INFO)
        self.create_section_header(card, "MALİ MÜŞAVİR / MUHASEBE")
        
        frm_muh = tk.Frame(card, bg=CLR_CARD_BG)
        frm_muh.pack(fill=tk.X, pady=10)
        
        self.create_input_field(frm_muh, "Adı Soyadı", "muh_ad_soyad", row=0, col=0)
        self.create_input_field(frm_muh, "Telefon", "muh_telefon", row=0, col=1)
        self.create_input_field(frm_muh, "E-Posta", "muh_email", row=1, col=0, colspan=2)

        self.draw_dashed_line(card) # Alt Çizgi

        # 5. BUTON (NEXT Tarzı)
        btn_save = tk.Button(card, text="KAYDET VE GÜNCELLE", command=self.kaydet,
                             bg="#4834d4", fg="white", font=("Segoe UI", 11, "bold"),
                             padx=30, pady=10, bd=0, cursor="hand2")
        btn_save.pack(side=tk.RIGHT, pady=20)

        # Canvas genişliğini güncelle (Ortalamak için önemli)
        canvas.update_idletasks()
        canvas.configure(scrollregion=canvas.bbox("all"))
        # Pencere genişleyince kartı ortalamak için canvas width ayarı
        canvas.itemconfigure(1, width=800) # Sabit genişlikte kart (800px)

    def create_section_header(self, parent, text):
        """Mavi başlık (COMPANY INFORMATION tarzı)"""
        tk.Label(parent, text=text, font=("Segoe UI", 12, "bold"), 
                 bg=CLR_CARD_BG, fg=CLR_SECTION_TEXT, anchor="w").pack(fill=tk.X, pady=(15, 5))

    def create_input_field(self, parent, label_text, var_key, row, col, colspan=1):
        """
        Referans görseldeki gibi:
        Label Üstte
        Input Altta (Yuvarlakımsı köşeli ve geniş)
        """
        container = tk.Frame(parent, bg=CLR_CARD_BG, padx=10, pady=5)
        container.grid(row=row, column=col, columnspan=colspan, sticky="ew")
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_columnconfigure(1, weight=1)

        # Label
        tk.Label(container, text=label_text, bg=CLR_CARD_BG, fg=CLR_LABEL_TEXT, 
                 font=("Segoe UI", 9, "bold"), anchor="w").pack(fill=tk.X)

        # Entry Variable
        val = self.data.get(var_key, "")
        if val is None: val = ""
        var = tk.StringVar(value=str(val))
        self.entry_vars[var_key] = var

        # Entry (Modern Görünüm için ipady ile yükseklik veriyoruz)
        entry = tk.Entry(container, textvariable=var, font=("Segoe UI", 11), 
                         bg="#f7f9fc", fg="#2c3e50", relief="flat", bd=1)
        # Entry etrafına çerçeve efekti için Frame kullanılabilir ama basitlik için highlight
        entry.config(highlightbackground=CLR_BORDER, highlightthickness=1, highlightcolor=CLR_SECTION_TEXT)
        entry.pack(fill=tk.X, ipady=8, pady=(5, 0)) # ipady inputu yüksek gösterir

    def draw_dashed_line(self, parent):
        """Canvas ile kesikli çizgi çizer"""
        canvas = tk.Canvas(parent, bg=CLR_CARD_BG, height=2, highlightthickness=0)
        canvas.pack(fill=tk.X, pady=15)
        canvas.update()
        w = 900 # Tahmini genişlik
        canvas.create_line(0, 1, w, 1, fill="#bdc3c7", dash=(4, 4), width=1)

    def kaydet(self):
        yeni_veri = {k: v.get() for k, v in self.entry_vars.items()}
        yeni_vkn = yeni_veri.get('vkn')
        
        # VKN Kontrolü (Zorunlu)
        if not yeni_vkn or yeni_vkn == '0000000000':
            messagebox.showwarning("Eksik Bilgi", "Lütfen geçerli bir Vergi Kimlik Numarası (VKN) giriniz.")
            return

        # Eski vkn'yi ve yeni veriyi motora gönder
        if mukellef_meta_kaydet(self.vkn, yeni_veri):
            messagebox.showinfo("Başarılı", "✅ Mükellef bilgileri başarıyla güncellendi.")
            
            # --- YENİ EKLENEN: OTURUM VE VKN GÜNCELLEMESİ ---
            self.vkn = yeni_vkn # Bu ekranın VKN'sini yenile
            setattr(self.main_app, 'vkn', yeni_vkn) # Ana uygulamanın VKN'sini yenile
            
            # Session Veritabanını Güncelle (Arayüz kapatılıp açılınca yeni VKN'den devam etsin diye)
            try:
                from utils.session_db import save_session
                save_session(yeni_vkn, getattr(self.main_app, 'yil', '-'))
            except: pass
            
            # Ana Ekranı (Üst Header vb.) Güncelle
            if hasattr(self.main_app, 'update_header_info'):
                self.main_app.update_header_info(yeni_veri['unvan'], yeni_vkn, getattr(self.main_app, 'yil', '-'))
        else:
            messagebox.showerror("Hata", "Kayıt sırasında bir hata oluştu. (Muhtemelen dosya yazma izni engellendi)")