import os
import json
import sqlite3
import re
from tkinter import messagebox
from config import get_mukellef_db_dir, get_mukellefler_dir, get_base_dir



def get_db_path(vkn):
    return os.path.join(get_mukellef_db_dir(), f"{vkn}.db")

def mukellef_meta_yukle(vkn):
    # 1. JSON (Öncelikli)
    json_path = os.path.join(get_mukellefler_dir(), f"meta_{vkn}.json")
    if os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f: return json.load(f)
        except: pass
        
    # 2. SQLite
    path = get_db_path(vkn)
    if not os.path.exists(path): return None
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.cursor()
        cur.execute("SELECT * FROM mukellef_bilgi WHERE vkn=?", (vkn,))
        row = cur.fetchone()
        return dict(row) if row else None
    except: return None
    finally: conn.close()


def mukellef_meta_kaydet(eski_vkn, data):
    yeni_vkn = str(data.get('vkn')).strip()
    yeni_unvan = str(data.get('unvan', 'Yeni Mukellef')).strip()
    eski_vkn = str(eski_vkn).strip() if eski_vkn else ""
    
    if not yeni_vkn or yeni_vkn == "0000000000": return False
    
    # Windows klasör isimlerinde yasaklı olan karakterleri temizle
    guvenli_unvan = re.sub(r'[\\/*?:"<>|]', "", yeni_unvan).strip()
    
    # YENİ FORMAT: UNVAN-VKN (Ekran görüntüsündeki yapı)
    hedef_klasor_adi = f"{guvenli_unvan}-{yeni_vkn}"
    
    degisenler = []
    hatalar = []
    mukellefler_klasoru = get_mukellefler_dir()

    # =========================================================================
    # 1. DOSYA VE FİZİKSEL KLASÖR GÜNCELLEMESİ
    # =========================================================================
    if eski_vkn and eski_vkn != "0000000000":
        
        # A. VKN değiştiyse Sistem Dosyalarını (.json ve .db) güncelle
        if eski_vkn != yeni_vkn:
            eski_json = os.path.join(mukellefler_klasoru, f"meta_{eski_vkn}.json")
            yeni_json = os.path.join(mukellefler_klasoru, f"meta_{yeni_vkn}.json")
            if os.path.exists(eski_json):
                try: 
                    os.replace(eski_json, yeni_json)
                    degisenler.append(f"JSON Dosyası: meta_{yeni_vkn}.json yapıldı.")
                except Exception as e: hatalar.append(f"JSON Dosyası Hatası: {e}")
                
            eski_db = get_db_path(eski_vkn)
            yeni_db = get_db_path(yeni_vkn)
            if os.path.exists(eski_db):
                try: 
                    os.replace(eski_db, yeni_db)
                    degisenler.append(f"Veritabanı: {yeni_vkn}.db yapıldı.")
                except Exception as e: hatalar.append(f"DB Dosyası Hatası: {e}")

       # B. "UNVAN-VKN" Klasörünü MUKELLEFLER Dizininde Bul ve Güncelle
        klasor_bulundu = False
        
        if os.path.exists(mukellefler_klasoru):
            for item in os.listdir(mukellefler_klasoru):
                item_path = os.path.join(mukellefler_klasoru, item)
                if os.path.isdir(item_path):
                    # Klasör adı eski VKN'yi içeriyorsa
                    if eski_vkn in item and item not in ["MUKELLEF_DB", "MUKELLEFLER", "modules", "utils", ".git", "__pycache__"]:
                        klasor_bulundu = True
                        if item != hedef_klasor_adi:
                            yeni_klasor_yolu = os.path.join(mukellefler_klasoru, hedef_klasor_adi)
                            
                            # YENİ: EĞER HEDEF KLASÖR ZATEN VARSA İŞLEMİ DURDUR VE UYAR
                            if os.path.exists(yeni_klasor_yolu):
                                hatalar.append(f"Klasör Çakışması:\n'{hedef_klasor_adi}' adında bir klasör zaten var! İsim değiştirme iptal edildi.")
                            else:
                                try:
                                    os.replace(item_path, yeni_klasor_yolu)
                                    degisenler.append(f"Ana Klasör Güncellendi:\n'{item}' -> '{hedef_klasor_adi}'")
                                except Exception as e:
                                    hatalar.append(f"Klasör Yeniden Adlandırma Hatası ('{item}'):\nBu klasör Excel'de veya Dosya Gezgininde açık olabilir.\nDetay: {e}")
        
        # Eğer sistemde eski VKN'ye ait klasör yoksa, MUKELLEFLER içine YENİ OLUŞTUR
        if not klasor_bulundu:
            yeni_klasor_yolu = os.path.join(mukellefler_klasoru, hedef_klasor_adi)
            
            # YENİ: EĞER YENİ OLUŞTURULACAK KLASÖR ZATEN VARSA UYAR
            if os.path.exists(yeni_klasor_yolu):
                hatalar.append(f"Klasör Çakışması:\n'{hedef_klasor_adi}' adında bir klasör zaten mevcut. Yeni klasör açılamadı.")
            else:
                try:
                    os.makedirs(yeni_klasor_yolu)
                    degisenler.append(f"Sistemde klasör bulunamadığı için YENİ OLUŞTURULDU:\n'{hedef_klasor_adi}'")
                except Exception as e:
                    hatalar.append(f"Klasör Oluşturma Hatası: {e}")
                    
    else:
        # ESKİ VKN YOKSA (Tamamen yeni mükellef kaydediliyorsa)
        yeni_klasor_yolu = os.path.join(mukellefler_klasoru, hedef_klasor_adi)
        if os.path.exists(yeni_klasor_yolu):
            hatalar.append(f"Klasör Çakışması:\n'{hedef_klasor_adi}' adında bir klasör zaten var! Kayıt yapıldı ancak yeni klasör açılamadı.")
        else:
            try:
                os.makedirs(yeni_klasor_yolu)
                degisenler.append(f"Yeni Klasör Oluşturuldu:\n'{hedef_klasor_adi}'")
            except Exception as e: pass
    # =========================================================================
    # 2. JSON KAYDETME
    # =========================================================================
    json_path = os.path.join(mukellefler_klasoru, f"meta_{yeni_vkn}.json")
    try:
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        hatalar.append(f"JSON Kaydetme Hatası: {e}")

    # =========================================================================
    # 3. SQLITE KAYDETME
    # =========================================================================
    path = get_db_path(yeni_vkn)
    try:
        conn = sqlite3.connect(path)
        cur = conn.cursor()
        cur.execute('''CREATE TABLE IF NOT EXISTS mukellef_bilgi (
            id INTEGER PRIMARY KEY, vkn TEXT UNIQUE, unvan TEXT, telefon TEXT, 
            fax TEXT, email TEXT, adres_cadde TEXT, adres_ek TEXT, adres_sehir TEXT, 
            adres_postakodu TEXT, vergi_dairesi TEXT, muh_ad_soyad TEXT, 
            muh_telefon TEXT, muh_email TEXT, guncelleme_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
        # Eski VKN kaydını sil
        if eski_vkn and eski_vkn != "0000000000" and eski_vkn != yeni_vkn:
            cur.execute("DELETE FROM mukellef_bilgi WHERE vkn=?", (eski_vkn,))

        cur.execute('''INSERT INTO mukellef_bilgi (vkn, unvan, telefon, fax, email, adres_cadde, adres_ek, adres_sehir, adres_postakodu, vergi_dairesi, muh_ad_soyad, muh_telefon, muh_email)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(vkn) DO UPDATE SET unvan=excluded.unvan, telefon=excluded.telefon, email=excluded.email''',
        (yeni_vkn, data.get('unvan'), data.get('telefon'), data.get('fax'), data.get('email'),
         data.get('adres_cadde'), data.get('adres_ek'), data.get('adres_sehir'), data.get('adres_postakodu'),
         data.get('vergi_dairesi'), data.get('muh_ad_soyad'), data.get('muh_telefon'), data.get('muh_email')))
        conn.commit()
    except Exception as e:
        hatalar.append(f"Veritabanı Kaydetme Hatası: {e}")
        return False
    finally:
        if 'conn' in locals(): conn.close()
        
    # EKRANDA SONUÇLARI KULLANICIYA BİLDİR
    if hatalar:
        messagebox.showwarning("Bazı Dosyalar Güncellenemedi", "İşlem sırasında bazı aksaklıklar yaşandı:\n\n" + "\n\n".join(hatalar))
    elif degisenler:
        messagebox.showinfo("Klasör ve Dosyalar Eşitlendi", "Arka planda yapılan güncellemeler:\n\n" + "\n\n".join(degisenler))

    return True