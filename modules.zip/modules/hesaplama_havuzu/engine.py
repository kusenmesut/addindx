import pandas as pd
import os
import sys
from datetime import datetime, timedelta
from config import get_mukellefler_dir
from utils.session_db import get_last_session

# Modül import kontrolü
try:
    from .tcmb_engine import TCMBClient
except ImportError:
    from tcmb_engine import TCMBClient

class CalculationEngine:
    def __init__(self):
        self.df = pd.DataFrame()
        self.status_msg = "Hazır"
        self.tcmb_client = TCMBClient()
        self._load_session_data()

    def _load_session_data(self):
        session = get_last_session()
        if not session:
            self.status_msg = "Oturum Yok"
            return

        vkn = session.get("vkn")
        yil = session.get("yil")
        if not vkn: return

        base_dir = get_mukellefler_dir()
        target_folder = None
        
        if os.path.exists(base_dir):
            for f in os.listdir(base_dir):
                if f.endswith(f"-{str(vkn).strip()}"):
                    target_folder = os.path.join(base_dir, f)
                    break
        
        if target_folder:
            parquet_path = os.path.join(target_folder, str(yil), f"{yil}_FULL.parquet")
            if os.path.exists(parquet_path):
                try:
                    self.df = pd.read_parquet(parquet_path)
                    
                    col_map = {
                        "KayitTarihi": "Tarih", 
                        "YevmiyeNo": "YevmiyeNo",
                        "HesapKodu": "KebirKodu",
                        "HesapAdi": "KebirAdi",
                        "MuavinKodu": "MuavinKodu",
                        "MuavinAdi": "MuavinAdi",
                        "Borc": "Borc", 
                        "Alacak": "Alacak"
                    }
                    self.df.rename(columns=col_map, inplace=True)
                    
                    if 'Tarih' in self.df.columns:
                        self.df['Tarih_Obj'] = pd.to_datetime(self.df['Tarih'], errors='coerce')
                    
                    for c in ['Borc', 'Alacak']:
                        self.df[c] = pd.to_numeric(self.df[c], errors='coerce').fillna(0)
                        
                    for col in ["MuavinKodu", "MuavinAdi", "KebirKodu", "KebirAdi"]:
                        if col not in self.df.columns:
                            self.df[col] = ""
                            
                except Exception as e:
                    print(f"Veri yükleme hatası: {e}")

    def get_account_hierarchy(self):
        if self.df.empty: return {}
        cols = ['KebirKodu', 'KebirAdi', 'MuavinKodu', 'MuavinAdi']
        temp_df = self.df[cols].drop_duplicates().dropna(subset=['KebirKodu'])
        hierarchy = {}
        for _, row in temp_df.iterrows():
            k_kod = str(row['KebirKodu']).strip()
            k_ad = str(row['KebirAdi']).strip()
            m_kod = str(row['MuavinKodu']).strip()
            m_ad = str(row['MuavinAdi']).strip()
            kebir_label = f"{k_kod} - {k_ad}"
            if kebir_label not in hierarchy:
                hierarchy[kebir_label] = []
            if m_kod and m_kod != k_kod:
                muavin_label = f"{m_kod} - {m_ad}"
                if muavin_label not in hierarchy[kebir_label]:
                    hierarchy[kebir_label].append(muavin_label)
        for k in hierarchy: hierarchy[k].sort()
        return hierarchy

    def calculate_adat(self, hesap_kodu_str, faiz_orani, adat_siniri, method="manual", filter_type="kebir"):
        if self.df.empty: return False, "Veri yüklenemedi."
        
        try:
            sinir = float(adat_siniri)
            sabit_faiz = float(faiz_orani) if faiz_orani else 0
            target_code = str(hesap_kodu_str).split(" - ")[0].strip()
        except: return False, "Format hatası."

        df_kasa = pd.DataFrame()
        if filter_type == "kebir":
            df_kasa = self.df[self.df['KebirKodu'].astype(str) == target_code].copy()
        else:
            df_kasa = self.df[self.df['MuavinKodu'].astype(str) == target_code].copy()
        
        if df_kasa.empty: return False, "Seçilen hesap için kayıt bulunamadı."

        df_kasa.sort_values(by=['Tarih_Obj', 'YevmiyeNo'], inplace=True)
        df_kasa['Net'] = df_kasa['Borc'] - df_kasa['Alacak']
        df_kasa['KümülatifBakiye'] = df_kasa['Net'].cumsum()
        
        # Groupby ve Reset Index düzeltmesi
        df_grouped = df_kasa.groupby(df_kasa['Tarih_Obj'].dt.date).last()
        if 'Tarih_Obj' in df_grouped.columns:
            df_grouped = df_grouped.drop(columns=['Tarih_Obj'])
        df_daily = df_grouped.reset_index()
        if 'Tarih_Obj' not in df_daily.columns:
             df_daily.rename(columns={df_daily.columns[0]: 'Tarih_Obj'}, inplace=True)
        
        df_daily['Tarih_Obj'] = pd.to_datetime(df_daily['Tarih_Obj'])
        df_daily['SonrakiTarih'] = df_daily['Tarih_Obj'].shift(-1)
        df_daily['GunSayisi'] = (df_daily['SonrakiTarih'] - df_daily['Tarih_Obj']).dt.days.fillna(0).astype(int)

        rates_map = {} 
        if method in ["tcmb_avans", "tcmb_ticari"]:
            # --- DÜZELTME BURADA ---
            # İlk işlem tarihinden 30 gün geriye git ki, o tarihte geçerli olan eski oranı yakalayabilelim.
            first_tx_date = df_daily['Tarih_Obj'].min()
            min_date = first_tx_date - timedelta(days=30)
            max_date = df_daily['Tarih_Obj'].max()
            
            if max_date > datetime.now(): max_date = datetime.now()
            
            main_k = "avans" if method == "tcmb_avans" else "ticari"
            sub_k = "avans" if method == "tcmb_avans" else "tl_genel"
            
            success_tcmb, tcmb_data = self.tcmb_client.get_rates("dummy", min_date, max_date, main_k, sub_k)
            if success_tcmb:
                for item in tcmb_data:
                    try:
                        d_obj = datetime.strptime(item["Tarih"], "%d-%m-%Y").date()
                        rates_map[d_obj] = item["Oran"]
                    except: pass

        results = []
        for _, row in df_daily.iterrows():
            bakiye = row['KümülatifBakiye']
            kalan_bakiye = bakiye - sinir
            
            if kalan_bakiye > 0 and row['GunSayisi'] > 0:
                current_rate = 0.0
                if method == "manual":
                    current_rate = sabit_faiz
                elif method in ["tcmb_avans", "tcmb_ticari"]:
                    target_date = row['Tarih_Obj'].date()
                    
                    if target_date in rates_map:
                        current_rate = rates_map[target_date]
                    else:
                        # Geriye dönük tarama artık 30 gün öncesi veriyi de içerdiği için
                        # ilk gün bile olsa "önceki" oranı bulabilecektir.
                        sorted_dates = sorted([d for d in rates_map.keys() if d <= target_date])
                        if sorted_dates: 
                            current_rate = rates_map[sorted_dates[-1]]
                        else: 
                            current_rate = 0 

                adat_tutar = (kalan_bakiye * row['GunSayisi'] * current_rate) / 36000
                
                results.append({
                    "Tarih": row['Tarih_Obj'].strftime("%d.%m.%Y"),
                    "YevmiyeNo": row['YevmiyeNo'],
                    "HesapKodu": row['MuavinKodu'] if row['MuavinKodu'] else row['KebirKodu'],
                    "HesapAdi": row['MuavinAdi'] if row['MuavinAdi'] else row['KebirAdi'],
                    "GunlukBakiye": bakiye,
                    "AdatSiniri": sinir,
                    "KalanBakiye": kalan_bakiye,
                    "GunSayisi": row['GunSayisi'],
                    "FaizOrani": current_rate,
                    "AdatTutar": adat_tutar
                })

        return True, results

    def calculate_reeskont(self, nominal_deger, faiz_orani, vade_tarihi, reeskont_tarihi, yil_gun=360):
        try:
            if hasattr(vade_tarihi, 'strftime'): d_vade = vade_tarihi
            else: d_vade = datetime.strptime(vade_tarihi, "%d.%m.%Y")
            if hasattr(reeskont_tarihi, 'strftime'): d_reeskont = reeskont_tarihi
            else: d_reeskont = datetime.strptime(reeskont_tarihi, "%d.%m.%Y")
            gun_farki = (d_vade - d_reeskont).days
            if gun_farki <= 0: return False, "Vade tarihi hatalı."
            rate = float(faiz_orani) / 100
            t = gun_farki / int(yil_gun)
            tasarruf = float(nominal_deger) / (1 + (rate * t))
            return True, {
                "vade_gun_sayisi": gun_farki,
                "reeskont_tutari": float(nominal_deger) - tasarruf,
                "tasarruf_degeri": tasarruf,
                "vade_tarihi_str": d_vade.strftime("%d.%m.%Y"),
                "reeskont_tarihi_str": d_reeskont.strftime("%d.%m.%Y"),
                "nominal_str": float(nominal_deger)
            }
        except Exception as e: return False, str(e)

    def fetch_tcmb_data(self, api_key_dummy, start_date, end_date, main_key, sub_key):
        return self.tcmb_client.get_rates(api_key_dummy, start_date, end_date, main_key, sub_key)

    def export_to_excel(self, data_list, filename_prefix="Adat"):
        if not data_list: return False, "Veri yok."
        try:
            path = os.path.join(os.path.expanduser("~"), "Desktop", f"{filename_prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
            pd.DataFrame(data_list).to_excel(path, index=False)
            return True, f"Kaydedildi:\n{path}"
        except Exception as e: return False, str(e)
        # --- BURAYI engine.py DOSYASININ EN ALTINA EKLEYİN ---

class FinansmanEngine:
    def __init__(self):
        self.df = pd.DataFrame()
        self.status_msg = "Hazır"
        self.load_data()

    def load_data(self):
        """Aktif oturuma ait verileri yükler"""
        session = get_last_session()
        if not session:
            self.status_msg = "Oturum Yok"
            return

        vkn = session.get("vkn")
        yil = session.get("yil")
        if not vkn: return

        base_dir = get_mukellefler_dir()
        target_folder = None
        
        if os.path.exists(base_dir):
            for f in os.listdir(base_dir):
                if f.endswith(f"-{str(vkn).strip()}"):
                    target_folder = os.path.join(base_dir, f)
                    break
        
        if target_folder:
            parquet_path = os.path.join(target_folder, str(yil), f"{yil}_FULL.parquet")
            if os.path.exists(parquet_path):
                try:
                    self.df = pd.read_parquet(parquet_path)
                    
                    # Sütun eşleştirme
                    col_map = {
                        "HesapKodu": "KebirKodu", "HesapAdi": "KebirAdi",
                        "Borc": "Borc", "Alacak": "Alacak"
                    }
                    self.df.rename(columns=col_map, inplace=True)
                    
                    for c in ['Borc', 'Alacak']:
                        self.df[c] = pd.to_numeric(self.df[c], errors='coerce').fillna(0)
                        
                    if 'KebirKodu' in self.df.columns:
                        self.df['KebirKodu'] = self.df['KebirKodu'].astype(str).str.strip()

                except Exception as e:
                    self.status_msg = f"Hata: {e}"

    def get_account_balance(self, code_start, balance_type="alacak_borc"):
        if self.df.empty: return 0.0
        mask = self.df['KebirKodu'].str.startswith(code_start, na=False)
        filtered = self.df[mask]
        if filtered.empty: return 0.0
        
        borc = filtered['Borc'].sum()
        alacak = filtered['Alacak'].sum()
        
        return (alacak - borc) if balance_type == "alacak_borc" else (borc - alacak)

    def get_fgk_verileri(self):
        """UI için gerekli ham verileri hazırlar"""
        if self.df.empty: return {"status": False, "msg": "Veri yok"}

        # 1. Özkaynaklar (5 Grubu - Pasif)
        ozkaynak = max(0, self.get_account_balance("5", "alacak_borc"))

        # 2. Yabancı Kaynaklar (3 ve 4 Grubu - Pasif)
        yabanci = self.get_account_balance("3", "alacak_borc") + self.get_account_balance("4", "alacak_borc")

        # 3. Finansman Giderleri (Aktif/Gider)
        gider_780 = self.get_account_balance("780", "borc_alacak")
        gider_660 = self.get_account_balance("660", "borc_alacak") # Kısa Vadeli Borçlanma
        gider_661 = self.get_account_balance("661", "borc_alacak") # Uzun Vadeli Borçlanma

        # 4. Kur Farkı Netleştirme (656 - 646)
        gider_656 = self.get_account_balance("656", "borc_alacak") # Kambiyo Zararı
        gelir_646 = self.get_account_balance("646", "alacak_borc") # Kambiyo Karı
        net_kur_farki = max(0, gider_656 - gelir_646)

        toplam_gider = gider_780 + gider_660 + gider_661 + net_kur_farki

        return {
            "status": True,
            "ozkaynaklar": ozkaynak,
            "yabanci_kaynaklar": yabanci,
            "toplam_finansman_gideri": toplam_gider
        }

    def calculate_kkeg(self, ozkaynak, yabanci_kaynak, toplam_gider):
        if yabanci_kaynak <= ozkaynak:
            return {
                "kisitlama_var": False,
                "msg": "Yabancı Kaynaklar Özkaynakları aşmadığı için kısıtlama yoktur."
            }

        asan_kisim = yabanci_kaynak - ozkaynak
        try:
            oran = asan_kisim / yabanci_kaynak
        except ZeroDivisionError:
            oran = 0

        kkeg_matrahi = toplam_gider * oran
        kkeg_tutari = kkeg_matrahi * 0.10 # %10 KKEG

        return {
            "kisitlama_var": True,
            "asan_kisim": asan_kisim,
            "oran_yuzde": oran * 100,
            "kkeg_matrahi": kkeg_matrahi,
            "kkeg_tutari": kkeg_tutari
        }