import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from .engine import CalculationEngine
import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from .engine import CalculationEngine
from .engine import CalculationEngine, FinansmanEngine

# --- MODERN RENK PALETİ ---
CLR_SIDEBAR_BG = "#ffffff"
CLR_SIDEBAR_BTN_HOVER = "#e8f5e9"
CLR_SIDEBAR_BTN_ACTIVE = "#4caf50"
CLR_SIDEBAR_TEXT = "#333333"
CLR_TABLE_ROW_ODD = "#f8f9fa"
CLR_TABLE_ROW_EVEN = "#ffffff"
CLR_ACCENT = "#27ae60"

class HesaplamaHavuzuFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#f4f6f9")
        self.engine = CalculationEngine()
        # --- DÜZELTİLEN BAŞLATMA KISMI ---
        self.fin_engine = None
        if FinansmanEngine:
            try:
                self.fin_engine = FinansmanEngine()
            except Exception as e:
                print(f"MODÜL HATASI: FinansmanEngine başlatılırken hata oluştu: {e}")
                self.fin_engine = None
        else:
            print("UYARI: FinansmanEngine sınıfı import edilemediği için modül kapalı.")

        self.active_btn = None
        self.adat_data_cache = []
        
        self.setup_styles()
        self.setup_layout()
        self.setup_sidebar()
        self.nav_reeskont()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Modern.Treeview", background="white", foreground="#2c3e50", rowheight=30, font=("Segoe UI", 10), borderwidth=0)
        style.configure("Modern.Treeview.Heading", background="#ecf0f1", foreground="#2c3e50", font=("Segoe UI", 10, "bold"), relief="flat")
        style.map("Modern.Treeview", background=[("selected", CLR_ACCENT)], foreground=[("selected", "white")])

    def setup_layout(self):
        self.main_container = tk.Frame(self, bg="#f4f6f9")
        self.main_container.pack(fill=tk.BOTH, expand=True)
        self.frame_sidebar = tk.Frame(self.main_container, bg=CLR_SIDEBAR_BG, width=250, bd=0)
        self.frame_sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.frame_sidebar.pack_propagate(False)
        tk.Frame(self.main_container, bg="#e0e0e0", width=1).pack(side=tk.LEFT, fill=tk.Y)
        self.frame_content = tk.Frame(self.main_container, bg="#f4f6f9")
        self.frame_content.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    def setup_sidebar(self):
        brand_frame = tk.Frame(self.frame_sidebar, bg=CLR_SIDEBAR_BG, height=80)
        brand_frame.pack(fill=tk.X)
        tk.Label(brand_frame, text="HESAPLAMA\nROBOTU", bg=CLR_SIDEBAR_BG, fg="#27ae60", font=("Segoe UI", 14, "bold"), justify="left").pack(side=tk.LEFT, padx=20, pady=20)
        
        self.sidebar_buttons = {}
        self.create_sidebar_btn("reeskont", "Reeskont İşlemleri", self.nav_reeskont)
        self.create_sidebar_btn("adat", "Adat İşlemleri", self.nav_adat)
        self.create_sidebar_btn("fgk", "Finansman Gider Kısıt.", self.nav_fgk)
        self.create_sidebar_btn("binek", "Binek Oto Gider Kısıt.", self.nav_binek)
        #self.create_sidebar_btn("tcmb", "TCMB Faiz Oranları", self.nav_tcmb)

    def create_sidebar_btn(self, btn_id, text, command):
        btn_frame = tk.Frame(self.frame_sidebar, bg=CLR_SIDEBAR_BG, height=50, cursor="hand2")
        btn_frame.pack(fill=tk.X, pady=2)
        indicator = tk.Frame(btn_frame, bg=CLR_SIDEBAR_BG, width=5)
        indicator.pack(side=tk.LEFT, fill=tk.Y)
        lbl = tk.Label(btn_frame, text=text, bg=CLR_SIDEBAR_BG, fg=CLR_SIDEBAR_TEXT, font=("Segoe UI", 11), anchor="w")
        lbl.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15)
        
        for w in [btn_frame, lbl, indicator]:
            w.bind("<Enter>", lambda e: self.on_hover(btn_id))
            w.bind("<Leave>", lambda e: self.on_leave(btn_id))
            w.bind("<Button-1>", lambda e: command())
        self.sidebar_buttons[btn_id] = {"frame": btn_frame, "lbl": lbl, "ind": indicator}

    def on_hover(self, btn_id):
        if self.active_btn != btn_id:
            self.sidebar_buttons[btn_id]["frame"].config(bg=CLR_SIDEBAR_BTN_HOVER)
            self.sidebar_buttons[btn_id]["lbl"].config(bg=CLR_SIDEBAR_BTN_HOVER)

    def on_leave(self, btn_id):
        if self.active_btn != btn_id:
            self.sidebar_buttons[btn_id]["frame"].config(bg=CLR_SIDEBAR_BG)
            self.sidebar_buttons[btn_id]["lbl"].config(bg=CLR_SIDEBAR_BG)

    def set_active_sidebar(self, btn_id):
        for bid, w in self.sidebar_buttons.items():
            w["frame"].config(bg=CLR_SIDEBAR_BG)
            w["lbl"].config(bg=CLR_SIDEBAR_BG, fg=CLR_SIDEBAR_TEXT, font=("Segoe UI", 11))
            w["ind"].config(bg=CLR_SIDEBAR_BG)
        if btn_id in self.sidebar_buttons:
            w = self.sidebar_buttons[btn_id]
            w["frame"].config(bg=CLR_SIDEBAR_BTN_HOVER)
            w["lbl"].config(bg=CLR_SIDEBAR_BTN_HOVER, fg=CLR_SIDEBAR_BTN_ACTIVE, font=("Segoe UI", 11, "bold"))
            w["ind"].config(bg=CLR_SIDEBAR_BTN_ACTIVE)
            self.active_btn = btn_id

    def clear_content(self):
        for w in self.frame_content.winfo_children(): w.destroy()

    def create_header(self, text):
        tk.Label(self.frame_content, text=text, bg="#f4f6f9", fg="#2c3e50", font=("Segoe UI", 16, "bold")).pack(fill=tk.X, padx=20, pady=20)
    
    def create_result_card(self, parent, title, value, row, col):
        card = tk.Frame(parent, bg="white", bd=0, relief="solid")
        card.grid(row=row, column=col, sticky="nsew", padx=5, pady=5)
        tk.Frame(card, bg="#2980b9", width=4).pack(side=tk.LEFT, fill=tk.Y)
        content = tk.Frame(card, bg="white", padx=10, pady=10)
        content.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tk.Label(content, text=title, bg="white", fg="#7f8c8d", font=("Segoe UI", 9)).pack(anchor="w")
        tk.Label(content, text=value, bg="white", fg="#2c3e50", font=("Segoe UI", 12, "bold")).pack(anchor="w")

    def create_input(self, parent, label, row, col, default=""):
        tk.Label(parent, text=label, bg="white", font=("Segoe UI", 9, "bold")).grid(row=row, column=col, sticky="w", padx=15, pady=(15,5))
        ent = tk.Entry(parent, bg="#f8f9fa", bd=1, relief="solid")
        ent.insert(0, default)
        ent.grid(row=row+1, column=col, padx=15, pady=(0,15), sticky="ew")
        return ent
    # --- FİNANSMAN GİDER KISITLAMASI PANELİ ---
    # --- FİNANSMAN GİDER KISITLAMASI (MANUEL - MODERN FORM) ---
    def nav_fgk(self):
        self.set_active_sidebar("fgk")
        self.clear_content()
        
        # 1. Başlık
        top = tk.Frame(self.frame_content, bg="#f4f6f9")
        top.pack(fill=tk.X, padx=20, pady=20)
        tk.Label(top, text="Finansman Gider Kısıtlaması Hesaplama", bg="#f4f6f9", fg="#2c3e50", font=("Segoe UI", 16, "bold")).pack(side=tk.LEFT)
        
        # 2. Ana Form Kartı
        # Scrollable bir yapı kurmak yerine sabit modern bir form yapıyoruz
        card = tk.Frame(self.frame_content, bg="white", bd=0, relief="flat")
        card.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 20))

        # Grid Yapılandırması
        # Sütun 0: Sıra No, Sütun 1: Açıklama, Sütun 2: Değer/Girdi, Sütun 3: Birim
        card.columnconfigure(1, weight=1)
        
        # --- STİL TANIMLARI ---
        lbl_font = ("Segoe UI", 10)
        lbl_bold = ("Segoe UI", 10, "bold")
        entry_bg = "#f8f9fa"
        
        row_idx = 0

        def add_separator(r):
            tk.Frame(card, bg="#e0e0e0", height=1).grid(row=r, column=0, columnspan=4, sticky="ew", pady=5, padx=10)

        # --- SATIR 1: ÖZSERMAYE ---
        tk.Label(card, text="1", bg="white", fg="#7f8c8d", font=lbl_bold).grid(row=row_idx, column=0, padx=10, pady=10)
        tk.Label(card, text="Özsermaye Tutarı:", bg="white", font=lbl_bold, anchor="w").grid(row=row_idx, column=1, sticky="w", padx=10)
        self.ent_man_ozkaynak = tk.Entry(card, bg=entry_bg, bd=1, relief="solid", font=lbl_font, justify="right")
        self.ent_man_ozkaynak.grid(row=row_idx, column=2, sticky="ew", padx=10, ipady=4)
        tk.Label(card, text="₺", bg="white", font=lbl_font).grid(row=row_idx, column=3, padx=10)
        row_idx += 1; add_separator(row_idx); row_idx += 1

        # --- SATIR 2: YABANCI KAYNAK ---
        tk.Label(card, text="2", bg="white", fg="#7f8c8d", font=lbl_bold).grid(row=row_idx, column=0, padx=10, pady=10)
        tk.Label(card, text="Yabancı Kaynak Toplamı (Aktif - Özsermaye):", bg="white", font=lbl_bold, anchor="w").grid(row=row_idx, column=1, sticky="w", padx=10)
        self.ent_man_yabanci = tk.Entry(card, bg=entry_bg, bd=1, relief="solid", font=lbl_font, justify="right")
        self.ent_man_yabanci.grid(row=row_idx, column=2, sticky="ew", padx=10, ipady=4)
        tk.Label(card, text="₺", bg="white", font=lbl_font).grid(row=row_idx, column=3, padx=10)
        row_idx += 1; add_separator(row_idx); row_idx += 1

        # --- SATIR 3 (HESAPLANAN): AŞAN KISIM ---
        tk.Label(card, text="3", bg="white", fg="#7f8c8d", font=lbl_font).grid(row=row_idx, column=0, padx=10, pady=10)
        tk.Label(card, text="Özsermayeyi Aşan Yabancı Kaynak Tutarı (2 - 1):", bg="white", font=lbl_font, anchor="w", fg="#e67e22").grid(row=row_idx, column=1, sticky="w", padx=10)
        self.lbl_res_asan = tk.Label(card, text="0.00", bg="white", font=lbl_bold, fg="#e67e22", anchor="e")
        self.lbl_res_asan.grid(row=row_idx, column=2, sticky="ew", padx=10)
        tk.Label(card, text="₺", bg="white", font=lbl_font).grid(row=row_idx, column=3, padx=10)
        row_idx += 1; add_separator(row_idx); row_idx += 1

        # --- SATIR 4 (HESAPLANAN): ORAN ---
        tk.Label(card, text="4", bg="white", fg="#7f8c8d", font=lbl_font).grid(row=row_idx, column=0, padx=10, pady=10)
        tk.Label(card, text="Aşan Kısmın Yabancı Kaynağa Oranı (3 / 2):", bg="white", font=lbl_font, anchor="w").grid(row=row_idx, column=1, sticky="w", padx=10)
        self.lbl_res_oran = tk.Label(card, text="% 0.00", bg="white", font=lbl_bold, anchor="e")
        self.lbl_res_oran.grid(row=row_idx, column=2, sticky="ew", padx=10)
        row_idx += 1; add_separator(row_idx); row_idx += 1

        # --- SATIR 5: FİNANSMAN GİDERİ ---
        tk.Label(card, text="5", bg="white", fg="#7f8c8d", font=lbl_bold).grid(row=row_idx, column=0, padx=10, pady=10)
        tk.Label(card, text="Finansman Gider Tutarı (780, 660, 656 vb.):\n(Kur farkı gelirleri netleştirilmiş)", bg="white", font=lbl_bold, anchor="w", justify="left").grid(row=row_idx, column=1, sticky="w", padx=10)
        self.ent_man_gider = tk.Entry(card, bg=entry_bg, bd=1, relief="solid", font=lbl_font, justify="right")
        self.ent_man_gider.grid(row=row_idx, column=2, sticky="ew", padx=10, ipady=4)
        tk.Label(card, text="₺", bg="white", font=lbl_font).grid(row=row_idx, column=3, padx=10)
        row_idx += 1; add_separator(row_idx); row_idx += 1

        # --- SATIR 6: ÖRTÜLÜ SERMAYE (İNDİRİM) ---
        tk.Label(card, text="6", bg="white", fg="#7f8c8d", font=lbl_bold).grid(row=row_idx, column=0, padx=10, pady=10)
        tk.Label(card, text="Örtülü Sermayeye Ait Finansman Gideri (KKEG):\n(Varsa düşülür)", bg="white", font=lbl_font, anchor="w", justify="left").grid(row=row_idx, column=1, sticky="w", padx=10)
        self.ent_man_ortulu = tk.Entry(card, bg=entry_bg, bd=1, relief="solid", font=lbl_font, justify="right")
        self.ent_man_ortulu.insert(0, "0")
        self.ent_man_ortulu.grid(row=row_idx, column=2, sticky="ew", padx=10, ipady=4)
        tk.Label(card, text="₺", bg="white", font=lbl_font).grid(row=row_idx, column=3, padx=10)
        row_idx += 1; add_separator(row_idx); row_idx += 1

        # --- SATIR 7 (HESAPLANAN): DİKKATE ALINACAK ---
        tk.Label(card, text="7", bg="white", fg="#7f8c8d", font=lbl_font).grid(row=row_idx, column=0, padx=10, pady=10)
        tk.Label(card, text="Hesaplamada Dikkate Alınacak Finansman Gideri (5 - 6):", bg="white", font=lbl_font, anchor="w").grid(row=row_idx, column=1, sticky="w", padx=10)
        self.lbl_res_matrah_baz = tk.Label(card, text="0.00", bg="white", font=lbl_bold, anchor="e")
        self.lbl_res_matrah_baz.grid(row=row_idx, column=2, sticky="ew", padx=10)
        tk.Label(card, text="₺", bg="white", font=lbl_font).grid(row=row_idx, column=3, padx=10)
        row_idx += 1; add_separator(row_idx); row_idx += 1

        # --- SATIR 8 (HESAPLANAN): AŞAN KISMA İSABET EDEN ---
        tk.Label(card, text="8", bg="white", fg="#7f8c8d", font=lbl_font).grid(row=row_idx, column=0, padx=10, pady=10)
        tk.Label(card, text="Aşan Kısma İsabet Eden Finansman Gideri (7 * 4):", bg="white", font=lbl_font, anchor="w").grid(row=row_idx, column=1, sticky="w", padx=10)
        self.lbl_res_isabet = tk.Label(card, text="0.00", bg="white", font=lbl_bold, anchor="e")
        self.lbl_res_isabet.grid(row=row_idx, column=2, sticky="ew", padx=10)
        tk.Label(card, text="₺", bg="white", font=lbl_font).grid(row=row_idx, column=3, padx=10)
        row_idx += 1; add_separator(row_idx); row_idx += 1

        # --- SATIR 9 (SONUÇ): KKEG ---
        res_bg = "#ffebee" # Hafif kırmızı arka plan
        
        # Arka plan çerçevesi
        res_frame = tk.Frame(card, bg=res_bg)
        res_frame.grid(row=row_idx, column=0, columnspan=4, sticky="ew", pady=10)
        res_frame.columnconfigure(1, weight=1)

        tk.Label(res_frame, text="9", bg=res_bg, fg="#c0392b", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, padx=10, pady=15)
        tk.Label(res_frame, text="KKEG OLACAK FİNANSMAN GİDERLERİ (8 * %10):", bg=res_bg, fg="#c0392b", font=("Segoe UI", 12, "bold"), anchor="w").grid(row=0, column=1, sticky="w", padx=10)
        self.lbl_res_final = tk.Label(res_frame, text="0.00", bg=res_bg, fg="#c0392b", font=("Segoe UI", 14, "bold"), anchor="e")
        self.lbl_res_final.grid(row=0, column=2, sticky="ew", padx=10)
        tk.Label(res_frame, text="₺", bg=res_bg, fg="#c0392b", font=("Segoe UI", 12, "bold")).grid(row=0, column=3, padx=10)
        
        row_idx += 1

        # --- HESAPLA BUTONU ---
        btn_frame = tk.Frame(card, bg="white")
        btn_frame.grid(row=row_idx, column=0, columnspan=4, pady=20, sticky="e", padx=20)
        
        tk.Button(btn_frame, text="TEMİZLE", bg="#95a5a6", fg="white", font=("Segoe UI", 10, "bold"), 
                  relief="flat", padx=20, pady=8, command=self.do_clear_fgk).pack(side=tk.LEFT, padx=10)
                  
        tk.Button(btn_frame, text="HESAPLA", bg="#e74c3c", fg="white", font=("Segoe UI", 11, "bold"), 
                  relief="flat", padx=30, pady=8, command=self.do_calculate_fgk_manual).pack(side=tk.LEFT)

# --- BİNEK OTO GİDER KISITLAMASI (2020-2026 KAPSAMLI) ---
    def nav_binek(self):
        self.set_active_sidebar("binek")
        self.clear_content()

        # MEVZUAT LİMİTLERİ (2020 - 2026)
        # --- GÜNCELLENMİŞ VERİTABANI: YILLIK LİMİTLER (2021-2026) ---
        # Kaynak: Kullanıcı tarafından sağlanan güncel vergi limitleri tablosu
        self.BINEK_LIMITLER = {
            "2026": {
                "kira": 46000.0,            # Aylık kira limiti (KDV hariç)
                "iktisap_vergi": 1200000.0, # ÖTV+KDV olarak gider yazılabilecek azami tutar
                "iktisap_matrah": 1380000.0,# Vergi hariç ilk iktisap bedeli (amortisman limiti)
                "iktisap_toplam": 2600000.0 # Vergiler maliyete eklendiğinde / 2. el iktisap limiti
            },
            "2025": {
                "kira": 37000.0,
                "iktisap_vergi": 990000.0,
                "iktisap_matrah": 1100000.0,
                "iktisap_toplam": 2100000.0
            },
            "2024": {
                "kira": 26000.0,
                "iktisap_vergi": 690000.0,
                "iktisap_matrah": 790000.0,
                "iktisap_toplam": 1500000.0
            },
            "2023": {
                "kira": 17000.0,
                "iktisap_vergi": 440000.0,
                "iktisap_matrah": 500000.0,
                "iktisap_toplam": 950000.0
            },
            "2022": {
                "kira": 8000.0,
                "iktisap_vergi": 200000.0,
                "iktisap_matrah": 230000.0,
                "iktisap_toplam": 430000.0
            },
            "2021": {
                "kira": 6000.0,
                "iktisap_vergi": 150000.0,
                "iktisap_matrah": 170000.0,
                "iktisap_toplam": 320000.0
            }
        }

        # --- BAŞLIK ---
        top = tk.Frame(self.frame_content, bg="#f4f6f9")
        top.pack(fill=tk.X, padx=20, pady=20)
        tk.Label(top, text="Binek Otomobil Gider Kısıtlaması (2020-2026)", bg="#f4f6f9", fg="#2c3e50", font=("Segoe UI", 16, "bold")).pack(side=tk.LEFT)

        # --- SCROLLABLE ANA ALAN ---
        canvas = tk.Canvas(self.frame_content, bg="#f4f6f9", highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.frame_content, orient="vertical", command=canvas.yview)
        self.scrollable_frame = tk.Frame(canvas, bg="#f4f6f9")

        self.scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True, padx=10)
        scrollbar.pack(side="right", fill="y")

        # --- 1. GİRİŞ KARTI ---
        card = tk.Frame(self.scrollable_frame, bg="white", bd=0, relief="flat", padx=20, pady=20)
        card.pack(fill=tk.X, padx=10, pady=(0, 20))

        # Üst Seçimler
        fr_sel = tk.Frame(card, bg="white")
        fr_sel.pack(fill=tk.X, pady=(0, 10))
        
        # İşlem Türü
        self.var_binek_tur = tk.StringVar(value="iktisap")
        fr_tur = tk.Frame(fr_sel, bg="white", bd=1, relief="solid", padx=5, pady=5)
        fr_tur.pack(side=tk.LEFT, padx=(0, 20))
        tk.Radiobutton(fr_tur, text="Satın Alma", variable=self.var_binek_tur, value="iktisap", command=self.update_binek_form, bg="white", font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(fr_tur, text="Kiralama", variable=self.var_binek_tur, value="kira", command=self.update_binek_form, bg="white", font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=5)

        # Dinamik Form Alanı
        self.form_frame = tk.Frame(card, bg="white")
        self.form_frame.pack(fill=tk.X)
        
        # Sonuç Alanı
        self.res_frame = tk.Frame(self.scrollable_frame, bg="white", bd=0, relief="flat", padx=20, pady=20)
        self.res_frame.pack(fill=tk.X, padx=10, pady=(0, 20))

        self.update_binek_form()

    def update_binek_form(self):
        for w in self.form_frame.winfo_children(): w.destroy()
        self.entries = {}
        tur = self.var_binek_tur.get()

        # Grid Yardımcısı
        def add_input(lbl, r, c, key, val="", width=25):
            tk.Label(self.form_frame, text=lbl, bg="white", font=("Segoe UI", 9, "bold")).grid(row=r, column=c, sticky="w", pady=(10, 5), padx=5)
            e = tk.Entry(self.form_frame, bg="white", bd=1, relief="solid", font=("Segoe UI", 11), width=width)
            if val: e.insert(0, val)
            e.grid(row=r+1, column=c, sticky="w", padx=5, ipady=3)
            self.entries[key] = e

        # Ortak: Yıl Seçimi
        tk.Label(self.form_frame, text="İşlem Yılı", bg="white", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", pady=(10, 5), padx=5)
        
        # Yılları sıralı getir (2026'dan 2020'ye)
        years = sorted(list(self.BINEK_LIMITLER.keys()), reverse=True)
        self.cb_binek_yil = ttk.Combobox(self.form_frame, values=years, width=23, state="readonly", font=("Segoe UI", 10))
        self.cb_binek_yil.current(0) # En güncel yıl varsayılan
        self.cb_binek_yil.grid(row=1, column=0, sticky="w", padx=5, ipady=3)
        
        # Yıl değişince limit bilgisini güncellemek için bind (Opsiyonel görsel bilgi eklenebilir)
        # self.cb_binek_yil.bind("<<ComboboxSelected>>", self.on_year_change)

        if tur == "iktisap":
            add_input("Toplam Fatura Tutarı (₺)", 0, 1, "toplam", "")
            
            # Bilgi Kartı (Limitler) - Dinamik Yapı
            # Kullanıcı yılı değiştirdiğinde burayı güncellemek için ayrı bir label tutabiliriz
            # Şimdilik varsayılan uyarı koyalım
            info_bg = "#e3f2fd"
            fr_info = tk.Frame(self.form_frame, bg=info_bg, padx=10, pady=10)
            fr_info.grid(row=2, column=0, rowspan=4, sticky="nw", padx=5, pady=15)
            tk.Label(fr_info, text="ℹ BİLGİ", bg=info_bg, font=("Segoe UI", 9, "bold"), fg="#0d47a1").pack(anchor="w")
            tk.Label(fr_info, text="Hesaplama seçilen yılın yasal limitlerine\ngöre otomatik yapılacaktır.", bg=info_bg, font=("Segoe UI", 8), fg="#0d47a1").pack(anchor="w")

            add_input("ÖTV Tutarı (₺)", 2, 1, "otv", "")
            add_input("KDV Tutarı (₺)", 2, 2, "kdv", "")

            # Yöntem Seçimi
            tk.Label(self.form_frame, text="Vergi İşleme Yöntemi", bg="white", font=("Segoe UI", 9, "bold")).grid(row=4, column=1, sticky="w", pady=(15, 5), padx=5)
            self.var_yontem = tk.StringVar(value="gider")
            
            fr_rb1 = tk.Frame(self.form_frame, bg="white", bd=1, relief="solid", padx=5, pady=5)
            fr_rb1.grid(row=5, column=1, columnspan=2, sticky="ew", padx=5, pady=2)
            tk.Radiobutton(fr_rb1, text="ÖTV ve KDV Gider Yazılacak", variable=self.var_yontem, value="gider", bg="white", font=("Segoe UI", 10, "bold")).pack(anchor="w")
            tk.Label(fr_rb1, text="ÖTV ve KDV tutarları gider olarak yazılacak", bg="white", fg="#7f8c8d", font=("Segoe UI", 8)).pack(anchor="w", padx=25)

            fr_rb2 = tk.Frame(self.form_frame, bg="white", bd=1, relief="solid", padx=5, pady=5)
            fr_rb2.grid(row=6, column=1, columnspan=2, sticky="ew", padx=5, pady=2)
            tk.Radiobutton(fr_rb2, text="ÖTV ve KDV Maliyete Eklenecek", variable=self.var_yontem, value="maliyet", bg="white", font=("Segoe UI", 10, "bold")).pack(anchor="w")
            tk.Label(fr_rb2, text="ÖTV ve KDV tutarları aracın maliyetine eklenecek", bg="white", fg="#7f8c8d", font=("Segoe UI", 8)).pack(anchor="w", padx=25)

        else: # Kiralama
            add_input("KDV Hariç Kiralama Tutarı (₺)", 0, 1, "kira", "")
            # KDV Oranı (Opsiyonel, standart %20)
            tk.Label(self.form_frame, text="ℹ Seçilen yıla ait kira limiti dikkate alınır.", bg="#f8f9fa", padx=10, pady=5).grid(row=2, column=0, sticky="w", padx=5)

        # Hesapla Butonu
        tk.Button(self.form_frame, text="Hesapla", bg="#2c3e50", fg="white", font=("Segoe UI", 10, "bold"), padx=20, pady=5, command=self.do_calculate_binek).grid(row=10, column=2, sticky="e", pady=20, padx=5)

    def do_calculate_binek(self):
        try:
            # Temizlik
            for w in self.res_frame.winfo_children(): w.destroy()

            def get_float(k):
                val = self.entries[k].get().replace(".", "").replace(",", ".") # TR Formatı
                return float(val) if val else 0.0

            yil = self.cb_binek_yil.get()
            limits = self.BINEK_LIMITLER[yil] # Seçilen yılın limitleri
            tur = self.var_binek_tur.get()
            
            result_rows = [] 
            journal_rows = []

            if tur == "iktisap":
                toplam = get_float("toplam")
                otv = get_float("otv")
                kdv = get_float("kdv")
                yontem = self.var_yontem.get()
                
                arac_bedel = toplam - otv - kdv

                if yontem == "gider":
                    # YÖNTEM A: Gider Yazma
                    limit_vergi = limits["iktisap_vergi"]
                    toplam_vergi = otv + kdv
                    
                    if toplam_vergi <= limit_vergi:
                        gider_vergi = toplam_vergi
                        kkeg_vergi = 0
                    else:
                        gider_vergi = limit_vergi
                        kkeg_vergi = toplam_vergi - limit_vergi
                    
                    gider_yazilan_otv = min(otv, gider_vergi)
                    gider_yazilan_kdv = gider_vergi - gider_yazilan_otv
                    
                    limit_matrah = limits["iktisap_matrah"]
                    amort_tabi = min(arac_bedel, limit_matrah)
                    amort_disi = arac_bedel - amort_tabi

                    result_rows.append(("Gider Yazılacak ÖTV", gider_yazilan_otv, "black", True))
                    result_rows.append(("Gider Yazılacak KDV", gider_yazilan_kdv, "black", True))
                    if kkeg_vergi > 0:
                        result_rows.append(("KKEG Vergiler (Kanunen Kabul Edilmeyen Gider)", kkeg_vergi, "#c0392b", True))
                    
                    result_rows.append(("SEP", 0, "", False))
                    result_rows.append(("Toplam Gider Yazılacak Tutar", gider_vergi, "#00b894", True))
                    
                    result_rows.append(("Amortismana Tabi Tutar (5 yılda giderleştirilebilir)", amort_tabi, "#333", False))
                    if amort_disi > 0:
                        result_rows.append(("Amortisman Dışı Tutar", amort_disi, "#c0392b", True))

                    # Muhasebe Kaydı
                    journal_rows.append(("7xx", "Gider Yazılacak ÖTV", gider_yazilan_otv, 0, False))
                    if gider_yazilan_kdv > 0:
                        journal_rows.append(("7xx", "Gider Yazılacak KDV", gider_yazilan_kdv, 0, False))
                    if kkeg_vergi > 0:
                        journal_rows.append(("689", "KKEG Vergiler", kkeg_vergi, 0, True))
                    
                    journal_rows.append(("254", "Amortismana Tabi Tutar", amort_tabi, 0, False))
                    if amort_disi > 0:
                        journal_rows.append(("254", "Amortisman Dışı Tutar", amort_disi, 0, True))
                    
                    journal_rows.append(("320", "Fatura Tutarı", 0, toplam, False))

                else:
                    # YÖNTEM B: Maliyete Ekleme
                    limit_toplam = limits["iktisap_toplam"]
                    maliyet = arac_bedel + otv + kdv
                    
                    amort_tabi = min(maliyet, limit_toplam)
                    amort_disi = maliyet - amort_tabi
                    
                    result_rows.append(("Amortismana Tabi Tutar", amort_tabi, "black", True))
                    if amort_disi > 0:
                        result_rows.append(("Amortisman Dışı Tutar", amort_disi, "#c0392b", True))
                    
                    journal_rows.append(("254", "Amortismana Tabi Tutar", amort_tabi, 0, False))
                    if amort_disi > 0:
                        journal_rows.append(("254", "Amortisman Dışı Tutar", amort_disi, 0, True))
                    journal_rows.append(("320", "Fatura Tutarı", 0, toplam, False))

            elif tur == "kira":
                kira = get_float("kira")
                limit = limits["kira"]
                kdv = kira * 0.20
                toplam = kira + kdv
                
                gider_kira = min(kira, limit)
                kkeg_kira = kira - gider_kira
                
                gider_kdv = kdv * (gider_kira / kira) if kira > 0 else 0
                kkeg_kdv = kdv - gider_kdv
                
                result_rows.append(("Gider Yazılabilir Tutar", gider_kira, "black", True))
                if kkeg_kira > 0:
                    # Sadece salt kira KKEG tutarını yansıtıyoruz (Örn: 113.000 TL)
                    result_rows.append(("KKEG Tutar", kkeg_kira, "#c0392b", True))
                
                journal_rows.append(("770", "Kira Gideri", gider_kira, 0, False))
                journal_rows.append(("191", "İndirilecek KDV", gider_kdv, 0, False))
                if kkeg_kira > 0:
                    journal_rows.append(("689", "KKEG Kira + KDV", kkeg_kira + kkeg_kdv, 0, True))
                journal_rows.append(("320", "Satıcılar", 0, toplam, False))

            # --- GÖRSELLEŞTİRME ---
            tk.Label(self.res_frame, text=f"Hesaplama Sonuçları ({yil})", bg="white", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(0,10))
            fr_res = tk.Frame(self.res_frame, bg="white")
            fr_res.pack(fill=tk.X)
            
            for i, (lbl, val, color, is_bold) in enumerate(result_rows):
                if lbl == "SEP":
                    tk.Frame(fr_res, bg="#00d2d3", height=2).grid(row=i, column=0, columnspan=2, sticky="ew", pady=10)
                    continue
                
                bg_color = "#fff9e6" if color == "#c0392b" else "white"
                row_fr = tk.Frame(fr_res, bg=bg_color)
                row_fr.grid(row=i, column=0, columnspan=2, sticky="ew", pady=2)
                
                font_style = ("Segoe UI", 10, "bold") if is_bold else ("Segoe UI", 10)
                tk.Label(row_fr, text=lbl, bg=bg_color, fg="#333", font=font_style, anchor="w").pack(side=tk.LEFT, padx=10, pady=8)
                tk.Label(row_fr, text=f"₺{val:,.2f}", bg=bg_color, fg=color, font=font_style).pack(side=tk.RIGHT, padx=10)

            tk.Label(self.res_frame, text="Muhasebe Kaydı", bg="white", font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(20, 5))
            tbl_frame = tk.Frame(self.res_frame, bg="white", bd=1, relief="solid")
            tbl_frame.pack(fill=tk.X)
            
            # Header
            h_bg = "#f1f2f6"
            tk.Label(tbl_frame, text="Hesap Kodu", bg=h_bg, font=("Segoe UI", 9, "bold"), width=15, anchor="w").grid(row=0, column=0, sticky="ew", ipady=5, padx=5)
            tk.Label(tbl_frame, text="Açıklama", bg=h_bg, font=("Segoe UI", 9, "bold"), width=40, anchor="w").grid(row=0, column=1, sticky="ew", ipady=5, padx=5)
            tk.Label(tbl_frame, text="Borç", bg=h_bg, font=("Segoe UI", 9, "bold"), width=15, anchor="e").grid(row=0, column=2, sticky="ew", ipady=5, padx=5)
            tk.Label(tbl_frame, text="Alacak", bg=h_bg, font=("Segoe UI", 9, "bold"), width=15, anchor="e").grid(row=0, column=3, sticky="ew", ipady=5, padx=5)
            
            t_borc = 0
            t_alacak = 0
            for idx, (kod, aciklama, borc, alacak, highlight) in enumerate(journal_rows):
                row_bg = "#fff9e6" if highlight else "white"
                tk.Label(tbl_frame, text=kod, bg=row_bg, font=("Segoe UI", 9), anchor="w").grid(row=idx+1, column=0, sticky="ew", pady=1, padx=5)
                tk.Label(tbl_frame, text=aciklama, bg=row_bg, font=("Segoe UI", 9), anchor="w").grid(row=idx+1, column=1, sticky="ew", pady=1, padx=5)
                b_txt = f"₺{borc:,.2f}" if borc > 0 else "-"
                a_txt = f"₺{alacak:,.2f}" if alacak > 0 else "-"
                tk.Label(tbl_frame, text=b_txt, bg=row_bg, font=("Segoe UI", 9, "bold"), anchor="e").grid(row=idx+1, column=2, sticky="ew", pady=1, padx=5)
                tk.Label(tbl_frame, text=a_txt, bg=row_bg, font=("Segoe UI", 9, "bold"), anchor="e").grid(row=idx+1, column=3, sticky="ew", pady=1, padx=5)
                t_borc += borc; t_alacak += alacak
            
            r_end = len(journal_rows) + 1
            tk.Label(tbl_frame, text="", bg="#f8f9fa").grid(row=r_end, column=0, sticky="ew")
            tk.Label(tbl_frame, text="Toplam:", bg="#f8f9fa", font=("Segoe UI", 9, "bold"), anchor="e").grid(row=r_end, column=1, sticky="ew", padx=5, ipady=5)
            tk.Label(tbl_frame, text=f"₺{t_borc:,.2f}", bg="#f8f9fa", font=("Segoe UI", 9, "bold"), anchor="e").grid(row=r_end, column=2, sticky="ew", padx=5)
            tk.Label(tbl_frame, text=f"₺{t_alacak:,.2f}", bg="#f8f9fa", font=("Segoe UI", 9, "bold"), anchor="e").grid(row=r_end, column=3, sticky="ew", padx=5)

            tk.Label(self.res_frame, text="✔ Borç ve Alacak Eşit", fg="#27ae60", bg="white", font=("Segoe UI", 9, "bold")).pack(pady=5)

        except ValueError:
            messagebox.showerror("Hata", "Lütfen tutar alanlarına geçerli sayılar giriniz.")

    def do_clear_fgk(self):
        """Formu temizler"""
        for ent in [self.ent_man_ozkaynak, self.ent_man_yabanci, self.ent_man_gider, self.ent_man_ortulu]:
            ent.delete(0, tk.END)
        self.ent_man_ortulu.insert(0, "0")
        
        # Sonuçları sıfırla
        self.lbl_res_asan.config(text="0.00")
        self.lbl_res_oran.config(text="% 0.00")
        self.lbl_res_matrah_baz.config(text="0.00")
        self.lbl_res_isabet.config(text="0.00")
        self.lbl_res_final.config(text="0.00")

    def do_calculate_fgk_manual(self):
        """Manuel form hesaplama mantığı"""
        try:
            # 1. Verileri Al (Virgülleri temizle, float'a çevir)
            def get_val(entry_widget):
                val = entry_widget.get().strip()
                if not val: return 0.0
                return float(val.replace(",", ""))

            ozkaynak = get_val(self.ent_man_ozkaynak)
            yabanci_kaynak = get_val(self.ent_man_yabanci)
            toplam_gider = get_val(self.ent_man_gider)
            ortulu_gider = get_val(self.ent_man_ortulu)

            # 2. İş Mantığı
            
            # Adım 3: Özsermayeyi Aşan Kısım
            asan_kisim = yabanci_kaynak - ozkaynak
            
            # Kısıtlama Var mı?
            if asan_kisim <= 0:
                self.lbl_res_asan.config(text="0.00 (Kısıtlama Yok)")
                self.lbl_res_oran.config(text="% 0.00")
                self.lbl_res_matrah_baz.config(text="0.00")
                self.lbl_res_isabet.config(text="0.00")
                self.lbl_res_final.config(text="0.00")
                messagebox.showinfo("Bilgi", "Yabancı kaynaklar özkaynakları aşmadığı için\nFinansman Gider Kısıtlaması uygulanmaz.")
                return

            # Adım 4: Oran
            try:
                oran = asan_kisim / yabanci_kaynak
            except ZeroDivisionError:
                oran = 0.0
            
            # Adım 7: Dikkate Alınacak Gider (Netleştirme)
            dikkate_alinacak_gider = max(0, toplam_gider - ortulu_gider)
            
            # Adım 8: Aşan Kısma İsabet Eden
            isabet_eden = dikkate_alinacak_gider * oran
            
            # Adım 9: KKEG (%10)
            kkeg = isabet_eden * 0.10

            # 3. Sonuçları Yazdır (Binlik ayraçlı)
            self.lbl_res_asan.config(text=f"{asan_kisim:,.2f}")
            self.lbl_res_oran.config(text=f"% {oran * 100:.2f}")
            self.lbl_res_matrah_baz.config(text=f"{dikkate_alinacak_gider:,.2f}")
            self.lbl_res_isabet.config(text=f"{isabet_eden:,.2f}")
            self.lbl_res_final.config(text=f"{kkeg:,.2f}")

        except ValueError:
            messagebox.showerror("Hata", "Lütfen geçerli sayısal değerler giriniz.")
    # --- REESKONT PANELİ ---
    def nav_reeskont(self):
        self.set_active_sidebar("reeskont")
        self.clear_content()
        self.create_header("Reeskont İşlemleri")
        card = tk.Frame(self.frame_content, bg="white", bd=1, relief="solid"); card.pack(fill=tk.X, padx=20, pady=20)
        
        self.ent_vade = self.create_input_date(card, "Vade Tarihi", 0, 0)
        self.ent_reeskont_tar = self.create_input_date(card, "Reeskont Tarihi", 0, 1)
        self.ent_oran = self.create_input(card, "Faiz Oranı (%)", 0, 2, "10")
        self.ent_nominal = self.create_input(card, "Nominal Değer", 2, 0, "0")
        self.ent_yil_gun = self.create_input(card, "Yıl Gün (360/365)", 2, 1, "360")
        
        tk.Button(card, text="HESAPLA", bg="#2980b9", fg="white", font=("Segoe UI", 10, "bold"), padx=20, pady=5, relief="flat", command=self.do_calculate_reeskont).grid(row=2, column=2, sticky="e", padx=15, pady=15)
        self.result_container = tk.Frame(self.frame_content, bg="#f4f6f9"); self.result_container.pack(fill=tk.X, padx=20)

    def create_input_date(self, parent, label, row, col):
        tk.Label(parent, text=label, bg="white", font=("Segoe UI", 10), anchor="w").grid(row=row, column=col, sticky="w", padx=15, pady=(15,5))
        widget = DateEntry(parent, width=20, background='darkblue', foreground='white', borderwidth=1, date_pattern='dd.mm.yyyy')
        widget.grid(row=row+1, column=col, sticky="w", padx=15, pady=(0,15))
        return widget

    def do_calculate_reeskont(self):
        for w in self.result_container.winfo_children(): w.destroy()
        self.result_container.columnconfigure(0, weight=1); self.result_container.columnconfigure(1, weight=1); self.result_container.columnconfigure(2, weight=1)
        success, result = self.engine.calculate_reeskont(self.ent_nominal.get(), self.ent_oran.get(), self.ent_vade.get(), self.ent_reeskont_tar.get(), self.ent_yil_gun.get())
        if not success: messagebox.showerror("Hata", result); return
        data = [("Vade Tarihi", result["vade_tarihi_str"]), ("Reeskont Tarihi", result["reeskont_tarihi_str"]), ("Gün", str(result["vade_gun_sayisi"])), ("Nominal", f"{result['nominal_str']:,.2f}"), ("Reeskont", f"{result['reeskont_tutari']:,.2f}"), ("Tasarruf", f"{result['tasarruf_degeri']:,.2f}")]
        for i, (k, v) in enumerate(data): self.create_result_card(self.result_container, k, v, i // 3, i % 3)

    # --- ADAT PANELİ (COMBOBOX DÜZELTİLDİ) ---
    # --- 1. GÜNCELLEME: ARAYÜZE ÖZET TABLO EKLENDİ ---
    def nav_adat(self):
        self.set_active_sidebar("adat")
        self.clear_content()
        self.adat_data_cache = []
        
        # Başlık ve Excel
        top = tk.Frame(self.frame_content, bg="#f4f6f9"); top.pack(fill=tk.X, padx=20, pady=20)
        tk.Label(top, text="Kasa Adat (Faiz) Hesaplama", bg="#f4f6f9", fg="#2c3e50", font=("Segoe UI", 16, "bold")).pack(side=tk.LEFT)
        tk.Button(top, text="📥 Excel", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), relief="flat", padx=15, pady=5, command=self.export_adat_excel).pack(side=tk.RIGHT)

        # Filtre Kartı
        card = tk.Frame(self.frame_content, bg="white", bd=0, relief="flat"); card.pack(fill=tk.X, padx=20, pady=(0, 20))
        
        # 1. Satır: Hesap Seçimi
        tk.Label(card, text="Ana Hesap (Kebir):", bg="white", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", padx=15, pady=(15,5))
        self.cb_main_account = ttk.Combobox(card, state="readonly", width=30)
        self.cb_main_account.grid(row=1, column=0, padx=15, pady=(0,15), sticky="ew")
        self.cb_main_account.bind("<<ComboboxSelected>>", self.on_main_account_change)

        tk.Label(card, text="Alt Hesap (Muavin):", bg="white", font=("Segoe UI", 9, "bold")).grid(row=0, column=1, sticky="w", padx=15, pady=(15,5))
        self.cb_sub_account = ttk.Combobox(card, state="readonly", width=30)
        self.cb_sub_account.grid(row=1, column=1, padx=15, pady=(0,15), sticky="ew")
        
        # Hesapları Yükle
        self.account_hierarchy = self.engine.get_account_hierarchy()
        if self.account_hierarchy:
            main_accounts = sorted(list(self.account_hierarchy.keys()))
            self.cb_main_account['values'] = main_accounts
            if main_accounts: self.cb_main_account.current(0); self.on_main_account_change(None)
        else:
            self.cb_main_account['values'] = ["Veri Yok"]

        # 2. Satır: Sınır ve Faiz
        tk.Label(card, text="Adat Sınırı (TL):", bg="white", font=("Segoe UI", 9, "bold")).grid(row=2, column=0, sticky="w", padx=15, pady=5)
        self.ent_adat_sinir = tk.Entry(card, bg="#f8f9fa", bd=1, relief="solid"); self.ent_adat_sinir.insert(0, "1000"); self.ent_adat_sinir.grid(row=3, column=0, padx=15, pady=(0,15), sticky="ew")

        # Faiz Yöntemi
        method_fr = tk.Frame(card, bg="white"); method_fr.grid(row=3, column=1, columnspan=2, sticky="w", padx=15, pady=(0,15))
        self.var_adat_method = tk.StringVar(value="manual")
        
        tk.Radiobutton(method_fr, text="İç Emsal Oran:", variable=self.var_adat_method, value="manual", bg="white", command=self.toggle_adat_inputs).pack(side=tk.LEFT)
        self.ent_adat_faiz = tk.Entry(method_fr, width=5, bg="#f8f9fa", bd=1, relief="solid"); self.ent_adat_faiz.insert(0, "35"); self.ent_adat_faiz.pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(method_fr, text="TCMB Avans", variable=self.var_adat_method, value="tcmb_avans", bg="white", command=self.toggle_adat_inputs).pack(side=tk.LEFT, padx=10)
        tk.Radiobutton(method_fr, text="TCMB Ticari", variable=self.var_adat_method, value="tcmb_ticari", bg="white", command=self.toggle_adat_inputs).pack(side=tk.LEFT, padx=10)

        # Hesapla Butonu
        tk.Button(card, text="LİSTELE", bg="#3498db", fg="white", font=("Segoe UI", 10, "bold"), relief="flat", padx=20, command=self.do_calculate_adat).grid(row=1, column=3, rowspan=3, padx=15, sticky="e")
        card.columnconfigure(2, weight=1)

        # --- ANA TABLO ---
        tbl_fr = tk.Frame(self.frame_content, bg="white"); tbl_fr.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 10))
        cols = ("Tarih", "Yev", "Kod", "HesapAdi", "GunlukBakiye", "Sinir", "KalanBakiye", "Gun", "FaizOrani", "AdatTutar")
        self.tree_adat = ttk.Treeview(tbl_fr, columns=cols, show="headings", style="Modern.Treeview", height=10)
        headers = {"Tarih": "Tarih", "Yev": "Yev. No", "Kod": "H. Kodu", "HesapAdi": "Hesap Adı", "GunlukBakiye": "Bakiye", "Sinir": "Sınır", "KalanBakiye": "Kalan", "Gun": "Gün", "FaizOrani": "Faiz %", "AdatTutar": "Adat Tutarı"}
        for c, t in headers.items(): 
            self.tree_adat.heading(c, text=t)
            w = 150 if c == "HesapAdi" else 80
            self.tree_adat.column(c, width=w, anchor="e" if "Bakiye" in c or "Tutar" in c else "center")
        
        sb = ttk.Scrollbar(tbl_fr, orient="vertical", command=self.tree_adat.yview); self.tree_adat.configure(yscrollcommand=sb.set); self.tree_adat.pack(side=tk.LEFT, fill=tk.BOTH, expand=True); sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree_adat.tag_configure("odd", background=CLR_TABLE_ROW_ODD); self.tree_adat.tag_configure("even", background=CLR_TABLE_ROW_EVEN)

        # --- ÖZET TABLO ALANI (YENİ EKLENDİ) ---
        summary_container = tk.Frame(self.frame_content, bg="white", bd=1, relief="solid")
        summary_container.pack(fill=tk.X, padx=20, pady=(0, 20))
        
        tk.Label(summary_container, text="Dönemsel Kümülatif Özet (Geçici Vergi Dönemleri)", bg="#ecf0f1", fg="#2c3e50", font=("Segoe UI", 10, "bold"), anchor="w", padx=10).pack(fill=tk.X)
        
        self.tree_summary = ttk.Treeview(summary_container, columns=("Donem", "Tutar"), show="headings", height=4, style="Modern.Treeview")
        self.tree_summary.heading("Donem", text="Dönem"); self.tree_summary.column("Donem", anchor="w", width=300)
        self.tree_summary.heading("Tutar", text="Kümülatif Toplam"); self.tree_summary.column("Tutar", anchor="e", width=150)
        self.tree_summary.pack(fill=tk.X)

        self.lbl_total_adat = tk.Label(self.frame_content, text="GENEL TOPLAM: 0.00 ₺", bg="#f4f6f9", fg="#c0392b", font=("Segoe UI", 12, "bold"), anchor="e")
        self.lbl_total_adat.pack(fill=tk.X, padx=20, pady=(0,20))




    def on_main_account_change(self, event):
        """Ana hesap değişince alt hesapları doldur"""
        selected_main = self.cb_main_account.get()
        if selected_main in self.account_hierarchy:
            # --- DÜZELTME BURADA ---
            # self.account_hierarchy[selected_main] zaten bir listedir. ["subs"] aranmamalı.
            subs_list = self.account_hierarchy[selected_main] 
            subs = ["TÜMÜ (Grup Bazlı Hesapla)"] + subs_list
            self.cb_sub_account['values'] = subs
            self.cb_sub_account.current(0)

    def toggle_adat_inputs(self):
        st = "normal" if self.var_adat_method.get() == "manual" else "disabled"
        bg = "#f8f9fa" if st == "normal" else "#e0e0e0"
        self.ent_adat_faiz.config(state=st, bg=bg)

        # --- 2. GÜNCELLEME: HESAPLAMA VE ÖZET DOLDURMA ---
    def do_calculate_adat(self):
        # Tabloları Temizle
        for i in self.tree_adat.get_children(): self.tree_adat.delete(i)
        for i in self.tree_summary.get_children(): self.tree_summary.delete(i)
        
        main_acc = self.cb_main_account.get()
        sub_acc = self.cb_sub_account.get()
        if not main_acc: messagebox.showerror("Hata", "Lütfen hesap seçiniz."); return

        if "TÜMÜ" in sub_acc:
            filter_type = "kebir"
            code_to_send = main_acc
        else:
            filter_type = "muavin"
            code_to_send = sub_acc

        method = self.var_adat_method.get()
        rate = self.ent_adat_faiz.get() if method == "manual" else "0"
        
        success, result = self.engine.calculate_adat(code_to_send, rate, self.ent_adat_sinir.get(), method=method, filter_type=filter_type)
        if not success: messagebox.showerror("Hata", result); return
        self.adat_data_cache = result
        
        # 1. Ana Tabloyu Doldur ve Toplamı Al
        grand_total = 0.0
        
        # 2. Özet Hesaplama Değişkenleri
        kumulatif = {3: 0.0, 6: 0.0, 9: 0.0, 12: 0.0}
        
        for i, row in enumerate(result):
            # Ana Tablo
            v = (row['Tarih'], row['YevmiyeNo'], row['HesapKodu'], row['HesapAdi'], 
                 f"{row['GunlukBakiye']:,.2f}", f"{row['AdatSiniri']:,.2f}", f"{row['KalanBakiye']:,.2f}", 
                 row['GunSayisi'], f"% {row['FaizOrani']:.2f}", f"{row['AdatTutar']:,.2f}")
            self.tree_adat.insert("", "end", values=v, tags=("even" if i%2==0 else "odd",))
            
            tutar = row['AdatTutar']
            grand_total += tutar
            
            # Özet Hesaplama (Ay bazlı kümülatif)
            try:
                # Tarih formatı: dd.mm.yyyy -> Ayı al
                ay = int(row['Tarih'].split('.')[1])
                
                # Kümülatif mantığı: 
                # 3 aylık: 1,2,3. aylar
                # 6 aylık: 1...6. aylar (Yani 3 aylığı da kapsar)
                if ay <= 3: kumulatif[3] += tutar
                if ay <= 6: kumulatif[6] += tutar
                if ay <= 9: kumulatif[9] += tutar
                if ay <= 12: kumulatif[12] += tutar
            except:
                pass

        # 3. Özet Tabloyu Doldur
        ozet_satirlari = [
            ("1. Geçici Vergi Dönemi (Ocak - Mart)", kumulatif[3]),
            ("2. Geçici Vergi Dönemi (Ocak - Haziran)", kumulatif[6]),
            ("3. Geçici Vergi Dönemi (Ocak - Eylül)", kumulatif[9]),
            ("4. Geçici Vergi Dönemi (Ocak - Aralık)", kumulatif[12])
        ]
        
        for donem, val in ozet_satirlari:
            self.tree_summary.insert("", "end", values=(donem, f"{val:,.2f}"))

        self.lbl_total_adat.config(text=f"GENEL TOPLAM: {grand_total:,.2f} ₺")

    def export_adat_excel(self):
        if not self.adat_data_cache: messagebox.showwarning("Uyarı", "Hesaplama yapınız"); return
        success, msg = self.engine.export_to_excel(self.adat_data_cache, "Adat"); messagebox.showinfo("Bilgi", msg) if success else messagebox.showerror("Hata", msg)

    # --- TCMB PANELİ ---
    def nav_tcmb(self):
        self.set_active_sidebar("tcmb")
        self.show_tcmb_panel()

    def show_tcmb_panel(self):
        self.clear_content()
        top = tk.Frame(self.frame_content, bg="#f4f6f9"); top.pack(fill=tk.X, padx=20, pady=20)
        tk.Label(top, text="TCMB Faiz Oranları", bg="#f4f6f9", fg="#2c3e50", font=("Segoe UI", 16, "bold")).pack(side=tk.LEFT)
        
        card = tk.Frame(self.frame_content, bg="white", bd=0, relief="flat"); card.pack(fill=tk.X, padx=20, pady=(0, 20))
        
        tk.Label(card, text="1. Kredi Türü:", bg="white", font=("Segoe UI", 10, "bold"), fg=CLR_ACCENT).grid(row=0, column=0, sticky="w", padx=15, pady=(15,5))
        self.var_main_cat = tk.StringVar(value="ticari")
        self.var_sub_cat = tk.StringVar()
        
        main_frame = tk.Frame(card, bg="white"); main_frame.grid(row=1, column=0, columnspan=4, sticky="w", padx=15)
        groups = [("Ticari Krediler (TL)", "ticari"), ("Döviz Kredileri", "doviz_kredi"), ("Tüketici Kredileri", "tuketici"), ("Avans / Reeskont", "avans")]
        for txt, val in groups:
            tk.Radiobutton(main_frame, text=txt, variable=self.var_main_cat, value=val, bg="white", command=self.update_sub_categories).pack(side=tk.LEFT, padx=(0, 15))

        tk.Label(card, text="2. Detay:", bg="white", font=("Segoe UI", 10, "bold"), fg=CLR_ACCENT).grid(row=2, column=0, sticky="w", padx=15, pady=(10,5))
        self.sub_cats_frame = tk.Frame(card, bg="#e8f6f3", bd=1, relief="solid"); self.sub_cats_frame.grid(row=3, column=0, columnspan=4, sticky="ew", padx=15, pady=5, ipady=5)
        self.update_sub_categories()

        tk.Label(card, text="3. Tarih:", bg="white", font=("Segoe UI", 10, "bold"), fg=CLR_ACCENT).grid(row=4, column=0, sticky="w", padx=15, pady=(15,5))
        date_fr = tk.Frame(card, bg="white"); date_fr.grid(row=5, column=0, columnspan=4, sticky="w", padx=15, pady=(0, 15))
        self.ent_tcmb_start = DateEntry(date_fr, width=12, background='darkblue', foreground='white', borderwidth=1, date_pattern='dd.mm.yyyy'); self.ent_tcmb_start.pack(side=tk.LEFT, padx=(0, 10))
        self.ent_tcmb_end = DateEntry(date_fr, width=12, background='darkblue', foreground='white', borderwidth=1, date_pattern='dd.mm.yyyy'); self.ent_tcmb_end.pack(side=tk.LEFT, padx=(0, 20))
        tk.Button(date_fr, text="GETİR", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), relief="flat", padx=20, command=self.do_fetch_tcmb).pack(side=tk.LEFT)

        tbl_fr = tk.Frame(self.frame_content, bg="white"); tbl_fr.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 20))
        self.tree_tcmb = ttk.Treeview(tbl_fr, columns=("Tarih", "Tur", "Oran"), show="headings", style="Modern.Treeview")
        self.tree_tcmb.heading("Tarih", text="Tarih"); self.tree_tcmb.column("Tarih", width=120, anchor="center")
        self.tree_tcmb.heading("Tur", text="Tür"); self.tree_tcmb.column("Tur", width=300)
        self.tree_tcmb.heading("Oran", text="Oran"); self.tree_tcmb.column("Oran", width=100, anchor="center")
        sb = ttk.Scrollbar(tbl_fr, orient="vertical", command=self.tree_tcmb.yview); self.tree_tcmb.configure(yscrollcommand=sb.set); self.tree_tcmb.pack(side=tk.LEFT, fill=tk.BOTH, expand=True); sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree_tcmb.tag_configure("odd", background=CLR_TABLE_ROW_ODD); self.tree_tcmb.tag_configure("even", background=CLR_TABLE_ROW_EVEN)

    def update_sub_categories(self):
        for w in self.sub_cats_frame.winfo_children(): w.destroy()
        m = self.var_main_cat.get()
        opts = {
            "ticari": [("Genel (TL)", "tl_genel"), ("KMH Hariç (TL)", "tl_kmh_haric")],
            "doviz_kredi": [("USD", "usd"), ("EUR", "eur")],
            "tuketici": [("Toplam", "toplam"), ("Toplam (KMH Dahil)", "toplam_kmh"), ("İhtiyaç", "ihtiyac"), ("İhtiyaç (KMH Dahil)", "ihtiyac_kmh"), ("Taşıt", "tasit"), ("Konut", "konut")],
            "avans": [("Reeskont (İskonto)", "reeskont"), ("Avans", "avans")]
        }
        curr = opts.get(m, [])
        if curr: self.var_sub_cat.set(curr[0][1])
        for t, v in curr:
            tk.Radiobutton(self.sub_cats_frame, text=t, variable=self.var_sub_cat, value=v, bg="#e8f6f3", font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=10)

    def do_fetch_tcmb(self):
        for i in self.tree_tcmb.get_children(): self.tree_tcmb.delete(i)
        success, result = self.engine.fetch_tcmb_data("dummy", self.ent_tcmb_start.get(), self.ent_tcmb_end.get(), self.var_main_cat.get(), self.var_sub_cat.get())
        if not success: messagebox.showerror("Hata", result); return
        for i, row in enumerate(result):
            self.tree_tcmb.insert("", "end", values=(row["Tarih"], row["Tur"], f"% {row['Oran']:.2f}"), tags=("even" if i%2==0 else "odd",))