import requests
import urllib3
from datetime import datetime

# SSL Uyarılarını Kapat
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class TCMBClient:
    """
    Sadece TCMB EVDS sisteminden veri çekmekten sorumlu sınıf.
    API Anahtarı Gömülüdür.
    YENİ: Ticari TL ve Döviz Kredileri ayrıldı.
    """
    def __init__(self):
        # --- GÖMÜLÜ API ANAHTARI ---
        self.EMBEDDED_API_KEY = "Vb5FIIBQRy" 
        # ---------------------------

        self.SERIES_MAP = {
            "ticari": {
                "label": "Ticari Krediler (TL)",
                "subs": {
                    "tl_genel": {"code": "TP.KTF17", "name": "Ticari (TL) - Genel"},
                    "tl_kmh_haric": {"code": "TP.KTF18", "name": "Ticari (TL) - KMH Hariç"}
                }
            },
            "doviz_kredi": {
                "label": "Döviz Kredileri",
                "subs": {
                    "usd": {"code": "TP.KTF17.USD", "name": "Ticari Kredi (USD)"},
                    "eur": {"code": "TP.KTF17.EUR", "name": "Ticari Kredi (EUR)"}
                }
            },
            "tuketici": {
                "label": "Tüketici Kredileri",
                "subs": {
                    "toplam": {"code": "TP.KTFTUK", "name": "Tüketici Toplam (İhtiyaç+Taşıt+Konut)"},
                    "toplam_kmh": {"code": "TP.KTFTUK01", "name": "Tüketici Toplam (KMH Dahil)"},
                    "ihtiyac": {"code": "TP.KTF10", "name": "İhtiyaç Kredisi"},
                    "ihtiyac_kmh": {"code": "TP.KTF101", "name": "İhtiyaç (KMH Dahil)"},
                    "tasit": {"code": "TP.KTF11", "name": "Taşıt Kredisi"},
                    "konut": {"code": "TP.KTF12", "name": "Konut Kredisi"}
                }
            },
            "avans": {
                "label": "Avans / Reeskont",
                "subs": {
                    "reeskont": {"code": "TP.REESAVANS.RIO", "name": "Reeskont (İskonto) %"},
                    "avans": {"code": "TP.REESAVANS.AFO", "name": "Avans Faiz Oranı %"}
                }
            }
        }

    def get_rates(self, dummy_key, start_date, end_date, main_key, sub_key):
        target_api_key = self.EMBEDDED_API_KEY
        
        if not target_api_key: return False, "API Anahtarı bulunamadı."

        if main_key not in self.SERIES_MAP: return False, "Geçersiz ana kategori."
        if sub_key not in self.SERIES_MAP[main_key]["subs"]: return False, "Geçersiz alt seçenek."

        selected_sub = self.SERIES_MAP[main_key]["subs"][sub_key]
        series_code = selected_sub["code"]
        series_name = selected_sub["name"]

        try:
            if hasattr(start_date, 'strftime'): s_date = start_date.strftime("%d-%m-%Y")
            else: s_date = str(start_date).replace(".", "-")
            if hasattr(end_date, 'strftime'): e_date = end_date.strftime("%d-%m-%Y")
            else: e_date = str(end_date).replace(".", "-")
        except: return False, "Tarih formatı hatası."

        # YENİ EVDS3 URL'si. URL içinde güvenlik duvarına takılmamak için "&key=" parametresi KALDIRILDI.
        # TCMB Güncel EVDS3 Endpoint'i
        url = (
            f"https://evds3.tcmb.gov.tr/igmevdsms-dis/series={series_code}"
            f"&startDate={s_date}&endDate={e_date}&type=json"
            f"&frequency=1&aggregationTypes=last&formulas=0"
        )

        headers = {
            'key': target_api_key, # API anahtarı zorunlu olarak SADECE burada gönderiliyor.
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json'
        }

        try:
            response = requests.get(url, headers=headers, verify=False, timeout=20)
            
            if response.status_code == 200:
                try:
                    data = response.json()
                except ValueError:
                    err_preview = response.text[:150].strip()
                    return False, f"TCMB verisi okunamadı. Sunucu JSON yerine düz metin döndürdü: {err_preview}"

                if "totalCount" in data and data["totalCount"] == 0: 
                    return False, "Seçilen tarihlerde veri bulunamadı."
                if "items" not in data: 
                    return False, "TCMB verisi boş döndü."

                parsed_data = []
                for item in data["items"]:
                    tarih = item.get("Tarih")
                    evds_key = series_code.replace(".", "_")
                    raw_val = item.get(evds_key)
                    if raw_val is not None and raw_val != "":
                        try:
                            parsed_data.append({
                                "Tarih": tarih,
                                "Tur": series_name,
                                "Oran": float(raw_val)
                            })
                        except: pass
                
                if not parsed_data: return False, "Sayısal veri bulunamadı."
                parsed_data.sort(key=lambda x: datetime.strptime(x["Tarih"], "%d-%m-%Y"), reverse=True)
                return True, parsed_data
            elif response.status_code == 403: 
                return False, "403 Hatası: API Anahtarı yetkisiz veya kullanım limiti dolmuş."
            else: 
                return False, f"Sunucu Hatası: HTTP {response.status_code}"
                
        except requests.exceptions.Timeout:
            return False, "Bağlantı Hatası: TCMB sunucusu zaman aşımına uğradı."
        except Exception as e: 
            return False, f"Bağlantı Hatası: {str(e)}"