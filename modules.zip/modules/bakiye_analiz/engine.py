import os
import pandas as pd
import sys
import numpy as np
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
from config import get_mukellefler_dir
from utils.session_db import get_last_session

class BalanceEngine:
    def __init__(self):
        self.df = pd.DataFrame()
        self.main_accounts = {} 
        self.status_msg = "Hazır"
        
        # Risk analizi için gerekli hesap tanımları
        self.CONTRA_ASSETS = {'103', '119', '122', '124', '129', '137', '139', '158', '199', '222', '224', '229', '257', '268', '299'}
        self.CONTRA_LIABILITIES = {'308', '322', '337', '371', '408', '422', '501', '580', '591'}
        self.REFLECTION_ACCOUNTS = {'701', '711', '721', '731', '741', '751', '761', '771', '781', '798'}

        self.load_data()

    def is_balance_valid(self, account_code, balance):
        # (Bu fonksiyon değişmedi, aynı kalacak)
        code = str(account_code).strip()
        group, kebir = code[0], code[:3]
        if abs(balance) < 0.01: return True
        if group in ['1', '2']:
            return balance < 0 if kebir in self.CONTRA_ASSETS else balance > 0
        elif group in ['3', '4', '5']:
            return balance > 0 if kebir in self.CONTRA_LIABILITIES else balance < 0
        elif group == '6':
            return balance < 0 if code.startswith(('60', '64', '67')) else balance > 0
        elif group == '7':
            return balance < 0 if kebir in self.REFLECTION_ACCOUNTS else balance > 0
        return True

    def get_active_file_path(self):
        # (Bu fonksiyon değişmedi, aynı kalacak)
        session = get_last_session()
        if not session: return None, "Oturum Yok", None
        vkn = session.get("vkn")
        year = session.get("year", session.get("yil"))
        if not vkn or str(vkn) == "---": return None, "Mükellef Seçilmedi", None
        base_dir = get_mukellefler_dir()
        target_folder = next((os.path.join(base_dir, f) for f in os.listdir(base_dir) if str(f).endswith(f"-{str(vkn).strip()}")), None)
        if not target_folder: return None, "Klasör Bulunamadı", None
        return os.path.join(target_folder, str(year), f"{str(year)}_FULL.parquet"), "Veri Yüklendi", year

    def load_data(self):
        target_file, msg, year = self.get_active_file_path()
        self.status_msg = msg
        if not target_file or not os.path.exists(target_file):
            self.status_msg = "Veri Yok"
            return

        try:
            self.df = pd.read_parquet(target_file)
            # Sütun eşleştirme
            col_map = {
                "KayitTarihi": "Tarih", "YevmiyeNo": "Yevmiye No",
                "HesapKodu": "Hesap Kodu", "HesapAdi": "Hesap Adı",
                "FisAciklamasi": "Fiş Açıklama", "DetayAciklama": "Detay Açıklama",
                "Borc": "Borç", "Alacak": "Alacak"
            }
            self.df.rename(columns=col_map, inplace=True)
            
            # Sayısal dönüşümler
            for col in ["Borç", "Alacak", "Yevmiye No"]:
                if col in self.df.columns:
                    self.df[col] = pd.to_numeric(self.df[col], errors='coerce').fillna(0)
            
            if 'Tarih' in self.df.columns:
                self.df['Tarih_Obj'] = pd.to_datetime(self.df['Tarih'], errors='coerce')

            self.df['Kebir Kodu'] = self.df['Hesap Kodu'].astype(str).str[:3]
            
            # --- VBA MANTIĞI BURADA BAŞLIYOR: SIRALAMA ---
            # VBA'daki: ORDER BY HesapKodu, KayitTarihi, YevmiyeNo
            self.df.sort_values(by=['Hesap Kodu', 'Tarih_Obj', 'Yevmiye No'], inplace=True)
            
            self.prepare_left_panel()

        except Exception as e:
            self.status_msg = f"Hata: {str(e)}"
            self.df = pd.DataFrame()

    def prepare_left_panel(self):
        if self.df.empty: return
        # Ana hesap bazında toplamları al
        grp = self.df.groupby(['Kebir Kodu'])[['Borç', 'Alacak']].sum().reset_index()
        try:
            names = self.df.groupby('Kebir Kodu')['Hesap Adı'].first().to_dict()
        except:
            names = {}
            
        self.main_accounts = {}
        for _, row in grp.iterrows():
            code = row['Kebir Kodu']
            bakiye = row['Borç'] - row['Alacak']
            self.main_accounts[code] = {
                "name": names.get(code, "Tanımsız"),
                "borc": row['Borç'], "alacak": row['Alacak'], 
                "bakiye": bakiye,
                "is_risky": not self.is_balance_valid(code, bakiye)
            }

    def _apply_vba_logic(self, dataframe, group_cols):
        """
        VBA Mantığını uygulayan yardımcı metod:
        1. Net Hareket (Borç - Alacak) hesapla
        2. Kümülatif Toplam (Running Balance) al
        3. Bakiyeyi Borç/Alacak sütunlarına dağıt
        """
        # Net Hareket
        dataframe['Net'] = dataframe['Borç'] - dataframe['Alacak']
        
        # Kümülatif Toplam (VBA'daki bakiye = bakiye + ... mantığı)
        dataframe['Kümülatif'] = dataframe['Net'].cumsum()
        
        # Sütunlara Dağıtma (Borç Bakiye / Alacak Bakiye)
        dataframe['BorcBakiye'] = dataframe['Kümülatif'].apply(lambda x: x if x > 0 else 0.0)
        dataframe['AlacakBakiye'] = dataframe['Kümülatif'].apply(lambda x: abs(x) if x < 0 else 0.0)
        
        return dataframe

    def get_period_data(self, account_code, period_type="daily"):
        """
        Seçili hesap için VBA mantığına göre sıralı bakiye hesaplar.
        """
        if self.df.empty: return []
        
        # 1. Sadece ilgili hesabı filtrele
        sub_df = self.df[self.df['Kebir Kodu'] == str(account_code)].copy()
        if sub_df.empty: return []

        # 2. VBA Mantığı: Kesinlikle Tarih ve Yevmiye sırasına göre olmalı
        sub_df.sort_values(by=['Tarih_Obj', 'Yevmiye No'], inplace=True)

        # 3. Dönemsel Gruplama (Günlük/Aylık/3 Aylık)
        if period_type == "daily":
            sub_df['GroupKey'] = sub_df['Tarih_Obj'].dt.to_period('D')
        elif period_type == "monthly":
            sub_df['GroupKey'] = sub_df['Tarih_Obj'].dt.to_period('M')
        else:
            sub_df['GroupKey'] = sub_df['Tarih_Obj'].dt.to_period('Q')

        # 4. Grup Toplamlarını Al
        grp = sub_df.groupby('GroupKey').agg({
            'Borç': 'sum', 
            'Alacak': 'sum',
            'Yevmiye No': 'max', 
            'Detay Açıklama': 'last'
        }).reset_index()

        # 5. Kümülatif Hesaplama (VBA Logic)
        grp = self._apply_vba_logic(grp, None)

        results = []
        tr_months = {1:"OCAK", 2:"ŞUBAT", 3:"MART", 4:"NİSAN", 5:"MAYIS", 6:"HAZİRAN", 7:"TEMMUZ", 8:"AĞUSTOS", 9:"EYLÜL", 10:"EKİM", 11:"KASIM", 12:"ARALIK"}
        
        for _, row in grp.iterrows():
            pv = row['GroupKey']
            if period_type == "daily": tl = pv.strftime("%d.%m.%Y")
            elif period_type == "monthly": tl = f"{pv.year} - {tr_months.get(pv.month,'')}"
            else: tl = f"{pv.year} - Q{pv.quarter}"
            
            results.append({
                "Zaman": tl, "YevmiyeNo": int(row['Yevmiye No']),
                "Aciklama": row['Detay Açıklama'], 
                "Borc": row['Borç'], "Alacak": row['Alacak'], 
                "BorcBakiye": row['BorcBakiye'], 
                "AlacakBakiye": row['AlacakBakiye'],
                "is_risky": not self.is_balance_valid(account_code, row['Kümülatif'])
            })
        return results

    def get_all_daily_data(self):
        """
        Tüm hesapların günlük özetini VBA mantığına (Hesap > Tarih > Yevmiye) göre çıkarır.
        """
        if self.df.empty: return []
        
        temp_df = self.df.copy()
        
        # VBA Mantığı: Önce Hesap Kodu, Sonra Tarih, Sonra Yevmiye
        temp_df.sort_values(by=['Kebir Kodu', 'Tarih_Obj', 'Yevmiye No'], inplace=True)
        temp_df['Gun'] = temp_df['Tarih_Obj'].dt.to_period('D')
        
        # 1. Her hesap ve gün için toplamları al
        grp = temp_df.groupby(['Kebir Kodu', 'Gun']).agg({
            'Hesap Adı': 'first', 
            'Borç': 'sum', 
            'Alacak': 'sum',
            'Yevmiye No': 'max', 
            'Detay Açıklama': 'last'
        }).reset_index()
        
        # 2. Tekrar sırala (GroupBy sırayı bozabilir)
        grp.sort_values(by=['Kebir Kodu', 'Gun'], inplace=True)

        # 3. Kümülatif Hesaplama (Hesap Kodu bazında gruplayarak kümülatif al)
        #    VBA'daki "If Account <> CurrentAccount Then Balance = 0" mantığı burada groupby().cumsum() ile yapılır.
        grp['Net'] = grp['Borç'] - grp['Alacak']
        grp['Kümülatif'] = grp.groupby('Kebir Kodu')['Net'].cumsum()
        
        # 4. Sütunlara Dağıt
        grp['BorcBakiye'] = grp['Kümülatif'].apply(lambda x: x if x > 0 else 0.0)
        grp['AlacakBakiye'] = grp['Kümülatif'].apply(lambda x: abs(x) if x < 0 else 0.0)

        results = []
        for _, row in grp.iterrows():
            code = row['Kebir Kodu']
            results.append({
                "Zaman": row['Gun'].strftime("%d.%m.%Y"),
                "HesapKodu": code, "HesapAdi": row['Hesap Adı'],
                "YevmiyeNo": int(row['Yevmiye No']), "Aciklama": row['Detay Açıklama'],
                "Borc": row['Borç'], "Alacak": row['Alacak'], 
                "BorcBakiye": row['BorcBakiye'], 
                "AlacakBakiye": row['AlacakBakiye'],
                "GizliKod": code, "GizliAd": row['Hesap Adı'],
                "is_risky": not self.is_balance_valid(code, row['Kümülatif'])
            })
        return results

    def get_fis_details(self, fis_no):
        if self.df.empty: return []
        s_fis = str(fis_no).split('.')[0].strip()
        mask = self.df['Yevmiye No'].astype(str).str.split('.').str[0] == s_fis
        rows = self.df[mask]
        return rows.to_dict('records')

    def export_excel(self, data, prefix="Bakiye"):
        if not data: return False, "Veri yok"
        try:
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            fn = f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            path = os.path.join(desktop, fn)
            export_data = [{k:v for k,v in d.items() if k!='is_risky'} for d in data]
            pd.DataFrame(export_data).to_excel(path, index=False)
            return True, f"Kaydedildi: {path}"
        except Exception as e: return False, str(e)