import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

try:
    from .engine import BalanceEngine
except ImportError:
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from engine import BalanceEngine

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
from config import CLR_BODY_BG, CLR_ACCENT

# NoteManager
try:
    from modules.not_yonetimi.ui import NoteManager
    HAS_NOTES = True
except ImportError:
    HAS_NOTES = False

CLR_HEADER_BG = "#154360"
CLR_HEADER_FG = "white"
CLR_TREE_STRIPE = "#D4E6F1"
CLR_BTN_BAR_BG = "#34495e"
CLR_TOTAL_BG = "#2980b9"
CLR_FIS_HEADER_BG = "#0F3057"
CLR_NEGATIVE_TXT = "#D90429"

class BalanceAnalizFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.engine = BalanceEngine()
        self.current_data = []
        self.active_view = "daily" 
        self.active_account_code = None
        self.setup_styles()
        self.setup_ui()
        self.load_left_panel()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Left.Treeview", font=("Arial", 10), rowheight=28)
        style.configure("Left.Treeview.Heading", font=("Arial", 10, "bold"), background=CLR_HEADER_BG, foreground="white", relief="flat")
        style.map("Left.Treeview", background=[("selected", "#F39C12")], foreground=[("selected", "white")])
        style.configure("Right.Treeview", font=("Arial", 9), rowheight=25)
        style.configure("Right.Treeview.Heading", font=("Arial", 9, "bold"), background=CLR_HEADER_BG, foreground="white", relief="flat")
        style.map("Right.Treeview", background=[("selected", "#F39C12")], foreground=[("selected", "white")])
        style.configure("Fis.Treeview", font=("Arial", 9), rowheight=25)
        style.configure("Fis.Treeview.Heading", font=("Arial", 9, "bold"), background="white", foreground="black")

    def setup_ui(self):
        main_container = tk.Frame(self, bg=CLR_BODY_BG)
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # --- ÜST BAR ---
        top_bar = tk.Frame(main_container, bg="white", height=45, bd=1, relief="solid")
        top_bar.pack(side=tk.TOP, fill=tk.X, pady=(0, 10))
        tk.Label(top_bar, text="📅 ZAMAN BAZLI BAKİYE ANALİZİ", bg="white", font=("Arial", 12, "bold"), fg="#2c3e50").pack(side=tk.LEFT, padx=15)
        
        btn_frame = tk.Frame(top_bar, bg="white")
        btn_frame.pack(side=tk.RIGHT, padx=10, pady=5)
        
        self.btn_day = tk.Button(btn_frame, text="GÜNLÜK", width=10, command=lambda: self.switch_view("daily"))
        self.btn_day.pack(side=tk.LEFT, padx=1)
        self.btn_month = tk.Button(btn_frame, text="AYLIK", width=10, command=lambda: self.switch_view("monthly"))
        self.btn_month.pack(side=tk.LEFT, padx=1)
        self.btn_quart = tk.Button(btn_frame, text="3 AYLIK", width=10, command=lambda: self.switch_view("quarterly"))
        self.btn_quart.pack(side=tk.LEFT, padx=1)
        
        # --- SİLİNDİ: self.btn_all_day satırları kaldırıldı ---
        
        # --- ALT BAR ---
        bottom_bar = tk.Frame(main_container, bg=CLR_BTN_BAR_BG, height=50, bd=1, relief="raised")
        bottom_bar.pack(side=tk.BOTTOM, fill=tk.X, pady=(10, 0))
        self.lbl_warning = tk.Label(bottom_bar, text="", bg=CLR_BTN_BAR_BG, fg="#FF5252", font=("Arial", 11, "bold"))
        self.lbl_warning.pack(side=tk.LEFT, padx=20)
        tk.Button(bottom_bar, text="📥 LİSTEYİ İNDİR (XLS)", bg="#e67e22", fg="white", font=("Arial", 10, "bold"), command=self.export_excel, padx=20, pady=5, bd=0).pack(side=tk.RIGHT, padx=20)
        
        # --- ANA PANEL ---
        self.paned = tk.PanedWindow(main_container, orient=tk.HORIZONTAL, sashwidth=6, bg="#bdc3c7")
        self.paned.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        # --- SOL PANEL ---
        left_frame = tk.Frame(self.paned, bg="white")
        self.paned.add(left_frame, width=350)
        tk.Label(left_frame, text="ANA HESAPLAR", bg=CLR_TOTAL_BG, fg="white", font=("Arial", 10, "bold"), height=2).pack(fill=tk.X)
        
        cols_left = ("Isim",)
        self.tree_left = ttk.Treeview(left_frame, columns=cols_left, show="headings", style="Left.Treeview")
        self.tree_left.heading("Isim", text="Hesap Adı"); self.tree_left.column("Isim", width=330)
        
        sb_ly = ttk.Scrollbar(left_frame, orient="vertical", command=self.tree_left.yview)
        self.tree_left.configure(yscrollcommand=sb_ly.set)
        self.tree_left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb_ly.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.tree_left.tag_configure("negative_left", foreground=CLR_NEGATIVE_TXT)
        self.tree_left.bind("<<TreeviewSelect>>", self.on_account_select)
        
        # --- SAĞ PANEL ---
        right_frame = tk.Frame(self.paned, bg="white")
        self.paned.add(right_frame)
        self.lbl_right_header = tk.Label(right_frame, text="SEÇİLİ HESAP DETAYI", bg="#E67E22", fg="white", font=("Arial", 10, "bold"), height=2)
        self.lbl_right_header.pack(fill=tk.X)
        
        cols_right = ("Zaman", "HesapKodu", "HesapAdi", "YevmiyeNo", "Aciklama", "Borc", "Alacak", "BorcBakiye", "AlacakBakiye")
        self.tree_right = ttk.Treeview(right_frame, columns=cols_right, show="headings", style="Right.Treeview")
        
        self.tree_right.heading("Zaman", text="Tarih"); self.tree_right.column("Zaman", width=80, anchor="center")
        self.tree_right.heading("HesapKodu", text="H. Kodu"); self.tree_right.column("HesapKodu", width=70, anchor="w")
        self.tree_right.heading("HesapAdi", text="Hesap Adı"); self.tree_right.column("HesapAdi", width=150, anchor="w")
        self.tree_right.heading("YevmiyeNo", text="Yev. No"); self.tree_right.column("YevmiyeNo", width=60, anchor="center")
        self.tree_right.heading("Aciklama", text="Açıklama"); self.tree_right.column("Aciklama", width=180, anchor="w")
        self.tree_right.heading("Borc", text="Borç"); self.tree_right.column("Borc", width=80, anchor="e")
        self.tree_right.heading("Alacak", text="Alacak"); self.tree_right.column("Alacak", width=80, anchor="e")
        self.tree_right.heading("BorcBakiye", text="B. Bakiye"); self.tree_right.column("BorcBakiye", width=80, anchor="e")
        self.tree_right.heading("AlacakBakiye", text="A. Bakiye"); self.tree_right.column("AlacakBakiye", width=80, anchor="e")
        
        sb_ry = ttk.Scrollbar(right_frame, orient="vertical", command=self.tree_right.yview)
        sb_rx = ttk.Scrollbar(right_frame, orient="horizontal", command=self.tree_right.xview)
        self.tree_right.configure(yscrollcommand=sb_ry.set, xscrollcommand=sb_rx.set)
        sb_rx.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb_ry.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.tree_right.tag_configure("negative_right", foreground=CLR_NEGATIVE_TXT)
        self.tree_right.tag_configure("odd", background=CLR_TREE_STRIPE)
        self.tree_right.tag_configure("even", background="white")
        self.tree_right.bind("<Double-1>", self.on_right_double_click)
        
        if HAS_NOTES:
            self.note_manager = NoteManager(
                self.tree_right, 
                "BAKIYE", 
                self, 
                indices={'ref': 3, 'borc': 5, 'alacak': 6, 'hk': 1, 'ha': 2}, 
                detail_callback=self.open_fis_detail_popup
            )
        
        self.update_buttons_visual()

    def switch_view(self, view_type):
        self.active_view = view_type
        self.update_buttons_visual()
        if view_type == "all_daily": self.load_all_daily()
        elif self.active_account_code: self.load_right_panel(self.active_account_code)
        else:
            for i in self.tree_right.get_children(): self.tree_right.delete(i)

    def update_buttons_visual(self):
        bg_active, bg_passive = "#2980b9", "#ecf0f1"
        fg_active, fg_passive = "white", "black"
        def style_btn(btn, active): btn.config(bg=bg_active if active else bg_passive, fg=fg_active if active else fg_passive, relief="sunken" if active else "raised")
        style_btn(self.btn_day, self.active_view == "daily")
        style_btn(self.btn_month, self.active_view == "monthly")
        style_btn(self.btn_quart, self.active_view == "quarterly")
        

    def load_left_panel(self):
        for i in self.tree_left.get_children(): self.tree_left.delete(i)
        accounts = self.engine.main_accounts
        neg_count = 0
        for code in sorted(accounts.keys()):
            data = accounts[code]
            display_name = f"{code} - {data['name']}"
            vals = (display_name,)
            row_tag = "negative_left" if data.get('is_risky') else ""
            if row_tag: neg_count += 1
            self.tree_left.insert("", "end", iid=code, values=vals, tags=(row_tag,))
        if neg_count > 0: self.lbl_warning.config(text=f"⚠️ DİKKAT: {neg_count} Adet Ana Hesapta Negatif Bakiye Var!", fg="#FF5252")
        else: self.lbl_warning.config(text="✅ Tüm Bakiyeler Normal.", fg="#2ECC71")

    def on_account_select(self, event):
        sel = self.tree_left.selection()
        if not sel: return
        code = sel[0] 
        self.active_account_code = code
        acc_name = self.engine.main_accounts[code]['name']
        if self.active_view == "all_daily": self.switch_view("daily")
        self.lbl_right_header.config(text=f"{code} - {acc_name} | {self.active_view.upper()} ANALİZİ")
        self.load_right_panel(code)

    # 1. TEK HESAP GÖRÜNÜMÜ İÇİN (load_right_panel)
    def load_right_panel(self, code):
        for i in self.tree_right.get_children(): self.tree_right.delete(i)
        
        data = self.engine.get_period_data(code, self.active_view)
        self.current_data = data
        neg_movements = 0
        
        # Hesap adını al
        acc_info = self.engine.main_accounts.get(code)
        acc_name = acc_info['name'] if acc_info else "Tanımsız Hesap"
        
        for i, row in enumerate(data):
            tags = ["even" if i % 2 == 0 else "odd"]
            if row.get('is_risky', False):
                tags.append("negative_right"); neg_movements += 1
            
            # --- DÜZELTME: Veri sırası Sütun Başlıklarıyla Eşleşti ---
            # Sıra: Zaman | Kod | Ad | Yevmiye | Açıklama | Borç | Alacak | B.Bakiye | A.Bakiye
            vals = (
                row['Zaman'],                   # 0. Zaman
                code,                           # 1. Hesap Kodu
                acc_name,                       # 2. Hesap Adı
                row['YevmiyeNo'],               # 3. Yevmiye No
                row['Aciklama'],                # 4. Açıklama
                f"{row['Borc']:,.2f}",          # 5. Borç
                f"{row['Alacak']:,.2f}",        # 6. Alacak
                f"{row['BorcBakiye']:,.2f}",    # 7. Borç Bakiye
                f"{row['AlacakBakiye']:,.2f}"   # 8. Alacak Bakiye
            )
            # ---------------------------------------------------------
            
            self.tree_right.insert("", "end", values=vals, tags=tuple(tags))
        
        if neg_movements > 0: self.lbl_warning.config(text=f"⚠️ Seçili hesapta {neg_movements} dönem ters bakiye verdi!", fg="#FF5252")
        else: self.lbl_warning.config(text="✅ Seçili hesap hareketleri normal.", fg="#2ECC71")
        if HAS_NOTES and hasattr(self, 'note_manager'): self.note_manager.color_rows()

    # 2. TÜMÜ (GÜN) GÖRÜNÜMÜ İÇİN (_populate_tree)
    def _populate_tree(self, data, default_code="", default_name=""):
        neg_movements = 0
        for i, row in enumerate(data):
            tags = ["even" if i % 2 == 0 else "odd"]
            if row.get('is_risky', False): tags.append("negative_right"); neg_movements += 1
            
            # Hesap Kodu ve Adını güvenli şekilde bul
            hk = row.get('HesapKodu') or row.get('GizliKod') or default_code
            ha = row.get('HesapAdi') or row.get('GizliAd') or default_name
            
            # --- DÜZELTME: Veri sırası Sütun Başlıklarıyla Eşleşti ---
            # Sıra: Zaman | Kod | Ad | Yevmiye | Açıklama | Borç | Alacak | B.Bakiye | A.Bakiye
            vals = (
                row['Zaman'],                   # 0. Zaman
                hk,                             # 1. Hesap Kodu
                ha,                             # 2. Hesap Adı
                row['YevmiyeNo'],               # 3. Yevmiye No
                row['Aciklama'],                # 4. Açıklama
                f"{row['Borc']:,.2f}",          # 5. Borç
                f"{row['Alacak']:,.2f}",        # 6. Alacak
                f"{row['BorcBakiye']:,.2f}",    # 7. Borç Bakiye
                f"{row['AlacakBakiye']:,.2f}"   # 8. Alacak Bakiye
            )
            # ---------------------------------------------------------
            
            self.tree_right.insert("", "end", values=vals, tags=tuple(tags))
            
        if self.active_view == "all_daily": 
             self.lbl_warning.config(text=f"⚠️ {neg_movements} riskli hareket!", fg="#FF5252" if neg_movements > 0 else "#2ECC71")
        if HAS_NOTES and hasattr(self, 'note_manager'): self.note_manager.color_rows()

    def load_all_daily(self):
        self.lbl_right_header.config(text="TÜM HESAPLARIN GÜNLÜK BAKİYE DURUMU")
        for i in self.tree_right.get_children(): self.tree_right.delete(i)
        data = self.engine.get_all_daily_data()
        self.current_data = data
        self._populate_tree(data)

    def _populate_tree(self, data, default_code="", default_name=""):
        neg_movements = 0
        for i, row in enumerate(data):
            tags = ["even" if i % 2 == 0 else "odd"]
            if row.get('is_risky', False): tags.append("negative_right"); neg_movements += 1
            hk = row.get('GizliKod', default_code); ha = row.get('GizliAd', default_name)
            
            # GÜNCELLEME: BorcBakiye ve AlacakBakiye eklendi
            vals = (
                row['Zaman'], row['YevmiyeNo'], row['Aciklama'], 
                f"{row['Borc']:,.2f}", f"{row['Alacak']:,.2f}", 
                f"{row['BorcBakiye']:,.2f}", f"{row['AlacakBakiye']:,.2f}",
                hk, ha
            )
            self.tree_right.insert("", "end", values=vals, tags=tuple(tags))
            
        if self.active_view == "all_daily": self.lbl_warning.config(text=f"⚠️ {neg_movements} riskli hareket!", fg="#FF5252" if neg_movements > 0 else "#2ECC71")
        if HAS_NOTES and hasattr(self, 'note_manager'): self.note_manager.color_rows()

    def on_right_double_click(self, event):
        sel = self.tree_right.selection()
        if not sel: return
        vals = self.tree_right.item(sel[0])['values']
        
        # GÜNCELLEME: Yevmiye No artık 3. indekste
        fis_no = vals[3] 
        
        self.open_fis_detail_popup(fis_no)


    def open_fis_detail_popup(self, fis_no):
        # 1- BİRDEN FAZLA PENCERE AÇILMASINI ENGELLEME
        if hasattr(self, '_fis_popup') and self._fis_popup.winfo_exists():
            self._fis_popup.destroy()

        items = self.engine.get_fis_details(fis_no)
        if not items: return
        
        popup = tk.Toplevel(self)
        self._fis_popup = popup # Sınıfa referansı kaydet
        
        popup.title(f"Fiş Detayı - No: {fis_no}")
        popup.geometry("1000x500")
        popup.configure(bg="white")
        
        head = tk.Frame(popup, bg=CLR_FIS_HEADER_BG, height=60)
        head.pack(fill=tk.X); head.pack_propagate(False)
        
        date_str = items[0].get('Tarih', '-') if 'Tarih' in items[0] else '-'
        if hasattr(date_str, 'strftime'): date_str = date_str.strftime('%d.%m.%Y')
        
        tk.Label(head, text=f"FİŞ NO: {fis_no}", bg=CLR_FIS_HEADER_BG, fg="white", font=("Arial", 16, "bold")).pack(side=tk.LEFT, padx=20)
        tk.Label(head, text=f"TARİH: {date_str}", bg=CLR_FIS_HEADER_BG, fg="white", font=("Arial", 14, "bold")).pack(side=tk.RIGHT, padx=20)
        
        # 2- İKİ YÖNLÜ SCROLL İÇİN CONTAINER OLUŞTURMA
        tree_container = tk.Frame(popup, bg="white")
        tree_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        cols = ("HesapKodu", "HesapAdı", "Açıklama", "Borc", "Alacak")
        tree = ttk.Treeview(tree_container, columns=cols, show="headings", style="Fis.Treeview")
        
        tree.column("HesapKodu", width=100); tree.heading("HesapKodu", text="Hesap Kodu")
        tree.column("HesapAdı", width=250); tree.heading("HesapAdı", text="Hesap Adı")
        tree.column("Açıklama", width=300); tree.heading("Açıklama", text="Açıklama")
        tree.column("Borc", width=100, anchor="e"); tree.heading("Borc", text="Borç")
        tree.column("Alacak", width=100, anchor="e"); tree.heading("Alacak", text="Alacak")
        
        # Dikey ve Yatay Scrollbar Tanımlamaları
        vsb = ttk.Scrollbar(tree_container, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(tree_container, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Grid Sistemi ile Container İçine Yerleştirme
        tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        # Container'ın esnemesi için grid yapılandırması
        tree_container.grid_columnconfigure(0, weight=1)
        tree_container.grid_rowconfigure(0, weight=1)
        
        t_b, t_a = 0.0, 0.0
        for i, it in enumerate(items):
            tag = "even" if i % 2 == 0 else "odd"
            b = float(it.get('Borç', 0)); a = float(it.get('Alacak', 0))
            t_b += b; t_a += a
            desc = f"{it.get('Fiş Açıklama','')} {it.get('Detay Açıklama','')}".strip()
            vals = (it.get('Hesap Kodu'), it.get('Hesap Adı'), desc, f"{b:,.2f}", f"{a:,.2f}")
            tree.insert("", "end", values=vals, tags=(tag,))
            
        tree.tag_configure("odd", background="#EAF2F8")
        tree.tag_configure("even", background="white")
        
        foot = tk.Frame(popup, bg="#f8f9fa", height=40)
        foot.pack(fill=tk.X, side=tk.BOTTOM)
        tk.Label(foot, text=f"TOPLAM BORÇ: {t_b:,.2f}", fg="#c0392b", font=("Arial",10,"bold"), bg="#f8f9fa").pack(side=tk.LEFT, padx=20)
        tk.Label(foot, text=f"TOPLAM ALACAK: {t_a:,.2f}", fg="#27ae60", font=("Arial",10,"bold"), bg="#f8f9fa").pack(side=tk.LEFT, padx=20)



    def export_excel(self):
        if not self.active_account_code and self.active_view != "all_daily":
            messagebox.showwarning("Uyarı", "Lütfen önce bir hesap seçiniz."); return
        prefix = f"Bakiye_{self.active_view}"
        success, msg = self.engine.export_excel(self.current_data, prefix)
        if success: messagebox.showinfo("Başarılı", msg)
        else: messagebox.showerror("Hata", msg)

    # --- YENİ NAVİGASYON FONKSİYONU ---
    def set_active_account(self, account_code):
        self.switch_view("daily")
        if self.tree_left.exists(account_code):
            self.tree_left.selection_set(account_code)
            self.tree_left.see(account_code)
            self.on_account_select(None)
        else:
            messagebox.showinfo("Bilgi", f"{account_code} nolu hesap Bakiye Analizinde bulunamadı.")