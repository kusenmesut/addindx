import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

# --- BAĞLANTILAR ---
try:
    from .engine import LedgerPropsEngine
except ImportError:
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from engine import LedgerPropsEngine

# Config Erişimi
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
try:
    from config import CLR_BODY_BG
except ImportError:
    CLR_BODY_BG = "#f4f6f7"

# --- MODERN RENK PALETİ ---
CLR_HEADER = "#2980B9"       # Koyu Mavi Başlık
CLR_PARENT = "#F1C40F"       # Turuncu/Sarı Parent Satır
CLR_PARENT_SEL = "#2ECC71"   # Yeşil (Seçili Parent)
CLR_CHILD_ODD = "#FFFFFF"    # Beyaz (Tek Satırlar)
CLR_CHILD_EVEN = "#EBF5FB"   # Açık Mavi/Gri (Çift Satırlar)
CLR_TEXT = "#2C3E50"         # Koyu Gri Yazı

# --- YENİ MANUEL SEÇİM PENCERESİ ---
class ManualSelectionWindow(tk.Toplevel):
    def __init__(self, master, engine, current_data, callback):
        super().__init__(master)
        self.title("Manuel Fiş Seçimi ve Düzenleme")
        
        # Form Boyutu
        w, h = 1150, 650
        ws = self.winfo_screenwidth()
        hs = self.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)
        self.geometry('%dx%d+%d+%d' % (w, h, x, y))
        self.configure(bg=CLR_BODY_BG)
        
        self.engine = engine
        self.callback = callback
        
        # Seçimleri Yükle
        self.selections = {
            "opening": set(self._parse_ids(current_data.get("opening", ""))),
            "reflection": set(self._parse_ids(current_data.get("reflection", ""))),
            "closing": set(self._parse_ids(current_data.get("closing", "")))
        }

        self.setup_styles()
        self.setup_ui()
        self.load_records("end") # Varsayılan

        # Pencere kapandığında ana formdaki değişkeni sıfırla
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _parse_ids(self, id_str):
        if not id_str:
            return []
        return [int(x.strip()) for x in str(id_str).split(',') if x.strip().isdigit()]

    def setup_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except:
            pass
        
        # Treeview Başlık Stili
        style.configure("Modern.Treeview.Heading", 
                        background=CLR_HEADER, 
                        foreground="white", 
                        font=("Segoe UI", 9, "bold"), # Font Küçültüldü
                        relief="flat")
        
        # Treeview Gövde Stili (KÜÇÜLTÜLDÜ)
        style.configure("Modern.Treeview", 
                        font=("Segoe UI", 9), 
                        rowheight=28,  # <-- 50'den 28'e düşürüldü
                        fieldbackground="white",
                        borderwidth=0)
        
        # Seçim Rengi
        style.map("Modern.Treeview", 
                  background=[("selected", "#3498DB")], 
                  foreground=[("selected", "white")])

    def setup_ui(self):
        # ÜST BAR
        top = tk.Frame(self, bg=CLR_BODY_BG, pady=10, padx=15)
        top.pack(fill=tk.X)
        
        btn_opts = {"font": ("Segoe UI", 9, "bold"), "width": 20, "height": 1, "bd": 0, "cursor": "hand2"}
        
        self.btn_start = tk.Button(top, text="Dönem Başı Kayıtları", bg="#BDC3C7", fg="white", **btn_opts,
                                   command=lambda: self.load_records("start"))
        self.btn_start.pack(side=tk.LEFT, padx=(0, 10))

        self.btn_end = tk.Button(top, text="Dönem Sonu Kayıtları", bg="#BDC3C7", fg="white", **btn_opts,
                                 command=lambda: self.load_records("end"))
        self.btn_end.pack(side=tk.LEFT)

        tk.Label(top, text="ℹ️ Kutucukları işaretlemek için üzerine tıklayın.", 
                 bg=CLR_BODY_BG, fg="#7F8C8D", font=("Segoe UI", 9, "italic")).pack(side=tk.LEFT, padx=20)

        # ORTA ALAN (TABLO + ÇİFT YÖNLÜ SCROLL)
        mid = tk.Frame(self, bg="white", bd=1, relief="solid")
        mid.pack(fill=tk.BOTH, expand=True, padx=15, pady=5)
        
        # Scrollbarlar için Grid Layout kullanıyoruz
        mid.grid_rowconfigure(0, weight=1)
        mid.grid_columnconfigure(0, weight=1)

        # Scrollbarlar
        vsb = ttk.Scrollbar(mid, orient="vertical")
        hsb = ttk.Scrollbar(mid, orient="horizontal")

        # Treeview
        cols = ("op", "cl", "ref", "date", "yev", "code", "name", "desc", "det", "borc", "alacak")
        self.tree = ttk.Treeview(mid, columns=cols, show="tree headings", 
                                 style="Modern.Treeview", selectmode="browse",
                                 yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Scrollbar Komutları
        vsb.config(command=self.tree.yview)
        hsb.config(command=self.tree.xview)

        # Yerleşim (Grid)
        self.tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')

        # Başlıklar
        self.tree.heading("#0", text="Detay", anchor="w")
        self.tree.heading("op", text="Açılış")
        self.tree.heading("cl", text="Kapanış")
        self.tree.heading("ref", text="Yansıtma")
        self.tree.heading("date", text="Tarih", anchor="center")
        self.tree.heading("yev", text="Yevmiye", anchor="center")
        self.tree.heading("code", text="H.Kodu", anchor="w")
        self.tree.heading("name", text="Hesap Adı", anchor="w")
        self.tree.heading("desc", text="Açıklama", anchor="w")
        self.tree.heading("det", text="Detay", anchor="w")
        self.tree.heading("borc", text="Borç", anchor="e")
        self.tree.heading("alacak", text="Alacak", anchor="e")

        # Genişlikler (Biraz daha kompakt)
        self.tree.column("#0", width=50, stretch=False)
        self.tree.column("op", width=60, anchor="center", stretch=False)
        self.tree.column("cl", width=60, anchor="center", stretch=False)
        self.tree.column("ref", width=70, anchor="center", stretch=False)
        self.tree.column("date", width=90, anchor="center", stretch=False)
        self.tree.column("yev", width=70, anchor="center", stretch=False)
        self.tree.column("code", width=100, anchor="w")
        self.tree.column("name", width=150, anchor="w")
        self.tree.column("desc", width=250, anchor="w")
        self.tree.column("det", width=150, anchor="w")
        self.tree.column("borc", width=100, anchor="e")
        self.tree.column("alacak", width=100, anchor="e")

        # Taglar (FONT BOYUTLARI KÜÇÜLTÜLDÜ - 14 -> 10)
        self.tree.tag_configure("parent", background=CLR_PARENT, foreground="black", font=("Segoe UI", 10, "bold"))
        self.tree.tag_configure("parent_sel", background=CLR_PARENT_SEL, foreground="white", font=("Segoe UI", 10, "bold"))
        self.tree.tag_configure("child_odd", background=CLR_CHILD_ODD, foreground=CLR_TEXT, font=("Segoe UI", 9))
        self.tree.tag_configure("child_even", background=CLR_CHILD_EVEN, foreground=CLR_TEXT, font=("Segoe UI", 9))

        self.tree.bind("<Button-1>", self.on_click)

        # ALT BAR
        bot = tk.Frame(self, bg=CLR_BODY_BG, pady=10, padx=15)
        bot.pack(fill=tk.X)
        
        tk.Button(bot, text="SEÇİMLERİ KAYDET VE KAPAT", bg="#27AE60", fg="white", 
                  font=("Segoe UI", 10, "bold"), bd=0, padx=25, pady=8, cursor="hand2",
                  command=self.save_and_close).pack(fill=tk.X)

    def load_records(self, mode):
        active = "#2980B9"
        passive = "#95A5A6"
        self.btn_start.config(bg=active if mode=="start" else passive)
        self.btn_end.config(bg=active if mode=="end" else passive)
        
        for i in self.tree.get_children():
            self.tree.delete(i)
        
        data, msg = self.engine.get_journal_entries(mode)
        if not data:
            messagebox.showinfo("Bilgi", msg)
            return

        for group in data:
            yev = group['yev_no']
            
            sel_op = yev in self.selections["opening"]
            sel_cl = yev in self.selections["closing"]
            sel_ref = yev in self.selections["reflection"]
            
            sym_op = "☑" if sel_op else "☐"
            sym_cl = "☑" if sel_cl else "☐"
            sym_ref = "☑" if sel_ref else "☐"
            
            tag = "parent_sel" if (sel_op or sel_cl or sel_ref) else "parent"
            
            p_vals = (sym_op, sym_cl, sym_ref, group['date'], yev, 
                      "", "", group['desc'], group['detail_desc'], 
                      f"{group['total_borc']:,.2f}", f"{group['total_alacak']:,.2f}")
            
            parent_id = self.tree.insert("", "end", text="", values=p_vals, tags=(tag,), open=False)
            
            for i, det in enumerate(group['details']):
                row_color_tag = "child_even" if i % 2 == 0 else "child_odd"
                c_vals = ("", "", "", "", "", 
                          det['code'], det['name'], 
                          det['desc'], det['detail'], 
                          f"{det['borc']:,.2f}", f"{det['alacak']:,.2f}")
                self.tree.insert(parent_id, "end", text="", values=c_vals, tags=(row_color_tag,))

    def on_click(self, event):
        region = self.tree.identify("region", event.x, event.y)
        if region != "cell": return
        
        col = self.tree.identify_column(event.x)
        item_id = self.tree.identify_row(event.y)
        if not item_id: return
        
        tags = self.tree.item(item_id, "tags")
        if "child_odd" in tags or "child_even" in tags: return 

        col_map = {"#1": "opening", "#2": "closing", "#3": "reflection"}
        action = col_map.get(col)
        
        if action:
            vals = list(self.tree.item(item_id, "values"))
            yev = int(vals[4])
            idx = int(col.replace("#", "")) - 1
            
            if vals[idx] == "☐":
                vals[idx] = "☑"
                self.selections[action].add(yev)
                others = ["opening", "closing", "reflection"]
                others.remove(action)
                idx_map = {"opening": 0, "closing": 1, "reflection": 2}
                for o in others:
                    if yev in self.selections[o]:
                        self.selections[o].remove(yev)
                        vals[idx_map[o]] = "☐"
            else:
                vals[idx] = "☐"
                if yev in self.selections[action]:
                    self.selections[action].remove(yev)
            
            new_tag = "parent_sel" if "☑" in vals[:3] else "parent"
            self.tree.item(item_id, values=vals, tags=(new_tag,))

    def save_and_close(self):
        try:
            res = {}
            for k in self.selections:
                res[k] = ", ".join(map(str, sorted(list(self.selections[k]))))
            
            if self.callback:
                self.callback(res)
        except Exception as e:
            messagebox.showerror("Hata", f"Kaydetme sırasında hata: {e}")
        finally:
            self.on_close()

    def on_close(self):
        if self.master and hasattr(self.master, 'manual_window'):
            self.master.manual_window = None
        self.destroy()

# --- ANA FRAME ---
class LedgerPropsFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.engine = LedgerPropsEngine()
        self.manual_window = None 
        self.setup_ui()
        self.load_data()

    def setup_ui(self):
        tk.Label(self, text="📚 DEFTER VE FİŞ ÖZELLİKLERİ", bg=CLR_BODY_BG, fg=CLR_TEXT, font=("Segoe UI", 18, "bold")).pack(pady=20)
        
        form = tk.Frame(self, bg="white", bd=1, relief="solid", padx=30, pady=30)
        form.pack(padx=40, pady=10, fill=tk.X)
        
        def mk_entry(lbl, var_name):
            tk.Label(form, text=lbl, bg="white", fg=CLR_TEXT, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 5))
            ent = tk.Entry(form, font=("Consolas", 12), bg="#FAFAFA", bd=1, relief="solid")
            ent.pack(fill=tk.X, ipady=5)
            setattr(self, var_name, ent)

        mk_entry("AÇILIŞ KAYDI (Yevmiye No):", "ent_opening")
        mk_entry("YANSITMA KAYDI (Yevmiye No):", "ent_reflection")
        mk_entry("KAPANIŞ KAYDI (Yevmiye No):", "ent_closing")

        btns = tk.Frame(self, bg=CLR_BODY_BG)
        btns.pack(pady=25)
        
        b_common = {"font": ("Segoe UI", 10, "bold"), "width": 18, "height": 2, "bd": 0, "cursor": "hand2"}
        
        tk.Button(btns, text="💾 KAYDET", bg="#27AE60", fg="white", **b_common, command=self.save).pack(side=tk.LEFT, padx=10)
        tk.Button(btns, text="✏️ MANUEL SEÇİM", bg="#F39C12", fg="white", **b_common, command=self.open_manual).pack(side=tk.LEFT, padx=10)
        tk.Button(btns, text="🔄 OTO. TARA", bg="#2980B9", fg="white", **b_common, command=self.rescan).pack(side=tk.LEFT, padx=10)

    def load_data(self):
        data, msg = self.engine.load_or_scan_properties()
        self._fill(data)

    def _fill(self, d):
        self.ent_opening.delete(0, tk.END)
        self.ent_opening.insert(0, d.get("opening", ""))
        
        self.ent_reflection.delete(0, tk.END)
        self.ent_reflection.insert(0, d.get("reflection", ""))
        
        self.ent_closing.delete(0, tk.END)
        self.ent_closing.insert(0, d.get("closing", ""))

    def open_manual(self):
        if self.manual_window is not None and self.manual_window.winfo_exists():
            self.manual_window.lift()
            self.manual_window.focus_force()
            return

        d = {
            "opening": self.ent_opening.get(),
            "reflection": self.ent_reflection.get(),
            "closing": self.ent_closing.get()
        }
        self.manual_window = ManualSelectionWindow(self, self.engine, d, self._fill)

    def rescan(self):
        d, m = self.engine.force_scan_and_update()
        if d:
            self._fill(d)
            messagebox.showinfo("Bilgi", "Otomatik tarama tamamlandı.")
        else:
            messagebox.showerror("Hata", m)

    def save(self):
        s, m = self.engine.save_user_input(
            self.ent_opening.get(), 
            self.ent_reflection.get(), 
            self.ent_closing.get()
        )
        if s:
            messagebox.showinfo("Bilgi", m)
        else:
            messagebox.showerror("Hata", m)