import os
import pandas as pd
import sys

# --- IMPORT AYARLARI ---
try:
    from .db import get_properties, save_properties
except ImportError:
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from db import get_properties, save_properties

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
try:
    from config import get_mukellefler_dir
    from utils.session_db import get_last_session
except ImportError:
    def get_mukellefler_dir(): return "."
    def get_last_session(): return {}

class LedgerPropsEngine:
    def __init__(self):
        self.vkn = None
        self.year = None
        self.status_msg = ""

    def get_active_context(self):
        session = get_last_session()
        if not session: return None, None, "Oturum Yok"
        self.vkn = session.get("vkn")
        self.year = session.get("year", session.get("yil"))
        if not self.vkn or str(self.vkn) in ["---", "None", "0000000000"]:
            return None, None, "Mükellef Seçilmedi"
        return self.vkn, self.year, "OK"

    def find_parquet_file(self):
        base_dir = get_mukellefler_dir()
        target_folder = None
        if os.path.exists(base_dir):
            for f in os.listdir(base_dir):
                if str(f).strip().endswith(f"-{str(self.vkn).strip()}"):
                    target_folder = os.path.join(base_dir, f)
                    break
        if not target_folder: return None
        return os.path.join(target_folder, str(self.year), f"{str(self.year)}_FULL.parquet")

    # --- EKSİK OLAN TARAMA FONKSİYONU EKLENDİ ---
    def _perform_scan(self, path):
        try:
            df = pd.read_parquet(path)
            # Sütun eşleştirme
            cols = {c.lower().strip(): c for c in df.columns}
            c_date = cols.get("kayittarihi") or cols.get("tarih")
            c_yev = cols.get("yevmiyeno")
            c_desc = cols.get("fisaciklamasi") or cols.get("aciklama")

            if not all([c_date, c_yev]): return None, "Gerekli sütunlar eksik."

            df[c_date] = pd.to_datetime(df[c_date], errors='coerce')
            
            # --- 1. AÇILIŞ FİŞİ (Ocak Ayı Min No) ---
            opening = ""
            df_jan = df[df[c_date].dt.month == 1]
            if not df_jan.empty:
                opening = str(df_jan[c_yev].min())

            # --- 2. YANSITMA VE KAPANIŞ (Aralık Ayı) ---
            reflection = []
            closing = ""
            
            df_dec = df[df[c_date].dt.month == 12]
            if not df_dec.empty:
                # Kapanış: Açıklamada 'kapanış' geçen VEYA En büyük no
                # Önce 'kapanış' kelimesine bak
                if c_desc:
                    closing_candidates = df_dec[df_dec[c_desc].astype(str).str.contains("kapanış|kapanis", case=False, na=False)]
                    if not closing_candidates.empty:
                        closing = str(closing_candidates[c_yev].max())
                
                # Bulamazsa en son fişi al
                if not closing:
                    closing = str(df_dec[c_yev].max())

                # Yansıtma: Açıklamada 'yansıtma' geçenler
                if c_desc:
                    ref_candidates = df_dec[df_dec[c_desc].astype(str).str.contains("yansıtma|yansitma", case=False, na=False)]
                    if not ref_candidates.empty:
                        reflection = sorted(ref_candidates[c_yev].unique().astype(str))

            return {
                "opening": opening,
                "reflection": ", ".join(reflection),
                "closing": closing
            }, "Tarama Başarılı"

        except Exception as e:
            return None, f"Hata: {e}"

    def load_or_scan_properties(self):
        vkn, year, msg = self.get_active_context()
        if not vkn: return {"opening": "", "reflection": "", "closing": ""}, msg
        
        # Önce veritabanına bak
        existing = get_properties(vkn, year)
        if existing:
            return {
                "opening": existing['opening_ids'], 
                "reflection": existing['reflection_ids'], 
                "closing": existing['closing_ids']
            }, "OK"
        
        # Yoksa Tara
        return self.force_scan_and_update()

    def save_user_input(self, opening, reflection, closing):
        vkn, year, msg = self.get_active_context()
        if not vkn: return False, msg
        data = {"vkn": vkn, "year": year, "opening": opening, "reflection": reflection, "closing": closing}
        try:
            save_properties(data)
            return True, "Başarıyla kaydedildi."
        except Exception as e: return False, str(e)

    def force_scan_and_update(self):
        """Dosyayı tarar ve sonucu döner (Kaydetmez, kullanıcı kaydetsin diye)"""
        path = self.find_parquet_file()
        if not path or not os.path.exists(path): 
            return {"opening": "", "reflection": "", "closing": ""}, "Dosya Yok"
            
        data, msg = self._perform_scan(path)
        if data:
            return data, "OK"
        return {"opening": "", "reflection": "", "closing": ""}, msg

    # --- MANUEL SEÇİM İÇİN VERİ ÇEKME ---
    def get_journal_entries(self, mode="end"):
        path = self.find_parquet_file()
        if not path or not os.path.exists(path): return [], "Veri dosyası bulunamadı."

        try:
            df = pd.read_parquet(path)
            col_map = {c: c.strip() for c in df.columns}
            df.rename(columns=col_map, inplace=True)
            
            cols_lower = {c.lower(): c for c in df.columns}
            c_date = cols_lower.get("kayittarihi") or cols_lower.get("tarih")
            c_yev = cols_lower.get("yevmiyeno")
            c_desc = cols_lower.get("fisaciklamasi") or cols_lower.get("aciklama")
            c_det = cols_lower.get("detayaciklama")
            c_borc = cols_lower.get("borc")
            c_alacak = cols_lower.get("alacak")
            c_code = cols_lower.get("hesapkodu") or cols_lower.get("kebirkodu")
            c_name = cols_lower.get("hesapadi") or cols_lower.get("ad")

            if not all([c_date, c_yev, c_borc, c_alacak]): return [], "Kritik sütunlar eksik."

            df[c_date] = pd.to_datetime(df[c_date], errors='coerce')
            
            target_df = pd.DataFrame()
            if mode == "start":
                target_df = df[df[c_date].dt.month == 1].copy()
                if target_df.empty: return [], "Ocak ayı kaydı yok."
                all_yevs = sorted(target_df[c_yev].unique())[:10]
                target_df = target_df[target_df[c_yev].isin(all_yevs)]
                target_df.sort_values(by=[c_yev, c_date], ascending=[True, True], inplace=True)
            else:
                target_df = df[df[c_date].dt.month == 12].copy()
                if target_df.empty: return [], "Aralık ayı kaydı yok."
                target_df.sort_values(by=[c_yev, c_date], ascending=[False, True], inplace=True)

            grouped_data = []
            
            for yev_no, group in target_df.groupby(c_yev, sort=False):
                raw_descs = group[c_desc].dropna().astype(str).unique()
                summary_desc = " | ".join([d for d in raw_descs if d.strip() not in ["", "nan", "None"]])
                if len(summary_desc) > 80: summary_desc = summary_desc[:77] + "..."

                summary_det = ""
                if c_det:
                    raw_dets = group[c_det].dropna().astype(str).unique()
                    summary_det = " | ".join([d for d in raw_dets if d.strip() not in ["", "nan", "None"]])
                    if len(summary_det) > 80: summary_det = summary_det[:77] + "..."

                summary = {
                    "yev_no": int(yev_no),
                    "date": group[c_date].iloc[0].strftime("%d.%m.%Y"),
                    "desc": summary_desc,
                    "detail_desc": summary_det,
                    "total_borc": group[c_borc].sum(),
                    "total_alacak": group[c_alacak].sum(),
                    "details": [] 
                }
                
                for _, row in group.iterrows():
                    summary["details"].append({
                        "code": str(row.get(c_code, "")),
                        "name": str(row.get(c_name, "")),
                        "desc": str(row.get(c_desc, "")),
                        "detail": str(row.get(c_det, "")) if c_det else "",
                        "borc": row.get(c_borc, 0),
                        "alacak": row.get(c_alacak, 0)
                    })
                
                grouped_data.append(summary)

            return grouped_data, "OK"

        except Exception as e: return [], f"Hata: {str(e)}"