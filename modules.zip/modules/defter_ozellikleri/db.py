import sqlite3
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
from config import get_base_dir

def get_db_path():
    return os.path.join(get_base_dir(), "ledger_props.db")

def init_db():
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ledger_properties (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vkn TEXT,
            year TEXT,
            opening_ids TEXT,    -- Açılış Yevmiye Noları (Virgülle ayrılmış)
            reflection_ids TEXT, -- Yansıtma Yevmiye Noları
            closing_ids TEXT,    -- Kapanış Yevmiye Noları
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(vkn, year)
        )
    ''')
    conn.commit()
    conn.close()

def get_properties(vkn, year):
    init_db()
    conn = sqlite3.connect(get_db_path())
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ledger_properties WHERE vkn=? AND year=?", (str(vkn), str(year)))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def save_properties(data):
    init_db()
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    
    # Upsert (Varsa güncelle, yoksa ekle)
    cursor.execute("SELECT id FROM ledger_properties WHERE vkn=? AND year=?", (data['vkn'], data['year']))
    row = cursor.fetchone()
    
    if row:
        cursor.execute('''
            UPDATE ledger_properties 
            SET opening_ids=?, reflection_ids=?, closing_ids=?, updated_at=CURRENT_TIMESTAMP
            WHERE id=?
        ''', (data['opening'], data['reflection'], data['closing'], row[0]))
    else:
        cursor.execute('''
            INSERT INTO ledger_properties (vkn, year, opening_ids, reflection_ids, closing_ids)
            VALUES (?, ?, ?, ?, ?)
        ''', (data['vkn'], data['year'], data['opening'], data['reflection'], data['closing']))
        
    conn.commit()
    conn.close()
