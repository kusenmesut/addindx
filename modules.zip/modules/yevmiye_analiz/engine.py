import os
import pandas as pd
import sys
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
from config import get_mukellefler_dir, get_base_dir
from utils.session_db import get_last_session

class YevmiyeEngine:
    def __init__(self):
        self.df = pd.DataFrame()
        self.filtered_df = pd.DataFrame()
        self.default_limit = 100 
        self.items_per_page = self.default_limit
        self.current_page = 1
        self.total_pages = 1
        self.status_msg = "Hazır"
        self.sort_col = None
        self.sort_reverse = False
        self.is_showing_all = False
        self.load_data()
# engine.py içerisine 'YevmiyeEngine' sınıfına eklenecek metod:

    def apply_advanced_query(self, conditions):
        """
        Pop-up'tan gelen dinamik koşulları işler.
        conditions yapısı: [{'col': 'Borç', 'op': '>', 'val': '5000'}, ...]
        """
        if self.df.empty: return
        
        temp_df = self.df.copy()
        
        # Her bir satır bir "VE (AND)" koşulu gibi çalışır.
        # İsterseniz "VEYA" mantığı da eklenebilir ama denetimde genelde "VE" daraltması kullanılır.
        for cond in conditions:
            col = cond['col']  # Örn: 'Borç', 'Hesap Kodu'
            op = cond['op']    # Örn: '=', '>', 'İçerir'
            val = cond['val']
            
            # Veri Tipi Yönetimi
            if col in ["Borç", "Alacak", "Yevmiye No"]:
                try: val = float(val)
                except: continue # Sayı değilse geç
            else:
                val = str(val).lower() # String işlemleri için küçült

            # Filtreleme Mantığı
            if col in temp_df.columns:
                if op == "=":
                    if isinstance(val, str):
                        temp_df = temp_df[temp_df[col].astype(str).str.lower() == val]
                    else:
                        temp_df = temp_df[temp_df[col] == val]
                elif op == ">":
                    temp_df = temp_df[temp_df[col] > val]
                elif op == "<":
                    temp_df = temp_df[temp_df[col] < val]
                elif op == "İçerir" and isinstance(val, str):
                    temp_df = temp_df[temp_df[col].astype(str).str.lower().str.contains(val, na=False)]
                elif op == "Başlar" and isinstance(val, str):
                    temp_df = temp_df[temp_df[col].astype(str).str.lower().str.startswith(val)]
        
        self.filtered_df = temp_df
        self.current_page = 1
        self.calculate_total_pages()
        return self.get_stats()
    
    
    def get_active_file_path(self):
        session = get_last_session()
        if not session: return None, "Oturum Yok", None
        vkn, yil = session.get("vkn"), session.get("yil")
        if not vkn or str(vkn) == "---": return None, "Mükellef Seçilmedi", None
        base_dir = get_mukellefler_dir()
        target_folder = None
        folder_name_display = ""
        if os.path.exists(base_dir):
            for f in os.listdir(base_dir):
                if str(f).strip().endswith(f"-{str(vkn).strip()}"):
                    target_folder = os.path.join(base_dir, f)
                    folder_name_display = f
                    break
        if not target_folder: return None, "Klasör Bulunamadı", None
        target_file = os.path.join(target_folder, str(yil), f"{yil}_FULL.parquet")
        return target_file, f"{folder_name_display} ({yil})", yil

    def load_data(self):
        target_file, display_name, yil = self.get_active_file_path()
        if not target_file:
            self.status_msg = display_name 
            return
        if not os.path.exists(target_file):
            self.status_msg = f"Veri Yok: {yil}_FULL.parquet"
            return
        try:
            self.df = pd.read_parquet(target_file)
            # --- GÜNCELLEME: MuavinKodu ve MuavinAdi eşleştirmeleri eklendi ---
            col_map = {
                "KayitTarihi": "Tarih", "YevmiyeNo": "Yevmiye No", "BelgeNo": "Belge No",
                "HesapKodu": "Hesap Kodu", "HesapAdi": "Hesap Adı",
                "MuavinKodu": "Muavin Kodu", "MuavinAdi": "Muavin Adı", 
                "FisAciklamasi": "Fiş Açıklama", "DetayAciklama": "Detay Açıklama",
                "Borc": "Borç", "Alacak": "Alacak"
            }
            self.df.rename(columns=col_map, inplace=True)
            # ... (fonksiyonun geri kalanı aynı kalacak)
            for col in ["Borç", "Alacak", "Yevmiye No"]:
                if col in self.df.columns:
                    self.df[col] = pd.to_numeric(self.df[col], errors='coerce').fillna(0)
            if 'Tarih' in self.df.columns:
                self.df['Tarih_Obj'] = pd.to_datetime(self.df['Tarih'], errors='coerce')
                self.df['Tarih'] = self.df['Tarih_Obj'].dt.strftime('%d.%m.%Y')
            for col in col_map.values():
                if col not in self.df.columns: self.df[col] = ""
            self.filtered_df = self.df.copy()
            self.calculate_total_pages()
            self.status_msg = f"✅ {display_name} - {len(self.df)} Kayıt"
            self.current_page = 1
        except Exception as e:
            self.status_msg = f"Hata: {str(e)}"
            self.df = pd.DataFrame()

    def filter_data(self, criteria):
        """Arayüzden gelen gelişmiş kriterlere göre DataFrame'i filtreler."""
        if self.df.empty: return self.get_stats()
        
        temp_df = self.df.copy()
        
        # 1. METİN ARAMA (Dahil Et & Hariç Tut)
        text = criteria.get('text', '')
        exclude = criteria.get('exclude', '')
        logic = criteria.get('logic', 'AND')
        target_col = criteria.get('target_col', 'Tümü')

        if target_col == "Tümü":
            cols_to_search = [
                'Yevmiye No', 
                'Belge No', 
                'Hesap Kodu', 
                'Hesap Adı', 
                'Muavin Kodu', 
                'Muavin Adı', 
                'Fiş Açıklama', 
                'Detay Açıklama',
                'Borç',    # Tümü dendiğinde tutarları da metin gibi arasın
                'Alacak'
            ]
        elif target_col == "Borç-Alacak":
            # Sadece tutar sütunlarında arama yap
            cols_to_search = ['Borç', 'Alacak']
        else:
            cols_to_search = [target_col]

        # İçerenler (Çoklu kelime AND / OR)
        if text:
            words = text.lower().split()
            mask_text = pd.Series(False if logic == 'OR' else True, index=temp_df.index)
            
            for word in words:
                word_mask = pd.Series(False, index=temp_df.index)
                for col in cols_to_search:
                    if col in temp_df.columns:
                        word_mask = word_mask | temp_df[col].astype(str).str.lower().str.contains(word, na=False)
                
                if logic == 'AND':
                    mask_text = mask_text & word_mask
                else: # OR
                    mask_text = mask_text | word_mask
                    
            temp_df = temp_df[mask_text]

        # Hariç Tutanlar (Exclude)
        if exclude:
            exc_words = exclude.lower().split()
            for word in exc_words:
                for col in cols_to_search:
                    if col in temp_df.columns:
                        temp_df = temp_df[~temp_df[col].astype(str).str.lower().str.contains(word, na=False)]

        # 2. TUTAR SÜZGECİ (Min - Max)
        min_tutar = criteria.get('min_tutar')
        max_tutar = criteria.get('max_tutar')
        if min_tutar is not None or max_tutar is not None:
            tutar_mask = pd.Series(False, index=temp_df.index)
            
            for t_col in ['Borç', 'Alacak']:
                if t_col in temp_df.columns:
                    col_data = pd.to_numeric(temp_df[t_col], errors='coerce').fillna(0)
                    m = pd.Series(True, index=temp_df.index)
                    if min_tutar is not None: m = m & (col_data >= min_tutar)
                    if max_tutar is not None: m = m & (col_data <= max_tutar)
                    tutar_mask = tutar_mask | m
                    
            temp_df = temp_df[tutar_mask]

        # 3. HESAP VE MUAVİN SÜZGECİ
        hk = criteria.get('hesap_kodu', 'Tümü')
        mk = criteria.get('muavin_kodu', 'Tümü')
        
        if hk and hk != "Tümü" and 'Hesap Kodu' in temp_df.columns:
            temp_df = temp_df[temp_df['Hesap Kodu'].astype(str) == str(hk)]
            
        if mk and mk != "Tümü" and 'Muavin Kodu' in temp_df.columns:
            temp_df = temp_df[temp_df['Muavin Kodu'].astype(str) == str(mk)]

        # 4. TARİH SÜZGECİ (Başlangıç - Bitiş) KESİN ÇÖZÜM
        start_dt = criteria.get('date_start', '').strip()
        end_dt = criteria.get('date_end', '').strip()
        
        if start_dt and end_dt and 'Tarih' in temp_df.columns:
            try:
                # 1. Arayüzden gelen stringleri gerçek tarihe çevir
                s_date = pd.to_datetime(start_dt, format='%d.%m.%Y', errors='coerce')
                e_date = pd.to_datetime(end_dt, format='%d.%m.%Y', errors='coerce')
                
                # 2. Eğer kullanıcı geçersiz bir tarih yazmadıysa işleme gir
                if pd.notna(s_date) and pd.notna(e_date):
                    # Orijinal 'Tarih' sütununu anlık olarak GÜN.AY.YIL formatıyla parse et
                    # (Bu sayede eski bozuk Tarih_Obj sütununu tamamen bypass etmiş oluyoruz)
                    df_dates = pd.to_datetime(temp_df['Tarih'], format='%d.%m.%Y', errors='coerce')
                    
                    # 3. Maskeyi oluştur: O anki satırın tarihi, Başlangıç ve Bitiş tarihleri arasında mı?
                    mask_dates = (df_dates >= s_date) & (df_dates <= e_date)
                    
                    # NaT olanları (hatalı satırları) False sayarak sadece doğruları getir
                    temp_df = temp_df[mask_dates.fillna(False)]
            except Exception as e:
                print(f"Tarih filtreleme hatası: {e}")

        # Sonuçları Kaydet ve İstatistikleri Döndür
        self.filtered_df = temp_df
        self.current_page = 1
        self.calculate_total_pages()
        return self.get_stats()

    def sort_data(self, col_name):
        if self.filtered_df.empty: return
        if self.sort_col == col_name:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_col = col_name
            self.sort_reverse = False
        sort_by = 'Tarih_Obj' if col_name == 'Tarih' and 'Tarih_Obj' in self.filtered_df.columns else col_name
        if sort_by in self.filtered_df.columns:
            self.filtered_df = self.filtered_df.sort_values(by=sort_by, ascending=not self.sort_reverse)
        self.current_page = 1

    def toggle_show_all(self, show_all):
        self.is_showing_all = show_all
        if show_all:
            self.items_per_page = len(self.filtered_df) if not self.filtered_df.empty else 1
        else:
            self.items_per_page = self.default_limit
        self.current_page = 1
        self.calculate_total_pages()

    def export_excel(self, export_type="filtered", filepath=None):
        """
        Belirtilen türe göre (Süzülenler veya Tüm Defter) veriyi Excel'e aktarır.
        """
        # 1. Hangi verinin aktarılacağını seç
        if export_type == "filtered":
            df_to_export = self.filtered_df
        else:
            df_to_export = self.df

        if df_to_export.empty:
            return False, "Aktarılacak veri bulunamadı."

        # 2. Dosya yolu belirtilmediyse masaüstüne yedekle (Güvenlik ağı)
        if not filepath:
            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            from datetime import datetime
            filename = f"Yevmiye_{export_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            filepath = os.path.join(desktop, filename)

        try:
            # İşimize yaramayan teknik sütunları (Tarih_Obj) dışarıda bırak
            export_cols = [c for c in df_to_export.columns if c != "Tarih_Obj"]
            df_final = df_to_export[export_cols]

            # 3. Excel'e Kaydet (Şık formatlama için xlsxwriter dener, yoksa standart kaydeder)
            try:
                # Eğer xlsxwriter yüklüyse sütun genişliklerini otomatik ayarlar (Çok şık durur)
                with pd.ExcelWriter(filepath, engine='xlsxwriter') as writer:
                    df_final.to_excel(writer, index=False, sheet_name='Yevmiye Defteri')
                    worksheet = writer.sheets['Yevmiye Defteri']
                    
                    for i, col in enumerate(df_final.columns):
                        # Sütun adının veya içindeki en uzun verinin karakter sayısını bul
                        max_len = max(df_final[col].astype(str).map(len).max(), len(col)) + 2
                        worksheet.set_column(i, i, max_len)
            except:
                # xlsxwriter kütüphanesi yoksa düz, ham kayıt yapar
                df_final.to_excel(filepath, index=False, sheet_name='Yevmiye Defteri')

            return True, f"Excel dosyası başarıyla oluşturuldu:\n\n{filepath}"
        except Exception as e:
            return False, f"Dışa aktarma sırasında bir hata oluştu:\n{str(e)}"

    def calculate_total_pages(self):
        if self.filtered_df.empty:
            self.total_pages = 1
        else:
            import math
            self.total_pages = math.ceil(len(self.filtered_df) / self.items_per_page)

    def get_page_data(self):
        if self.filtered_df.empty: return []
        start = (self.current_page - 1) * self.items_per_page
        end = start + self.items_per_page
        return self.filtered_df.iloc[start:end].to_dict('records')

    def change_page(self, direction, target=None):
        if self.filtered_df.empty: return
        if target:
            try: self.current_page = int(target)
            except: pass
        elif direction == "next" and self.current_page < self.total_pages: self.current_page += 1
        elif direction == "prev" and self.current_page > 1: self.current_page -= 1
        elif direction == "first": self.current_page = 1
        elif direction == "last": self.current_page = self.total_pages
        self.current_page = max(1, min(self.current_page, self.total_pages))

    def get_stats(self):
        if self.filtered_df.empty:
            return {"toplam_kayit": 0, "toplam_borc": 0, "toplam_alacak": 0}
        return {
            "toplam_kayit": len(self.filtered_df),
            "toplam_borc": self.filtered_df['Borç'].sum(),
            "toplam_alacak": self.filtered_df['Alacak'].sum()
        }

    # --- YENİ METOT: Fiş Detayı Getirme ---
    def get_rows_by_fis_no(self, fis_no):
        if self.df.empty: return []
        # Fiş numarasına göre filtrele
        fis_df = self.df[self.df['Yevmiye No'].astype(str) == str(fis_no)]
        return fis_df.to_dict('records')
