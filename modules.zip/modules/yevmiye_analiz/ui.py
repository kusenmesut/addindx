import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os
import pandas as pd
import sqlite3
import zipfile
import io
import tempfile
import shutil

# --- PATH AYARLARI ---
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
from config import CLR_BODY_BG, CLR_ACCENT, get_mukellefler_dir
from utils.session_db import get_last_session
from .engine import YevmiyeEngine
# --- MODÜL IMPORTLARI ---
# Fatura Görüntüleme Modülü
try:
    from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
except ImportError:
    FaturaGoruntulePopup = None

# Not Yönetimi ve Dashboard
try:
    from modules.not_yonetimi.db import upsert_note, get_single_note, get_active_risks_dict
    from modules.not_yonetimi.ui import NoteDashboard
    HAS_NOTES = True
except ImportError:
    HAS_NOTES = False

# --- TASARIM RENKLERİ ---
CLR_FIS_HEADER_BG = "#0F3057"
CLR_FIS_HEADER_FG = "#FFFFFF"
CLR_ROW_ODD = "#EAF2F8"
CLR_ROW_EVEN = "#FFFFFF"
FONT_MAIN = ("Arial", 9)
FONT_BOLD = ("Arial", 9, "bold")



# =============================================================================
# Kapatılabilir Sekmeler İçin Özel Notebook Sınıfı
# =============================================================================
class ClosableNotebook(ttk.Notebook):
    __initialized = False
    def __init__(self, *args, close_callback=None, close_all_callback=None, **kwargs):
        if not self.__initialized:
            self.__initialize_custom_style()
            ClosableNotebook.__initialized = True
        kwargs["style"] = "Closable.TNotebook"
        super().__init__(*args, **kwargs)
        self.close_callback = close_callback
        self.close_all_callback = close_all_callback
        self.bind("<ButtonPress-1>", self.on_close_press, "+")
        self.bind("<ButtonRelease-1>", self.on_close_release, "+")
        self.bind("<Button-3>", self.on_right_click, "+") 

    def __initialize_custom_style(self):
        style = ttk.Style()
        try:
            from PIL import Image, ImageTk
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            img = Image.open(os.path.join(base_dir, "kapat.ico")).resize((12, 12), Image.Resampling.LANCZOS)
            self.img_close = ImageTk.PhotoImage(img)
            self.img_closeactive = ImageTk.PhotoImage(img)    
            self.img_closepressed = ImageTk.PhotoImage(img)   
        except Exception:
            self.img_close = tk.PhotoImage(width=12, height=12)
            self.img_closeactive = tk.PhotoImage(width=12, height=12)
            self.img_closepressed = tk.PhotoImage(width=12, height=12)

        try:
            style.element_create("close", "image", self.img_close,
                                ("active", "pressed", "!disabled", self.img_closepressed),
                                ("active", "!disabled", self.img_closeactive), border=8, sticky='')
        except tk.TclError: pass 

        style.layout("Closable.TNotebook", [("Closable.client", {"sticky": "nswe"})])
        style.layout("Closable.TNotebook.Tab", [
            ("Closable.tab", {"sticky": "nswe", "children": [
                ("Closable.padding", {"side": "top", "sticky": "nswe", "children": [
                    ("Closable.focus", {"side": "top", "sticky": "nswe", "children": [
                        ("Closable.label", {"side": "left", "sticky": ""}),
                        ("Closable.close", {"side": "left", "sticky": ""}),
                    ]})
                ]})
            ]})
        ])
        
        style.configure("Closable.TNotebook", background=CLR_BODY_BG, borderwidth=0)
        style.configure("Closable.TNotebook.Tab", background="#E0E5F2", foreground="#A3AED0", padding=[15, 8], font=("DM Sans", 10, "bold"), borderwidth=0)
        style.map("Closable.TNotebook.Tab", background=[("selected", "#1B2559")], foreground=[("selected", "white")])

    def on_close_press(self, event):
        element = self.identify(event.x, event.y)
        if "close" in element:
            index = self.index(f"@{event.x},{event.y}")
            self.state(['pressed'])
            self._active = index

    def on_close_release(self, event):
        if not self.instate(['pressed']): return
        element = self.identify(event.x, event.y)
        index = self.index(f"@{event.x},{event.y}")
        if "close" in element and self._active == index:
            self._close_single(index)
        self.state(['!pressed'])
        self._active = None

    def on_right_click(self, event):
        try:
            index = self.index(f"@{event.x},{event.y}")
            menu = tk.Menu(self, tearoff=0)
            menu.add_command(label="❌ Kapat", command=lambda: self._close_single(index))
            menu.add_separator()
            menu.add_command(label="🗑️ Diğer Tümünü Kapat", command=self._close_all)
            menu.tk_popup(event.x_root, event.y_root)
        except tk.TclError: pass

    def _close_single(self, index):
        if self.close_callback: self.close_callback(index)
        else: self.forget(index)

    def _close_all(self):
        if self.close_all_callback: self.close_all_callback()
# --- NOT YÖNETİCİSİ (SAĞ TIK MENÜSÜ) ---
class NoteManager:
    def __init__(self, tree, table_name, master, indices=None, detail_callback=None):
        self.tree = tree
        self.table_name = table_name
        self.root = master
        self.detail_callback = detail_callback
        
        # Varsayılan indeksler (Ana liste için: Ref=2, Belge=3)
        default_indices = {'ref': 2, 'belge': 3, 'hk': 4, 'ha': 5, 'borc': 8, 'alacak': 9}
        
        if indices:
            self.idx = indices
        else:
            self.idx = default_indices

        # --- MENÜ OLUŞTURMA ---
        self.menu = tk.Menu(tree, tearoff=0)
        self.menu.add_command(label="📝 Not Ekle / Risk Ata", command=self.popup)
        
        if self.detail_callback:
            self.menu.add_separator()
            self.menu.add_command(label="📄 Fiş Detayını Göster", command=self.call_detail)
        
        # --- BELGE GÖSTER ---
        self.menu.add_separator()
        self.menu.add_command(label="🔎 Belge Göster (E-Fatura)", command=self.show_invoice_document)
        # --------------------

        self.menu.add_separator()
        self.menu.add_command(label="📊 Tüm Riskleri Göster (Panel)", command=self.open_dash)
        
        # SAĞ TIK BAĞLAMASI (Windows için Button-3, Mac için Button-2 olabilir)
        self.tree.bind("<Button-3>", self.show_menu)
        
        # Risk Renkleri
        self.tree.tag_configure("RISK_HIGH", background="#ff9999")
        self.tree.tag_configure("RISK_MID", background="#ffe599")
        self.tree.tag_configure("RISK_LOW", background="#d9ead3")
# --- YENİ EKLENECEK / GÜNCELLENECEK METODLAR ---



    def show_invoice_document(self):
        """Seçili satırdaki Belge No ile dosya yolunu bulur ve görüntüler."""
        if FaturaGoruntulePopup is None:
            messagebox.showerror("Hata", "Fatura görüntüleme modülü (ui_goruntule) yüklenemedi.")
            return

        sel = self.tree.selection()
        if not sel: return
        
        vals = self.tree.item(sel[0])['values']
        belge_idx = self.idx.get('belge', 3)

        try:
            belge_no = str(vals[belge_idx]).strip()
        except IndexError:
            messagebox.showerror("Hata", "Belge numarası sütunu okunamadı.")
            return

        if not belge_no or belge_no in ["-", "", "None", "0", "nan"]:
            messagebox.showwarning("Uyarı", "Geçerli bir Belge Numarası yok.")
            return

        # 1. Veritabanından dosya bilgilerini çek
        file_info = self.get_invoice_file_info(belge_no)

        if not file_info:
            messagebox.showinfo("Sonuç", f"'{belge_no}' numaralı belge arşivde bulunamadı.")
            return

        source_path = file_info.get('DOSYA_YOLU')
        dosya_adi = file_info.get('ZIP_ICI_AD') 
        # Eğer ZIP içi ad yoksa ve DOSYA sütunu varsa onu kullan
        if not dosya_adi: dosya_adi = file_info.get('DOSYA')

        if not source_path or not os.path.exists(source_path):
            messagebox.showwarning("Hata", f"Dosya diskte bulunamadı:\n{source_path}")
            return

        final_path = source_path
        
        # 2. ZIP İşlemleri
        if source_path.lower().endswith('.zip'):
            if not dosya_adi:
                messagebox.showerror("Hata", "Dosya ZIP formatında ama içindeki XML adı veritabanında yok.")
                return
                
            temp_dir = tempfile.gettempdir()
            extracted_path = self.find_and_extract_xml(source_path, dosya_adi, temp_dir)
            
            if extracted_path:
                final_path = extracted_path
            else:
                messagebox.showerror("Hata", f"ZIP içinde dosya bulunamadı:\n{dosya_adi}")
                return

        # 3. Görüntüleyiciyi Aç
        try:
            target_master = self.root.winfo_toplevel()
            FaturaGoruntulePopup(target_master, final_path)
        except Exception as e:
            messagebox.showerror("Hata", f"Görüntüleyici açılırken hata: {e}")



    def show_menu(self, event):
        # Tıklanan satırı seçili hale getir
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.menu.post(event.x_root, event.y_root)

    # =========================================================================
    # BELGE GÖSTER (E-FATURA) GÜNCEL VE TEK FONKSİYONU
    # =========================================================================
    def show_invoice_document(self):
        """
        Seçili satırdaki Belge No'yu alır, .0 uzantısını temizler, 
        veritabanından faturayı bulur ve UI_Goruntule modülüne fırlatır.
        """
        if FaturaGoruntulePopup is None:
            messagebox.showerror("Hata", "Fatura görüntüleme modülü (ui_goruntule) yüklenemedi.")
            return

        sel = self.tree.selection()
        if not sel: return
        
        vals = self.tree.item(sel[0])['values']
        belge_idx = self.idx.get('belge', 3)

        try:
            belge_no = str(vals[belge_idx]).strip()
        except IndexError:
            messagebox.showerror("Hata", "Belge numarası sütunu okunamadı.")
            return

        # SİHİRLİ DOKUNUŞ: Numaradaki .0 uzantısını temizle (Örn: BSR2022...191.0 -> BSR2022...191)
        if belge_no.endswith('.0'):
            belge_no = belge_no[:-2]

        if not belge_no or belge_no in ["-", "", "None", "0", "nan", "."]:
            messagebox.showwarning("Uyarı", "Bu satırda geçerli bir Belge Numarası bulunmuyor.")
            return

        # Veritabanından faturayı DataFrame olarak çek
        df_fatura = self.fetch_invoice_from_db(belge_no)

        if df_fatura is not None and not df_fatura.empty:
            try:
                target_master = self.root.winfo_toplevel()
                # Görüntüleyici artık DataFrame alıyor, dosya okuma/ZIP açma işini kendi halledecek
                FaturaGoruntulePopup(target_master, df_fatura)
            except Exception as e:
                messagebox.showerror("Hata", f"Görüntüleyici açılırken hata oluştu:\n{e}")
        else:
            messagebox.showinfo("Bulunamadı", f"'{belge_no}' numaralı belge E-Fatura arşivinde (Veritabanında) bulunamadı.")

    def fetch_invoice_from_db(self, fatura_no):
        """
        Dinamik Tablo ve Sütun tespiti yaparak veritabanından faturayı çeker.
        (50 Sütunluk yeni NO_FATURA ile Eski FATURA_NO sistemine tam uyumlu)
        """
        try:
            session = get_last_session()
            if not session or not session.get('vkn'): return None
            
            vkn = session.get('vkn')
            yil = session.get('yil')
            
            base_dir = get_mukellefler_dir()
            target_folder = None
            
            if os.path.exists(base_dir):
                for f in os.listdir(base_dir):
                    if f.endswith(f"-{vkn}") and os.path.isdir(os.path.join(base_dir, f)):
                        target_folder = os.path.join(base_dir, f)
                        break
            
            if not target_folder: return None

            db_path = os.path.join(target_folder, str(yil), f"fatura_data_{yil}.db")
            if not os.path.exists(db_path): return None

            conn = sqlite3.connect(db_path)
            
            # 1. Tablo adını veritabanından dinamik olarak bul
            c = conn.cursor()
            c.execute("SELECT name FROM sqlite_master WHERE type='table' LIMIT 1")
            res = c.fetchone()
            if not res:
                conn.close()
                return None
            
            tbl_name = res[0]
            
            # 2. Sütun adını kontrol et (Eski veri tabanlarında FATURA_NO, yeni 50'li yapıda NO_FATURA)
            df_limit1 = pd.read_sql(f"SELECT * FROM {tbl_name} LIMIT 1", conn)
            col_name = "NO_FATURA" if "NO_FATURA" in df_limit1.columns else "FATURA_NO"
            
            # 3. Gerçek Faturayı Çek
            query = f"SELECT * FROM {tbl_name} WHERE {col_name} = ?"
            df = pd.read_sql(query, conn, params=(fatura_no,))
            conn.close()
            
            return df

        except Exception as e:
            print(f"Fatura DB Sorgu Hatası: {e}")
            return None
    # =========================================================================

    def call_detail(self):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0])['values']
        try:
            ref_idx = self.idx.get('ref', 2)
            row_ref = str(vals[ref_idx])
            if self.detail_callback: self.detail_callback(row_ref)
        except: pass

    def popup(self):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0])['values']
        
        try:
            ref_idx = self.idx.get('ref', 0)
            row_ref = str(vals[ref_idx])
            
            hk_idx = self.idx.get('hk')
            h_kodu = str(vals[hk_idx]) if hk_idx is not None else ""
            
            ha_idx = self.idx.get('ha')
            h_adi = str(vals[ha_idx]) if ha_idx is not None else ""
            
            b_idx = self.idx.get('borc')
            borc = str(vals[b_idx]) if b_idx is not None else "0"
            
            a_idx = self.idx.get('alacak')
            alacak = str(vals[a_idx]) if a_idx is not None else "0"
        except:
            row_ref = "UNK"; h_kodu=""; h_adi=""; borc="0"; alacak="0"

        sess = get_last_session()
        vkn = sess.get('vkn', '000')
        note = get_single_note(vkn, self.table_name, row_ref)
        
        top = tk.Toplevel(self.root)
        top.title(f"Not Ekle: {row_ref}")
        top.geometry("450x500")
        
        tk.Label(top, text="Risk Seviyesi", font=("Arial",10,"bold")).pack(pady=5)
        cmb_risk = ttk.Combobox(top, values=["Yüksek", "Orta", "Düşük"], state="readonly")
        cmb_risk.pack(pady=5)
        cmb_risk.set(note['risk_level'] if note else "Düşük")
        
        tk.Label(top, text="Açıklama", font=("Arial",10,"bold")).pack(pady=5)
        t_desc = tk.Text(top, height=5, width=45); t_desc.pack(padx=10)
        if note: t_desc.insert("1.0", note['description'])
        
        tk.Label(top, text="Aksiyon", font=("Arial",10,"bold")).pack(pady=5)
        t_act = tk.Text(top, height=5, width=45); t_act.pack(padx=10)
        if note: t_act.insert("1.0", note['action_plan'])
        
        def save():
            d = {
                "vkn": vkn, "table_source": self.table_name, "row_ref": row_ref,
                "risk_level": cmb_risk.get(), "status": "Devam",
                "description": t_desc.get("1.0", "end").strip(),
                "action_plan": t_act.get("1.0", "end").strip(),
                "hesap_kodu": h_kodu, "hesap_adi": h_adi, "borc": borc, "alacak": alacak
            }
            upsert_note(d)
            cmap = {"Yüksek":"RISK_HIGH", "Orta":"RISK_MID", "Düşük":"RISK_LOW"}
            self.tree.item(sel[0], tags=(cmap[cmb_risk.get()],))
            top.destroy()
            
        tk.Button(top, text="KAYDET", bg="#2980b9", fg="white", command=save).pack(pady=20, fill=tk.X, padx=20)

    def open_dash(self):
        if NoteDashboard._instance is None or not NoteDashboard._instance.winfo_exists():
            app_ref = self.root
            while not hasattr(app_ref, 'open_module') and app_ref.master:
                app_ref = app_ref.master
            
            NoteDashboard._instance = NoteDashboard(app_ref)
        else:
            NoteDashboard._instance.lift()

    def color_rows(self):
        sess = get_last_session()
        vkn = sess.get('vkn')
        if not vkn: return
        active_risks = get_active_risks_dict(vkn, self.table_name)
        ref_idx = self.idx.get('ref', 2)
        
        for item in self.tree.get_children():
            vals = self.tree.item(item)['values']
            try: r = str(vals[ref_idx])
            except: continue
            
            curr = list(self.tree.item(item, "tags"))
            clean_tags = [t for t in curr if not t.startswith("RISK_")]
            
            if r in active_risks:
                risk = active_risks[r]
                cmap = {"Yüksek":"RISK_HIGH", "Orta":"RISK_MID", "Düşük":"RISK_LOW"}
                if risk in cmap: 
                    clean_tags.append(cmap[risk])
            
            self.tree.item(item, tags=tuple(clean_tags))

# --- ANA EKRAN (YEVMİYE ANALİZİ) ---
class YevmiyeAnalizFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.engine = YevmiyeEngine()
        self.setup_styles()
        self.setup_ui()
        self.refresh_data()
        self.load_hesap_kodu_combobox()

    def setup_styles(self):
        style = ttk.Style()
        try: style.theme_use("clam") 
        except: pass
        
        # --- MODERN NOTEBOOK (TAB) STİLİ (maliui renkleri) ---
        style.configure("Modern.TNotebook", background="#F8F9FC", borderwidth=0)
        style.configure("Modern.TNotebook.Tab",
                        background="#E0E5F2",      # Açık gri/mavi pasif sekme
                        foreground="#A3AED0",      # Pasif sekme yazı rengi
                        padding=[25, 8],
                        font=("DM Sans", 10, "bold"),
                        borderwidth=0)

        # SEÇİLİ (AKTİF) SEKME VURGUSU
        style.map("Modern.TNotebook.Tab",
                  background=[("selected", "#1B2559")], # Aktif sekme: MaliUI Lacivert
                  foreground=[("selected", "white")],   
                  expand=[("selected", [1, 1, 1, 0])])

        # --- ANA TABLO (Yevmiye) STİLİ ---
        style.configure("Pro.Treeview.Heading", 
                        font=("DM Sans", 10, "bold"), 
                        background="#1B2559",           # MaliUI Lacivert Header
                        foreground="white", 
                        relief="flat", 
                        borderwidth=0)
        style.configure("Pro.Treeview", 
                        font=("DM Sans", 10), 
                        background="white", 
                        fieldbackground="white", 
                        foreground="#2B3674",           # MaliUI Koyu Mavi Metin
                        rowheight=30, 
                        borderwidth=0)
        style.map("Pro.Treeview", 
                  background=[("selected", "#FF9F43")], # MaliUI Turuncu Seçim
                  foreground=[("selected", "white")])

        # --- FİŞ DETAY POPUP TABLO STİLİ ---
        style.configure("Fis.Treeview.Heading", 
                        font=("DM Sans", 10, "bold"), 
                        background="#1B2559", 
                        foreground="white", 
                        relief="flat", 
                        borderwidth=0)
        style.configure("Fis.Treeview", 
                        font=("DM Sans", 10), 
                        background="white", 
                        fieldbackground="white", 
                        foreground="#2B3674", 
                        rowheight=30, 
                        borderwidth=0)
        style.map("Fis.Treeview", 
                  background=[("selected", "#FF9F43")], 
                  foreground=[("selected", "white")])


    def setup_ui(self):
       
        stats_frame = tk.Frame(self, bg=CLR_BODY_BG)
        stats_frame.pack(fill=tk.X, padx=10, pady=10)
        self.card_borc = self.create_card(stats_frame, "TOPLAM BORÇ", "#c0392b")
        self.card_alacak = self.create_card(stats_frame, "TOPLAM ALACAK", "#27ae60")
        self.card_adet = self.create_card(stats_frame, "TOPLAM KAYIT", "#8e44ad")

        # =====================================================================
        # YENİ: AKORDİYON MANTIKLI ARAMA VE SÜZME PANELLERİ
        # =====================================================================
        self.is_arama_open = False
        self.is_suzme_open = False

        # --- 1. ARAMA GRUBU BAŞLIĞI VE İÇERİĞİ ---
        self.btn_toggle_arama = tk.Button(
            self, text="➕ GELİŞMİŞ ARAMA", 
            bg="#e2e8f0", fg="#334155", font=("Arial", 9, "bold"), bd=0, padx=10, pady=4,
            cursor="hand2", anchor="w", command=self.toggle_arama
        )
        self.btn_toggle_arama.pack(fill=tk.X, padx=10, pady=(8, 0))

        self.frame_arama = tk.Frame(self, bg="white", highlightbackground="#cbd5e1", highlightthickness=1)
        
        row_arama = tk.Frame(self.frame_arama, bg="white", padx=10, pady=8)
        row_arama.pack(fill=tk.X)

        tk.Label(row_arama, text="Aranacak Sütun:", bg="white", font=FONT_MAIN).pack(side=tk.LEFT, padx=(0, 2))
        self.cmb_col = ttk.Combobox(row_arama, values=["Tümü", "Fiş Açıklama", "Muavin Adı", "Hesap Adı", "Belge No", "Borç-Alacak"], state="readonly", width=12)
        self.cmb_col.set("Tümü")
        self.cmb_col.pack(side=tk.LEFT, padx=(0, 10))

        tk.Label(row_arama, text="İçeren Kelimeler:", bg="white", font=FONT_MAIN).pack(side=tk.LEFT, padx=(0, 2))
        self.ent_text = tk.Entry(row_arama, width=20, font=FONT_MAIN, bd=1, relief="solid")
        self.ent_text.pack(side=tk.LEFT, padx=(0, 5))

        self.var_logic = tk.StringVar(value="AND")
        tk.Radiobutton(row_arama, text="Ve (Hepsi)", variable=self.var_logic, value="AND", bg="white").pack(side=tk.LEFT)
        tk.Radiobutton(row_arama, text="Veya (Herhangi)", variable=self.var_logic, value="OR", bg="white").pack(side=tk.LEFT, padx=(0, 10))

        tk.Label(row_arama, text="Hariç Tut (Geçmeyen):", bg="white", font=FONT_MAIN).pack(side=tk.LEFT, padx=(0, 2))
        self.ent_exclude = tk.Entry(row_arama, width=15, font=FONT_MAIN, bd=1, relief="solid")
        self.ent_exclude.pack(side=tk.LEFT)

        tk.Button(row_arama, text="FİLTREYİ UYGULA", bg="#2980b9", fg="white", font=("Arial", 8, "bold"), command=self.apply_filter, padx=15).pack(side=tk.RIGHT, padx=5)


        # --- 2. VERİ SÜZME GRUBU BAŞLIĞI VE İÇERİĞİ ---
        self.btn_toggle_suzme = tk.Button(
            self, text="➕ VERİ SÜZME VE TARİH", 
            bg="#e2e8f0", fg="#334155", font=("Arial", 9, "bold"), bd=0, padx=10, pady=4,
            cursor="hand2", anchor="w", command=self.toggle_suzme
        )
        self.btn_toggle_suzme.pack(fill=tk.X, padx=10, pady=(5, 0))

        self.frame_suzme = tk.Frame(self, bg="white", highlightbackground="#cbd5e1", highlightthickness=1)
        
        row_suzme_1 = tk.Frame(self.frame_suzme, bg="white", padx=10, pady=5)
        row_suzme_1.pack(fill=tk.X)

        tk.Label(row_suzme_1, text="Ana Hesap:", bg="white", font=FONT_MAIN).pack(side=tk.LEFT, padx=(0, 2))
        self.cmb_ana_hesap = ttk.Combobox(row_suzme_1, state="readonly", width=25)
        self.cmb_ana_hesap.pack(side=tk.LEFT, padx=(0, 10))
        self.cmb_ana_hesap.bind("<<ComboboxSelected>>", self.on_ana_hesap_selected)

        tk.Label(row_suzme_1, text="Muavin Seç:", bg="white", font=FONT_MAIN).pack(side=tk.LEFT, padx=(0, 2))
        self.cmb_muavin = ttk.Combobox(row_suzme_1, state="readonly", width=30)
        self.cmb_muavin.pack(side=tk.LEFT, padx=(0, 10))

        tk.Label(row_suzme_1, text="Tutar:", bg="white", font=FONT_MAIN).pack(side=tk.LEFT, padx=(0, 2))
        self.ent_min = tk.Entry(row_suzme_1, width=10, bd=1, relief="solid")
        self.ent_min.pack(side=tk.LEFT)
        tk.Label(row_suzme_1, text="-", bg="white").pack(side=tk.LEFT, padx=1)
        self.ent_max = tk.Entry(row_suzme_1, width=10, bd=1, relief="solid")
        self.ent_max.pack(side=tk.LEFT)

        row_suzme_2 = tk.Frame(self.frame_suzme, bg="white", padx=10, pady=5)
        row_suzme_2.pack(fill=tk.X)

        try:
            from utils.session_db import get_last_session
            active_session = get_last_session()
            current_yil = str(active_session.get('yil', '')) if active_session and active_session.get('yil') else ""
        except:
            current_yil = ""

        tk.Label(row_suzme_2, text="Tarih:", bg="white", font=FONT_MAIN).pack(side=tk.LEFT, padx=(0, 2))
        self.ent_date_start = tk.Entry(row_suzme_2, width=10, bd=1, relief="solid")
        if current_yil: self.ent_date_start.insert(0, f"01.01.{current_yil}")
        self.ent_date_start.pack(side=tk.LEFT)
        
        tk.Label(row_suzme_2, text="-", bg="white").pack(side=tk.LEFT, padx=1)
        
        self.ent_date_end = tk.Entry(row_suzme_2, width=10, bd=1, relief="solid")
        if current_yil: self.ent_date_end.insert(0, f"31.12.{current_yil}")
        self.ent_date_end.pack(side=tk.LEFT, padx=(0, 10))

        tk.Label(row_suzme_2, text="Geçici Vergi Dönemi:", bg="white", font=FONT_MAIN, fg="gray").pack(side=tk.LEFT, padx=(0, 2))
        ttk.Button(row_suzme_2, text="1", command=lambda: self.set_dates("01.01", "31.03"), width=2).pack(side=tk.LEFT, padx=1)
        ttk.Button(row_suzme_2, text="2", command=lambda: self.set_dates("01.04", "30.06"), width=2).pack(side=tk.LEFT, padx=1)
        ttk.Button(row_suzme_2, text="3", command=lambda: self.set_dates("01.07", "30.09"), width=2).pack(side=tk.LEFT, padx=1)
        ttk.Button(row_suzme_2, text="4", command=lambda: self.set_dates("01.10", "31.12"), width=2).pack(side=tk.LEFT, padx=1)

        tk.Button(row_suzme_2, text="FİLTREYİ UYGULA", bg="#2980b9", fg="white", font=("Arial", 8, "bold"), command=self.apply_filter, padx=15).pack(side=tk.RIGHT, padx=5)

        self.ent_text.bind("<Return>", lambda e: self.apply_filter())

        # (Buradan sonra önceki adımda kurduğumuz "table_toolbar" kodu devam edecek...)

        # =====================================================================
        # YENİ: TABLO ARAÇ ÇUBUĞU (Sekmelerin Hemen Üstünde, Sağa Hizalı)
        # =====================================================================
        table_toolbar = tk.Frame(self, bg=CLR_BODY_BG)
        table_toolbar.pack(fill=tk.X, padx=10, pady=(15, 0))

        # 1. En Sağda Excel Butonu
        tk.Button(table_toolbar, text="💾 Excel'e Aktar", command=self.export_excel, 
                  bg="#27ae60", fg="white", font=FONT_BOLD, bd=0, padx=15, pady=4).pack(side=tk.RIGHT, padx=(10, 0))

        # 2. Onun Solunda Tek Sayfada Göster
        self.var_show_all = tk.BooleanVar()
        tk.Checkbutton(table_toolbar, text="Tek Sayfada Göster", variable=self.var_show_all, 
                       bg=CLR_BODY_BG, activebackground=CLR_BODY_BG, font=FONT_MAIN, 
                       command=self.toggle_show_all).pack(side=tk.RIGHT, padx=10)

        # 3. Onun Solunda Sütunları Yönet Butonu
        self.btn_columns = tk.Button(table_toolbar, text="⚙️ Sütunları Yönet ▼", 
                                     bg="#34495e", fg="white", font=FONT_BOLD, bd=0, padx=12, pady=4,
                                     activebackground="#2c3e50", activeforeground="white",
                                     command=self.show_column_menu)
        self.btn_columns.pack(side=tk.RIGHT, padx=5)

        # --- Sütun Gizle/Göster Menüsü Altyapısı ---
        cols = ("Sıra", "Tarih", "Yevmiye No", "Belge No", "Hesap Kodu", "Hesap Adı", "Muavin Kodu", "Muavin Adı", "Fiş Açıklama", "Detay Açıklama", "Borç", "Alacak")
        self.col_vars = {}
        self.column_menu = tk.Menu(self, tearoff=0, font=FONT_MAIN, bg="white", activebackground="#2980b9", activeforeground="white")
        
        for c in cols:
            var = tk.BooleanVar(value=True)
            self.col_vars[c] = var
            self.column_menu.add_checkbutton(label=f" {c}", variable=var, command=self.update_tree_columns)

        # =====================================================================
        # ANA TABLO VE SEKMELİ YAPI (NOTEBOOK)
        # =====================================================================
        self.tab_trees = {}
        self.tab_dataframes = {}
        self.note_managers = {}

        # Notebook'un üst boşluğunu(pady) kapattık ki toolbar ile bitişik dursun
        self.notebook = ClosableNotebook(self, close_callback=self.close_tab_by_index, close_all_callback=self.close_all_tabs)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=(2, 10))

        # İlk sekme (Ana Liste) - ESKİ TABLE CONTAINER YERİNE BURASI KULLANILIYOR
        table_container = tk.Frame(self.notebook, bg="white", bd=1, relief="solid")
        self.notebook.add(table_container, text="📌 Ana Liste (Tümü)")
        
        self.tree = ttk.Treeview(table_container, columns=cols, show="headings", style="Pro.Treeview")
        self.tab_trees[str(table_container)] = self.tree
        
        # Sütun Genişlikleri
        self.tree.column("Sıra", width=40, anchor="center")
        self.tree.column("Tarih", width=80, anchor="center")
        self.tree.column("Yevmiye No", width=70, anchor="center")
        self.tree.column("Belge No", width=80, anchor="center")
        self.tree.column("Hesap Kodu", width=80, anchor="w")
        self.tree.column("Hesap Adı", width=150, anchor="w")
        self.tree.column("Muavin Kodu", width=90, anchor="w")
        self.tree.column("Muavin Adı", width=150, anchor="w")
        self.tree.column("Fiş Açıklama", width=150, anchor="w")
        self.tree.column("Detay Açıklama", width=150, anchor="w")
        self.tree.column("Borç", width=90, anchor="e")
        self.tree.column("Alacak", width=90, anchor="e")
        
        for c in cols: 
            self.tree.heading(c, text=c, command=lambda _c=c: self.sort_column(_c))
        
        sb_y = ttk.Scrollbar(table_container, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb_y.set)
        self.tree.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        sb_y.pack(side=tk.RIGHT, fill=tk.Y, in_=self.tree)
        self.tree.bind("<Double-1>", self.on_double_click)


        bottom_bar = tk.Frame(self, bg="#ecf0f1", height=40)
        bottom_bar.pack(fill=tk.X, side=tk.BOTTOM)
        # ... (Sayfalama butonları aynı kalacak) ...

        if HAS_NOTES:
            # --- GÜNCELLEME: Araya 2 yeni sütun girdiği için borc ve alacak indeksleri 10 ve 11 oldu ---
            self.note_manager = NoteManager(self.tree, "YEVMİYE", self, 
                                            indices={'ref': 2, 'belge': 3, 'hk': 4, 'ha': 5, 'borc': 10, 'alacak': 11},
                                            detail_callback=self.open_fis_detail_popup)
        self.lbl_page_info = tk.Label(bottom_bar, text="...", bg="#ecf0f1")
        self.lbl_page_info.pack(side=tk.LEFT, padx=10)
        
        nav_center = tk.Frame(bottom_bar, bg="#ecf0f1"); nav_center.pack(side=tk.LEFT, expand=True)
        tk.Button(nav_center, text="<", command=lambda: self.navigate("prev"), width=3).pack(side=tk.LEFT)
        self.lbl_page_num = tk.Label(nav_center, text="1 / 1", bg="#ecf0f1", font=FONT_BOLD)
        self.lbl_page_num.pack(side=tk.LEFT, padx=10)
        tk.Button(nav_center, text=">", command=lambda: self.navigate("next"), width=3).pack(side=tk.LEFT)

        if HAS_NOTES:
            # NoteManager başlatılıyor.
            # Ana ekrandaki sütun indekslerini veriyoruz:
            self.note_manager = NoteManager(self.tree, "YEVMİYE", self, 
                                            indices={'ref': 2, 'belge': 3, 'hk': 4, 'ha': 5, 'borc': 8, 'alacak': 9},
                                            detail_callback=self.open_fis_detail_popup)



    def create_card(self, parent, title, color):
        f = tk.Frame(parent, bg="white", bd=1, relief="ridge")
        f.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        tk.Frame(f, bg=color, height=4).pack(fill=tk.X, side=tk.TOP)
        tk.Label(f, text=title, bg="white", fg="gray", font=("Arial", 8)).pack(anchor="w", padx=10, pady=(5,0))
        l = tk.Label(f, text="0", bg="white", font=("Arial", 12, "bold"))
        l.pack(anchor="w", padx=10, pady=(0,5))
        return l

    def close_tab_by_index(self, index):
        """Tıklanan sekmeyi kapatır. Ana sekme kapatılamaz."""
        if index == 0:
            messagebox.showwarning("Uyarı", "Ana liste (Tümü) sekmesi kapatılamaz.")
            return
        
        tab_id = self.notebook.tabs()[index]
        if tab_id in self.tab_trees: del self.tab_trees[tab_id]
        if tab_id in self.tab_dataframes: del self.tab_dataframes[tab_id]
        if tab_id in self.note_managers: del self.note_managers[tab_id]
        self.notebook.forget(tab_id)

    def close_all_tabs(self):
        """Ana sekme hariç tüm filtre sekmelerini kapatır."""
        tabs = list(self.notebook.tabs())
        for tab_id in tabs[1:]:
            if tab_id in self.tab_trees: del self.tab_trees[tab_id]
            if tab_id in self.tab_dataframes: del self.tab_dataframes[tab_id]
            if tab_id in self.note_managers: del self.note_managers[tab_id]
            self.notebook.forget(tab_id)

    def create_new_results_tab(self, title, df):
        """Filtreleme sonucu için yeni bir sekme (Tab) ve Treeview oluşturur."""
        tab_frame = tk.Frame(self.notebook, bg="white", bd=1, relief="solid")
        self.notebook.add(tab_frame, text=title)
        self.notebook.select(tab_frame) # Yeni açılan sekmeye odaklan
        
        self.tab_dataframes[str(tab_frame)] = df

        cols = ("Sıra", "Tarih", "Yevmiye No", "Belge No", "Hesap Kodu", "Hesap Adı", "Muavin Kodu", "Muavin Adı", "Fiş Açıklama", "Detay Açıklama", "Borç", "Alacak")
        new_tree = ttk.Treeview(tab_frame, columns=cols, show="headings", style="Pro.Treeview")
        self.tab_trees[str(tab_frame)] = new_tree
        
        # Sütun Genişlikleri
        new_tree.column("Sıra", width=40, anchor="center")
        new_tree.column("Tarih", width=80, anchor="center")
        new_tree.column("Yevmiye No", width=70, anchor="center")
        new_tree.column("Belge No", width=80, anchor="center")
        new_tree.column("Hesap Kodu", width=80, anchor="w")
        new_tree.column("Hesap Adı", width=150, anchor="w")
        new_tree.column("Muavin Kodu", width=90, anchor="w")
        new_tree.column("Muavin Adı", width=150, anchor="w")
        new_tree.column("Fiş Açıklama", width=150, anchor="w")
        new_tree.column("Detay Açıklama", width=150, anchor="w")
        new_tree.column("Borç", width=90, anchor="e")
        new_tree.column("Alacak", width=90, anchor="e")
        
        for c in cols: new_tree.heading(c, text=c)
            
        sb_y = ttk.Scrollbar(tab_frame, orient="vertical", command=new_tree.yview)
        new_tree.configure(yscrollcommand=sb_y.set)
        new_tree.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        sb_y.pack(side=tk.RIGHT, fill=tk.Y, in_=new_tree)

        # Yeni tabloya çift tıklama (Detay Göster) bağlaması
        new_tree.bind("<Double-1>", lambda e, t=new_tree: self.on_dynamic_double_click(e, t))

        # Sağ Tık Not ve Fatura Menüsünü Yeni Sekmeye Bağla
        if HAS_NOTES:
            nm = NoteManager(new_tree, "YEVMİYE", self, 
                            indices={'ref': 2, 'belge': 3, 'hk': 4, 'ha': 5, 'borc': 10, 'alacak': 11},
                            detail_callback=self.open_fis_detail_popup)
            self.note_managers[str(tab_frame)] = nm

        # Verileri Doldur
        for i, row in df.iterrows():
            tag = "even" if i % 2 == 0 else "odd"
            m_kod = row.get("Muavin Kodu", "")
            m_adi = row.get("Muavin Adı", "")
            vals = (i + 1, row.get("Tarih"), int(row.get("Yevmiye No",0)), row.get("Belge No"),
                    row.get("Hesap Kodu"), row.get("Hesap Adı"), m_kod, m_adi, 
                    row.get("Fiş Açıklama"), row.get("Detay Açıklama"),
                    f"{float(row.get('Borç',0)):,.2f}", f"{float(row.get('Alacak',0)):,.2f}")
            new_tree.insert("", "end", values=vals, tags=(tag,))
            
        # (create_new_results_tab metodunun en son satırları...)        
        new_tree.tag_configure("odd", background="#F8F9FC")
        new_tree.tag_configure("even", background="white")
        
        # YENİ EKLENEN/KONTROL EDİLEN KISIM: 
        # Yeni tablo ekrana çizilmeden hemen önce mevcut sütun ayarlarını bu sekmeye de giydir:
        self.update_tree_columns()

    def on_dynamic_double_click(self, event, tree_widget):
        """Yeni sekmelerdeki tablolara çift tıklandığında popup açar."""
        sel = tree_widget.selection()
        if not sel: return
        fis_no = tree_widget.item(sel[0])['values'][2]
        self.open_fis_detail_popup(fis_no=fis_no)

    def refresh_data(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        data = self.engine.get_page_data()
        start = (self.engine.current_page - 1) * self.engine.items_per_page
        for i, row in enumerate(data):
            tag = "even" if i % 2 == 0 else "odd"
            
            m_kod = row.get("Muavin Kodu", "")
            m_adi = row.get("Muavin Adı", "")
            
            vals = (start + i + 1, row.get("Tarih"), int(row.get("Yevmiye No",0)), row.get("Belge No"),
                    row.get("Hesap Kodu"), row.get("Hesap Adı"), 
                    m_kod, m_adi, 
                    row.get("Fiş Açıklama"), row.get("Detay Açıklama"),
                    f"{float(row.get('Borç',0)):,.2f}", f"{float(row.get('Alacak',0)):,.2f}")
            self.tree.insert("", "end", values=vals, tags=(tag,))
            
        # --- GÜNCELLENEN KISIM: maliui zebra satır renkleri ---
        self.tree.tag_configure("odd", background="#F8F9FC")
        self.tree.tag_configure("even", background="white")
        
        stats = self.engine.get_stats()
        self.card_borc.config(text=f"{stats['toplam_borc']:,.2f}")
        self.card_alacak.config(text=f"{stats['toplam_alacak']:,.2f}")
        self.card_adet.config(text=f"{stats['toplam_kayit']}")
        self.lbl_page_num.config(text=f"{self.engine.current_page} / {self.engine.total_pages}")
        if HAS_NOTES and hasattr(self, 'note_manager'): self.note_manager.color_rows()

    def load_hesap_kodu_combobox(self):
        """Veri yüklendiğinde Ana Hesap Combobox'ını 'KOD - AD' formatında doldurur"""
        if hasattr(self, 'cmb_ana_hesap') and not self.engine.df.empty:
            df = self.engine.df
            if 'Hesap Kodu' in df.columns and 'Hesap Adı' in df.columns:
                hesaplar_dict = {}
                
                # Sadece benzersiz Ana Hesap Kodu ve Adı ikililerini al
                for _, row in df[['Hesap Kodu', 'Hesap Adı']].drop_duplicates().iterrows():
                    kod = str(row['Hesap Kodu']).strip()
                    adi = str(row['Hesap Adı']).strip()
                    
                    # Geçersiz (nan, boş) verileri atla
                    if kod and kod.lower() != 'nan' and kod != 'None':
                        hesaplar_dict[kod] = f"{kod} - {adi}"
                
                # Kod sırasına göre diz ve listeye ekle
                sirali_hesaplar = [hesaplar_dict[k] for k in sorted(hesaplar_dict.keys())]
                self.cmb_ana_hesap['values'] = ["Tümü"] + sirali_hesaplar
                self.cmb_ana_hesap.set("Tümü")

    def on_ana_hesap_selected(self, event):
        """Ana hesap seçildiğinde ona bağlı muavinleri 'KOD - AD' formatında listeler"""
        secim = self.cmb_ana_hesap.get()
        if secim == "Tümü" or self.engine.df.empty:
            self.cmb_muavin['values'] = []
            self.cmb_muavin.set("")
            return

        # "100 - KASA" string'inden sadece "100" kısmını kopar
        secilen_hesap_kodu = secim.split(" - ")[0].strip()
        
        df = self.engine.df
        # Sadece seçilen ana hesaba ait satırları süz
        hesap_df = df[df['Hesap Kodu'].astype(str).str.strip() == secilen_hesap_kodu]
        
        muavinler_dict = {}
        if 'Muavin Kodu' in hesap_df.columns and 'Muavin Adı' in hesap_df.columns:
            for _, row in hesap_df[['Muavin Kodu', 'Muavin Adı']].drop_duplicates().iterrows():
                m_kod = str(row['Muavin Kodu']).strip()
                m_adi = str(row['Muavin Adı']).strip()
                
                if m_kod and m_kod.lower() != 'nan' and m_kod != 'None':
                    muavinler_dict[m_kod] = f"{m_kod} - {m_adi}"
        
        # Muavinleri de kod sırasına göre diz
        sirali_muavinler = [muavinler_dict[k] for k in sorted(muavinler_dict.keys())]
        self.cmb_muavin['values'] = ["Tümü"] + sirali_muavinler
        self.cmb_muavin.set("Tümü")

    def set_dates(self, start_day_month, end_day_month):
        """Seçilen dönemin tarihlerini SADECE aktif inceleme yılına göre ayarlar."""
        try:
            from utils.session_db import get_last_session
            session = get_last_session()
            yil = str(session.get('yil', '')) if session and session.get('yil') else ""
        except:
            yil = ""

        self.ent_date_start.delete(0, tk.END)
        self.ent_date_end.delete(0, tk.END)

        if yil:
            self.ent_date_start.insert(0, f"{start_day_month}.{yil}")
            self.ent_date_end.insert(0, f"{end_day_month}.{yil}")
        else:
            from tkinter import messagebox
            messagebox.showwarning("Uyarı", "Aktif bir inceleme dönemi (yılı) bulunamadı. Lütfen mükellef seçin.")




    def toggle_arama(self):
        # Süzme panelini otomatik kapatan mantık kaldırıldı. Paneller bağımsız.
        if getattr(self, 'is_arama_open', False):
            self.frame_arama.pack_forget()
            self.btn_toggle_arama.config(text="➕ GELİŞMİŞ ARAMA", bg="#e2e8f0")
            self.is_arama_open = False
        else:
            self.frame_arama.pack(fill=tk.X, padx=10, after=self.btn_toggle_arama)
            self.btn_toggle_arama.config(text="➖ GELİŞMİŞ ARAMA", bg="#cbd5e1")
            self.is_arama_open = True

    def toggle_suzme(self):
        # Arama panelini otomatik kapatan mantık kaldırıldı.
        if getattr(self, 'is_suzme_open', False):
            self.frame_suzme.pack_forget()
            self.btn_toggle_suzme.config(text="➕ VERİ SÜZME VE TARİH", bg="#e2e8f0")
            self.is_suzme_open = False
        else:
            self.frame_suzme.pack(fill=tk.X, padx=10, after=self.btn_toggle_suzme)
            self.btn_toggle_suzme.config(text="➖ VERİ SÜZME VE TARİH", bg="#cbd5e1")
            self.is_suzme_open = True



    def apply_filter(self):
        try:
            # 1. KULLANICININ GİRDİĞİ DEĞERLERİ HAFIZAYA AL
            ana_hesap_secim = self.cmb_ana_hesap.get() or "Tümü"
            muavin_secim = self.cmb_muavin.get() or "Tümü"
            col_secim = self.cmb_col.get() or "Tümü"
            text_secim = self.ent_text.get().strip()
            logic_secim = self.var_logic.get()
            exclude_secim = self.ent_exclude.get().strip()
            min_val = self.ent_min.get()
            max_val = self.ent_max.get()
            d_start = self.ent_date_start.get().strip()
            d_end = self.ent_date_end.get().strip()
            
            # 2. OTOMATİK TEMİZLİK
            self.cmb_col.set("Tümü")
            self.ent_text.delete(0, tk.END)
            self.ent_exclude.delete(0, tk.END)
            self.ent_min.delete(0, tk.END)
            self.ent_max.delete(0, tk.END)
            self.cmb_ana_hesap.set("Tümü")
            
            if hasattr(self, 'cmb_muavin'):
                self.cmb_muavin.set("")
                self.cmb_muavin['values'] = []
                
            # Tarihleri ilgili yıla döndür
            try:
                from utils.session_db import get_last_session
                active_session = get_last_session()
                current_yil = str(active_session.get('yil', '')) if active_session and active_session.get('yil') else ""
                if current_yil:
                    self.ent_date_start.delete(0, tk.END)
                    self.ent_date_start.insert(0, f"01.01.{current_yil}")
                    self.ent_date_end.delete(0, tk.END)
                    self.ent_date_end.insert(0, f"31.12.{current_yil}")
            except:
                pass

            # 3. İŞLEM BİTİNCE PANELLERİ BAĞIMSIZ KAPAT
            if getattr(self, 'is_arama_open', False):
                self.toggle_arama()
            if getattr(self, 'is_suzme_open', False):
                self.toggle_suzme()

            # 4. FİLTRE KRİTERLERİNİ (CRITERIA) GÜVENLİ OLUŞTUR
            hk_kodu = ana_hesap_secim.split(" - ")[0].strip() if ana_hesap_secim != "Tümü" else "Tümü"
            mk_kodu = muavin_secim.split(" - ")[0].strip() if muavin_secim not in ["", "Tümü"] else "Tümü"

            criteria = {
                'target_col': col_secim,
                'text': text_secim,
                'logic': logic_secim,
                'exclude': exclude_secim,
                'min_tutar': float(min_val) if min_val else None,
                'max_tutar': float(max_val) if max_val else None,
                'date_start': d_start,
                'date_end': d_end,
                'hesap_kodu': hk_kodu,
                'muavin_kodu': mk_kodu
            }

            # 5. MOTOR ÜZERİNDEN VERİYİ FİLTRELE
            self.engine.filter_data(criteria)
            filtered_df = self.engine.filtered_df.copy()

            # 6. SONUÇ YOKSA KONTROLÜ
            if filtered_df.empty:
                from tkinter import messagebox
                messagebox.showinfo("Sonuç Yok", "Bu filtrelere uygun kayıt bulunamadı.")
                self.engine.filtered_df = self.engine.df.copy()
                self.refresh_data()
                return

            # 7. YENİ SEKMEYİ OLUŞTUR
            search_text = criteria['text'] if criteria['text'] else ("Hesap: " + hk_kodu if hk_kodu != "Tümü" else "Detaylı Süzme")
            tab_title = f"🔍 {search_text} ({len(filtered_df)} Kayıt)"
            
            self.create_new_results_tab(tab_title, filtered_df)

            # 8. ANA LİSTEYİ GERİ DÖNDÜR
            self.engine.filtered_df = self.engine.df.copy()
            self.engine.current_page = 1
            self.engine.calculate_total_pages()
            self.refresh_data()

        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror("Filtre Hatası", f"Lütfen girdiğiniz verileri kontrol edin.\n{e}")

    def clear_filters(self):
        # --- HAYAT BELİRTİSİ TESTİ ---
        
        # -----------------------------
        
        print("\n--- TEMİZLE İŞLEMİ BAŞLADI ---")
        # ... (fonksiyonun geri kalan kodları aynı kalsın) ...
        
        try:
            # 1. ARAMA SEKMESİNİ TEMİZLE
            self.cmb_col.set("Tümü")
            self.ent_text.delete(0, tk.END)
            self.ent_exclude.delete(0, tk.END)
            self.var_logic.set("AND")
            self.ent_min.delete(0, tk.END)
            self.ent_max.delete(0, tk.END)
            print("ADIM 1 BAŞARILI: Arama kutuları temizlendi.")
        except Exception as e:
            print(f"HATA ADIM 1 (Arama Kutuları): {e}")

        try:
            # 2. TARİH KUTULARINI OTURUM YILINA GÖRE SIFIRLA
            try:
                from utils.session_db import get_last_session
                active_session = get_last_session()
                current_yil = str(active_session.get('yil', '')) if active_session and active_session.get('yil') else ""
            except:
                current_yil = ""
                
            self.ent_date_start.delete(0, tk.END)
            self.ent_date_end.delete(0, tk.END)
            
            if current_yil:
                self.ent_date_start.insert(0, f"01.01.{current_yil}")
                self.ent_date_end.insert(0, f"31.12.{current_yil}")
                
            print("ADIM 2 BAŞARILI: Tarih kutuları yıla göre sıfırlandı.")
        except Exception as e:
            print(f"HATA ADIM 2 (Tarihler): {e}")

        try:
            # 3. HESAP / MUAVİN SEÇİMLERİNİ SIFIRLA
            if hasattr(self, 'cmb_ana_hesap'):
                self.cmb_ana_hesap.set("Tümü")
            if hasattr(self, 'cmb_muavin'):
                self.cmb_muavin.set("")
                self.cmb_muavin['values'] = []
            print("ADIM 3 BAŞARILI: Hesap planı sıfırlandı.")
        except Exception as e:
            print(f"HATA ADIM 3 (Hesap Planı): {e}")

        try:
            # 4. SAYFALAMA AYARINI SIFIRLA
            self.var_show_all.set(False)
            self.engine.toggle_show_all(False)
            print("ADIM 4 BAŞARILI: Sayfalama sıfırlandı.")
        except Exception as e:
            print(f"HATA ADIM 4 (Sayfalama): {e}")

        try:
            # 5. MOTORU SIFIRLA VE TABLOYU YENİLE
            if not self.engine.df.empty:
                self.engine.filtered_df = self.engine.df.copy()
                self.engine.current_page = 1
                self.engine.calculate_total_pages()
            
            self.refresh_data()
            print("ADIM 5 BAŞARILI: Motor sıfırlandı ve tablo çizildi.")
            print("--- TEMİZLE İŞLEMİ KUSURSUZ TAMAMLANDI ---\n")
        except Exception as e:
            print(f"HATA ADIM 5 (Motor/Tablo Yenileme): {e}")

    def toggle_show_all(self): self.engine.toggle_show_all(self.var_show_all.get()); self.refresh_data()

    def show_column_menu(self):
        """Sütun seçim menüsünü butonun hemen altında dinamik olarak açar."""
        # Butonun ekrandaki mutlak X ve Y koordinatlarını hesapla
        x = self.btn_columns.winfo_rootx()
        y = self.btn_columns.winfo_rooty() + self.btn_columns.winfo_height()
        
        # Menüyü tam butonun altında konumlandırarak göster
        self.column_menu.post(x, y)


    def update_tree_columns(self):
        """Sütun seçim menüsü işaretlendiğinde açık olan tüm sekmelerdeki tabloları anında eşitler."""
        # 1. Hangi sütunların görünür (True) olduğunu tespit et
        visible_cols = [c for c in self.col_vars if self.col_vars[c].get()]
        
        # 2. Kayıtlı olan TÜM sekmelerdeki tablolara (Treeview) bu görünümü uygula
        for tab_id, tree in self.tab_trees.items():
            try:
                tree["displaycolumns"] = visible_cols
            except Exception as e:
                print(f"Sütun güncelleme hatası: {e}")
    
    
    
    def sort_column(self, col): self.engine.sort_data(col); self.refresh_data()
    
    def navigate(self, d): self.engine.change_page(d); self.refresh_data()
    
    def on_double_click(self, event): self.open_fis_detail_popup()

# YevmiyeAnalizFrame sınıfı içindeki metod:
    

    def export_excel(self):
        """Aktif sekmeye göre akıllı Excel aktarım yöneticisi."""
        # Aktif sekmenin ID'sini ve Index'ini bul
        active_tab_id = self.notebook.select()
        active_index = self.notebook.index(active_tab_id)

        # 1. EĞER YENİ AÇILMIŞ BİR FİLTRE SEKMESİNDEYSE (Ana Liste değilse)
        if active_index != 0:
            df_to_export = self.tab_dataframes.get(active_tab_id)
            if df_to_export is None or df_to_export.empty:
                messagebox.showwarning("Uyarı", "Aktarılacak veri bulunamadı.")
                return

            from tkinter import filedialog
            tab_name = self.notebook.tab(active_tab_id, "text").replace("🔍 ", "").split(" (")[0]
            default_name = f"Filtre_{tab_name}.xlsx".replace(" ", "_")
            
            filepath = filedialog.asksaveasfilename(defaultextension=".xlsx", initialfile=default_name, filetypes=[("Excel Dosyaları", "*.xlsx")])
            if not filepath: return
            
            self.master.config(cursor="watch")
            self.update_idletasks()
            try:
                # Doğrudan sekmenin hafızasındaki veriyi dışarı basıyoruz
                df_to_export.to_excel(filepath, index=False)
                messagebox.showinfo("Başarılı", f"Veriler '{filepath}' konumuna aktarıldı.")
            except Exception as e:
                messagebox.showerror("Hata", f"Dışa aktarma hatası: {e}")
            finally:
                self.master.config(cursor="")
            return

        # 2. EĞER ANA LİSTEDEYSE (Eski orijinal Popup'lı indirme sistemi devreye girer)
        if self.engine.df.empty:
            messagebox.showwarning("Uyarı", "Sistemde aktarılacak bir Yevmiye verisi yok.")
            return

        popup = tk.Toplevel(self)
        popup.title("Excel İndirme Seçenekleri")
        popup.geometry("450x300")
        popup.configure(bg="white")
        popup.resizable(False, False)
        popup.transient(self)
        popup.grab_set()

        tk.Label(popup, text="📊 Excel Dışa Aktarma Aracı", font=("Arial", 14, "bold"), bg="white", fg="#2980b9").pack(pady=(20, 10))
        tk.Label(popup, text="Lütfen indirmek istediğiniz veri kapsamını seçin:", bg="white", font=FONT_MAIN).pack(pady=(0, 15))

        def do_export(export_type):
            popup.destroy() 
            prefix = "Suzulen_Kayitlar" if export_type == "filtered" else "Tum_Defter"
            default_name = f"Yevmiye_{prefix}.xlsx"
            
            from tkinter import filedialog
            filepath = filedialog.asksaveasfilename(defaultextension=".xlsx", initialfile=default_name, filetypes=[("Excel Dosyaları", "*.xlsx")])
            if not filepath: return 

            self.master.config(cursor="watch")
            self.update_idletasks()
            success, msg = self.engine.export_excel(export_type=export_type, filepath=filepath)
            self.master.config(cursor="")

            if success: messagebox.showinfo("İşlem Başarılı", msg)
            else: messagebox.showerror("Dışa Aktarma Hatası", msg)

        btn_frame = tk.Frame(popup, bg="white")
        btn_frame.pack(fill=tk.BOTH, expand=True, padx=30)

        kayit_sayisi = len(self.engine.filtered_df)
        tk.Button(btn_frame, text=f"🔍 Sadece Süzülenleri İndir\n(Motor Hafızasındaki {kayit_sayisi} Kayıt)", bg="#2980b9", fg="white", font=("Arial", 10, "bold"), height=2, bd=0, command=lambda: do_export("filtered")).pack(fill=tk.X, pady=5)
        tk.Button(btn_frame, text=f"📁 Tüm Defteri İndir\n(Veritabanındaki Tüm Ham Veri)", bg="#27ae60", fg="white", font=("Arial", 10, "bold"), height=2, bd=0, command=lambda: do_export("all")).pack(fill=tk.X, pady=5)
        tk.Button(btn_frame, text="Vazgeç", bg="#95a5a6", fg="white", font=("Arial", 10), bd=0, height=1, command=popup.destroy).pack(fill=tk.X, pady=(15, 0))
    
    
    def focus_on_record(self, search_term):
        """
        KESİN ÇÖZÜM: Arayüz gecikmesini bypass ederek doğrudan
        Engine (Motor) üzerinden filtreleme yapar.
        """
        try:
            # 1. Arama Terimini Hazırla
            term = str(search_term).strip()
            
            # 2. Veri Güvenliği Kontrolü (Veri yoksa yükle)
            if self.engine.df.empty:
                self.engine.load_data()

            # 3. DOĞRUDAN FİLTRELEME (UI'dan okuma yapma, emri direkt ver)
            # Entry kutusundaki değeri beklemeden motoru tetikliyoruz.
            criteria = {
                'text': term,
                'min_tutar': None,
                'max_tutar': None
            }
            self.engine.filter_data(criteria)
            
            # 4. Sayfalama Ayarı (Tek sayfada göster)
            # Önce veriyi süzdük, şimdi "hepsini göster" diyerek sayfalamayı ayarlıyoruz.
            self.var_show_all.set(False)
            self.engine.toggle_show_all(False)
            
            # 5. Arayüz Kutularını Güncelle (Sadece görsel amaçlı)
            # Kullanıcı ne arandığını görsün diye sonradan yazıyoruz.
            self.ent_text.delete(0, tk.END)
            self.ent_text.insert(0, term)
            self.ent_min.delete(0, tk.END)
            self.ent_max.delete(0, tk.END)
            
            # 6. Tabloyu Çiz
            self.refresh_data()
            
            # 7. Sonuç Varsa Odaklan ve Seç
            # Tkinter'ın çizim yapması için ufak bir nefes aldırıyoruz
            self.update_idletasks()
            
            children = self.tree.get_children()
            if children:
                target_item = children[0]
                self.tree.selection_set(target_item)
                self.tree.focus(target_item)
                self.tree.see(target_item)
            else:
                # Bulunamadıysa sessiz kal veya log bas
                print(f"DEBUG: '{term}' arandı ama yevmiyede bulunamadı.")
                
        except Exception as e:
            messagebox.showerror("Arama Hatası", f"Fiş aranırken hata oluştu:\n{str(e)}")
    # --- YENİ EKLENEN KÖPRÜ FONKSİYONU ---
    def show_fis_popup_by_doc_no(self, belge_no):
        """
        Dışarıdan (Fatura Listesinden) çağrılır.
        Verilen Belge Numarasını (Fatura No) arar,
        bulursa Fiş Detay Penceresini açar.
        """
        try:
            # 1. Veri Yüklü mü Kontrol Et, Değilse Yükle
            if self.engine.df.empty:
                self.engine.load_data()
                
            if self.engine.df.empty:
                messagebox.showwarning("Uyarı", "Yevmiye verisi yüklenemedi.")
                return

            # 2. Belge Numarasına Göre Fiş Numarasını Bul
            # Pandas ile Belge No sütununda arama yapıyoruz
            # Not: Veri tiplerini string'e çevirerek karşılaştırıyoruz
            
            # Belge No sütunundaki boşlukları temizle ve string yap
            df_search = self.engine.df.copy()
            df_search['Belge No'] = df_search['Belge No'].astype(str).str.strip()
            
            # Aranan belgeyi de temizle
            target_doc = str(belge_no).strip()
            
            # Eşleşen satırları bul
            match = df_search[df_search['Belge No'] == target_doc]

            if match.empty:
                # Tam eşleşme yoksa, "Fiş Açıklaması" içinde ara (Opsiyonel ama faydalı)
                mask_desc = df_search['Fiş Açıklama'].astype(str).str.contains(target_doc, na=False)
                match = df_search[mask_desc]

            if match.empty:
                messagebox.showinfo("Sonuç", f"'{target_doc}' numaralı belge Yevmiye Defterinde bulunamadı.\n(Muhasebeleşmemiş olabilir)")
                return

            # 3. İlk eşleşen kaydın 'Yevmiye No'sunu al
            # Birden fazla satır olabilir, hepsi aynı fişe aittir genelde.
            found_fis_no = match.iloc[0]['Yevmiye No']

            # 4. Mevcut Popup Fonksiyonunu Çağır
            self.open_fis_detail_popup(fis_no=found_fis_no)

        except Exception as e:
            messagebox.showerror("Hata", f"Fiş aranırken hata oluştu:\n{e}")
    
    # --- FİŞ DETAY POPUP (MUAVİN EKLENMİŞ, SCROLLLU VE TEK PENCERE KONTROLLÜ HALİ) ---
    def open_fis_detail_popup(self, fis_no=None):
        # 1- BİRDEN FAZLA PENCERE AÇILMASINI ENGELLEME
        # Eğer daha önce açılmış ve hala hayatta olan bir detay penceresi varsa, onu kapat
        if hasattr(self, '_fis_popup') and self._fis_popup.winfo_exists():
            self._fis_popup.destroy()

        if not fis_no:
            sel = self.tree.selection()
            if not sel: return
            fis_no = self.tree.item(sel[0])['values'][2]

        items = self.engine.get_rows_by_fis_no(fis_no)
        if not items:
            messagebox.showwarning("Uyarı", "Kayıt bulunamadı.")
            return

        # Pencereyi oluştur ve referansını sınıfa kaydet (_fis_popup)
        popup = tk.Toplevel(self)
        self._fis_popup = popup 
        
        popup.title(f"Fiş İnceleme - No: {fis_no}")
        popup.geometry("1300x650") 
        popup.configure(bg="white")
        
        # --- POP-UP BAŞLIK KISMINI GÜNCELLE ---
        head = tk.Frame(popup, bg="#1B2559", height=60) # CLR_FIS_HEADER_BG yerine MaliUI Header rengi
        head.pack(fill=tk.X); head.pack_propagate(False)
        tk.Label(head, text=f"FİŞ NO: {fis_no}", bg="#1B2559", fg="white", font=("DM Sans", 16, "bold")).pack(side=tk.LEFT, padx=20)
        tk.Label(head, text=f"TARİH: {items[0].get('Tarih','-')}", bg="#1B2559", fg="white", font=("DM Sans", 14, "bold")).pack(side=tk.RIGHT, padx=20)
        
        cols = ("Ref", "HesapKodu", "HesapAdı", "MuavinKodu", "MuavinAdı", "BelgeNo", "FisAciklama", "DetayAciklama", "Borc", "Alacak")
        
        # 2- İKİ YÖNLÜ SCROLL İÇİN CONTAINER (TAŞIYICI) OLUŞTURMA
        tree_container = tk.Frame(popup, bg="white")
        tree_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        tree = ttk.Treeview(tree_container, columns=cols, show="headings", style="Fis.Treeview")
        tree.column("Ref", width=0, stretch=False)
        
        tree.column("HesapKodu", width=80); tree.heading("HesapKodu", text="Hesap Kodu")
        tree.column("HesapAdı", width=150); tree.heading("HesapAdı", text="Hesap Adı")
        
        tree.column("MuavinKodu", width=90); tree.heading("MuavinKodu", text="Muavin Kodu")
        tree.column("MuavinAdı", width=180); tree.heading("MuavinAdı", text="Muavin Adı")
        
        tree.column("BelgeNo", width=90, anchor="center"); tree.heading("BelgeNo", text="Belge No")
        tree.column("FisAciklama", width=180); tree.heading("FisAciklama", text="Fiş Açıklama")
        tree.column("DetayAciklama", width=180); tree.heading("DetayAciklama", text="Detay Açıklama")
        tree.column("Borc", width=90, anchor="e"); tree.heading("Borc", text="Borç")
        tree.column("Alacak", width=90, anchor="e"); tree.heading("Alacak", text="Alacak")
        
        # Scrollbar Tanımlamaları (Dikey ve Yatay)
        vsb = ttk.Scrollbar(tree_container, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(tree_container, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Grid Sistemi ile Container İçine Yerleştirme
        tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        # Container'ın esnemesi için grid yapılandırması
        tree_container.grid_columnconfigure(0, weight=1)
        tree_container.grid_rowconfigure(0, weight=1)
        
        t_b, t_a = 0.0, 0.0
        for i, it in enumerate(items):
            tag = "even" if i % 2 == 0 else "odd"
            b = float(it.get('Borç', 0)); a = float(it.get('Alacak', 0))
            t_b += b; t_a += a
            
            vals = (
                fis_no, 
                it.get('Hesap Kodu', ''), 
                it.get('Hesap Adı', ''),
                it.get('Muavin Kodu', ''), 
                it.get('Muavin Adı', ''),  
                it.get('Belge No', ''), 
                it.get('Fiş Açıklama', ''), 
                it.get('Detay Açıklama', ''), 
                f"{b:,.2f}", 
                f"{a:,.2f}"
            )
            tree.insert("", "end", values=vals, tags=(tag,))
            
        # --- GÜNCELLENEN KISIM: Pop-up zebra satır renkleri ---
        tree.tag_configure("odd", background="#F8F9FC")
        tree.tag_configure("even", background="white")
        
        # --- POPUP İÇİN NOT YÖNETİCİSİ ---
        if HAS_NOTES:
            popup_indices = {
                'ref': 0,
                'hk': 1, 
                'ha': 2,
                'belge': 5, 
                'borc': 8,  
                'alacak': 9 
            }
            popup_notes = NoteManager(tree, "YEVMİYE", popup, indices=popup_indices)
            popup_notes.color_rows()

        # Alt Toplamlar
        foot = tk.Frame(popup, bg="#f8f9fa", height=50, bd=1, relief="solid")
        foot.pack(fill=tk.X, side=tk.BOTTOM)
        
        lbl_s = {"font":("Arial", 11, "bold"), "bg":"#f8f9fa"}
        tk.Label(foot, text=f"TOPLAM BORÇ: {t_b:,.2f}", fg="#c0392b", **lbl_s).pack(side=tk.LEFT, padx=20, pady=15)
        tk.Label(foot, text=f"TOPLAM ALACAK: {t_a:,.2f}", fg="#27ae60", **lbl_s).pack(side=tk.LEFT, padx=20)
        
        diff = t_b - t_a
        d_txt = f"✅ FİŞ DENGEDE" if abs(diff) < 0.01 else f"⚠️ BAKİYE FARKI: {diff:,.2f}"
        d_clr = "green" if abs(diff) < 0.01 else "red"
        tk.Label(foot, text=d_txt, fg=d_clr, font=("Arial", 12, "bold"), bg="#f8f9fa").pack(side=tk.RIGHT, padx=30)

# ui.py dosyasına eklenecek (Dosyanın uygun bir yerine)

