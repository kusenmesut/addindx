import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys

# Yolu ayarla (Veritabanı ve Config erişimi için)
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from db import init_db, upsert_note, get_notes_by_filter, update_status, get_single_note, get_active_risks_dict

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
from utils.session_db import get_last_session



# --- RENKLER ---
CLR_ORANGE_BTN = "#ED7D31"
CLR_BLUE_BTN = "#4472C4"
CLR_RED_BTN = "#C00000"
CLR_FORM_HEADER = "#5B9BD5" 
CLR_FORM_BG = "#DDEBF7"     
CLR_WHITE = "#FFFFFF"

class NoteDashboard(tk.Toplevel):
    _instance = None
    def __init__(self, master_app, target_vkn=None, target_unvan=None):
        super().__init__(master_app)
        self.master_app = master_app
        self.title("Risk ve Not Yönetim Paneli")
        self.geometry("1400x750")
        
        # --- GÜNCELLEME: Dışarıdan parametre geldiyse onu kullan, yoksa session'ı kullan ---
        sess = get_last_session()
        self.vkn = target_vkn if target_vkn else sess.get('vkn', '000')
        self.unvan = target_unvan if target_unvan else sess.get('unvan', 'Seçili Mükellef Yok')
        self.yil = sess.get('yil', '---')
        # ----------------------------------------------------------------------------------
        
        self.current_note = None
        self.active_tab_key = "ongoing"
        
        self.setup_ui()
        self.switch_tab("ongoing")
        
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def on_close(self):
        NoteDashboard._instance = None
        self.destroy()

    def setup_ui(self):

        # --- YENİ EKLENEN: MÜKELLEF VE DÖNEM BİLGİ BANDI ---
        info_header = tk.Frame(self, bg="#f8f9fa", pady=10, bd=1, relief="ridge")
        info_header.pack(fill=tk.X, padx=10, pady=(10, 0))
        
        # Ünvan (Büyük ve Belirgin)
        tk.Label(info_header, text=f"🏢 {self.unvan}", 
                 font=("Segoe UI", 14, "bold"), bg="#f8f9fa", fg="#2c3e50").pack()
        
        # VKN ve Dönem (Alt bilgi)
        tk.Label(info_header, text=f"🆔 VKN: {self.vkn}    |    📅 Dönem: {self.yil}", 
                 font=("Segoe UI", 11), bg="#f8f9fa", fg="#7f8c8d").pack()
        # -------------------------------------------------
        
        # --- ÜST BUTONLAR ---
        top_frame = tk.Frame(self, bg=CLR_WHITE, height=45)
        top_frame.pack(fill=tk.X, pady=(10,0), padx=10)
        
        self.btn_ongoing = tk.Button(top_frame, text="DEVAM EDEN NOTLAR", bg=CLR_ORANGE_BTN, fg="white", font=("Arial", 11, "bold"), relief="flat", padx=20, pady=8, command=lambda: self.switch_tab("ongoing"))
        self.btn_ongoing.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))
        
        self.btn_completed = tk.Button(top_frame, text="TAMAMLANANLAR", bg=CLR_BLUE_BTN, fg="white", font=("Arial", 11, "bold"), relief="flat", padx=20, pady=8, command=lambda: self.switch_tab("completed"))
        self.btn_completed.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
        
        self.btn_all = tk.Button(top_frame, text="TÜM NOTLAR", bg=CLR_RED_BTN, fg="white", font=("Arial", 11, "bold"), relief="flat", padx=20, pady=8, command=lambda: self.switch_tab("all"))
        self.btn_all.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2, 0))


        # --- YENİ EKLENEN: PDF RAPOR BUTONU ---
        self.btn_export = tk.Button(top_frame, text="📥 PDF RAPORLA", bg="#8e44ad", fg="white", font=("Arial", 11, "bold"), relief="flat", padx=20, pady=8, command=self.export_colorful_report)
        self.btn_export.pack(side=tk.RIGHT, fill=tk.X, padx=(20, 0))


        # --- ANA PANEL (SPLIT VIEW) ---
        main_pane = tk.PanedWindow(self, orient=tk.HORIZONTAL, bg="#cccccc", sashwidth=5)
        main_pane.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # SOL TARAFA LİSTE
        self.left_frame = tk.Frame(main_pane, bg="white")
        main_pane.add(self.left_frame, width=900)

        cols = ("ID", "Risk", "Kaynak", "Ref", "Hesap Kodu", "Hesap Adı", "Açıklama", "Eklenme", "Tamamlanma")
        self.tree = ttk.Treeview(self.left_frame, columns=cols, show="headings", selectmode="browse")
        
        self.tree.column("ID", width=0, stretch=False)
        self.tree.column("Risk", width=80, anchor="center")
        self.tree.column("Kaynak", width=100, anchor="center")
        self.tree.column("Ref", width=80, anchor="center")
        self.tree.column("Hesap Kodu", width=80, anchor="w")
        self.tree.column("Hesap Adı", width=150, anchor="w")
        self.tree.column("Açıklama", width=250, anchor="w")
        self.tree.column("Eklenme", width=120, anchor="center")
        self.tree.column("Tamamlanma", width=120, anchor="center")
        
        for c in cols: self.tree.heading(c, text=c)

        sb = ttk.Scrollbar(self.left_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Double-1>", self.on_double_click)
        
        self.tree.tag_configure("R_HIGH", background="#ffadad")
        self.tree.tag_configure("R_MID", background="#ffd6a5")
        self.tree.tag_configure("R_LOW", background="#caffbf")
        self.tree.tag_configure("R_DONE", background="#e0e0e0", foreground="#555")

        # SAĞ TARAFA FORM
        self.right_frame = tk.Frame(main_pane, bg="white", bd=1, relief="solid")
        main_pane.add(self.right_frame)

        tk.Label(self.right_frame, text="DETAY VE DÜZENLEME", bg="white", font=("Arial", 12, "bold")).pack(pady=10)

        lbl_risk = tk.Label(self.right_frame, text="RİSK DURUMU SEÇİNİZ", bg=CLR_FORM_HEADER, fg="white", font=("Arial", 10, "bold"), pady=5)
        lbl_risk.pack(fill=tk.X, padx=10, pady=(5, 0))
        self.cmb_risk = ttk.Combobox(self.right_frame, values=["Yüksek", "Orta", "Düşük"], state="readonly", font=("Arial", 11))
        self.cmb_risk.pack(fill=tk.X, padx=10, pady=(0, 10))
        self.cmb_risk.set("Düşük")

        lbl_desc = tk.Label(self.right_frame, text="RİSK AÇIKLAMASI", bg=CLR_FORM_HEADER, fg="white", font=("Arial", 10, "bold"), pady=5)
        lbl_desc.pack(fill=tk.X, padx=10, pady=(5, 0))
        self.txt_desc = tk.Text(self.right_frame, height=6, bg=CLR_FORM_BG, font=("Arial", 10), bd=0)
        self.txt_desc.pack(fill=tk.X, padx=10, pady=(0, 10))

        lbl_act = tk.Label(self.right_frame, text="YAPILACAK İŞLEMLER", bg=CLR_FORM_HEADER, fg="white", font=("Arial", 10, "bold"), pady=5)
        lbl_act.pack(fill=tk.X, padx=10, pady=(5, 0))
        self.txt_action = tk.Text(self.right_frame, height=6, bg=CLR_FORM_BG, font=("Arial", 10), bd=0)
        self.txt_action.pack(fill=tk.X, padx=10, pady=(0, 10))

        btn_box = tk.Frame(self.right_frame, bg="white")
        btn_box.pack(fill=tk.X, padx=10, pady=20)
        
        # KAYDET/GÜNCELLE BUTONU
        self.btn_save = tk.Button(btn_box, text="💾 KAYDET (GÜNCELLE)", bg="#7f8c8d", fg="white", font=("Arial", 10, "bold"), height=2, command=self.save_current_note)
        self.btn_save.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)

        self.btn_complete = tk.Button(btn_box, text="✓ GÖREVİ TAMAMLA", bg="#27ae60", fg="white", font=("Arial", 10, "bold"), height=2, command=self.complete_task)
        self.btn_complete.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=2)
        
        tk.Label(self.right_frame, text="KAYNAĞA GİTMEK İÇİN SATIRA ÇİFT TIKLAYIN.", bg="#fff3cd", fg="black", font=("Arial", 9, "bold")).pack(side=tk.BOTTOM, fill=tk.X)

    def switch_tab(self, tab_key):
        self.active_tab_key = tab_key
        self.load_data(tab_key)

    def load_data(self, tab_key):
        for i in self.tree.get_children(): self.tree.delete(i)
        
        filter_map = {
            "ongoing": "ONGOING",
            "completed": "COMPLETED",
            "all": "ALL"
        }
        
        data = get_notes_by_filter(self.vkn, status_filter=filter_map.get(tab_key, "ALL"))
        
        for n in data:
            tag = "R_LOW"
            if str(n.get('status')) == "Tamamlandı": tag = "R_DONE"
            elif n['risk_level'] == "Yüksek": tag = "R_HIGH"
            elif n['risk_level'] == "Orta": tag = "R_MID"
            
            created = str(n.get('created_at', ''))[:16]
            completed = str(n.get('completed_at', ''))[:16] if n.get('completed_at') else "-"
            
            vals = (
                n['id'], 
                n['risk_level'], 
                n['table_source'], 
                n['row_ref'], 
                n['hesap_kodu'], 
                n['hesap_adi'], 
                n['description'], 
                created, 
                completed
            )
            self.tree.insert("", "end", values=vals, tags=(tag,))


    def export_colorful_report(self):
        """Tüm notları çeker, durumlarına göre ana gruplara ayırır, modüllere göre alt gruplar ve renkli bir HTML raporu oluşturarak tarayıcıda açar."""
        import webbrowser
        import tempfile
        import os
        from datetime import datetime
        
        # Tüm notları veritabanından çek
        notes = get_notes_by_filter(self.vkn, status_filter="ALL")
        
        if not notes:
            messagebox.showinfo("Bilgi", "Bu mükellefe ait raporlanacak bir not bulunamadı.")
            return

        # 1. Ana Gruplama (Durum: Devam / Tamamlandı) ve Alt Gruplama (Modül)
        grouped_by_status = {
            "Devam Eden İşlemler": {},
            "Tamamlanan İşlemler": {}
        }
        
        devam_count = 0
        tamam_count = 0

        for n in notes:
            status = str(n.get('status', 'Devam'))
            src = str(n.get('table_source', 'GENEL')).upper()
            
            # Duruma göre ana başlığı belirle
            if status == "Tamamlandı":
                main_key = "Tamamlanan İşlemler"
                tamam_count += 1
            else:
                main_key = "Devam Eden İşlemler"
                devam_count += 1
                
            # Alt grubu (modülü) oluştur ve notu ekle
            if src not in grouped_by_status[main_key]:
                grouped_by_status[main_key][src] = []
            grouped_by_status[main_key][src].append(n)

        # HTML Şablonunu ve CSS Tasarımını Hazırla
        now_str = datetime.now().strftime("%d.%m.%Y %H:%M")
        html_content = f"""
        <!DOCTYPE html>
        <html lang="tr">
        <head>
            <meta charset="UTF-8">
            <title>{self.unvan} - Risk Raporu</title>
            <style>
                body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f4f6f9; color: #333; padding: 30px; line-height: 1.6; }}
                .report-header {{ text-align: center; background: #2c3e50; color: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }}
                .report-header h1 {{ margin: 0; font-size: 24px; }}
                .report-header p {{ margin: 5px 0 0 0; font-size: 14px; color: #bdc3c7; }}
                
                /* Ana Grup Başlıkları */
                .main-group-title {{ background: #2980b9; color: white; padding: 15px 20px; font-size: 20px; font-weight: bold; margin-top: 40px; margin-bottom: 20px; border-radius: 8px; text-transform: uppercase; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
                .main-group-title.tamamlandi {{ background: #27ae60; }}
                
                .group-container {{ margin-bottom: 30px; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.05); border: 1px solid #e1e8ed; }}
                .group-title {{ background: #34495e; color: white; padding: 10px 20px; font-size: 16px; font-weight: bold; margin: 0; }}
                
                table {{ width: 100%; border-collapse: collapse; }}
                th {{ background: #ecf0f1; color: #7f8c8d; padding: 12px 15px; text-align: left; font-size: 13px; text-transform: uppercase; }}
                td {{ padding: 12px 15px; border-top: 1px solid #ecf0f1; font-size: 14px; }}
                
                /* Renk Kodlamaları */
                .row-Yüksek {{ background-color: #ffeaa7; }}
                .row-Yüksek td.risk-col {{ color: #d35400; font-weight: bold; }}
                .row-Orta {{ background-color: #fdf2e9; }}
                .row-Orta td.risk-col {{ color: #e67e22; font-weight: bold; }}
                .row-Düşük {{ background-color: #e8f8f5; }}
                .row-Düşük td.risk-col {{ color: #16a085; font-weight: bold; }}
                
                .status-Tamamlandı {{ text-decoration: line-through; color: #95a5a6; background-color: #f9f9f9; }}
                .status-badge {{ display: inline-block; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; }}
                .badge-Devam {{ background: #3498db; color: white; }}
                .badge-Tamamlandı {{ background: #27ae60; color: white; }}
                
                @media print {{
                    body {{ background: white; padding: 0; }}
                    .main-group-title, .group-container {{ box-shadow: none; border: 1px solid #ccc; page-break-inside: avoid; }}
                    .btn-print {{ display: none; }}
                }}
                .btn-print {{ display: block; width: 200px; margin: 0 auto 20px auto; text-align: center; background: #e74c3c; color: white; padding: 10px; text-decoration: none; border-radius: 5px; font-weight: bold; cursor: pointer; }}
            </style>
        </head>
        <body>
            <div class="btn-print" onclick="window.print()">🖨️ PDF OLARAK KAYDET / YAZDIR</div>
            
            <div class="report-header">
                <h1>{self.unvan}</h1>
                <p>Mali Denetim Risk Raporu | VKN: {self.vkn} | Dönem: {self.yil} | Çıktı Tarihi: {now_str}</p>
                <p style="margin-top: 10px; font-weight: bold; color: white;">Toplam: {devam_count} Devam Eden, {tamam_count} Tamamlanan Not</p>
            </div>
        """

        # Ana grupları (Devam / Tamamlandı) sırayla HTML'e ekle
        for main_status, modules in grouped_by_status.items():
            # Eğer bu ana grupta hiç kayıt yoksa, başlığını oluşturma (Örn: Tamamlanan hiç not yoksa o kısmı gizler)
            if not modules:
                continue 
                
            title_class = "main-group-title"
            if main_status == "Tamamlanan İşlemler":
                title_class += " tamamlandi"
                icon = "✅"
            else:
                icon = "⏳"

            html_content += f"""
            <div class="{title_class}">{icon} {main_status}</div>
            """

            # O ana grubun içindeki modül bazlı tabloları ekle
            for group_name, items in modules.items():
                html_content += f"""
                <div class="group-container">
                    <div class="group-title">📂 Kaynak: {group_name} ({len(items)} Kayıt)</div>
                    <table>
                        <thead>
                            <tr>
                                <th>Ref/Belge No</th>
                                <th>Hesap Kodu</th>
                                <th>Risk</th>
                                <th>Açıklama</th>
                                <th>Aksiyon Planı</th>
                                <th>Durum</th>
                            </tr>
                        </thead>
                        <tbody>
                """
                
                for item in items:
                    risk = item.get('risk_level', 'Düşük')
                    status = item.get('status', 'Devam')
                    
                    row_class = f"row-{risk}" if status != 'Tamamlandı' else "status-Tamamlandı"
                    
                    html_content += f"""
                            <tr class="{row_class}">
                                <td><b>{item.get('row_ref', '-')}</b></td>
                                <td>{item.get('hesap_kodu', '-')}</td>
                                <td class="risk-col">{risk}</td>
                                <td>{item.get('description', '-')}</td>
                                <td>{item.get('action_plan', '-')}</td>
                                <td><span class="status-badge badge-{status}">{status}</span></td>
                            </tr>
                    """
                    
                html_content += """
                        </tbody>
                    </table>
                </div>
                """

        html_content += """
        </body>
        </html>
        """

        # Geçici bir HTML dosyasına kaydet ve tarayıcıda aç
        try:
            fd, path = tempfile.mkstemp(suffix=".html", prefix="Risk_Raporu_")
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            webbrowser.open('file://' + os.path.realpath(path))
            
        except Exception as e:
            messagebox.showerror("Hata", f"Rapor oluşturulurken bir hata meydana geldi:\n{str(e)}")


    def on_select(self, event):
        sel = self.tree.selection()
        if not sel: return
        
        vals = self.tree.item(sel[0])['values']
        
        status = "Tamamlandı" if vals[8] != "-" else "Devam"
        self.current_note = {
            "id": vals[0], 
            "status": status, 
            "row_ref": vals[3], 
            "table_source": vals[2]
        }
        
        self.cmb_risk.set(vals[1])
        self.txt_desc.delete("1.0", tk.END)
        self.txt_desc.insert("1.0", str(vals[6]))
        
        # Tam veriyi veritabanından çek
        full_note = get_single_note(self.vkn, vals[2], vals[3])
        self.txt_action.delete("1.0", tk.END)
        if full_note:
            self.txt_action.insert("1.0", full_note.get('action_plan', ''))
            
        # --- GÜNCELLEME: Buton her şartta (Tamamlanmış olsa bile) aktif ---
        self.btn_complete.config(state="normal", bg="#27ae60", text="✓ GÖREVİ TAMAMLA")

    def save_current_note(self):
        """Panel üzerinden notu günceller"""
        if not self.current_note:
            messagebox.showwarning("Uyarı", "Lütfen listeden bir not seçiniz.")
            return

        full_data = get_single_note(self.vkn, self.current_note['table_source'], self.current_note['row_ref'])
        if not full_data:
            messagebox.showerror("Hata", "Orijinal kayıt bulunamadı.")
            return

        # --- GÜNCELLEME: Ana uygulamaya (master_app) bakma, bu panelin ünvanını kullan ---
        full_data['unvan'] = self.unvan
        # -------------------------------------------------------------------------------

        full_data['risk_level'] = self.cmb_risk.get()
        full_data['description'] = self.txt_desc.get("1.0", "end-1c").strip()
        full_data['action_plan'] = self.txt_action.get("1.0", "end-1c").strip()
        
        try:
            upsert_note(full_data)
            messagebox.showinfo("Başarılı", "Not ve risk durumu güncellendi.")
            self.load_data(self.active_tab_key)
        except Exception as e:
            messagebox.showerror("Hata", f"Güncelleme hatası: {str(e)}")

    def complete_task(self):
        if not self.current_note: return
        
        if messagebox.askyesno("Onay", "Bu görevi tamamlandı olarak işaretlemek istiyor musunuz?"):
            update_status(self.current_note['id'], "Tamamlandı")
            self.load_data(self.active_tab_key)
            self.current_note = None
            self.txt_desc.delete("1.0", tk.END)
            self.txt_action.delete("1.0", tk.END)


    def fetch_fis_details(self, fis_no):
        import os
        import pandas as pd
        
        try:
            from config import get_mukellefler_dir
            base_dir = get_mukellefler_dir()
        except ImportError:
            return [] # Konfigürasyon bulunamazsa boş dön

        target_folder = None
        if os.path.exists(base_dir):
            for f in os.listdir(base_dir):
                if f.endswith(f"-{self.vkn}"):
                    target_folder = os.path.join(base_dir, f)
                    break
                    
        if not target_folder: return []
        
        # Dinamik yıla göre klasör ve dosya yolunu oluştur
        parquet_path = os.path.join(target_folder, str(self.yil), f"{self.yil}_FULL.parquet")
        if not os.path.exists(parquet_path): return []
        
        try:
            # Yevmiye verilerini oku
            df = pd.read_parquet(parquet_path)
            col_name = "YevmiyeNo" if "YevmiyeNo" in df.columns else ("Yevmiye No" if "Yevmiye No" in df.columns else None)
            if not col_name: return []
            
            # Seçili yevmiye numarasına ait satırları filtrele
            fis_df = df[df[col_name].astype(str).str.strip() == str(fis_no).strip()]
            return fis_df.to_dict('records')
        except Exception as e:
            print(f"Fiş detay okuma hatası: {e}")
            return []

    def open_fis_detail_popup(self, fis_no):
        from tkinter import filedialog
        import pandas as pd
        
        # 1- BİRDEN FAZLA PENCERE AÇILMASINI ENGELLEME
        if hasattr(self, '_fis_popup') and self._fis_popup.winfo_exists():
            self._fis_popup.destroy()

        items = self.fetch_fis_details(fis_no)
        if not items:
            messagebox.showinfo("Bilgi", "Fiş detayı bulunamadı veya veritabanında okunamadı.")
            return

        popup = tk.Toplevel(self)
        self._fis_popup = popup
        
        popup.title(f"Fiş İnceleme - No: {fis_no}")
        popup.geometry("1200x650")
        popup.configure(bg="white")
        
        # --- TASARIM RENKLERİ ---
        HEADER_BG = "#0b2b40"
        TEXT_WHITE = "white"
        
        # 1. BAŞLIK ALANI
        date_str = str(items[0].get('KayitTarihi', '-')) if items else "-"
        # Datetime formatı gelirse temizleyelim
        if len(date_str) > 10: date_str = date_str[:10]
        
        header_frame = tk.Frame(popup, bg=HEADER_BG, height=60)
        header_frame.pack(fill="x")
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text=f"FİŞ NO: {fis_no}", bg=HEADER_BG, fg=TEXT_WHITE, 
                 font=("Segoe UI", 16, "bold")).pack(side="left", padx=20)
        
        tk.Label(header_frame, text=f"TARİH: {date_str}", bg=HEADER_BG, fg=TEXT_WHITE, 
                 font=("Segoe UI", 14, "bold")).pack(side="right", padx=20)

        # --- ARAÇ ÇUBUĞU ---
        toolbar_frame = tk.Frame(popup, bg="#ecf0f1", height=40)
        toolbar_frame.pack(fill="x")
        toolbar_frame.pack_propagate(False)

        def _export_excel():
            if not items: return
            try:
                df_exp = pd.DataFrame(items)
                col_map = {
                    'HesapKodu': 'Hesap Kodu', 'HesapAdi': 'Hesap Adı', 'BelgeNo': 'Belge No',
                    'FisAciklamasi': 'Fiş Açıklama', 'DetayAciklama': 'Detay Açıklama',
                    'Borc': 'Borç', 'Alacak': 'Alacak'
                }
                existing_keys = [k for k in col_map.keys() if k in df_exp.columns]
                df_exp = df_exp[existing_keys].rename(columns=col_map)
                
                path = filedialog.asksaveasfilename(
                    parent=popup,
                    defaultextension=".xlsx", 
                    filetypes=[("Excel Dosyası", "*.xlsx")],
                    title=f"Fiş_{fis_no}_Detay"
                )
                if path:
                    df_exp.to_excel(path, index=False)
                    messagebox.showinfo("Başarılı", "Excel dosyası başarıyla kaydedildi.", parent=popup)
            except Exception as e:
                messagebox.showerror("Hata", str(e), parent=popup)

        tk.Button(toolbar_frame, text="📥 Excel İndir", bg="#27ae60", fg="white", 
                  font=("Segoe UI", 9, "bold"), relief="flat", padx=10, 
                  command=_export_excel).pack(side="right", padx=10, pady=5)

        tk.Label(toolbar_frame, text="💡 İpucu: Satırları kopyalamak için tabloya sağ tıklayınız.", 
                 bg="#ecf0f1", fg="#7f8c8d", font=("Segoe UI", 8)).pack(side="left", padx=20)

        # 2. TABLO ALANI
        cols = ("HesapKodu", "HesapAdı", "BelgeNo", "FisAciklama", "DetayAciklama", "Borc", "Alacak")
        
        tree_frame = tk.Frame(popup, bg="white")
        tree_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        style = ttk.Style()
        style.configure("FisDetay.Treeview", rowheight=25, font=('Segoe UI', 9))
        style.configure("FisDetay.Treeview.Heading", font=('Segoe UI', 9, 'bold'))
        
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", style="FisDetay.Treeview", selectmode="extended")
        
        ysb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        
        tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        tree.heading("HesapKodu", text="Hesap Kodu");      tree.column("HesapKodu", width=100, anchor="w")
        tree.heading("HesapAdı", text="Hesap Adı");        tree.column("HesapAdı", width=200, anchor="w")
        tree.heading("BelgeNo", text="Belge No");          tree.column("BelgeNo", width=100, anchor="w")
        tree.heading("FisAciklama", text="Fiş Açıklama");  tree.column("FisAciklama", width=200, anchor="w")
        tree.heading("DetayAciklama", text="Detay Açıklama"); tree.column("DetayAciklama", width=200, anchor="w")
        tree.heading("Borc", text="Borç");                 tree.column("Borc", width=120, anchor="e")
        tree.heading("Alacak", text="Alacak");             tree.column("Alacak", width=120, anchor="e")

        tree.tag_configure('odd', background='#f1f8ff')
        tree.tag_configure('even', background='white')

        # Sağ Tık Menüsü
        context_menu = tk.Menu(tree, tearoff=0)
        
        def _copy_selection():
            selection = tree.selection()
            if not selection: return
            res = ""
            for item in selection:
                vals = tree.item(item)['values']
                res += "\t".join([str(v) for v in vals]) + "\n"
            popup.clipboard_clear()
            popup.clipboard_append(res)
            
        def _copy_all():
            res = "\t".join([tree.heading(c)['text'] for c in cols]) + "\n"
            for child in tree.get_children():
                vals = tree.item(child)['values']
                res += "\t".join([str(v) for v in vals]) + "\n"
            popup.clipboard_clear()
            popup.clipboard_append(res)

        context_menu.add_command(label="Seçili Satırları Kopyala", command=_copy_selection)
        context_menu.add_command(label="Tüm Tabloyu Kopyala", command=_copy_all)

        def _on_right_click(event):
            try: context_menu.post(event.x_root, event.y_root)
            except: pass
            
        tree.bind("<Button-3>", _on_right_click)
        if popup.tk.call('tk', 'windowingsystem') == 'aqua': tree.bind("<Button-2>", _on_right_click)

        # 3. VERİ DOLDURMA
        total_borc = 0.0
        total_alacak = 0.0
        
        for i, it in enumerate(items):
            try: b = float(it.get('Borc', 0))
            except: b = 0.0
            try: a = float(it.get('Alacak', 0))
            except: a = 0.0
            
            total_borc += b
            total_alacak += a
            
            # Kuruş hanesini iki basamakta sabitliyoruz
            fmt_borc = f"{b:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
            fmt_alacak = f"{a:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
            
            vals = (
                it.get('HesapKodu', ''), 
                it.get('HesapAdi', ''), 
                it.get('BelgeNo', ''), 
                it.get('FisAciklamasi', ''), 
                it.get('DetayAciklama', ''), 
                fmt_borc, 
                fmt_alacak
            )
            
            tag = 'odd' if i % 2 == 0 else 'even'
            tree.insert("", "end", values=vals, tags=(tag,))
            
        # 4. ALT BİLGİ (TOPLAMLAR)
        footer_frame = tk.Frame(popup, bg="white", height=50)
        footer_frame.pack(fill="x", side="bottom")
        tk.Frame(footer_frame, bg="#bdc3c7", height=1).pack(fill="x", side="top")
        
        diff = abs(total_borc - total_alacak)
        is_balanced = diff < 0.01
        
        status_text = "✅ FİŞ DENGEDE" if is_balanced else "❌ DENGESİZ"
        status_bg = "#27ae60" if is_balanced else "#c0392b"
        
        t_borc_fmt = f"{total_borc:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        t_alacak_fmt = f"{total_alacak:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        
        lbl_borc = tk.Label(footer_frame, text=f"TOPLAM BORÇ: {t_borc_fmt}", fg="#c0392b", bg="white", font=("Segoe UI", 11, "bold"))
        lbl_borc.pack(side="left", padx=20, pady=15)
        
        lbl_alacak = tk.Label(footer_frame, text=f"TOPLAM ALACAK: {t_alacak_fmt}", fg="#27ae60", bg="white", font=("Segoe UI", 11, "bold"))
        lbl_alacak.pack(side="left", padx=20, pady=15)
        
        lbl_status = tk.Label(footer_frame, text=status_text, fg="white", bg=status_bg, font=("Segoe UI", 10, "bold"), padx=10, pady=5)
        lbl_status.pack(side="right", padx=20, pady=10)
    
    def on_double_click(self, event):
        """
        Çift tıklama ile ilgili modülü açar ve satıra odaklanır (Go-To).
        Kaynak YEVMİYE ise doğrudan Fiş Detayı Popup'ını açar.
        """
        if not self.current_note: return
        
        # Ana uygulamanın (üst barın) o anki aktif VKN'sini al
        aktif_vkn = getattr(self.master_app, 'vkn', '---')
        
        # Eğer panelin VKN'si ile ana uygulamanın VKN'si eşleşmiyorsa işlemi durdur ve uyar
        if self.vkn != aktif_vkn:
            messagebox.showwarning(
                "Mükellef Uyuşmazlığı", 
                f"Bu fişin/kaydın detayına gitmek için öncelikle '{self.unvan}' firmasını ana menüden aktif mükellef olarak seçmelisiniz.\n\n"
                f"Şu anki aktif mükellef VKN: {aktif_vkn}"
            )
            return
            
        # 1. HEDEF BİLGİLERİNİ AL
        target_ref = str(self.current_note['row_ref'])
        table_source = str(self.current_note['table_source']).upper().strip()
        
        # --- YENİ EKLENEN: YEVMİYE İSE FİŞ DETAYINI AÇ ---
        if "YEVMİYE" in table_source or "YEVMIYE" in table_source:
            self.open_fis_detail_popup(target_ref)
            return
        
        # --- DİĞER MODÜLLER İÇİN ESKİ NAVİGASYON MANTIĞI DEVAM EDER ---
        sel = self.tree.selection()
        account_code = None
        if sel:
            vals = self.tree.item(sel[0])['values']
            account_code = str(vals[4]) if len(vals) > 4 else None

        try:
            # 2. ANA UYGULAMA (CONTROLLER) ERIŞİMİ
            app = self.master_app
            while not hasattr(app, 'open_module') and app.master:
                app = app.master
            
            if hasattr(app, 'open_module'):
                module_name = None
                title = ""
                
                if "MIZAN" in table_source:
                    module_name = "MizanFrame"
                    title = "Mizan Analizi"
                elif "BAKIYE" in table_source or "BAKİYE" in table_source:
                    module_name = "BalanceAnalizFrame"
                    title = "Bakiye Analizi"
                elif "DENETIM" in table_source or "RISK" in table_source:
                    module_name = "DenetimFrame" 
                    title = "Denetim Paneli"
                
                if module_name:
                    app.open_module(module_name, False, title)
                    app.update_idletasks()

                    if hasattr(app, 'content_area'):
                        frames = app.content_area.winfo_children()
                        target_frame = None
                        
                        for widget in frames:
                             if widget.__class__.__name__ == module_name:
                                target_frame = widget
                                break
                        
                        if target_frame:
                            if module_name == "DenetimFrame" and hasattr(target_frame, 'audit_tab'):
                                target_frame.notebook.select(target_frame.audit_tab)
                                target_frame.audit_tab.focus_on_record(target_ref)
                            elif hasattr(target_frame, 'focus_on_record'):
                                try:
                                    target_frame.focus_on_record(target_ref, account_code)
                                except TypeError:
                                    target_frame.focus_on_record(target_ref)
                                    
        except Exception as e:
            messagebox.showerror("Navigasyon Hatası", f"Modüle gidilemedi: {str(e)}")


class NoteManager:
    """
    Herhangi bir Treeview'a entegre edilerek Sağ Tık Menüsü, Renklendirme ve Popup sağlar.
    """
    def __init__(self, tree, table_name, master, indices=None, detail_callback=None):
        self.tree = tree
        self.table_name = table_name 
        self.root = master
        self.detail_callback = detail_callback 
        
        # İndeks Haritası (Hangi sütun neyi ifade ediyor?)
        if indices:
            self.idx = indices
        else:
            self.idx = {'ref': 2, 'hk': 4, 'ha': 5, 'borc': 8, 'alacak': 9}

        # Menü Oluştur
        self.menu = tk.Menu(tree, tearoff=0)
        self.menu.add_command(label="📝 Not Ekle / Risk Ata", command=self.popup)
        
        if self.detail_callback:
            self.menu.add_separator()
            self.menu.add_command(label="📄 Fiş Detayını Göster", command=self.call_detail)
            
        self.menu.add_separator()
        self.menu.add_command(label="📊 Tüm Riskleri Göster (Panel)", command=self.open_dash)
        
        # Bağlamalar
        self.tree.bind("<Button-3>", self.show_menu)
        if self.tree.tk.call('tk', 'windowingsystem') == 'aqua':
            self.tree.bind("<Button-2>", self.show_menu)
            
        # Renk Tanımları
        self.tree.tag_configure("RISK_HIGH", background="#ff9999")
        self.tree.tag_configure("RISK_MID", background="#ffe599")
        self.tree.tag_configure("RISK_LOW", background="#d9ead3")

    def show_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.menu.post(event.x_root, event.y_root)

    def call_detail(self):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0])['values']
        try:
            row_ref = str(vals[self.idx['ref']])
            if self.detail_callback:
                self.detail_callback(row_ref)
        except: pass

    def open_dash(self):
        if NoteDashboard._instance is None or not NoteDashboard._instance.winfo_exists():
            app_ref = self.root
            while not hasattr(app_ref, 'open_module') and app_ref.master:
                app_ref = app_ref.master
            NoteDashboard._instance = NoteDashboard(app_ref)
        else:
            NoteDashboard._instance.lift()

    def popup(self):
        sel = self.tree.selection()
        if not sel: return
        
        vals = self.tree.item(sel[0])['values']
        
        # Esnek Veri Çekme
        try:
            def get_val(key):
                idx = self.idx.get(key)
                if idx is not None and isinstance(idx, int) and 0 <= idx < len(vals):
                    return str(vals[idx])
                return ""

            row_ref = get_val('ref')
            if not row_ref or row_ref in ["0", "None", "", "nan"]:
                if vals and vals[0]: row_ref = str(vals[0])
                else: row_ref = "UNK"
                
            h_kodu = get_val('hk')
            h_adi = get_val('ha')
            borc = get_val('borc') or "0"
            alacak = get_val('alacak') or "0"
        except: 
            row_ref="UNK"; h_kodu=""; h_adi=""; borc="0"; alacak="0"

        # --- GÜNCELLEME: Oturumdan (Session) Ünvan bilgisini de alıyoruz ---
        sess = get_last_session()
        vkn = sess.get('vkn', '000')
        unvan = sess.get('unvan', 'Bilinmeyen Ünvan') # Yeni Eklenen Satır
        
        note = get_single_note(vkn, self.table_name, row_ref)
        
        top = tk.Toplevel(self.root)
        top.title(f"Not Ekle: {row_ref}")
        top.geometry("450x500")

        tk.Label(top, text="Risk Seviyesi", font=("Arial",10,"bold")).pack(pady=5)
        cmb_risk = ttk.Combobox(top, values=["Yüksek", "Orta", "Düşük"], state="readonly")
        cmb_risk.pack(pady=5)
        cmb_risk.set(note['risk_level'] if note else "Düşük")

        tk.Label(top, text="Açıklama", font=("Arial",10,"bold")).pack(pady=5)
        t_desc = tk.Text(top, height=5, width=45)
        t_desc.pack(padx=10)
        if note: t_desc.insert("1.0", note['description'])

        tk.Label(top, text="Aksiyon", font=("Arial",10,"bold")).pack(pady=5)
        t_act = tk.Text(top, height=5, width=45)
        t_act.pack(padx=10)
        if note: t_act.insert("1.0", note['action_plan'])

        # popup() fonksiyonu içindeki save() metodu şöyle olmalı:
        # popup() fonksiyonu içindeki save() metodu şu şekilde olmalı:
        def save():
            # --- GÜÇLENDİRİLMİŞ ÜNVAN ÇEKME MANTIĞI ---
            sess = get_last_session() or {}
            vkn = sess.get('vkn', '000')
            unvan = sess.get('unvan', 'Bilinmeyen Ünvan')
            
            # Arayüz (UI) hiyerarşisinden ana uygulamayı (toplevel) bulup teyit et
            try:
                app_ref = self.root.winfo_toplevel()
                if hasattr(app_ref, 'unvan') and app_ref.unvan and app_ref.unvan != "Seçili Mükellef Yok":
                    unvan = app_ref.unvan
            except: pass
            # ------------------------------------------
            
            d = {
                "vkn": vkn,
                "unvan": unvan, 
                "table_source": self.table_name,
                "row_ref": row_ref,
                "risk_level": cmb_risk.get(),
                "status": "Devam",
                "description": t_desc.get("1.0", "end").strip(),
                "action_plan": t_act.get("1.0", "end").strip(),
                "hesap_kodu": h_kodu,
                "hesap_adi": h_adi,
                "borc": borc,
                "alacak": alacak
            }
            upsert_note(d)
            
            # Ağaç görünümünü güncelle
            cmap = {"Yüksek":"RISK_HIGH", "Orta":"RISK_MID", "Düşük":"RISK_LOW"}
            current_tags = list(self.tree.item(sel[0], "tags"))
            new_tags = [t for t in current_tags if not t.startswith("RISK_")]
            new_tags.append(cmap[cmb_risk.get()])
            
            self.tree.item(sel[0], tags=tuple(new_tags))
            top.destroy()
            messagebox.showinfo("Başarılı", "Not kaydedildi.")

        tk.Button(top, text="KAYDET", bg="#2980b9", fg="white", command=save).pack(pady=20, fill=tk.X, padx=20)
    
    def color_rows(self):
        sess = get_last_session()
        vkn = sess.get('vkn')
        if not vkn: return
        
        active_risks = get_active_risks_dict(vkn, self.table_name)
        
        for item in self.tree.get_children():
            vals = self.tree.item(item)['values']
            try:
                idx_ref = self.idx.get('ref')
                if idx_ref is not None and idx_ref < len(vals):
                    r = str(vals[idx_ref])
                else:
                    r = str(vals[0])
            except: continue
            
            curr = list(self.tree.item(item, "tags"))
            new = [t for t in curr if not t.startswith("RISK_")]
            
            if r in active_risks:
                risk = active_risks[r]
                cmap = {"Yüksek":"RISK_HIGH", "Orta":"RISK_MID", "Düşük":"RISK_LOW"}
                if risk in cmap: new.append(cmap[risk])
            
            self.tree.item(item, tags=tuple(new))