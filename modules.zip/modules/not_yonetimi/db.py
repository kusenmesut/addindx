import sqlite3
import os
import sys
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
from config import get_base_dir
from config import get_base_dir, get_mukellefler_dir
def get_db_path():
    return os.path.join(get_base_dir(), "notes.db")

def init_db():
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    # Tabloyu oluştur (unvan kolonu eklendi)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS risk_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vkn TEXT,
            unvan TEXT,  
            table_source TEXT,
            row_ref TEXT,
            risk_level TEXT,
            status TEXT,
            description TEXT,
            action_plan TEXT,
            hesap_kodu TEXT,
            hesap_adi TEXT,
            borc TEXT,
            alacak TEXT,
            created_at TIMESTAMP,
            completed_at TIMESTAMP
        )
    ''')
    
    # MEVCUT VERİTABANINI GÜNCELLEME (Eğer tablo eskiden varsa ve unvan kolonu yoksa otomatik ekler)
    try:
        cursor.execute("ALTER TABLE risk_notes ADD COLUMN unvan TEXT")
    except sqlite3.OperationalError:
        pass # Eğer kolon zaten varsa hata verir, biz bu hatayı görmezden geliriz.
        
    conn.commit()
    conn.close()


def upsert_note(data):
    init_db()
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # 1. ADIM: "DÜŞEYARA" MANTIĞI İLE KLASÖRLERDEN ÜNVANI BULMA
    hedef_vkn = data.get('vkn', '')
    bulunan_unvan = 'Bilinmeyen Ünvan'
    
    if hedef_vkn and hedef_vkn != '000' and hedef_vkn != '---':
        root_dir = get_mukellefler_dir()
        if os.path.exists(root_dir):
            for folder in os.listdir(root_dir):
                if os.path.isdir(os.path.join(root_dir, folder)) and "-" in folder:
                    # Klasör adını sağdan ilk tireye göre böl (UNVAN - VKN)
                    parts = folder.rsplit("-", 1)
                    if len(parts) == 2:
                        klasor_vkn = parts[1].strip()
                        if klasor_vkn == hedef_vkn:
                            bulunan_unvan = parts[0].strip()
                            break # Ünvanı bulduk, aramayı bitir
    
    # Eğer klasörlerde bulamadıysa, (çok nadir) son çare olarak UI'dan geleni kullan
    if bulunan_unvan == 'Bilinmeyen Ünvan':
        bulunan_unvan = data.get('unvan', 'Bilinmeyen Ünvan')

    # 2. ADIM: VERİTABANINA KAYIT İŞLEMİ
    cursor.execute("SELECT id FROM risk_notes WHERE vkn=? AND table_source=? AND row_ref=?", 
                   (data['vkn'], data['table_source'], data['row_ref']))
    row = cursor.fetchone()
    
    if row:
        # KAYIT VARSA GÜNCELLE
        sql = '''UPDATE risk_notes SET unvan=?, risk_level=?, status=?, description=?, action_plan=?, 
                 hesap_kodu=?, hesap_adi=?, borc=?, alacak=?
                 WHERE id=?'''
        params = (bulunan_unvan, data['risk_level'], data['status'], data['description'], data['action_plan'],
                  data['hesap_kodu'], data['hesap_adi'], data['borc'], data['alacak'], row[0])
    else:
        # YENİ KAYIT
        sql = '''INSERT INTO risk_notes (vkn, unvan, table_source, row_ref, risk_level, status, description, 
                 action_plan, hesap_kodu, hesap_adi, borc, alacak, created_at) 
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)'''
        params = (data['vkn'], bulunan_unvan, data['table_source'], data['row_ref'], data['risk_level'], data['status'],
                  data['description'], data['action_plan'], data['hesap_kodu'], data['hesap_adi'],
                  data['borc'], data['alacak'], now)
    
    cursor.execute(sql, params)
    conn.commit()
    conn.close()

def update_status(note_id, new_status):
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    if new_status == "Tamamlandı":
        cursor.execute("UPDATE risk_notes SET status=?, completed_at=? WHERE id=?", (new_status, now, note_id))
    else:
        cursor.execute("UPDATE risk_notes SET status=? WHERE id=?", (new_status, note_id))
        
    conn.commit()
    conn.close()

def get_notes_by_filter(vkn, status_filter=None):
    init_db()
    conn = sqlite3.connect(get_db_path())
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if status_filter == "ALL":
        cursor.execute("SELECT * FROM risk_notes WHERE vkn=? ORDER BY created_at DESC", (vkn,))
    elif status_filter == "COMPLETED":
        cursor.execute("SELECT * FROM risk_notes WHERE vkn=? AND status='Tamamlandı' ORDER BY completed_at DESC", (vkn,))
    else:
        cursor.execute("SELECT * FROM risk_notes WHERE vkn=? AND status!='Tamamlandı' ORDER BY created_at DESC", (vkn,))
        
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows

def get_single_note(vkn, table_source, row_ref):
    init_db()
    conn = sqlite3.connect(get_db_path())
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM risk_notes WHERE vkn=? AND table_source=? AND row_ref=?", 
                   (vkn, table_source, row_ref))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def get_active_risks_dict(vkn, table_source):
    init_db()
    conn = sqlite3.connect(get_db_path())
    cursor = conn.cursor()
    cursor.execute("SELECT row_ref, risk_level FROM risk_notes WHERE vkn=? AND table_source=? AND status!='Tamamlandı'", (vkn, table_source))
    data = {row[0]: row[1] for row in cursor.fetchall()}
    conn.close()
    return data
