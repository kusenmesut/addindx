import tkinter as tk
from tkinter import ttk, messagebox
import threading
import json

# Motor Bağlantısı (Aynı kalıyor)
try:
    from .engine import TalepEngine
except ImportError:
    try:
        from modules.talep_oneri.engine import TalepEngine
    except ImportError:
        class TalepEngine:
            def talep_kaydet(self, data): return True, "Test Modu: Kayıt Başarılı"
            def gecmis_talepleri_getir(self): return []

# --- RENK PALETİ ---
COL_MAIN_BG = "#e9ecef"    # Gri Zemin
COL_CARD_BG = "#218838"    # Ana Yeşil
COL_BTN_BG  = "#1e7e34"    # Koyu Yeşil
COL_BTN_SEL = "#155724"    # Seçili Buton
COL_TEXT_W  = "#ffffff"
COL_INPUT_BG= "#ffffff"

class ModernBoxButton(tk.Frame):
    """Yeşil Seçim Kartları (Aynı kalıyor)"""
    def __init__(self, parent, icon, title, value, select_callback):
        super().__init__(parent, bg=COL_BTN_BG, cursor="hand2", width=140, height=140)
        self.pack_propagate(False)
        self.value = value
        self.callback = select_callback
        self.is_selected = False
        
        self.lbl_icon = tk.Label(self, text=icon, font=("Segoe UI Emoji", 36), bg=COL_BTN_BG, fg=COL_TEXT_W)
        self.lbl_icon.place(relx=0.5, rely=0.4, anchor="center")
        
        self.lbl_title = tk.Label(self, text=title, font=("Segoe UI", 11, "bold"), bg=COL_BTN_BG, fg=COL_TEXT_W)
        self.lbl_title.place(relx=0.5, rely=0.75, anchor="center")

        for w in [self, self.lbl_icon, self.lbl_title]:
            w.bind("<Button-1>", lambda e: self.callback(self.value))
            w.bind("<Enter>", self.on_enter)
            w.bind("<Leave>", self.on_leave)

    def set_selected(self, selected):
        self.is_selected = selected
        color = COL_BTN_SEL if selected else COL_BTN_BG
        self.config(bg=color, highlightthickness=3 if selected else 0, highlightbackground="white")
        self.lbl_icon.config(bg=color)
        self.lbl_title.config(bg=color)

    def on_enter(self, e):
        if not self.is_selected:
            self.config(bg=COL_BTN_SEL)
            self.lbl_icon.config(bg=COL_BTN_SEL)
            self.lbl_title.config(bg=COL_BTN_SEL)

    def on_leave(self, e):
        if not self.is_selected:
            self.config(bg=COL_BTN_BG)
            self.lbl_icon.config(bg=COL_BTN_BG)
            self.lbl_title.config(bg=COL_BTN_BG)

# --- YENİ BİLEŞEN: Combobox Yerine Modern Seçim Grubu ---
class ModernOptionGroup(tk.Frame):
    """Combobox yerine kullanılacak tıklanabilir yatay seçim butonları"""
    def __init__(self, parent, options, bg_color=COL_CARD_BG):
        super().__init__(parent, bg=bg_color)
        self.options = options
        self.selected_value = options[0] if options else ""
        self.labels = {}
        
        for opt in options:
            # Buton gibi davranan etiketler
            lbl = tk.Label(self, text=opt, font=("Segoe UI", 10, "bold"), 
                           bg=COL_INPUT_BG, fg=COL_BTN_BG, padx=15, pady=6, cursor="hand2")
            lbl.pack(side="left", padx=(0, 10))
            
            # Hover ve Tıklama eventleri
            lbl.bind("<Button-1>", lambda e, val=opt: self.select_option(val))
            lbl.bind("<Enter>", lambda e, val=opt: self.on_enter(val))
            lbl.bind("<Leave>", lambda e, val=opt: self.on_leave(val))
            self.labels[opt] = lbl
            
        self.select_option(self.selected_value)

    def select_option(self, value):
        self.selected_value = value
        for opt, lbl in self.labels.items():
            if opt == value:
                lbl.config(bg=COL_BTN_SEL, fg=COL_TEXT_W)
            else:
                lbl.config(bg=COL_INPUT_BG, fg=COL_BTN_BG)
                
    def on_enter(self, value):
        if self.selected_value != value:
            self.labels[value].config(bg="#e2e6ea") # Hafif gri hover

    def on_leave(self, value):
        if self.selected_value != value:
            self.labels[value].config(bg=COL_INPUT_BG)

    def get(self):
        return self.selected_value


class TalepFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=COL_MAIN_BG)
        self.engine = TalepEngine()
        self.history_cache = {}
        
        # --- STİL ---
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TNotebook", background=COL_MAIN_BG, borderwidth=0)
        style.configure("TNotebook.Tab", font=("Segoe UI", 11), padding=[15, 8], background="#ced4da")
        style.map("TNotebook.Tab", background=[("selected", COL_CARD_BG)], foreground=[("selected", "white")])
        
        style.configure("Clean.TEntry", fieldbackground=COL_INPUT_BG, borderwidth=0, padding=10)
        
        style.configure("Next.TButton", font=("Segoe UI", 11, "bold"), background="white", foreground=COL_CARD_BG, borderwidth=0)
        style.map("Next.TButton", background=[("active", "#f8f9fa")])
        
        style.configure("Back.TButton", font=("Segoe UI", 11), background=COL_BTN_BG, foreground="white", borderwidth=0)

        # --- TAB YAPISI ---
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=20, pady=20)

        self.tab_new = tk.Frame(self.notebook, bg=COL_MAIN_BG)
        self.notebook.add(self.tab_new, text="✨ Yeni Bildirim")
        self.setup_new_request_ui()

        self.tab_history = tk.Frame(self.notebook, bg=COL_MAIN_BG)
        self.notebook.add(self.tab_history, text="📜 Geçmiş Taleplerim")
        self.setup_history_ui()
        
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_change)

    def setup_new_request_ui(self):
        self.card = tk.Frame(self.tab_new, bg=COL_CARD_BG)
        self.card.place(relx=0.5, rely=0.5, anchor="center", width=800, height=600)
        self.current_step = 1
        self.selected_type = None
        self.box_widgets = {}
        self.form_widgets = {}
        self.show_step_1()

    def show_step_1(self):
        self.clear_card()
        self.current_step = 1
        
        tk.Label(self.card, text="Hangi konuda destek lazım? *", font=("Segoe UI", 18, "bold"), bg=COL_CARD_BG, fg=COL_TEXT_W).pack(pady=(50, 5))
        tk.Label(self.card, text="Lütfen yapmak istediğiniz işlem türünü seçin ve İleri deyin.", font=("Segoe UI", 10), bg=COL_CARD_BG, fg="#d1e7dd").pack(pady=(0, 40))

        btn_frame = tk.Frame(self.card, bg=COL_CARD_BG)
        btn_frame.pack()

        types = [("🧠", "Yeni Senaryo", "Senaryo"), ("💡", "Geliştirme", "Geliştirme"), ("🐞", "Hata Bildirimi", "Hata")]
        for i, (icon, title, val) in enumerate(types):
            box = ModernBoxButton(btn_frame, icon, title, val, self.on_box_select)
            box.grid(row=0, column=i, padx=20)
            self.box_widgets[val] = box

        footer = tk.Frame(self.card, bg=COL_CARD_BG)
        footer.pack(fill="x", side="bottom", padx=60, pady=50)
        self.btn_next = ttk.Button(footer, text="İleri (Next) >", style="Next.TButton", command=self.go_next)
        self.btn_next.pack(side="right", ipady=10, ipadx=40)

    def on_box_select(self, value):
        self.selected_type = value
        for val, widget in self.box_widgets.items(): widget.set_selected(val == value)

    def go_next(self):
        if not self.selected_type: return messagebox.showwarning("Uyarı", "Lütfen seçim yapın.")
        self.show_step_2()

    def show_step_2(self):
        self.clear_card()
        self.current_step = 2
        self.form_widgets = {}

        header = tk.Frame(self.card, bg=COL_CARD_BG)
        header.pack(fill="x", padx=40, pady=(40, 20))
        title_map = {"Senaryo": "Yeni Senaryo Fikri", "Geliştirme": "Özellik Önerisi", "Hata": "Hata Bildirimi"}
        tk.Label(header, text=title_map.get(self.selected_type), font=("Segoe UI", 18, "bold"), bg=COL_CARD_BG, fg=COL_TEXT_W).pack(side="left")

        form_area = tk.Frame(self.card, bg=COL_CARD_BG)
        form_area.pack(fill="both", expand=True, padx=40)

        # Combo yerine "options" kullanılıyor
        if self.selected_type == "Senaryo":
            self.add_field(form_area, "Senaryo Adı", "entry", key="baslik")
            self.add_field(form_area, "Kategori", "options", ["Yevmiye Analiz","Fatura Analiz", "Diğer"], key="kategori")
            self.add_field(form_area, "Mantık / Açıklama", "text", height=5, key="detay")
        elif self.selected_type == "Geliştirme":
            self.add_field(form_area, "Öneri Konusu", "entry", key="baslik")
            self.add_field(form_area, "Önem", "options", ["Düşük", "Normal", "Yüksek (Acil)"], key="onem")
            self.add_field(form_area, "Detaylar", "text", height=6, key="detay")
        elif self.selected_type == "Hata":
            self.add_field(form_area, "Hatalı Yer", "entry", key="baslik")
            self.add_field(form_area, "Hata Tipi", "options", ["Yanlış Hesap", "Crash", "Görünüm"], key="tip")
            self.add_field(form_area, "Hata Detayı", "text", height=5, key="detay")

        footer = tk.Frame(self.card, bg=COL_CARD_BG)
        footer.pack(fill="x", side="bottom", padx=40, pady=40)
        ttk.Button(footer, text="< Geri", style="Back.TButton", command=self.show_step_1).pack(side="left", ipady=10, ipadx=20)
        ttk.Button(footer, text="GÖNDER", style="Next.TButton", command=self.submit_form).pack(side="right", ipady=10, ipadx=30)

    # Geçmiş Arayüzü (Aynı kalıyor)
    def setup_history_ui(self):
        self.paned = ttk.PanedWindow(self.tab_history, orient=tk.HORIZONTAL)
        self.paned.pack(fill="both", expand=True, padx=10, pady=10)

        left_frame = tk.Frame(self.paned, bg="white", relief="solid", bd=1)
        self.paned.add(left_frame, weight=1)

        cols = ("Tarih", "Tip", "Konu")
        self.tree = ttk.Treeview(left_frame, columns=cols, show="headings", selectmode="browse")
        self.tree.heading("Tarih", text="Tarih")
        self.tree.heading("Tip", text="Tip")
        self.tree.heading("Konu", text="Konu")
        self.tree.column("Tarih", width=130)
        self.tree.column("Tip", width=100)
        self.tree.column("Konu", width=250)
        
        self.tree.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(left_frame, orient="vertical", command=self.tree.yview)
        sb.pack(side="right", fill="y")
        self.tree.configure(yscroll=sb.set)
        
        self.tree.bind("<<TreeviewSelect>>", self.on_history_select)

        right_frame = tk.Frame(self.paned, bg="#f8f9fa", relief="solid", bd=1)
        self.paned.add(right_frame, weight=2)
        
        tk.Label(right_frame, text="Talep Detayı", font=("Segoe UI", 12, "bold"), bg="#f8f9fa").pack(pady=10)
        
        self.txt_history_detail = tk.Text(right_frame, wrap="word", font=("Consolas", 10), padx=15, pady=15, bg="white", state="disabled", relief="flat")
        self.txt_history_detail.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        ttk.Button(right_frame, text="Listeyi Yenile", command=self.load_history).pack(pady=5)

    def on_tab_change(self, event):
        if str(self.notebook.select()).endswith(str(self.tab_history)): 
            self.load_history()

    def load_history(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        self.history_cache = {} 
        
        rows = self.engine.gecmis_talepleri_getir()
        for row in rows:
            tarih_kisa = str(row["tarih"])[:16]
            item_id = self.tree.insert("", "end", values=(tarih_kisa, row["tip"], row["baslik"]))
            self.history_cache[item_id] = dict(row)

    def on_history_select(self, event):
        selection = self.tree.selection()
        if not selection: return
        
        item_id = selection[0]
        row_data = self.history_cache.get(item_id)
        
        if not row_data: return

        self.txt_history_detail.config(state="normal")
        self.txt_history_detail.delete("1.0", tk.END)
        
        self.txt_history_detail.insert(tk.END, f"TARİH  : {row_data['tarih']}\n")
        self.txt_history_detail.insert(tk.END, f"TÜR    : {row_data['tip']}\n")
        self.txt_history_detail.insert(tk.END, f"BAŞLIK : {row_data['baslik']}\n")
        self.txt_history_detail.insert(tk.END, "-"*50 + "\n\n")
        
        try:
            detaylar = json.loads(row_data["detay_json"])
            key_map = {
                "baslik": "Konu Başlığı",
                "kategori": "Kategori",
                "detay": "Açıklama / Mantık",
                "onem": "Önem Derecesi",
                "tip": "Hata Tipi"
            }

            for key, value in detaylar.items():
                if key == "baslik": continue 
                
                label = key_map.get(key, key.upper()) 
                self.txt_history_detail.insert(tk.END, f"[{label}]:\n", "bold_tag")
                self.txt_history_detail.insert(tk.END, f"{value}\n\n")

        except json.JSONDecodeError:
            self.txt_history_detail.insert(tk.END, "Detay verisi okunamadı (JSON Hatası).\nRaw Data:\n" + str(row_data["detay_json"]))
        
        self.txt_history_detail.tag_configure("bold_tag", font=("Segoe UI", 10, "bold"), foreground=COL_BTN_BG)
        self.txt_history_detail.config(state="disabled")

    # --- Yardımcı Fonksiyonlar ---
    def clear_card(self):
        for widget in self.card.winfo_children(): widget.destroy()

    def add_field(self, parent, label, widget_type="entry", values=None, height=1, key=None):
        tk.Label(parent, text=label, font=("Segoe UI", 10, "bold"), bg=COL_CARD_BG, fg=COL_TEXT_W).pack(anchor="w", pady=(10, 2))
        w = None
        if widget_type == "entry":
            w = ttk.Entry(parent, style="Clean.TEntry", font=("Segoe UI", 10))
            w.pack(fill="x", ipady=6)
        elif widget_type == "options":  # Yeni ModernOptionGroup Entegrasyonu
            w = ModernOptionGroup(parent, options=values)
            w.pack(fill="x", pady=2)
        elif widget_type == "text":
            w = tk.Text(parent, height=height, font=("Segoe UI", 10), borderwidth=0, padx=5, pady=5)
            w.pack(fill="x", pady=0)
        if key: self.form_widgets[key] = w

    def submit_form(self):
        data = {"tip": self.selected_type, "detaylar": {}}
        main_title = ""
        for key, widget in self.form_widgets.items():
            val = widget.get("1.0", tk.END).strip() if isinstance(widget, tk.Text) else widget.get()
            data["detaylar"][key] = val
            if key == "baslik": main_title = val
            
        if not main_title: return messagebox.showwarning("Eksik", "Başlık giriniz.")
        data["baslik"] = main_title
        threading.Thread(target=self._send, args=(data,), daemon=True).start()

    def _send(self, data):
        success, msg = self.engine.talep_kaydet(data)
        self.after(0, lambda: [messagebox.showinfo("Bilgi", msg), self.show_step_1(), self.load_history()] if success else messagebox.showerror("Hata", msg))

if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("1000x800")
    app = TalepFrame(root)
    app.pack(fill="both", expand=True)
    root.mainloop()