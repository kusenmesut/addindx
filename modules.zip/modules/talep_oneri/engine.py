import sqlite3
import os
import datetime
import requests
import urllib3
import json

# SSL Uyarılarını Gizle
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Render Sunucu Adresi
API_BASE_URL = "https://ghostserver-rgyz.onrender.com/api"

class TalepEngine:
    def __init__(self):
        self.local_db_path = os.path.join("data", "system.db")
        self._init_local_db()

    def _init_local_db(self):
        if not os.path.exists("data"): os.makedirs("data")
        conn = sqlite3.connect(self.local_db_path)
        cursor = conn.cursor()
        
        # Yerel tabloda da email sütunu olsun (Yedeklilik için)
        try:
            cursor.execute("ALTER TABLE talepler ADD COLUMN email TEXT")
        except: pass

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS talepler (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tip TEXT,
                baslik TEXT,
                detay_json TEXT,
                tarih DATETIME,
                email TEXT,  -- Yeni Sütun
                api_status TEXT DEFAULT 'Pending'
            )
        ''')
        conn.commit()
        conn.close()

    def _get_user_email(self):
        """Aktif kullanıcının e-postasını bulur."""
        # 1. 'modules/kullanici_profil' dosyasını kontrol et
        try:
            candidates = [
                os.path.join(os.getcwd(), "modules", "kullanici_profil"),
                os.path.join(os.getcwd(), "modules", "kullanici_profil.json"),
                os.path.join(os.getcwd(), "modules", "kullanici_profil.txt")
            ]
            for path in candidates:
                if os.path.exists(path):
                    with open(path, "r", encoding="utf-8") as f:
                        content = f.read().strip()
                        # Eğer JSON ise
                        if content.startswith("{"):
                            data = json.loads(content)
                            return data.get("email", "bilinmeyen@user.com")
                        # Düz yazı ise
                        if "@" in content:
                            return content
        except: pass
        
        # 2. Bulamazsa login_data.json'a bak
        try:
            if os.path.exists("login_data.json"):
                with open("login_data.json", "r") as f:
                    return json.load(f).get("email")
        except: pass

        return "misafir@sistem.com"

    def talep_kaydet(self, veri_paketi):
        tarih = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        detay_str = json.dumps(veri_paketi["detaylar"], ensure_ascii=False)
        user_email = self._get_user_email() # E-postayı al
        
        try:
            # 1. YEREL KAYIT
            conn = sqlite3.connect(self.local_db_path)
            cursor = conn.cursor()
            cursor.execute(
                'INSERT INTO talepler (tip, baslik, detay_json, tarih, email) VALUES (?, ?, ?, ?, ?)', 
                (veri_paketi["tip"], veri_paketi["baslik"], detay_str, tarih, user_email)
            )
            conn.commit()
            conn.close()

            # 2. API GÖNDERİMİ (Email Dahil)
            payload = {
                "token": "user_token",
                "email": user_email,       # <--- EKLENDİ
                "type": veri_paketi["tip"],
                "subject": veri_paketi["baslik"],
                "message": detay_str, 
                "contact": f"App User ({user_email})"
            }
            
            requests.post(f"{API_BASE_URL}/submit-feedback", json=payload, timeout=5, verify=False)
            return True, "Bildiriminiz başarıyla iletildi."
            
        except Exception as e:
            return True, f"Kayıt başarılı (Sunucuya erişilemedi, yerelde saklandı). Hata: {e}"

    def gecmis_talepleri_getir(self):
        try:
            conn = sqlite3.connect(self.local_db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM talepler ORDER BY tarih DESC")
            rows = [dict(row) for row in cursor.fetchall()]
            conn.close()
            return rows
        except:
            return []