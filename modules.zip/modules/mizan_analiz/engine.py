import os
import pandas as pd
import sqlite3
import sys
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))

from config import get_mukellefler_dir, get_base_dir
from utils.session_db import get_last_session

class MizanEngine:
    # 1. DEĞİŞİKLİK: Artık VKN ve YIL bilgilerini de direkt dışarıdan alabiliyoruz
    def __init__(self, ozel_dosya_yolu=None, vkn=None, yil=None):
        self.ozel_dosya_yolu = ozel_dosya_yolu
        self.param_vkn = vkn
        self.param_yil = yil
        self.df = pd.DataFrame()
        self.clean_df = pd.DataFrame()
        self.mizan_summary = {}
        self.grand_totals = {"borc": 0.0, "alacak": 0.0, "bakiye": 0.0}
        self.status_msg = "Hazır"
        self.load_data()

    def get_ledger_db_path(self):
        return os.path.join(get_base_dir(), "ledger_props.db")

    def get_closing_ids_from_db(self, vkn, year):
        db_path = self.get_ledger_db_path()
        if not os.path.exists(db_path):
            return []
        try:
            conn = sqlite3.connect(db_path); cursor = conn.cursor()
            cursor.execute("SELECT closing_ids FROM ledger_properties WHERE vkn=? AND year=?", (str(vkn), str(year)))
            row = cursor.fetchone(); conn.close()
            if row and row[0]:
                return [int(x.strip()) for x in row[0].split(',') if x.strip().isdigit()]
        except:
            return []
        return []

    def get_active_file_path(self):
        # 1. Eğer doğrudan enjeksiyon yapıldıysa (Yükleme anı)
        if self.ozel_dosya_yolu and self.param_vkn and self.param_yil:
            if os.path.exists(self.ozel_dosya_yolu):
                return self.ozel_dosya_yolu, "Mizan Hazır (Direkt Enjeksiyon)", self.param_vkn, self.param_yil

        # 2. Oturumu al
        session = get_last_session()
        if not session:
            return None, "Oturum Yok", None, None
            
        vkn = session.get("vkn")
        year = session.get("year", session.get("yil"))
        
        if not vkn or str(vkn) == "---":
            return None, "Mükellef Seçilmedi", None, None

        # --- 3. KESİN ÇÖZÜM: GLOBAL ARŞİV HAFIZASI KONTROLÜ ---
        # Programın herhangi bir yerinden arşiv seçilmişse, yol RAM'de tutulur.
        
        global_yol = os.environ.get('EDENETIM_AKTIF_DOSYA')
        
        # Eğer hafızada bir yol varsa ve bu yol ŞU ANKİ Mükellefin VKN'sini içeriyorsa 
        # (başka mükellefe geçilmediğinden emin olmak için güvenlik kontrolü)
        if global_yol and os.path.exists(global_yol) and str(vkn) in global_yol:
            return global_yol, "Mizan Hazır (Arşiv Hafızası)", vkn, year

        # 4. Standart / İlk Yükleme Mantığı (Hiç arşiv seçilmemişse)
        base_dir = get_mukellefler_dir()
        target_folder = None
        for f in os.listdir(base_dir):
            if str(f).strip().endswith(f"-{str(vkn).strip()}"):
                target_folder = os.path.join(base_dir, f)
                break
                
        if not target_folder:
            return None, "Klasör Bulunamadı", None, None
            
        return os.path.join(target_folder, str(year), f"{str(year)}_FULL.parquet"), "Mizan Hazır", vkn, year
    

    def load_data(self):
        target_file, msg, vkn, year = self.get_active_file_path()
        self.status_msg = msg
        if not target_file or not os.path.exists(target_file):
            self.status_msg = "Veri Yok"
            return
            
        try:
            self.df = pd.read_parquet(target_file)
            col_map = {"KayitTarihi": "Tarih", "YevmiyeNo": "Yevmiye No", "BelgeNo": "Belge No",
                       "HesapKodu": "Kebir Kodu", "HesapAdi": "Kebir Adı",
                       "MuavinKodu": "Muavin Kodu", "MuavinAdi": "Muavin Adı",
                       "FisAciklamasi": "Fiş Açıklama", "DetayAciklama": "Detay Açıklama",
                       "Borc": "Borç", "Alacak": "Alacak"}
            self.df.rename(columns=col_map, inplace=True)
            for col in ["Borç", "Alacak", "Yevmiye No"]:
                if col in self.df.columns:
                    self.df[col] = pd.to_numeric(self.df[col], errors='coerce').fillna(0)
            required = ["Kebir Kodu", "Kebir Adı", "Muavin Kodu", "Muavin Adı"]
            for r in required:
                if r not in self.df.columns:
                    self.df[r] = ""
            closing_ids = self.get_closing_ids_from_db(vkn, year)
            if closing_ids:
                self.clean_df = self.df[~self.df['Yevmiye No'].isin(closing_ids)].copy()
            else:
                if not self.df.empty:
                    last_id = self.df['Yevmiye No'].max()
                    self.clean_df = self.df[self.df['Yevmiye No'] != last_id].copy()
                else:
                    self.clean_df = self.df.copy()
            self.prepare_mizan_summary()
        except Exception as e:
            self.status_msg = f"Hata: {str(e)}"
            self.df = pd.DataFrame()
            self.clean_df = pd.DataFrame()

    def bakiye_hesapla(self, hesap_kodu, borc, alacak):
        """
        TDHP'ye göre hesabın aktif/pasif karakterini belirler ve bakiyeyi ona göre döndürür.
        """
        hesap_kodu = str(hesap_kodu).strip()
        if not hesap_kodu:
            return borc - alacak
            
        ilk_karakter = hesap_kodu[0]
        
        # Pasif ana gruplar ve Aktifi Düzenleyici (Pasif Karakterli) hesaplar
        pasif_ana_gruplar = ('3', '4', '5')
        aktif_duzenleyiciler = ('103', '119', '122', '129', '137', '199', '241', '243', '245', '257', '268', '278', '289', '299')
        gelir_pasifler = ('60', '64', '67')
        
        is_pasif = False
        
        if ilk_karakter in pasif_ana_gruplar:
            is_pasif = True
        elif any(hesap_kodu.startswith(kod) for kod in aktif_duzenleyiciler):
            is_pasif = True
        elif any(hesap_kodu.startswith(kod) for kod in gelir_pasifler):
            is_pasif = True
            
        if is_pasif:
            # Pasif karakterli hesaplar normalde ALACAK bakiyesi verir. 
            # Bakiye = Alacak - Borç. Eğer sonuç negatifse bu bir 'Ters Bakiye' riskidir ve negatif görünür.
            return alacak - borc
        else:
            # Aktif karakterli hesaplar normalde BORÇ bakiyesi verir.
            # Bakiye = Borç - Alacak.
            return borc - alacak


    def prepare_mizan_summary(self):
        if self.clean_df.empty:
            return
        self.grand_totals["borc"] = self.clean_df['Borç'].sum()
        self.grand_totals["alacak"] = self.clean_df['Alacak'].sum()
        self.grand_totals["bakiye"] = self.grand_totals["borc"] - self.grand_totals["alacak"]
        df_muavin = self.clean_df.groupby(['Kebir Kodu', 'Kebir Adı', 'Muavin Kodu', 'Muavin Adı'])[['Borç', 'Alacak']].sum().reset_index()
        self.mizan_summary = {}
        for kebir_kod, group in df_muavin.groupby('Kebir Kodu'):
            kebir_adi = group.iloc[0]['Kebir Adı']
            k_borc = group['Borç'].sum()
            k_alacak = group['Alacak'].sum()
            # Kebir bakiye hesaplaması
            k_bakiye = self.bakiye_hesapla(kebir_kod, k_borc, k_alacak)
            
            sub_accounts = []
            for _, row in group.iterrows():
                # Muavin bakiye hesaplaması
                m_bakiye = self.bakiye_hesapla(row['Muavin Kodu'], row['Borç'], row['Alacak'])
                sub_accounts.append({"code": row['Muavin Kodu'], "name": row['Muavin Adı'], "borc": row['Borç'], "alacak": row['Alacak'], "bakiye": m_bakiye})
            self.mizan_summary[kebir_kod] = {"name": kebir_adi, "borc": k_borc, "alacak": k_alacak, "bakiye": k_bakiye, "sub_accounts": sub_accounts}

    def get_details_for_account(self, code):
        if self.clean_df.empty:
            return []
        is_muavin = self.clean_df[self.clean_df['Muavin Kodu'] == code]
        if not is_muavin.empty:
            return is_muavin.to_dict('records')
        is_kebir = self.clean_df[self.clean_df['Kebir Kodu'] == code]
        if not is_kebir.empty:
            return is_kebir.to_dict('records')
        return []

    def get_transactions_by_desc(self, description):
        if (self.clean_df.empty and self.df.empty) or not description:
            return []
        df_source = self.clean_df if not self.clean_df.empty else self.df
        target_desc = str(description).strip()
        mask = df_source['Fiş Açıklama'].astype(str).str.strip() == target_desc
        rows = df_source[mask].sort_values(by=['Tarih', 'Yevmiye No'])
        return rows.to_dict('records')

    def get_fis_details(self, fis_no):
        if self.df.empty:
            return []
        s_fis = str(fis_no).split('.')[0].strip()
        mask = self.df['Yevmiye No'].astype(str).str.split('.').str[0] == s_fis
        rows = self.df[mask]
        return rows.to_dict('records')

    def analyze_account_correlation(self, target_code):
        if self.clean_df.empty:
            return [], "Veri Yok"
        target_str = str(target_code)
        mask_target = (self.clean_df['Kebir Kodu'] == target_str) | (self.clean_df['Muavin Kodu'] == target_str)
        target_fis_list = self.clean_df.loc[mask_target, 'Yevmiye No'].unique()
        if len(target_fis_list) == 0:
            return [], "Bu hesapla ilgili fiş kaydı bulunamadı."
        related_df = self.clean_df[self.clean_df['Yevmiye No'].isin(target_fis_list)].copy()
        related_df = related_df[~((related_df['Kebir Kodu'] == target_str) | (related_df['Muavin Kodu'] == target_str))]
        if related_df.empty:
            return [], "Tek taraflı kayıt?"
        correlation = related_df.groupby(['Kebir Kodu', 'Kebir Adı']).agg(TekrarSayisi=('Yevmiye No', 'nunique')).reset_index()
        correlation.sort_values(by='TekrarSayisi', ascending=False, inplace=True)
        target_name = "Bilinmiyor"
        try:
            row = self.clean_df[(self.clean_df['Kebir Kodu'] == target_str) | (self.clean_df['Muavin Kodu'] == target_str)].iloc[0]
            target_name = row['Muavin Adı'] if row['Muavin Kodu'] == target_str else row['Kebir Adı']
        except:
            pass
        results = []
        for _, row in correlation.iterrows():
            results.append({"HesapKodu1": target_str, "HesapAdı1": target_name, "TekrarSayisi": int(row['TekrarSayisi']), "HesapKodu2": row['Kebir Kodu'], "HesapAdı2": row['Kebir Adı']})
        return results, "OK"

    def get_shared_journals_unique(self, code1, code2):
        if self.clean_df.empty:
            return []
        fis1 = set(self.clean_df.loc[(self.clean_df['Kebir Kodu']==code1)|(self.clean_df['Muavin Kodu']==code1), 'Yevmiye No'])
        fis2 = set(self.clean_df.loc[(self.clean_df['Kebir Kodu']==code2)|(self.clean_df['Muavin Kodu']==code2), 'Yevmiye No'])
        common_fis = list(fis1.intersection(fis2))
        if not common_fis:
            return []
        df_common = self.clean_df[self.clean_df['Yevmiye No'].isin(common_fis)].copy()
        grouped = df_common.groupby('Yevmiye No').agg({
            'Tarih': 'first',
            'Fiş Açıklama': 'first',
            'Borç': 'sum',
            'Alacak': 'sum'
        }).reset_index()
        return grouped.to_dict('records')

    def _choose_source_df(self):
        """Internal helper: tercihen clean_df kullan, yoksa df."""
        return self.clean_df if not self.clean_df.empty else self.df

    def get_fis_signature(self, fis_no):
        df_source = self._choose_source_df()
        if df_source.empty:
            return ""
        s_fis = str(fis_no).split('.')[0].strip()
        mask = df_source['Yevmiye No'].astype(str).str.split('.').str[0] == s_fis
        rows = df_source.loc[mask]
        if rows.empty:
            return ""
        kebir_codes = rows['Kebir Kodu'].astype(str).str.strip().replace('', pd.NA).dropna().unique().tolist()
        def sort_key(x):
            try:
                return (0, int(x))
            except:
                return (1, x)
        kebir_codes_sorted = sorted(kebir_codes, key=sort_key)
        signature = "+".join(kebir_codes_sorted)
        return signature

    def find_fis_matches_by_signature(self, fis_no):
        df_source = self._choose_source_df()
        if df_source.empty:
            return []

        target_sig = self.get_fis_signature(fis_no)
        if not target_sig:
            return []

        df_source = df_source.copy()
        df_source['YevmiyeKey'] = df_source['Yevmiye No'].astype(str).str.split('.').str[0]
        grouped = df_source.groupby('YevmiyeKey').agg({
            'Kebir Kodu': lambda s: list(pd.Series(s.astype(str)).str.strip().replace('', pd.NA).dropna().unique()),
            'Tarih': 'first',
            'Borç': 'sum',
            'Alacak': 'sum',
            'Fiş Açıklama': 'first'
        }).reset_index()

        def make_sig_from_list(lst):
            if not lst:
                return ""
            def sort_key(x):
                try:
                    return (0, int(x))
                except:
                    return (1, x)
            lst_sorted = sorted([str(x).strip() for x in lst if str(x).strip() != ""], key=sort_key)
            return "+".join(lst_sorted)

        grouped['Signature'] = grouped['Kebir Kodu'].apply(make_sig_from_list)
        s_fis_key = str(fis_no).split('.')[0].strip()
        matches = grouped[(grouped['Signature'] == target_sig) & (grouped['YevmiyeKey'] != s_fis_key)]

        results = []
        for _, row in matches.iterrows():
            results.append({
                'Yevmiye No': row['YevmiyeKey'],
                'Signature': row['Signature'],
                'Tarih': row['Tarih'],
                'Borç': float(row['Borç']) if not pd.isna(row['Borç']) else 0.0,
                'Alacak': float(row['Alacak']) if not pd.isna(row['Alacak']) else 0.0,
                'Fiş Açıklama': row.get('Fiş Açıklama', '')
            })
        return results

    def analyze_monthly_volatility(self, account_code):
        df_source = self._choose_source_df()
        if df_source.empty:
            return []

        ac = str(account_code)
        df = df_source.copy()
        mask = (df['Kebir Kodu'] == ac) | (df['Muavin Kodu'] == ac)
        rows = df.loc[mask].copy()
        if rows.empty:
            return []

        rows['Tarih'] = pd.to_datetime(rows['Tarih'], errors='coerce')
        rows.sort_values(by=['Tarih', 'Yevmiye No'], inplace=True)

        rows['delta'] = pd.to_numeric(rows.get('Borç', 0), errors='coerce').fillna(0) - pd.to_numeric(rows.get('Alacak', 0), errors='coerce').fillna(0)
        rows['running'] = rows['delta'].cumsum()

        rows['period'] = rows['Tarih'].dt.to_period('M').astype(str)

        results = []
        grouped = rows.groupby('period')
        for period, g in grouped:
            if g.empty:
                continue
            min_val = g['running'].min()
            max_val = g['running'].max()
            min_rows = g[g['running'] == min_val]
            max_rows = g[g['running'] == max_val]
            for _, r in min_rows.iterrows():
                results.append({
                    'period': period,
                    'type': 'Dip',
                    'tarih': r['Tarih'],
                    'Yevmiye No': r.get('Yevmiye No', ''),
                    'Fiş Açıklama': r.get('Fiş Açıklama', ''),
                    'balance': float(r['running']) if not pd.isna(r['running']) else 0.0
                })
            for _, r in max_rows.iterrows():
                results.append({
                    'period': period,
                    'type': 'Zirve',
                    'tarih': r['Tarih'],
                    'Yevmiye No': r.get('Yevmiye No', ''),
                    'Fiş Açıklama': r.get('Fiş Açıklama', ''),
                    'balance': float(r['running']) if not pd.isna(r['running']) else 0.0
                })

        results.sort(key=lambda x: (x['period'], 0 if x['type'] == 'Dip' else 1))
        return results

    def export_ana_mizan(self, filepath=None):
        return self._export_helper(self.mizan_summary, "Ana_Mizan", detailed=False, filepath=filepath)

    def export_muavin_mizan(self, filepath=None):
        return self._export_helper(self.mizan_summary, "Muavin_Mizan", detailed=True, filepath=filepath)

    def export_right_panel(self, details_list, filepath=None):
        if not details_list:
            return False, "Veri yok."
        try:
            if filepath:
                save_path = filepath
            else:
                desktop = os.path.join(os.path.expanduser("~"), "Desktop")
                filename = f"Detay_Listesi_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
                save_path = os.path.join(desktop, filename)
                
            pd.DataFrame(details_list).to_excel(save_path, index=False)
            return True, f"Aktarıldı:\n{save_path}"
        except Exception as e:
            return False, str(e)

    def _export_helper(self, summary, name, detailed=False, filepath=None):
        if not summary:
            return False, "Veri yok"
        try:
            rows = []
            for k, v in summary.items():
                if not detailed:
                    rows.append({"Kod":k, "Ad":v['name'], "Borc":v['borc'], "Alacak":v['alacak'], "Bakiye":v['bakiye']})
                else:
                    for sub in v['sub_accounts']:
                        rows.append({"Kod":sub['code'], "Ad":sub['name'], "Borc":sub['borc'], "Alacak":sub['alacak'], "Bakiye":sub['bakiye']})
            
            if filepath:
                save_path = filepath
            else:
                desktop = os.path.join(os.path.expanduser("~"), "Desktop")
                save_path = os.path.join(desktop, f"{name}_{datetime.now().strftime('%Y%m%d')}.xlsx")
                
            pd.DataFrame(rows).to_excel(save_path, index=False)
            return True, f"Aktarıldı:\n{save_path}"
        except Exception as e:
            return False, str(e)

    def save_to_sqlite(self):
        if not self.mizan_summary:
            return False, "Kaydedilecek mizan verisi bulunamadı."

        try:
            # 1. Aktif dosya yolunu ve klasörü al
            target_file, msg, vkn, year = self.get_active_file_path()
            
            if not target_file or not os.path.exists(os.path.dirname(target_file)):
                return False, f"Hedef klasör bulunamadı: {msg}"

            # 2. Veritabanı yolunu belirle (Parquet ile aynı klasör)
            target_folder = os.path.dirname(target_file)
            db_name = f"mizan_data_{year}.db"
            db_path = os.path.join(target_folder, db_name)

            # 3. Bağlantıyı Kur ve Tabloları Hazırla
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()

            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ana_mizan (
                    hesap_kodu TEXT PRIMARY KEY,
                    hesap_adi TEXT,
                    borc REAL,
                    alacak REAL,
                    bakiye REAL
                )
            ''')

            cursor.execute('''
                CREATE TABLE IF NOT EXISTS muavin_mizan (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ana_hesap_kodu TEXT,
                    hesap_kodu TEXT,
                    hesap_adi TEXT,
                    borc REAL,
                    alacak REAL,
                    bakiye REAL
                )
            ''')

            # 4. Temizlik
            cursor.execute("DELETE FROM ana_mizan")
            cursor.execute("DELETE FROM muavin_mizan")

            # 5. Verileri Hazırla
            ana_data = []
            muavin_data = []

            for kebir_kod, data in self.mizan_summary.items():
                ana_data.append((kebir_kod, data['name'], data['borc'], data['alacak'], data['bakiye']))
                
                for sub in data['sub_accounts']:
                    muavin_data.append((kebir_kod, sub['code'], sub['name'], sub['borc'], sub['alacak'], sub['bakiye']))

            # 6. Kayıt
            cursor.executemany("INSERT INTO ana_mizan VALUES (?, ?, ?, ?, ?)", ana_data)
            cursor.executemany("INSERT INTO muavin_mizan (ana_hesap_kodu, hesap_kodu, hesap_adi, borc, alacak, bakiye) VALUES (?, ?, ?, ?, ?, ?)", muavin_data)

            conn.commit()
            conn.close()

            return True, f"Mizan başarıyla kaydedildi: {db_name}"

        except Exception as e:
            return False, f"Veritabanı kayıt hatası: {str(e)}"