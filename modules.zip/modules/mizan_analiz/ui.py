import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os
import pandas as pd
# --- MEVCUT IMPORTLARIN ALTINA EKLEYİN ---
import zipfile
import io
import tempfile
import sqlite3
import shutil
from tkinter import ttk, messagebox, filedialog  # filedialog BURAYA EKLENDİ
# Config ve Utils (örnek.py'den alındı)
try:
    from config import get_mukellefler_dir
    from utils.session_db import get_last_session
except ImportError:
    pass # Eğer proje yapısında bu yollar farklıysa düzenlenmeli

# Fatura Görüntüleme Modülü
try:
    from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
except ImportError:
    FaturaGoruntulePopup = None
# Matplotlib guard ve imports
HAS_MATPLOTLIB = False
try:
    import matplotlib
    matplotlib.use("TkAgg")
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.figure import Figure
    import matplotlib.dates as mdates
    HAS_MATPLOTLIB = True
except Exception:
    HAS_MATPLOTLIB = False

# Proje yolu (engine.py burada olmalı)
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from engine import MizanEngine

# config (renkler vb.) - yoksa fallback
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
try:
    from config import CLR_BODY_BG, CLR_ACCENT
except Exception:
    CLR_BODY_BG = "#f4f6f7"
    CLR_ACCENT = "#1d2936"

# NoteManager (opsiyonel) - Modülün varlığını kontrol et
HAS_NOTES = False
try:
    from modules.not_yonetimi.ui import NoteManager
    HAS_NOTES = True
except ImportError:
    print("UYARI: Not Yönetimi modülü (import) bulunamadı.")
except Exception as e:
    print(f"UYARI: Not Yönetimi yüklenirken hata: {e}")

# Tasarım renkleri
CLR_HEADER_BG = "#154360"
CLR_TREE_STRIPE = "#D4E6F1"
CLR_TOTAL_BG = "#2E86C1"
CLR_DETAIL_TOTAL_BG = "#E67E22"
CLR_BTN_BAR_BG = "#34495e"
CLR_FIS_HEADER_BG = "#0F3057"
CLR_ROW_ODD = "#EAF2F8"
CLR_ROW_EVEN = "#FFFFFF"

class MizanFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.engine = MizanEngine()
        self.current_details_list = []
        self.note_manager = None
        self.setup_styles()
        self.setup_ui()
        self.load_mizan_tree()

    def setup_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure("Mizan.Treeview", font=("Arial", 10), rowheight=28)
        style.configure("Mizan.Treeview.Heading", font=("Arial", 10, "bold"), background=CLR_HEADER_BG, foreground="white", relief="flat")
        style.map("Mizan.Treeview", background=[("selected", "#F39C12")], foreground=[("selected", "white")])

        style.configure("Detail.Treeview", font=("Arial", 9), rowheight=25)
        style.configure("Detail.Treeview.Heading", font=("Arial", 9, "bold"), background=CLR_HEADER_BG, foreground="white", relief="flat")
        style.map("Detail.Treeview", background=[("selected", "#F39C12")], foreground=[("selected", "white")])

        style.configure("Fis.Treeview", font=("Arial", 9), rowheight=25)
        style.configure("Fis.Treeview.Heading", font=("Arial", 9, "bold"), background="white", foreground="black")

    def setup_ui(self):
        # Main Container
        main_container = tk.Frame(self, bg=CLR_BODY_BG)
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Top Bar
        top_bar = tk.Frame(main_container, bg="white", height=45, bd=1, relief="solid")
        top_bar.pack(fill=tk.X, pady=(0, 10))
        tk.Label(top_bar, text="📊 FİNANSAL MİZAN VE HAREKET ANALİZİ", bg="white", font=("Arial", 12, "bold"), fg="#2c3e50").pack(side=tk.LEFT, padx=15, pady=10)

        # Bottom Bar (Buttons)
        bottom_bar = tk.Frame(main_container, bg=CLR_BTN_BAR_BG, height=50, bd=1, relief="raised")
        bottom_bar.pack(side=tk.BOTTOM, fill=tk.X, pady=(10, 0))

        btn_opts = {"font": ("Arial", 10, "bold"), "fg": "white", "bd": 0, "pady": 10}
        tk.Button(bottom_bar, text="ANA MİZAN (XLS)", bg="#2980b9", command=self.export_ana_mizan, **btn_opts).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2,1))
        tk.Button(bottom_bar, text="MUAVİN (XLS)", bg="#27ae60", command=self.export_muavin_mizan, **btn_opts).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=1)
        tk.Button(bottom_bar, text="📥 LİSTEYİ İNDİR (XLS)", bg="#e67e22", command=self.export_right_panel, **btn_opts).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(1,2))

        # PanedWindow
        self.paned = tk.PanedWindow(main_container, orient=tk.HORIZONTAL, sashwidth=6, bg="#bdc3c7")
        self.paned.pack(fill=tk.BOTH, expand=True)

        # --- LEFT PANEL: MIZAN TREE ---
        left_frame = tk.Frame(self.paned, bg="white")
        self.paned.add(left_frame, width=500)

        cols = ("Isim", "Borc", "Alacak", "Bakiye")
        self.tree_mizan = ttk.Treeview(left_frame, columns=cols, show="tree headings", style="Mizan.Treeview")

        self.tree_mizan.heading("#0", text="Kod"); self.tree_mizan.column("#0", width=120, minwidth=100)
        self.tree_mizan.heading("Isim", text="Hesap Adı"); self.tree_mizan.column("Isim", width=180, minwidth=150)
        self.tree_mizan.heading("Borc", text="Borç"); self.tree_mizan.column("Borc", width=90, anchor="e")
        self.tree_mizan.heading("Alacak", text="Alacak"); self.tree_mizan.column("Alacak", width=90, anchor="e")
        self.tree_mizan.heading("Bakiye", text="Bakiye"); self.tree_mizan.column("Bakiye", width=90, anchor="e")

        # Scrollbars (Left)
        sb_left_y = ttk.Scrollbar(left_frame, orient="vertical", command=self.tree_mizan.yview)
        sb_left_x = ttk.Scrollbar(left_frame, orient="horizontal", command=self.tree_mizan.xview)
        self.tree_mizan.configure(yscrollcommand=sb_left_y.set, xscrollcommand=sb_left_x.set)

        sb_left_y.pack(side=tk.RIGHT, fill=tk.Y)
        sb_left_x.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_mizan.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.tree_mizan.bind("<<TreeviewSelect>>", self.on_account_select)
        self.tree_mizan.bind("<Button-3>", self.show_context_menu)

        # --- RIGHT PANEL: DETAIL TABLE ---
        right_frame = tk.Frame(self.paned, bg="white")
        self.paned.add(right_frame)

        # --- YENİLENEN HEADER (ÜST ÇUBUK) ---
        # Başlık ve Toplamları aynı satırda tutacak Frame
        self.top_header_frame = tk.Frame(right_frame, bg=CLR_HEADER_BG, height=40)
        self.top_header_frame.pack(fill=tk.X)

        # 1. Sol Taraf: Başlık
        self.lbl_detail_header = tk.Label(self.top_header_frame, text="HESAP HAREKETLERİ", 
                                          bg=CLR_HEADER_BG, fg="white", font=("Arial", 11, "bold"), anchor="w")
        self.lbl_detail_header.pack(side=tk.LEFT, padx=10, pady=8)

        # 2. Sağ Taraf: Toplamlar (Sağdan Sola Doğru Eklenir: Bakiye -> Alacak -> Borç -> Kayıt)
        
        # Bakiye (En Sağ)
        self.lbl_top_bakiye = tk.Label(self.top_header_frame, text="BAKİYE: 0.00", 
                                       bg=CLR_HEADER_BG, fg="#F1C40F", font=("Arial", 10, "bold")) # Sarı renk
        self.lbl_top_bakiye.pack(side=tk.RIGHT, padx=(5, 10))

        # Alacak
        self.lbl_top_alacak = tk.Label(self.top_header_frame, text="ALACAK: 0.00", 
                                       bg=CLR_HEADER_BG, fg="#2ECC71", font=("Arial", 9, "bold")) # Açık Yeşil
        self.lbl_top_alacak.pack(side=tk.RIGHT, padx=5)

        # Borç
        self.lbl_top_borc = tk.Label(self.top_header_frame, text="BORÇ: 0.00", 
                                     bg=CLR_HEADER_BG, fg="#E74C3C", font=("Arial", 9, "bold")) # Açık Kırmızı
        self.lbl_top_borc.pack(side=tk.RIGHT, padx=5)
        
        # Kayıt Sayısı
        self.lbl_top_count = tk.Label(self.top_header_frame, text="[0 Kayıt]", 
                                      bg=CLR_HEADER_BG, fg="#BDC3C7", font=("Arial", 9))
        self.lbl_top_count.pack(side=tk.RIGHT, padx=(10, 5))

        # --- TABLE VIEW ---
        # --- TABLE VIEW (GÜNCELLENDİ: BelgeNo Eklendi) ---
        cols_det = ("Tarih", "YevmiyeNo", "BelgeNo", "KebirKodu", "KebirAdi", "MuavinKodu", "MuavinAdi", "FişAçıklama", "DetayAçıklama", "Borç", "Alacak", "Bakiye")
        self.tree_detail = ttk.Treeview(right_frame, columns=cols_det, show="headings", style="Detail.Treeview")

     

        self.tree_detail.heading("Tarih", text="Tarih"); self.tree_detail.column("Tarih", width=80, anchor="center")
        self.tree_detail.heading("YevmiyeNo", text="Yevmiye"); self.tree_detail.column("YevmiyeNo", width=70, anchor="center")
        self.tree_detail.heading("KebirKodu", text="Ana Hesap"); self.tree_detail.column("KebirKodu", width=80, anchor="w")
        self.tree_detail.heading("KebirAdi", text="Ana Hesap Adı"); self.tree_detail.column("KebirAdi", width=120, anchor="w")
        self.tree_detail.heading("MuavinKodu", text="Alt Hesap"); self.tree_detail.column("MuavinKodu", width=90, anchor="w")
        self.tree_detail.heading("MuavinAdi", text="Alt Hesap Adı"); self.tree_detail.column("MuavinAdi", width=150, anchor="w")
        self.tree_detail.heading("FişAçıklama", text="Fiş Açık."); self.tree_detail.column("FişAçıklama", width=150, anchor="w")
        self.tree_detail.heading("DetayAçıklama", text="Detay Açık."); self.tree_detail.column("DetayAçıklama", width=150, anchor="w")
        self.tree_detail.heading("BelgeNo", text="Belge No"); self.tree_detail.column("BelgeNo", width=90, anchor="center")
        self.tree_detail.heading("Borç", text="Borç"); self.tree_detail.column("Borç", width=90, anchor="e")
        self.tree_detail.heading("Alacak", text="Alacak"); self.tree_detail.column("Alacak", width=100, anchor="e")
        self.tree_detail.heading("Bakiye", text="Bakiye"); self.tree_detail.column("Bakiye", width=90, anchor="e")

        # Scrollbars (Right)
        sb_right_y = ttk.Scrollbar(right_frame, orient="vertical", command=self.tree_detail.yview)
        sb_right_x = ttk.Scrollbar(right_frame, orient="horizontal", command=self.tree_detail.xview)
        self.tree_detail.configure(yscrollcommand=sb_right_y.set, xscrollcommand=sb_right_x.set)

        sb_right_y.pack(side=tk.RIGHT, fill=tk.Y)
        sb_right_x.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_detail.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.tree_detail.bind("<Double-1>", self.on_right_double_click)
        # Varsayılan bağlama
        self.tree_detail.bind("<Button-3>", self.show_detail_context_menu)

        # Context Menu (Left Mizan Tree)
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="🔍 Bu Hesabın Bakiye Denetimini Yap", command=self.go_to_balance_audit_popup)
        self.context_menu.add_command(label="📈 Sıklık/Frekans Denetimi", command=self.open_correlation_audit)
        self.context_menu.add_command(label="📉 Grafik Denetimi (Yıl Boyunca)", command=self.open_chart_audit_popup)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="📈 Bakiye Dalgalanma Analizi (Dip/Zirve)", command=self.open_volatility_analysis_popup_left)

        # Sağ Panel Menüsü
        self.context_menu_detail = tk.Menu(self, tearoff=0)
        self.context_menu_detail.add_command(label="📝 Not Ekle / Risk Ata", command=self._detail_menu_add_note)
        self.context_menu_detail.add_command(label="📄 Fiş Detayını Göster", command=self._detail_menu_show_fis_detail)
        self.context_menu_detail.add_command(label="⚠️ Tüm Riskleri Göster", command=self._detail_menu_show_all_risks)
        self.context_menu_detail.add_separator()
        self.context_menu_detail.add_command(label="🧩 Aynı Fiş Yapısını Sorgula", command=self._detail_menu_query_same_signature)
        self.context_menu_detail.add_command(label="🔎 Belge Göster (Fatura)", command=self.show_invoice_document)
     
        # --- NOTE MANAGER INTEGRATION ---
        if HAS_NOTES:
            try:
                self.note_manager = NoteManager(
                    self.tree_detail, 
                    "MİZAN", 
                    self, 
                    indices={'ref': 1, 'hk': 4, 'ha': 5, 'borc': 8, 'alacak': 9}, 
                    detail_callback=self.open_fis_detail_popup
                )
            except Exception as e:
                print(f"NoteManager yüklenirken hata oluştu: {e}")
                self.note_manager = None
        else:
            self.note_manager = None

        # Override right click
        try:
            try:
                self.tree_detail.unbind("<Button-3>")
            except Exception:
                pass
            self.tree_detail.bind("<Button-3>", self.show_detail_context_menu)
        except Exception as e:
            print(f"Binding override sırasında hata: {e}")

    # ---- Context menu gösterimler ----
    def show_context_menu(self, event):
        item = self.tree_mizan.identify_row(event.y)
        if item:
            self.tree_mizan.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)

    def show_detail_context_menu(self, event):
        item = self.tree_detail.identify_row(event.y)
        if item:
            self.tree_detail.selection_set(item)
            try:
                self.context_menu_detail.post(event.x_root, event.y_root)
            except Exception as e:
                print("Context menu post hatası:", e)

    # ----- Detail menu handlers ----
    def _detail_menu_add_note(self):
        sel = self.tree_detail.selection()
        if not sel:
            messagebox.showinfo("Bilgi", "Lütfen bir kayıt seçin.")
            return

        if not HAS_NOTES:
            messagebox.showinfo("Notlar", "Not Yönetimi modülü bulunamadı.")
            return

        if self.note_manager is None:
            messagebox.showerror("Hata", "Not Yöneticisi başlatılamadı (Nesne None).")
            return

        try:
            nm = self.note_manager
            # Olası fonksiyon isimlerini dene
            possible_methods = [
                'popup', 
                'open_editor', 
                'show_editor', 
                'open_note_popup', 
                'add_note', 
                'edit_note', 
                'show_gui'
            ]
            
            success = False
            for method_name in possible_methods:
                if hasattr(nm, method_name):
                    func = getattr(nm, method_name)
                    try:
                        func(self.tree_detail, sel)
                        success = True; break
                    except TypeError:
                        try:
                            func()
                            success = True; break
                        except Exception:
                            pass
            
            if not success:
                if hasattr(nm, 'color_rows'):
                    nm.color_rows()
                messagebox.showinfo("Hata", "Not yöneticisi yüklü ancak uygun açılış fonksiyonu bulunamadı.")

        except Exception as e:
            messagebox.showerror("Hata", f"Not yöneticisi işlem hatası: {e}")

    def _detail_menu_show_fis_detail(self):
        sel = self.tree_detail.selection()
        if not sel:
            messagebox.showinfo("Bilgi", "Lütfen bir kayıt seçin.")
            return
        vals = self.tree_detail.item(sel[0])['values']
        if len(vals) < 2:
            messagebox.showwarning("Uyarı", "Seçili satırdan fiş numarası alınamadı.")
            return
        fis_no = vals[1]
        self.open_fis_detail_popup(fis_no)

    def _detail_menu_show_all_risks(self):
        if HAS_NOTES and self.note_manager:
            try:
                nm = self.note_manager
                possible_dashboard_methods = ['open_dash', 'show_all_notes', 'open_notes_overview']
                success = False
                for m in possible_dashboard_methods:
                    if hasattr(nm, m):
                        getattr(nm, m)()
                        success = True
                        break
                if not success:
                    messagebox.showinfo("Risks", "Not yöneticisi yüklü; ancak genel görünüm fonksiyonu bulunamadı.")
            except Exception as e:
                messagebox.showerror("Hata", f"Not yöneticisi işlem hatası: {e}")
        else:
            messagebox.showinfo("Risks", "Not yönetimi modülü aktif değil.")

    # ------------------ AYNI FİŞ YAPISI SORGULA ------------------
    def _detail_menu_query_same_signature(self):
        sel = self.tree_detail.selection()
        if not sel:
            messagebox.showinfo("Bilgi", "Lütfen bir kayıt seçin.")
            return
        vals = self.tree_detail.item(sel[0])['values']
        if len(vals) < 2:
            messagebox.showwarning("Uyarı", "Seçili satırdan fiş numarası alınamadı.")
            return
        fis_no = vals[1]
        
        try:
            matches = self.engine.find_fis_matches_by_signature(fis_no)
        except Exception as e:
            messagebox.showerror("Hata", f"İşlem sırasında hata: {e}")
            return
            
        if not matches:
            messagebox.showinfo("Sonuç", "Aynı fiş yapısına sahip başka kayıt bulunamadı.")
            return

        popup = tk.Toplevel(self)
        popup.title(f"Aynı Yapıda Fişler - {fis_no} ({len(matches)} adet)")
        popup.geometry("1100x600")
        
        head = tk.Frame(popup, bg="#34495e", height=50); head.pack(fill=tk.X); head.pack_propagate(False)
        tk.Label(head, text=f"Aynı Yapıda Fişler ({len(matches)})", fg="white", bg="#34495e", font=("Arial", 12, "bold")).pack(side=tk.LEFT, padx=10)
        
        cols = ("YevmiyeNo", "Tarih", "Signature", "FisAciklama", "DetayAciklama", "Toplam Borç", "Toplam Alacak")
        tree = ttk.Treeview(popup, columns=cols, show="headings", style="Fis.Treeview")
        
        tree.heading("YevmiyeNo", text="Yevmiye No"); tree.column("YevmiyeNo", width=90, anchor="center")
        tree.heading("Tarih", text="Tarih"); tree.column("Tarih", width=100, anchor="center")
        tree.heading("Signature", text="Signature"); tree.column("Signature", width=200)
        tree.heading("FisAciklama", text="Fiş Açıklama"); tree.column("FisAciklama", width=250)
        tree.heading("DetayAciklama", text="Detay Açıklama"); tree.column("DetayAciklama", width=250)
        tree.heading("Toplam Borç", text="Toplam Borç"); tree.column("Toplam Borç", width=120, anchor="e")
        tree.heading("Toplam Alacak", text="Toplam Alacak"); tree.column("Toplam Alacak", width=120, anchor="e")
        
        sb_y = ttk.Scrollbar(popup, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb_y.set)
        sb_y.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        def on_match_double_click(event):
            sel_items = tree.selection()
            if not sel_items: return
            try:
                yevmiye_no = tree.item(sel_items[0])['values'][0]
                self.open_fis_detail_popup(yevmiye_no)
            except Exception as e:
                print(f"Detay açma hatası: {e}")

        tree.bind("<Double-1>", on_match_double_click)
        
        t_b, t_a = 0.0, 0.0
        for i, row in enumerate(matches):
            tag = "even" if i % 2 == 0 else "odd"
            b = float(row.get('Borç', 0)); a = float(row.get('Alacak', 0))
            t_b += b; t_a += a
            tarih = str(row.get('Tarih', ''))[:10]
            vals = (
                row.get('Yevmiye No'), 
                tarih, 
                row.get('Signature'), 
                row.get('Fiş Açıklama', ''), 
                row.get('Detay Açıklama', ''), 
                f"{b:,.2f}", 
                f"{a:,.2f}"
            )
            tree.insert("", "end", values=vals, tags=(tag,))
            
        tree.tag_configure("odd", background=CLR_ROW_ODD); tree.tag_configure("even", background=CLR_ROW_EVEN)
        
        foot = tk.Frame(popup, bg="#ecf0f1", height=40); foot.pack(fill=tk.X)
        tk.Label(foot, text=f"TOPLAM BORÇ: {t_b:,.2f}", font=("Arial", 10, "bold"), bg="#ecf0f1", fg="#c0392b").pack(side=tk.LEFT, padx=20)
        tk.Label(foot, text=f"TOPLAM ALACAK: {t_a:,.2f}", font=("Arial", 10, "bold"), bg="#ecf0f1", fg="#27ae60").pack(side=tk.LEFT, padx=20)

    # ------------------ VOLATILITY ANALYSIS POPUP ------------------
    def open_volatility_analysis_popup_left(self):
        sel = self.tree_mizan.selection()
        if not sel:
            messagebox.showinfo("Bilgi", "Lütfen bir ana hesap seçin (sol panel).")
            return
        item = self.tree_mizan.item(sel[0])
        account_code = str(item.get('text', '')).strip()
        if not account_code:
            messagebox.showwarning("Uyarı", "Seçili ana hesap için kod bulunamadı.")
            return

        try:
            results = self.engine.analyze_monthly_volatility(account_code)
        except Exception as e:
            messagebox.showerror("Hata", f"Analiz sırasında hata oluştu: {e}")
            return

        if not results:
            messagebox.showinfo("Sonuç", f"{account_code} için dip/zirve tespiti yapılmadı (veri yok).")
            return

        popup = tk.Toplevel(self)
        popup.title(f"Bakiye Dalgalanma (Dip / Zirve) - {account_code}")
        popup.geometry("1000x700")

        head = tk.Frame(popup, bg="#2c3e50", height=50); head.pack(fill=tk.X); head.pack_propagate(False)
        tk.Label(head, text=f"Bakiye Dalgalanma (Dip / Zirve) - {account_code}", fg="white", bg="#2c3e50", font=("Arial", 12, "bold")).pack(side=tk.LEFT, padx=10)

        frame_top = tk.Frame(popup)
        frame_top.pack(fill=tk.BOTH, expand=False, padx=5, pady=5)

        cols = ("Donem", "Tur", "Tarih", "YevmiyeNo", "FisAciklama", "Bakiye")
        tree = ttk.Treeview(frame_top, columns=cols, show="headings", height=8)
        tree.heading("Donem", text="Dönem"); tree.column("Donem", width=110, anchor="center")
        tree.heading("Tur", text="Tür"); tree.column("Tur", width=80, anchor="center")
        tree.heading("Tarih", text="Tarih"); tree.column("Tarih", width=100, anchor="center")
        tree.heading("YevmiyeNo", text="Yevmiye No"); tree.column("YevmiyeNo", width=110, anchor="center")
        tree.heading("FisAciklama", text="Fiş Açıklaması"); tree.column("FisAciklama", width=420, anchor="w")
        tree.heading("Bakiye", text="O Anki Bakiye"); tree.column("Bakiye", width=150, anchor="e")

        sb_y = ttk.Scrollbar(frame_top, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb_y.set)
        sb_y.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)

        tree.tag_configure("dip", background="#fdecea")
        tree.tag_configure("zirve", background="#eafaf1")

        for i, r in enumerate(results):
            tag = "dip" if r.get('type') == 'Dip' else "zirve"
            tarih = r.get('tarih')
            if hasattr(tarih, 'strftime'):
                tarih_str = tarih.strftime('%d.%m.%Y')
            else:
                tarih_str = str(tarih)[:10]
            yno = r.get('Yevmiye No', '')
            fisacik = r.get('Fiş Açıklama', '')
            bal = r.get('balance', 0.0)
            vals = (r.get('period', ''), r.get('type', ''), tarih_str, yno, fisacik, f"{bal:,.2f}")
            tree.insert("", "end", values=vals, tags=(tag,))

        def _on_vol_tree_select(event):
            sel_items = tree.selection()
            if not sel_items: return
            try:
                vals = tree.item(sel_items[0])['values']
                if len(vals) >= 4 and vals[3]:
                    fis_no = vals[3]
                    try: self.open_fis_detail_popup(fis_no)
                    except Exception: pass
            except Exception: pass

        tree.bind("<<TreeviewSelect>>", _on_vol_tree_select)
        tree.bind("<Double-1>", lambda ev: _on_vol_tree_select(ev))

        frame_chart = tk.Frame(popup, height=320, bg="white")
        frame_chart.pack(fill=tk.BOTH, expand=True, padx=5, pady=(2,8))

        if not HAS_MATPLOTLIB:
            tk.Label(frame_chart, text="Grafik gösterimi için matplotlib yüklü olmalıdır.", fg="red").pack(padx=10, pady=10)
        else:
            try:
                details = self.engine.get_details_for_account(account_code)
                points_info = []
                if details:
                    df = pd.DataFrame(details)
                    df['Tarih'] = pd.to_datetime(df['Tarih'], errors='coerce')
                    df.sort_values(by=['Tarih', 'Yevmiye No'], inplace=True)
                    df['delta'] = pd.to_numeric(df.get('Borç', 0), errors='coerce').fillna(0) - pd.to_numeric(df.get('Alacak', 0), errors='coerce').fillna(0)
                    df['running'] = df['delta'].cumsum()
                    df['period'] = df['Tarih'].dt.to_period('M').astype(str)
                    grouped = df.groupby('period')
                    x = []
                    y = []
                    for period, g in grouped:
                        last_row = g.iloc[-1]
                        bal = float(last_row.get('running', 0.0))
                        yevmiye = last_row.get('Yevmiye No', '')
                        acik = last_row.get('Fiş Açıklama', '') or last_row.get('Detay Açıklama', '') or ""
                        x.append(pd.to_datetime(period + "-01"))
                        y.append(bal)
                        points_info.append({'x': pd.to_datetime(period + "-01"), 'y': bal, 'yevmiye': yevmiye, 'aciklama': acik, 'period': period})
                else:
                    monthly = {}
                    for r in results:
                        p = r['period']
                        monthly.setdefault(p, []).append(r)
                    periods = sorted(monthly.keys())
                    x = []
                    y = []
                    for p in periods:
                        chosen = None
                        for rec in monthly[p]:
                            if rec.get('type') == 'Zirve': chosen = rec; break
                        if not chosen: chosen = monthly[p][0]
                        bal = float(chosen.get('balance', 0.0))
                        x.append(pd.to_datetime(p + "-01"))
                        y.append(bal)
                        points_info.append({'x': pd.to_datetime(p + "-01"), 'y': bal, 'yevmiye': chosen.get('Yevmiye No', ''), 'aciklama': chosen.get('Fiş Açıklama',''), 'period': p})

                fig = Figure(figsize=(10,3.2), dpi=100)
                ax = fig.add_subplot(111)
                ax.plot(x, y, linestyle='-', linewidth=1.5, marker='o')
                scatter = ax.scatter(x, y, s=60, picker=True, zorder=5)
                ax.set_title(f"{account_code} - Aylık Ay Sonu Bakiyeleri", fontsize=10)
                ax.set_xlabel("Dönem")
                ax.set_ylabel("Bakiye")
                try:
                    ax.xaxis.set_major_locator(mdates.MonthLocator())
                    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
                    fig.autofmt_xdate(rotation=25)
                except Exception:
                    pass
                ax.ticklabel_format(axis='y', style='plain')
                ax.legend([f"{len(y)} Aylık Bakiyeler"], loc='upper left')

                annot = ax.annotate("", xy=(0,0), xytext=(15,15), textcoords="offset points",
                                    bbox=dict(boxstyle="round", fc="w"), arrowprops=dict(arrowstyle="->"))
                annot.set_visible(False)

                def update_annot(ind):
                    i = ind["ind"][0]
                    info = points_info[i]
                    xval = info['x']; yval = info['y']
                    text = f"{info.get('period','')}\nYevmiye: {info.get('yevmiye','')}\nAçıklama: {str(info.get('aciklama',''))}\nBakiye: {yval:,.2f}"
                    annot.xy = (xval, yval)
                    annot.set_text(text)
                    annot.get_bbox_patch().set_alpha(0.95)

                def hover(event):
                    vis = annot.get_visible()
                    if event.inaxes == ax:
                        cont, ind = scatter.contains(event)
                        if cont:
                            update_annot(ind)
                            annot.set_visible(True)
                            fig.canvas.draw_idle()
                        else:
                            if vis: annot.set_visible(False); fig.canvas.draw_idle()

                fig.canvas.mpl_connect("motion_notify_event", hover)
                canvas = FigureCanvasTkAgg(fig, master=frame_chart)
                canvas.draw()
                widget = canvas.get_tk_widget()
                widget.pack(fill=tk.BOTH, expand=True)
            except Exception as e:
                tk.Label(frame_chart, text=f"Grafik çiziminde hata: {e}", fg="red").pack(padx=10, pady=10)

        foot = tk.Frame(popup, bg="#f8f9fa", height=40); foot.pack(fill=tk.X, side=tk.BOTTOM)
        tk.Button(foot, text="Kapat", command=popup.destroy, font=("Arial", 10)).pack(side=tk.RIGHT, padx=10, pady=6)

    # ------------------ Diğer yardımcı metotlar ------------------
    def go_to_balance_audit_popup(self):
        sel = self.tree_mizan.selection()
        if not sel: return
        full_code = self.tree_mizan.item(sel[0])['text']
        try:
            from modules.bakiye_analiz.ui import BalanceAnalizFrame
            popup = tk.Toplevel(self)
            popup.title(f"Bakiye Denetimi: {full_code}")
            popup.geometry("1200x700")
            frame = BalanceAnalizFrame(popup)
            frame.pack(fill=tk.BOTH, expand=True)
            if hasattr(frame, 'set_active_account'):
                frame.set_active_account(full_code)
            popup.focus_force()
        except ImportError:
            messagebox.showerror("Hata", "Bakiye Analiz Modülü yüklenemedi.")
        except Exception as e:
            messagebox.showerror("Hata", f"Hata: {str(e)}")

    def open_chart_audit_popup(self):
        sel = self.tree_mizan.selection()
        if not sel: return
        full_code = self.tree_mizan.item(sel[0])['text']
        try:
            from modules.grafik_denetim.ui import ChartAuditFrame
            popup = tk.Toplevel(self)
            popup.title(f"Grafik Analizi: {full_code}")
            popup.geometry("1200x700")
            frame = ChartAuditFrame(popup)
            frame.pack(fill=tk.BOTH, expand=True)
            if hasattr(frame, 'select_account'):
                frame.select_account(full_code)
            popup.focus_force()
        except ImportError:
            messagebox.showerror("Hata", "Grafik Denetim Modülü yüklenemedi.")
        except Exception as e:
            messagebox.showerror("Hata", f"Hata: {str(e)}")

    def load_mizan_tree(self):
        for item in self.tree_mizan.get_children(): self.tree_mizan.delete(item)
        summary = getattr(self.engine, 'mizan_summary', {})
        for kebir_code in sorted(summary.keys()):
            data = summary[kebir_code]
            vals = (data['name'], f"{data['borc']:,.2f}", f"{data['alacak']:,.2f}", f"{data['bakiye']:,.2f}")
            main_id = self.tree_mizan.insert("", "end", text=kebir_code, values=vals, open=False)
            for sub in data['sub_accounts']:
                sub_vals = (sub['name'], f"{sub['borc']:,.2f}", f"{sub['alacak']:,.2f}", f"{sub['bakiye']:,.2f}")
                self.tree_mizan.insert(main_id, "end", text=sub['code'], values=sub_vals)

    def on_account_select(self, event):
        sel = self.tree_mizan.selection()
        if not sel: return
        item = self.tree_mizan.item(sel[0])
        account_code = item['text']
        self.lbl_detail_header.config(text=f"Hareketler: {account_code} - {item['values'][0]}")
        self.load_details(account_code)

    def load_details(self, account_code):
        for i in self.tree_detail.get_children(): self.tree_detail.delete(i)
        rows = self.engine.get_details_for_account(account_code)
        self.current_details_list = rows
        t_b, t_a = 0.0, 0.0
        
        for i, row in enumerate(rows):
            tag = "even" if i % 2 == 0 else "odd"
            b = float(row.get('Borç', 0)); a = float(row.get('Alacak', 0))
            t_b += b; t_a += a
            
            # Kümülatif bakiyeyi de engine'deki TDHP karakter mantığına göre alıyoruz
            gosterilecek_r_b = self.engine.bakiye_hesapla(account_code, t_b, t_a)
            
            # --- GÜNCELLEME: Belge No Eklendi ---
            vals = (str(row.get('Tarih', ''))[:10], int(row.get('Yevmiye No', 0)),
                    row.get('Belge No', ''),
                    row.get('Kebir Kodu', ''), row.get('Kebir Adı', ''),
                    row.get('Muavin Kodu', ''), row.get('Muavin Adı', ''),
                    row.get('Fiş Açıklama', ''), row.get('Detay Açıklama', ''), 
                    f"{b:,.2f}", f"{a:,.2f}", f"{gosterilecek_r_b:,.2f}")
            self.tree_detail.insert("", "end", values=vals, tags=(tag,))
        # ... (Fonksiyonun kalanı aynı)
        
        self.tree_detail.tag_configure("odd", background=CLR_TREE_STRIPE)
        self.tree_detail.tag_configure("even", background="white")
        
        # --- GÜNCELLENEN KISIM: ÜST SAĞ KÖŞE ETİKETLERİ ---
        # Üst başlıktaki genel bakiye için de aynı fonksiyonu çağır
        son_bakiye = self.engine.bakiye_hesapla(account_code, t_b, t_a)
        
        self.lbl_top_count.config(text=f"[{len(rows)} Kayıt]")
        self.lbl_top_borc.config(text=f"BORÇ: {t_b:,.2f}")
        self.lbl_top_alacak.config(text=f"ALACAK: {t_a:,.2f}")
        self.lbl_top_bakiye.config(text=f"BAKİYE: {son_bakiye:,.2f}")
        # --------------------------------------------------
        
        if HAS_NOTES and self.note_manager:
            try: self.note_manager.color_rows()
            except Exception: pass

    def open_correlation_audit(self):
        sel = self.tree_mizan.selection()
        if not sel: return
        account_code = self.tree_mizan.item(sel[0])['text']
        results, msg = self.engine.analyze_account_correlation(account_code)
        if not results: messagebox.showinfo("Bilgi", msg); return
        popup = tk.Toplevel(self)
        popup.title(f"Sıklık Denetimi - {account_code}"); popup.geometry("800x500")
        tk.Label(popup, text=f"{account_code} İLE ÇALIŞAN HESAPLAR", font=("Arial", 11, "bold"), bg="#f39c12", fg="white", pady=10).pack(fill=tk.X)
        cols = ("Kod1", "Ad1", "Tekrar", "Kod2", "Ad2")
        tree = ttk.Treeview(popup, columns=cols, show="headings")
        tree.column("Kod1", width=80); tree.heading("Kod1", text="Hesap")
        tree.column("Ad1", width=150); tree.heading("Ad1", text="Adı")
        tree.column("Tekrar", width=80, anchor="center"); tree.heading("Tekrar", text="Ortak Fiş")
        tree.column("Kod2", width=80); tree.heading("Kod2", text="Karşı Hesap")
        tree.column("Ad2", width=150); tree.heading("Ad2", text="Karşı Adı")
        tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        for r in results: tree.insert("", "end", values=(r['HesapKodu1'], r['HesapAdı1'], r['TekrarSayisi'], r['HesapKodu2'], r['HesapAdı2']))
        
        def on_corr_select(event):
            sel_item = tree.selection()
            if not sel_item: return
            vals = tree.item(sel_item[0])['values']
            code2 = vals[3]
            self.lbl_detail_header.config(text=f"FİLTRE: {account_code} <-> {code2} Ortak Fişleri", fg="#F39C12")
            
            rows = self.engine.get_shared_journals_unique(str(account_code), str(code2))
            for i in self.tree_detail.get_children(): self.tree_detail.delete(i)
            
            t_b, t_a = 0.0, 0.0
            for row in rows:
                b = float(row.get('Borç', 0)); a = float(row.get('Alacak', 0))
                t_b += b; t_a += a
                tarih = str(row.get('Tarih', ''))[:10]; fis_acik = row.get('Fiş Açıklama', '')
                vals = (tarih, int(row['Yevmiye No']), "", "", "", "", fis_acik, "TOPLAM", f"{b:,.2f}", f"{a:,.2f}", "0.00")
                self.tree_detail.insert("", "end", values=vals)
                
            # --- FİLTRE SONRASI ÜST TOPLAMLAR GÜNCELLEMESİ ---
            self.lbl_top_count.config(text=f"[{len(rows)} Kayıt]")
            self.lbl_top_borc.config(text=f"BORÇ: {t_b:,.2f}")
            self.lbl_top_alacak.config(text=f"ALACAK: {t_a:,.2f}")
            self.lbl_top_bakiye.config(text=f"BAKİYE: {t_b-t_a:,.2f}")
            # -------------------------------------------------

        tree.bind("<<TreeviewSelect>>", on_corr_select)

    def export_ana_mizan(self):
        file_path = filedialog.asksaveasfilename(
            title="Ana Mizanı Kaydet",
            defaultextension=".xlsx",
            filetypes=[("Excel Dosyaları", "*.xlsx"), ("Tüm Dosyalar", "*.*")],
            initialfile="Ana_Mizan.xlsx"
        )
        if file_path:  # Kullanıcı iptal butonuna basmadıysa
            # Not: engine.py içindeki bu metodun 'filepath' parametresi alacak şekilde güncellenmesi gerekir
            self._msg(self.engine.export_ana_mizan(filepath=file_path))

    def export_muavin_mizan(self):
        file_path = filedialog.asksaveasfilename(
            title="Muavin Mizanı Kaydet",
            defaultextension=".xlsx",
            filetypes=[("Excel Dosyaları", "*.xlsx"), ("Tüm Dosyalar", "*.*")],
            initialfile="Muavin_Mizan.xlsx"
        )
        if file_path:
            self._msg(self.engine.export_muavin_mizan(filepath=file_path))

    def export_right_panel(self):
        file_path = filedialog.asksaveasfilename(
            title="Hesap Hareketlerini Kaydet",
            defaultextension=".xlsx",
            filetypes=[("Excel Dosyaları", "*.xlsx"), ("Tüm Dosyalar", "*.*")],
            initialfile="Hesap_Hareketleri.xlsx"
        )
        if file_path:
            self._msg(self.engine.export_right_panel(self.current_details_list, filepath=file_path))

    def _msg(self, res):
        s, m = res
        if s: messagebox.showinfo("Başarılı", m)
        else: messagebox.showerror("Hata", m)

    def on_right_double_click(self, event):
        sel = self.tree_detail.selection()
        if not sel: return
        vals = self.tree_detail.item(sel[0])['values']
        self.open_fis_detail_popup(vals[1])


    def open_fis_detail_popup(self, fis_no):
        # 1- BİRDEN FAZLA PENCERE AÇILMASINI ENGELLEME
        if hasattr(self, '_fis_popup') and self._fis_popup.winfo_exists():
            self._fis_popup.destroy()

        items = self.engine.get_fis_details(fis_no)
        if not items:
            messagebox.showinfo("Bilgi", f"{fis_no} numaralı fiş için detay bulunamadı.")
            return
            
        popup = tk.Toplevel(self)
        self._fis_popup = popup # Sınıfa referansı kaydet
        
        popup.title(f"Fiş Detayı - No: {fis_no}")
        popup.geometry("1100x600")
        popup.configure(bg="white")
        
        head = tk.Frame(popup, bg=CLR_FIS_HEADER_BG, height=60)
        head.pack(fill=tk.X)
        head.pack_propagate(False)
        
        date_str = items[0].get('Tarih', '-') if 'Tarih' in items[0] else '-'
        if hasattr(date_str, 'strftime'): date_str = date_str.strftime('%d.%m.%Y')
        
        tk.Label(head, text=f"FİŞ NO: {fis_no}", bg=CLR_FIS_HEADER_BG, fg="white", font=("Arial", 16, "bold")).pack(side=tk.LEFT, padx=20)
        tk.Label(head, text=f"TARİH: {date_str}", bg=CLR_FIS_HEADER_BG, fg="white", font=("Arial", 14, "bold")).pack(side=tk.RIGHT, padx=20)
        
        # 2- İKİ YÖNLÜ SCROLL İÇİN CONTAINER OLUŞTURMA
        tree_frame = tk.Frame(popup, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # --- GÜNCELLEME: Muavin Kodu ve Adı Sütunları Eklendi ---
        cols = ("Ref", "KebirKodu", "KebirAdı", "MuavinKodu", "MuavinAdı", "FisAciklama", "DetayAciklama", "Borc", "Alacak")
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", style="Fis.Treeview")
        
        tree.column("Ref", width=0, stretch=False)
        tree.column("KebirKodu", width=80); tree.heading("KebirKodu", text="Kebir Kodu")
        tree.column("KebirAdı", width=150); tree.heading("KebirAdı", text="Kebir Adı")
        
        tree.column("MuavinKodu", width=100); tree.heading("MuavinKodu", text="Muavin Kodu")
        tree.column("MuavinAdı", width=200); tree.heading("MuavinAdı", text="Muavin Adı")
        
        tree.column("FisAciklama", width=180); tree.heading("FisAciklama", text="Fiş Açıklama")
        tree.column("DetayAciklama", width=180); tree.heading("DetayAciklama", text="Detay Açıklama")
        tree.column("Borc", width=100, anchor="e"); tree.heading("Borc", text="Borç")
        tree.column("Alacak", width=100, anchor="e"); tree.heading("Alacak", text="Alacak")
        
        # Scrollbar Tanımlamaları (Dikey ve Yatay)
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Grid Sistemi ile Container İçine Yerleştirme
        tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        # Container'ın esnemesi için grid yapılandırması
        tree_frame.grid_columnconfigure(0, weight=1)
        tree_frame.grid_rowconfigure(0, weight=1)
        
        t_b, t_a = 0.0, 0.0
        for i, it in enumerate(items):
            tag = "even" if i % 2 == 0 else "odd"
            b = float(it.get('Borç', 0)); a = float(it.get('Alacak', 0))
            t_b += b; t_a += a
            
            h_kod = it.get('Kebir Kodu', '')
            h_adi = it.get('Kebir Adı', '')
            m_kod = it.get('Muavin Kodu', it.get('Hesap Kodu', '')) # Veri tabanına göre fallback yapıldı
            m_adi = it.get('Muavin Adı', it.get('Hesap Adı', ''))
            
            vals = (fis_no, h_kod, h_adi, m_kod, m_adi, it.get('Fiş Açıklama',''), it.get('Detay Açıklama',''), f"{b:,.2f}", f"{a:,.2f}")
            tree.insert("", "end", values=vals, tags=(tag,))
            
        tree.tag_configure("odd", background=CLR_ROW_ODD); tree.tag_configure("even", background=CLR_ROW_EVEN)
        
        if HAS_NOTES:
            try:
                # DİKKAT: Sütunlar arttığı için Borç(7) ve Alacak(8) indeksleri güncellendi
                popup_notes = NoteManager(tree, "YEVMİYE", popup, indices={'ref':0, 'hk':3, 'ha':4, 'borc':7, 'alacak':8})
                popup_notes.color_rows()
            except Exception:
                pass
                
        foot = tk.Frame(popup, bg="#f8f9fa", height=40); foot.pack(fill=tk.X, side=tk.BOTTOM)
        tk.Label(foot, text=f"TOPLAM BORÇ: {t_b:,.2f}", fg="#c0392b", font=("Arial",10,"bold"), bg="#f8f9fa").pack(side=tk.LEFT, padx=20)
        tk.Label(foot, text=f"TOPLAM ALACAK: {t_a:,.2f}", fg="#27ae60", font=("Arial",10,"bold"), bg="#f8f9fa").pack(side=tk.LEFT, padx=20)
        diff = t_b - t_a; d_txt = f"✅ FİŞ DENGEDE" if abs(diff) < 0.01 else f"⚠️ BAKİYE FARKI: {diff:,.2f}"; d_clr = "green" if abs(diff) < 0.01 else "red"
        tk.Label(foot, text=d_txt, fg=d_clr, font=("Arial", 12, "bold"), bg="#f8f9fa").pack(side=tk.RIGHT, padx=30)

    def focus_on_record(self, row_ref, account_code=None):
        if account_code:
            found = False
            for main in self.tree_mizan.get_children():
                if self.tree_mizan.item(main, "text") == str(account_code):
                    self.tree_mizan.selection_set(main); self.tree_mizan.see(main); found=True
                else:
                    for sub in self.tree_mizan.get_children(main):
                        if self.tree_mizan.item(sub, "text") == str(account_code):
                            self.tree_mizan.item(main, open=True); self.tree_mizan.selection_set(sub); self.tree_mizan.see(sub); found=True
                if found: self.on_account_select(None); break
        for child in self.tree_detail.get_children():
            if str(self.tree_detail.item(child)['values'][1]) == str(row_ref):
                self.tree_detail.selection_set(child); self.tree_detail.see(child); self.tree_detail.focus(child); break
            # =========================================================================
    # --- FATURA GÖRÜNTÜLEME FONKSİYONLARI (ÖRNEK.PY'DEN UYARLANDI) ---
    # =========================================================================

    # =========================================================================
    # --- FATURA GÖRÜNTÜLEME FONKSİYONLARI (GÜNCELLENMİŞ - KAPSAMLI ARAMA) ---
    # =========================================================================

    def show_invoice_document(self):
        """
        Seçili satırdaki Belge No, Fiş Açıklama ve Detay Açıklama alanlarını alır,
        veritabanındaki FATURA_NO'ları bu metinlerin içinde arar ve eşleşen 
        faturayı DataFrame formatında görüntüleyiciye gönderir.
        """
        if FaturaGoruntulePopup is None:
            messagebox.showerror("Hata", "Fatura görüntüleme modülü (ui_goruntule) yüklenemedi.")
            return

        sel = self.tree_detail.selection()
        if not sel: 
            messagebox.showinfo("Bilgi", "Lütfen listeden bir kayıt seçin.")
            return
        
        vals = self.tree_detail.item(sel[0])['values']
        
        # Sütun sırasına göre ilgili alanları alıyoruz 
        # (MizanUI'de: 2->BelgeNo, 7->FişAçıklama, 8->DetayAçıklama)
        try:
            belge_no = str(vals[2]).strip()
            fis_aciklama = str(vals[7]).strip()
            detay_aciklama = str(vals[8]).strip()
        except IndexError:
            messagebox.showerror("Hata", "Tablo sütunları okunamadı.")
            return

        # 1. Veritabanından Faturayı Çek
        df_fatura = self.fetch_invoice_from_db(belge_no, fis_aciklama, detay_aciklama)

        if df_fatura is not None and not df_fatura.empty:
            # 2. Görüntüleyiciyi Aç (DataFrame gönderiyoruz)
            try:
                target_master = self.winfo_toplevel()
                FaturaGoruntulePopup(target_master, df_fatura)
            except Exception as e:
                messagebox.showerror("Hata", f"Görüntüleyici açılırken hata oluştu:\n{e}")
        else:
            messagebox.showinfo("Sonuç", "Seçili kaydın Belge No veya açıklamalarında veritabanındaki bir fatura numarası bulunamadı.")

    def fetch_invoice_from_db(self, belge_no, fis_aciklama, detay_aciklama):
        """
        Aktif oturumun veritabanına bağlanır. Fatura Numarasını:
        1- Doğrudan BelgeNo'ya eşit mi diye kontrol eder.
        2- Eşit değilse, birleştirilmiş açıklamalar metni İÇİNDE geçiyor mu diye bakar.
        """
        try:
            # Oturum bilgilerini al
            session = get_last_session()
            if not session or not session.get('vkn'): 
                return None
            
            vkn = session.get('vkn')
            yil = session.get('yil')
            
            # Veritabanı yolunu bul
            try:
                base_dir = get_mukellefler_dir()
            except:
                return None

            target_folder = None
            if os.path.exists(base_dir):
                for f in os.listdir(base_dir):
                    if f.endswith(f"-{vkn}") and os.path.isdir(os.path.join(base_dir, f)):
                        target_folder = os.path.join(base_dir, f)
                        break
            
            if not target_folder: 
                return None

            db_path = os.path.join(target_folder, str(yil), f"fatura_data_{yil}.db")
            if not os.path.exists(db_path): 
                return None

            conn = sqlite3.connect(db_path)
            
            # Tüm metinleri birleştirip büyük harfe çeviriyoruz (Arama kolaylığı için)
            aranacak_metin = f"{belge_no} {fis_aciklama} {detay_aciklama}".replace('i', 'İ').replace('ı', 'I').upper()
            
            # SQL Sorgusu: Sütun adını NO_FATURA olarak düzelttik
            query = """
                SELECT * FROM FATURALAR 
                WHERE NO_FATURA = ? 
                   OR (
                       NO_FATURA IS NOT NULL 
                       AND LENGTH(NO_FATURA) > 4 
                       AND INSTR(?, UPPER(NO_FATURA)) > 0
                   )
            """
            
            # Pandas ile oku
            df = pd.read_sql(query, conn, params=(belge_no, aranacak_metin))
            conn.close()
            
            # Eğer açıklama içinde birden fazla fatura geçiyorsa, sadece ilk tespit edilen faturanın detaylarını göster
            if not df.empty:
                ilk_fatura_no = df.iloc[0]['NO_FATURA']
                df = df[df['NO_FATURA'] == ilk_fatura_no]
            
            return df

        except Exception as e:
            print(f"Fatura DB Sorgu Hatası: {e}")
            return None
        


    def find_and_extract_xml(self, zip_path, target_filename, dest_dir):
        """ZIP içinden XML dosyasını bulup çıkarır."""
        def search_in_zip(current_zip, target_name):
            for name in current_zip.namelist():
                if os.path.basename(name) == target_name:
                    return current_zip.read(name)
            for name in current_zip.namelist():
                if name.lower().endswith('.zip'):
                    try:
                        nested_data = io.BytesIO(current_zip.read(name))
                        with zipfile.ZipFile(nested_data) as nested_z:
                            result = search_in_zip(nested_z, target_name)
                            if result: return result
                    except: continue
            return None

        try:
            with zipfile.ZipFile(zip_path, 'r') as z:
                content = search_in_zip(z, target_filename)
                if content:
                    target_path = os.path.join(dest_dir, target_filename)
                    with open(target_path, 'wb') as f:
                        f.write(content)
                    return target_path
        except Exception as e:
            print(f"ZIP Hatası: {e}")
        return None