import os
import multiprocessing
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# LXML ve Webview kontrolü
try:
    import lxml.etree as le
    import webview
    KUTUPHANELER_TAMAM = True
except ImportError:
    KUTUPHANELER_TAMAM = False

try:
    from parser import parse_single_invoice_content
except ImportError:
    print("[HATA] faturaparser.py bulunamadı!")
    exit()

# --- SİHİRLİ KISIM: GİB ŞABLONU KODUN İÇİNE GÖMÜLDÜ ---
# --- SİHİRLİ KISIM: GİB ŞABLONU KODUN İÇİNE GÖMÜLDÜ ---
STANDART_GIB_XSLT = """<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:n1="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
    xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
    xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
    xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">

    <xsl:output method="html" encoding="UTF-8" indent="yes"/>

    <xsl:template match="/">
        <xsl:apply-templates select="//n1:Invoice"/>
    </xsl:template>

    <xsl:template match="n1:Invoice">
        <html>
            <head>
                <title>e-Fatura - GİB Standart Formatı</title>
                <style type="text/css">
                    body { font-family: 'Tahoma', "Times New Roman", Times, serif; font-size: 11px; color: #333; background-color: #FFF; margin: 30px; }
                    table { border-collapse: collapse; width: 100%; }
                    td, th { border: 1px solid black; padding: 4px; font-size: 11px; }
                    .no-border, .no-border td { border: none; }
                    .header-title { font-size: 1.4em; font-weight: bold; text-align: center; font-family: Arial, sans-serif; margin-top:5px; display:block;}
                    .gib-logo { width: 95px; }
                    .info-table { width: 260px; float: right; border: 2px solid gray; }
                    .info-table td { border: 1px solid gray; padding: 3px; }
                    .totals-table { width: 35%; float: right; margin-top: 15px; border: 2px solid black; }
                    .totals-table td { border: 1px solid black; padding: 4px; }
                    .notes-box { border: 2px solid black; padding: 10px; margin-top: 20px; width: 100%; }
                    hr { border: 1px solid black; }
                </style>
            </head>
            <body>
                <table class="no-border" width="100%">
                    <tr>
                        <td width="40%" valign="top">
                            <hr/>
                            <b><xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name"/></b><br/><br/>
                            <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName"/> / <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName"/><br/>
                            Vergi Dairesi: <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme/cbc:Name"/><br/>
                            VKN/TCKN: <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID"/><br/>
                            <hr/>
                        </td>
                        <td width="20%" align="center" valign="middle">
                            <img src="gib_logo.png" class="gib-logo" alt="GİB Logo"/><br/>
                            <span class="header-title">e-FATURA</span>
                        </td>
                        <td width="40%" valign="top"></td>
                    </tr>
                    <tr>
                        <td valign="top">
                            <br/><hr/>
                            <b>SAYIN</b><br/>
                            <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name"/><br/>
                            <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:StreetName"/><br/>
                            <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName"/> / <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:CityName"/><br/>
                            Vergi Dairesi: <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme/cbc:Name"/><br/>
                            VKN/TCKN: <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PartyIdentification/cbc:ID"/>
                            <br/><hr/>
                        </td>
                        <td colspan="2" valign="bottom">
                            <table class="info-table">
                                <tr><td><b>Özelleştirme No:</b></td><td><xsl:value-of select="cbc:CustomizationID"/></td></tr>
                                <tr><td><b>Senaryo:</b></td><td><xsl:value-of select="cbc:ProfileID"/></td></tr>
                                <tr><td><b>Fatura Tipi:</b></td><td><xsl:value-of select="cbc:InvoiceTypeCode"/></td></tr>
                                <tr><td><b>Fatura No:</b></td><td><xsl:value-of select="cbc:ID"/></td></tr>
                                <tr><td><b>Fatura Tarihi:</b></td><td><xsl:value-of select="cbc:IssueDate"/></td></tr>
                            </table>
                        </td>
                    </tr>
                </table>

                <br/>
                <b>ETTN:</b> <xsl:value-of select="cbc:UUID"/><br/><br/>

                <table border="1" style="border: 2px solid black;">
                    <tr style="background-color: #ffffff; font-weight: bold; text-align: center;">
                        <td width="4%">Sıra No</td>
                        <td width="25%">Mal Hizmet</td>
                        <td width="8%">Miktar</td>
                        <td width="8%">Birim Fiyat</td>
                        <td width="8%">İskonto Oranı</td>
                        <td width="8%">İskonto Tutarı</td>
                        <td width="7%">KDV Oranı</td>
                        <td width="9%">KDV Tutarı</td>
                        <td width="13%">Diğer Vergiler</td>
                        <td width="10%">Mal Hizmet Tutarı</td>
                    </tr>
                    <xsl:for-each select="cac:InvoiceLine">
                        <tr>
                            <td align="center"><xsl:value-of select="cbc:ID"/></td>
                            <td><xsl:value-of select="cac:Item/cbc:Name"/></td>
                            <td align="right"><xsl:value-of select="cbc:InvoicedQuantity"/> <xsl:value-of select="cbc:InvoicedQuantity/@unitCode"/></td>
                            <td align="right"><xsl:value-of select="cac:Price/cbc:PriceAmount"/> TL</td>
                            <td align="right"></td>
                            <td align="right"></td>
                            <td align="right">%<xsl:value-of select="cac:TaxTotal/cac:TaxSubtotal/cbc:Percent"/></td>
                            <td align="right"><xsl:value-of select="cac:TaxTotal/cac:TaxSubtotal/cbc:TaxAmount"/> TL</td>
                            <td align="right" style="font-size: 9px; color: gray;">
                                <xsl:for-each select="cac:WithholdingTaxTotal/cac:TaxSubtotal">
                                    TEVKİFAT (%<xsl:value-of select="cbc:Percent"/>) = <xsl:value-of select="cbc:TaxAmount"/> TL<br/>
                                </xsl:for-each>
                            </td>
                            <td align="right"><xsl:value-of select="cbc:LineExtensionAmount"/> TL</td>
                        </tr>
                    </xsl:for-each>
                </table>

                <table class="totals-table">
                    <tr><td width="60%"><b>Mal Hizmet Toplam Tutarı</b></td><td align="right" width="40%"><xsl:value-of select="cac:LegalMonetaryTotal/cbc:LineExtensionAmount"/> TL</td></tr>
                    <tr><td><b>Toplam İskonto</b></td><td align="right"><xsl:value-of select="cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount"/> TL</td></tr>
                    <xsl:for-each select="cac:TaxTotal[1]/cac:TaxSubtotal">
                        <tr><td><b>Hesaplanan KDV (%<xsl:value-of select="cbc:Percent"/>)</b></td><td align="right"><xsl:value-of select="cbc:TaxAmount"/> TL</td></tr>
                    </xsl:for-each>
                    <xsl:if test="cac:WithholdingTaxTotal">
                        <tr><td><b>Hesaplanan KDV Tevkifat</b></td><td align="right"><xsl:value-of select="cac:WithholdingTaxTotal/cbc:TaxAmount"/> TL</td></tr>
                    </xsl:if>
                    <tr><td><b>Vergiler Dahil Toplam Tutar</b></td><td align="right"><xsl:value-of select="cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount"/> TL</td></tr>
                    <tr><td><b>Ödenecek Tutar</b></td><td align="right"><xsl:value-of select="cac:LegalMonetaryTotal/cbc:PayableAmount"/> TL</td></tr>
                </table>

                <div style="clear: both;"></div>

                <div class="notes-box">
                    <xsl:for-each select="cbc:Note">
                        <b>Not: </b><xsl:value-of select="."/><br/>
                    </xsl:for-each>
                </div>
            </body>
        </html>
    </xsl:template>
</xsl:stylesheet>
"""



# --- WEBVIEW İÇİN BAĞIMSIZ FONKSİYON ---
def gib_gorselini_baslat(pencere_basligi, html_dosya_yolu):
    webview.create_window(pencere_basligi, url=html_dosya_yolu, width=1100, height=800)
    webview.start()

class GIBTestArayuzu:
    def __init__(self, root):
        self.root = root
        self.root.title("GİB E-Fatura Veri & Görsel Test Aracı (Denetim Formatı)")
        self.root.geometry("1250x700")
        self.root.config(bg="#f4f7f6")
        
        self.secili_xml_yolu = None

        # --- ÜST PANEL ---
        ust_frame = tk.Frame(self.root, bg="#ffffff", pady=15, relief=tk.RAISED, borderwidth=1)
        ust_frame.pack(fill=tk.X, padx=10, pady=10)

        self.btn_sec = tk.Button(ust_frame, text="📂 1. XML Seç ve Veriyi Çek", command=self.dosya_sec_ve_oku, 
                                 font=("Segoe UI", 11, "bold"), bg="#2980b9", fg="white", padx=15, pady=8)
        self.btn_sec.pack(side=tk.LEFT, padx=15)

        self.btn_gorsel = tk.Button(ust_frame, text="👁️ 2. Standart GİB Formatında Aç", command=self.orijinal_gorseli_ac, 
                                 font=("Segoe UI", 11, "bold"), bg="#d35400", fg="white", padx=15, pady=8, state=tk.DISABLED)
        self.btn_gorsel.pack(side=tk.LEFT, padx=10)

        self.lbl_bilgi = tk.Label(ust_frame, text="Bekleniyor... Test etmek için XML seçin.", 
                                  font=("Segoe UI", 10), bg="#ffffff", fg="#7f8c8d")
        self.lbl_bilgi.pack(side=tk.LEFT, padx=20)

        # --- TABLO PANELİ ---
        tablo_frame = tk.Frame(self.root)
        tablo_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        scroll_y = ttk.Scrollbar(tablo_frame, orient=tk.VERTICAL)
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        scroll_x = ttk.Scrollbar(tablo_frame, orient=tk.HORIZONTAL)
        scroll_x.pack(side=tk.BOTTOM, fill=tk.X)

        self.tablo = ttk.Treeview(tablo_frame, yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self.tablo.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scroll_y.config(command=self.tablo.yview)
        scroll_x.config(command=self.tablo.xview)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview.Heading", font=('Segoe UI', 9, 'bold'), background="#ecf0f1", foreground="#2c3e50")
        style.configure("Treeview", font=('Segoe UI', 9), rowheight=25)
        style.map('Treeview', background=[('selected', '#3498db')])

    def dosya_sec_ve_oku(self):
        xml_yolu = filedialog.askopenfilename(
            title="GİB XML Faturası Seçin",
            filetypes=[("XML Dosyaları", "*.xml")]
        )
        if not xml_yolu: return

        self.secili_xml_yolu = xml_yolu
        self.lbl_bilgi.config(text=f"Analiz ediliyor: {os.path.basename(xml_yolu)}...", fg="#e67e22")
        self.root.update()

        try:
            with open(xml_yolu, 'rb') as f:
                xml_content = f.read()
                
            satirlar = parse_single_invoice_content(xml_content, os.path.basename(xml_yolu))
            
            if not satirlar:
                messagebox.showwarning("Uyarı", "XML'den veri çıkarılamadı.")
                return

            self.tabloyu_doldur(satirlar)
            self.lbl_bilgi.config(text=f"Başarılı! {len(satirlar)} kalem yüklendi.", fg="#27ae60")
            
            if KUTUPHANELER_TAMAM:
                self.btn_gorsel.config(state=tk.NORMAL)

        except Exception as e:
            messagebox.showerror("Hata", f"Veri çekilirken hata oluştu:\n{e}")

    def tabloyu_doldur(self, veri_listesi):
        self.tablo.delete(*self.tablo.get_children())
        if not veri_listesi: return

        sutunlar = list(veri_listesi[0].keys())
        self.tablo['columns'] = sutunlar
        self.tablo['show'] = 'headings'

        for col in sutunlar:
            self.tablo.heading(col, text=col)
            if col in ["MAL_HIZMET_CINSI", "SATICI_KURUM", "ALICI_KURUM"]:
                self.tablo.column(col, width=280, anchor=tk.W)
            elif "UUID" in col:
                self.tablo.column(col, width=250, anchor=tk.CENTER)
            else:
                self.tablo.column(col, width=130, anchor=tk.E if "TUTAR" in col or "MATRAH" in col or "ORAN" in col else tk.CENTER)

        for satir in veri_listesi:
            degerler = [satir.get(col, "") for col in sutunlar]
            self.tablo.insert("", tk.END, values=degerler)

    def orijinal_gorseli_ac(self):
        try:
            # 1. Ham XML Faturasını Oku
            dom = le.parse(self.secili_xml_yolu)
            
            # 2. İçine gömdüğümüz STANDART_GIB_XSLT şablonunu hazırla
            xslt_root = le.XML(STANDART_GIB_XSLT.encode('utf-8'))
            transform = le.XSLT(xslt_root)

            # 3. İkisini birleştirip HTML üret
            newdom = transform(dom)
            html_icerik = str(newdom)

            # 4. HTML'i geçici olarak projenin içine yaz ki 'gib_logo.png' resmini görebilsin
            proje_dizini = os.path.dirname(os.path.abspath(__file__))
            html_dosya_yolu = os.path.join(proje_dizini, "gecici_fatura_gorunumu.html")
            
            with open(html_dosya_yolu, "w", encoding="utf-8") as f:
                f.write(html_icerik)

            # 5. Görüntüleyiciyi ayrı bir işlem (Process) olarak başlat
            pencere_basligi = f"GİB Fatura (VDK Formatı) - {os.path.basename(self.secili_xml_yolu)}"
            p = multiprocessing.Process(target=gib_gorselini_baslat, args=(pencere_basligi, html_dosya_yolu))
            p.start()

        except Exception as e:
            messagebox.showerror("Görsel Hatası", f"HTML oluşturulurken hata:\n{e}")

if __name__ == "__main__":
    multiprocessing.freeze_support()
    root = tk.Tk()
    app = GIBTestArayuzu(root)
    root.mainloop()