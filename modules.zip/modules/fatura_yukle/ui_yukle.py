import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinterdnd2 import DND_FILES
import os
import pandas as pd
import threading
import queue  # Thread'den ana ekrana veri taşımak için
from config import CLR_BODY_BG, CLR_ACCENT, CLR_DROP_BG, CLR_BTN_BG, CLR_BTN_FG
from .engine import toplu_fatura_oku, faturayi_veritabanina_kaydet
import concurrent.futures
import multiprocessing
import tkinter.scrolledtext as st
from .engine import toplu_fatura_iptal_et  # engine.py'den yeni fonksiyonu import et

class FaturaIptalPenceresi(tk.Toplevel):
    def __init__(self, master, vkn, yil):
        super().__init__(master)
        self.vkn = vkn
        self.yil = yil
        
        self.title("❌ Toplu Fatura İptal Girişi")
        self.geometry("450x550")
        self.configure(bg=CLR_BODY_BG)
        self.resizable(False, False)
        
        # Ana pencerenin ortasında açılmasını sağla
        self.update_idletasks()
        x = master.winfo_x() + (master.winfo_width() // 2) - (450 // 2)
        y = master.winfo_y() + (master.winfo_height() // 2) - (550 // 2)
        self.geometry(f"+{x}+{y}")
        
        self.transient(master)
        self.grab_set() # Kullanıcı bu ekranı kapatmadan ana ekrana tıklayamaz
        
        self.setup_ui()
        
    def setup_ui(self):
        tk.Label(self, text="İptal Edilecek ETTN Numaraları", 
                 font=("Segoe UI", 14, "bold"), bg=CLR_BODY_BG, fg="#2c3e50").pack(pady=(20, 5))
                 
        tk.Label(self, text="Her satıra bir ETTN gelecek şekilde listeyi aşağıya yapıştırın:", 
                 bg=CLR_BODY_BG, fg="gray", font=("Segoe UI", 10)).pack(pady=(0, 10))
        
        # Çok satırlı metin kutusu
        self.txt_ettn = st.ScrolledText(self, width=45, height=20, font=("Consolas", 9))
        self.txt_ettn.pack(padx=20, pady=5)
        
        # Butonlar
        btn_frame = tk.Frame(self, bg=CLR_BODY_BG)
        btn_frame.pack(fill=tk.X, padx=20, pady=15)
        
        tk.Button(btn_frame, text="KAPAT", command=self.destroy,
                  bg="#95a5a6", fg="white", font=("Segoe UI", 11, "bold"), 
                  pady=8, bd=0, cursor="hand2").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
                  
        tk.Button(btn_frame, text="🚫 İPTAL OLARAK İŞARETLE", command=self.iptal_kaydet,
                  bg="#e74c3c", fg="white", font=("Segoe UI", 11, "bold"), 
                  pady=8, bd=0, cursor="hand2").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))

    def iptal_kaydet(self):
        icerik = self.txt_ettn.get("1.0", tk.END).strip()
        
        if not icerik:
            messagebox.showwarning("Eksik Veri", "Lütfen en az bir ETTN numarası girin.")
            return
            
        # Boş satırları temizleyip listeye çeviriyoruz
        ettn_listesi = [satir.strip() for satir in icerik.split('\n') if satir.strip()]
        
        onay = messagebox.askyesno("Onay", f"Toplam {len(ettn_listesi)} adet ETTN tespit edildi.\nBu faturaların Tip bilgisi 'IPTAL' olarak güncellenecek. Onaylıyor musunuz?")
        
        if onay:
            try:
                guncellenen_sayi = toplu_fatura_iptal_et(ettn_listesi, vkn=self.vkn, yil=self.yil)
                messagebox.showinfo("Başarılı", f"İşlem Tamamlandı!\n\nVeritabanında bulunup güncellenen fatura sayısı: {guncellenen_sayi}")
                self.destroy()
            except Exception as e:
                messagebox.showerror("Veritabanı Hatası", f"Güncelleme sırasında hata oluştu:\n{e}")

class FaturaYukleFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.master = master
        self.df_fatura = pd.DataFrame()
        self.queue = queue.Queue()  # Thread iletişimi için kuyruk
        self.setup_ui()

    def setup_ui(self):
        # Başlık
        tk.Label(self, text="📄 E-FATURA YÜKLEME VE ANALİZ", 
                 font=("Segoe UI", 16, "bold"), bg=CLR_BODY_BG, fg="#2c3e50").pack(pady=(20, 15))
        
        # --- DROP ZONE ---
        self.drop_canvas = tk.Canvas(self, bg=CLR_DROP_BG, height=180, highlightthickness=0, cursor="hand2")
        self.drop_canvas.pack(fill=tk.X, padx=40, pady=10)
        self.drop_canvas.bind("<Configure>", self.draw_drop_zone)
        self.drop_canvas.bind("<Button-1>", lambda e: self.browse_files())

        try:
            self.drop_canvas.drop_target_register(DND_FILES)
            self.drop_canvas.dnd_bind('<<Drop>>', self.on_drop)
        except Exception as e:
            print(f"Sürükle-Bırak Hatası: {e}")

        self.lbl_info = tk.Label(self, text="Henüz dosya seçilmedi.", bg=CLR_BODY_BG, fg="gray", font=("Segoe UI", 10))
        self.lbl_info.pack(pady=5)

        # --- BUTONLAR (TABLONUN ÜSTÜNE ALINDI) ---
        btn_frame = tk.Frame(self, bg=CLR_BODY_BG)
        btn_frame.pack(fill=tk.X, padx=40, pady=(10, 5)) # Alt ve üst boşluklar ayarlandı
        
        self.btn_save = tk.Button(btn_frame, text="💾 SİSTEME KAYDET", command=self.save_to_database, 
                                  bg=CLR_ACCENT, fg="white", font=("Segoe UI", 11, "bold"), 
                                  state=tk.DISABLED, pady=8, bd=0, cursor="hand2")
        self.btn_save.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        
        tk.Button(btn_frame, text="📊 EXCEL'E AKTAR", command=self.export_excel, 
                  bg="#27ae60", fg="white", font=("Segoe UI", 11, "bold"), 
                  pady=8, bd=0, cursor="hand2").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        # YENİ BUTON: TOPLU İPTAL GİRİŞİ
        tk.Button(btn_frame, text="🚫 İPTAL FATURA İŞLE", command=self.open_iptal_ekrani, 
                  bg="#e74c3c", fg="white", font=("Segoe UI", 11, "bold"), 
                  pady=8, bd=0, cursor="hand2").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))

        # --- TABLO ALANI (BUTONLARIN ALTINA ALINDI) ---
        container = tk.Frame(self, bg=CLR_BODY_BG)
        container.pack(fill=tk.BOTH, expand=True, padx=40, pady=(5, 20)) # Tablonun alt boşluğu artırıldı
        
        scroll_y = ttk.Scrollbar(container, orient="vertical")
        scroll_x = ttk.Scrollbar(container, orient="horizontal")

        self.cols = [
            "NO_FATURA", "TARIH_FATURA", "SATICI_KURUM", "ALICI_KURUM", 
            "MAL_HIZMET_CINSI", "MIKTAR", "BR", "FIYAT_BR", "TUTAR", 
            "KDV_ORANI_KLM", "KDV_KLM", "T_DEF_INDEX", "TOPLAM_TUTAR", "PARA_KODU",
            "SATICI_VKN_TCKN", "ALICI_VKN_TCKN", "TUR_FATURA", "TIP_FATURA", 
            "ETTN", "DOSYA_YOLU"
        ]
        
        self.tree = ttk.Treeview(container, columns=self.cols, show='headings', 
                                 yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set, height=12)
        
        scroll_y.config(command=self.tree.yview); scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        scroll_x.config(command=self.tree.xview); scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(fill=tk.BOTH, expand=True)

        col_headers = {
            "NO_FATURA": "Fatura No", "TARIH_FATURA": "Tarih", "SATICI_KURUM": "Satıcı Ünvan", 
            "ALICI_KURUM": "Alıcı Ünvan", "MAL_HIZMET_CINSI": "Mal/Hizmet", "TOPLAM_TUTAR": "Ödenecek Tutar",
            "T_DEF_INDEX": "Tevkifat Kodu", "FIYAT_BR": "Birim Fiyat", "TUTAR": "Matrah"
        }
        
        for col in self.cols:
            self.tree.heading(col, text=col_headers.get(col, col.replace("_", " ").title()))
            self.tree.column(col, width=110, anchor="w")

    def open_iptal_ekrani(self):
        root = self.winfo_toplevel()
        
        # Mükellef ve Yıl seçilmiş mi kontrol et
        if not hasattr(root, 'vkn') or str(root.vkn) in ["---", "0000000000", "None", ""]:
            messagebox.showerror("Hata", "Lütfen önce bir Mükellef ve Yıl seçiniz.")
            return
            
        # Ekranı çağır (self, vkn, yil)
        FaturaIptalPenceresi(self, root.vkn, root.yil)

    def draw_drop_zone(self, event=None):
        w = self.drop_canvas.winfo_width()
        h = self.drop_canvas.winfo_height()
        self.drop_canvas.delete("all")
        self.drop_canvas.create_rectangle(10, 10, w-10, h-10, outline="white", width=2, dash=(10, 10))
        cx = w / 2
        self.drop_canvas.create_text(cx, 80, text="🧾 XML / ZIP Dosyalarını Buraya Bırakın", fill="white", font=("Segoe UI", 14, "bold"))
        
        if not hasattr(self, 'btn_browse_c'):
            self.btn_browse_c = tk.Button(self.drop_canvas, text="Dosya Seç", command=self.browse_files,
                                          bg=CLR_BTN_BG, fg=CLR_BTN_FG, font=("Segoe UI", 10, "bold"),
                                          relief="flat", padx=20, cursor="hand2")
        self.drop_canvas.create_window(cx, 130, window=self.btn_browse_c)

    # ================= LOADER POP-UP FONKSİYONLARI =================
    def show_loader(self):
        """Yükleniyor pop-up ekranını oluşturur ve animasyonu başlatır."""
        self.loader_win = tk.Toplevel(self)
        self.loader_win.title("İşleniyor...")
        self.loader_win.geometry("350x120")
        self.loader_win.resizable(False, False)
        
        # Ana pencerenin ortasına sabitleme
        self.loader_win.update_idletasks()
        x = self.master.winfo_x() + (self.master.winfo_width() // 2) - (350 // 2)
        y = self.master.winfo_y() + (self.master.winfo_height() // 2) - (120 // 2)
        self.loader_win.geometry(f"+{x}+{y}")
        
        self.loader_win.transient(self.master) # Ana pencerenin üstünde kalmasını sağlar
        self.loader_win.grab_set() # Diğer pencerelere tıklanmasını engeller
        self.loader_win.configure(bg=CLR_BODY_BG)
        
        tk.Label(self.loader_win, text="Faturalar okunuyor ve analiz ediliyor.\nLütfen bekleyin...", 
                 bg=CLR_BODY_BG, fg="#2c3e50", font=("Segoe UI", 10)).pack(pady=(15, 10))
        
        self.progress = ttk.Progressbar(self.loader_win, mode="indeterminate", length=250)
        self.progress.pack()
        self.progress.start(10) # Hızı ayarlayan milisaniye değeri

    def close_loader(self):
        """Loader ekranını kapatır."""
        if hasattr(self, 'loader_win'):
            self.progress.stop()
            self.loader_win.grab_release()
            self.loader_win.destroy()
    # ===============================================================

    def on_drop(self, event):
        data = event.data
        if data.startswith('{'): paths = [p.strip('{}') for p in data.split('} {')]
        else: paths = data.split()
        self.process_files(paths)

    def browse_files(self):
        files = filedialog.askopenfilenames(filetypes=[("Fatura", "*.xml *.zip")])
        if files: self.process_files(files)

    def process_files(self, files):
        if not files: return
        self.lbl_info.config(text="Faturalar okunuyor...", fg="#2980b9")
        self.show_loader() # Pop-up'ı göster
        
        # Okuma işlemini ayrı bir thread'de başlat
        threading.Thread(target=self._read_files_thread, args=(files,), daemon=True).start()
        
        # Kuyruğu kontrol etmeye başla
        self.after(100, self._check_queue)

    def _read_files_thread(self, files):
        """Arka planda çalışacak olan ÇOKLU (Paralel) fatura okuma fonksiyonu."""
        all_data = []
        error = None
        
        try:
            # İşlemci (CPU) çekirdek sayısını baz alarak optimum thread sayısını belirle
            max_threads = min(32, (multiprocessing.cpu_count() or 1) + 4)
            
            # Dosyaları işlemci çekirdeklerine dağıtıyoruz
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
                # Her bir dosya için toplu_fatura_oku fonksiyonunu havuza gönder
                future_to_file = {executor.submit(toplu_fatura_oku, path): path for path in files}
                
                # İşlemi biten dosyanın sonucunu anında al
                for future in concurrent.futures.as_completed(future_to_file):
                    path = future_to_file[future]
                    try:
                        rows = future.result()
                        if rows:
                            all_data.extend(rows)
                    except Exception as e:
                        print(f"Hata! {path} dosyası okunamadı: {e}")
                        
        except Exception as e:
            error = str(e)
            
        # Sonuçları ana thread'in okuması için kuyruğa ekle
        self.queue.put({"data": all_data, "error": error})

    def _check_queue(self):
        """Ana thread'de düzenli olarak kuyruğu kontrol eden fonksiyon."""
        try:
            result = self.queue.get_nowait()
            self.close_loader() # İşlem bittiği için loader'ı kapat
            
            if result["error"]:
                messagebox.showerror("Hata", result["error"])
                self.lbl_info.config(text="Okuma hatası.", fg="red")
                return

            all_data = result["data"]
            if all_data:
                try: 
                    temp_df = pd.DataFrame(all_data)
                    
                    # Ana ekrandan aktif VKN ve YIL bilgisini al
                    root = self.winfo_toplevel()
                    aktif_vkn_obj = getattr(root, 'vkn', None)
                    aktif_yil_obj = getattr(root, 'yil', None)
                    
                    vkn_str = str(aktif_vkn_obj.get()).strip() if hasattr(aktif_vkn_obj, 'get') else str(aktif_vkn_obj).strip()
                    yil_str = str(aktif_yil_obj.get()).strip() if hasattr(aktif_yil_obj, 'get') else str(aktif_yil_obj).strip()
                    
                    vkn_str = vkn_str.replace(".0", "")
                    yil_str = yil_str.replace(".0", "")
                    
                    # 1. TEMEL KONTROL: Ana ekranda seçim yapılmış mı?
                    if vkn_str in ["---", "0000000000", "None", ""]:
                        messagebox.showerror("Eksik Bilgi", "Lütfen ana ekrandan Mükellef (VKN) seçtiğinizden emin olun!")
                        self.lbl_info.config(text="Yükleme iptal edildi (VKN Seçilmedi).", fg="red")
                        return
                        
                    if yil_str in ["---", "0", "None", ""]:
                        messagebox.showerror("Eksik Bilgi", "Lütfen ana ekrandan Çalışma Yılı seçtiğinizden emin olun!")
                        self.lbl_info.config(text="Yükleme iptal edildi (Yıl Seçilmedi).", fg="red")
                        return

                    # --- 2. VKN GLOBAL KONTROLÜ (Veri setinde herhangi bir yerde var mı?) ---
                    # Hızlı tarama için listeye çeviriyoruz
                    satici_vkn_list = temp_df['SATICI_VKN_TCKN'].astype(str).str.replace(".0", "", regex=False).str.strip().tolist()
                    alici_vkn_list = temp_df['ALICI_VKN_TCKN'].astype(str).str.replace(".0", "", regex=False).str.strip().tolist()
                    
                    if (vkn_str not in satici_vkn_list) and (vkn_str not in alici_vkn_list):
                        # VKN dosyada HİÇ yoksa işlemi tamamen durdur
                        messagebox.showerror("İşlem İptal", f"Yüklenen veri setindeki hiçbir faturada seçili mükellefe ({vkn_str}) ait bir kayıt bulunamadı.\nFarklı bir firmaya ait dosya yüklemiş olabilirsiniz.")
                        self.lbl_info.config(text="Yükleme iptal edildi (Mükellef eşleşmedi).", fg="red")
                        return

                    # --- 3. YIL KONTROLÜ (Kısmi Yükleme - Satır Satır) ---
                    hatali_yil_sayisi = 0
                    gecerli_satirlar = []

                    for _, row in temp_df.iterrows():
                        satir_gecerli = True
                        
                        tarih_val = str(row.get('TARIH_FATURA', '')).strip()
                        if tarih_val and tarih_val != "nan" and tarih_val != "None":
                            # Çalışma yılı, faturanın tarihi İÇİNDE GEÇMİYORSA
                            if yil_str not in tarih_val:
                                satir_gecerli = False
                                hatali_yil_sayisi += 1

                        if satir_gecerli:
                            gecerli_satirlar.append(row)

                    # Hiç geçerli yıla ait fatura yoksa
                    if not gecerli_satirlar:
                        messagebox.showerror("İşlem İptal", "Mükellef eşleşmesi başarılı ancak faturaların tümü seçili çalışma yılına uymadığı için yüklenecek geçerli fatura bulunamadı.")
                        self.lbl_info.config(text="Yükleme iptal edildi (Geçerli yıl bulunamadı).", fg="red")
                        return

                    # --- 4. KISMİ YÜKLEME BİLGİLENDİRMESİ VE TABLOYA YANSITMA ---
                    temp_df = pd.DataFrame(gecerli_satirlar)

                    if hatali_yil_sayisi > 0:
                        uyari_mesaji = (f"Bilgi: Veri setinde mükellef eşleşmesi sağlandı ancak bazı faturalar çalışma yılına uymadığı için es geçildi.\n\n"
                                        f"❌ Yılı Uymayan ve Atlanan Fatura: {hatali_yil_sayisi} adet\n\n"
                                        f"✅ Kalan {len(temp_df)} fatura tabloya eklendi.")
                        messagebox.showwarning("Kısmi Yükleme", uyari_mesaji)

                    # Mükerrer kayıt temizliği
                    if not temp_df.empty and 'ETTN' in temp_df.columns and 'KALEM_NO' in temp_df.columns:
                        initial_len = len(temp_df)
                        temp_df.drop_duplicates(subset=['ETTN', 'KALEM_NO'], inplace=True)
                        final_len = len(temp_df)
                        if initial_len != final_len:
                            print(f"Bilgi: {initial_len - final_len} adet mükerrer satır temizlendi.")

                    self.df_fatura = temp_df
                    self.refresh_tree()
                    self.btn_save.config(state=tk.NORMAL)
                    
                    durum_metni = f"✅ {len(self.df_fatura)} geçerli fatura okundu."
                    if hatali_yil_sayisi > 0:
                        durum_metni += f" ({hatali_yil_sayisi} satır yılı uymadığı için atlandı)."
                    self.lbl_info.config(text=durum_metni, fg="green")

                except Exception as e:
                    messagebox.showerror("Veri Analiz Hatası", f"Faturalar kontrol edilirken beklenmeyen bir hata oluştu:\n{str(e)}")
                    self.lbl_info.config(text="Hata oluştu.", fg="red")

            else:
                self.lbl_info.config(text="Okunabilir veri bulunamadı (Dosya formatı geçersiz olabilir).", fg="red")
                
        except queue.Empty:
            self.after(100, self._check_queue)

    def refresh_tree(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        limit = 500
        for i, row in self.df_fatura.iterrows():
            if i >= limit: break
            vals = [row.get(c, "") for c in self.cols]
            self.tree.insert("", "end", values=vals)

    def save_to_database(self):
        root = self.winfo_toplevel()
        
        if not hasattr(root, 'vkn') or str(root.vkn) in ["---", "0000000000", "None"]:
            messagebox.showerror("Hata", "Lütfen önce bir Mükellef ve Yıl seçiniz.")
            return

        confirm = messagebox.askyesno("Onay", f"{len(self.df_fatura)} adet fatura veri tabanına işlenecek.\nOnaylıyor musunuz?")
        if not confirm: return

        try:
            added, skipped, db_path = faturayi_veritabanina_kaydet(
                self.df_fatura, 
                vkn=root.vkn, 
                yil=root.yil
            )
            
            msg = (f"✅ İşlem Tamamlandı\n\n"
                   f"Eklenen: {added}\n"
                   f"Mükerrer (Atlanan): {skipped}\n"
                   f"DB: {os.path.basename(db_path)}")
            
            messagebox.showinfo("Başarılı", msg)
            
            # --- EKLENEN KISIM: İşlem bitince ekranı temizle ---
            self.reset_screen()
            
        except FileNotFoundError as fnf:
            messagebox.showerror("Klasör Hatası", str(fnf))
        except Exception as e:
            messagebox.showerror("Veritabanı Hatası", f"Kayıt başarısız:\n{e}")

    def export_excel(self):
        if self.df_fatura.empty: return
        path = filedialog.asksaveasfilename(defaultextension=".xlsx")
        if path:
            self.df_fatura.to_excel(path, index=False)
            messagebox.showinfo("Tamam", "Excel kaydedildi.")

    def reset_screen(self):
        """Kayıt işleminden sonra ekranı ve belleği sıfırlar."""
        # 1. Arka plandaki Dataframe'i temizle
        self.df_fatura = pd.DataFrame()
        
        # 2. Arayüzdeki tabloyu (Treeview) temizle
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        # 3. Kaydet butonunu tekrar inaktif duruma getir
        self.btn_save.config(state=tk.DISABLED)
        
        # 4. Alt kısımdaki bilgi etiketini ilk haline döndür
        self.lbl_info.config(text="Kayıt tamamlandı. Yeni dosya yükleyebilirsiniz.", fg="gray")