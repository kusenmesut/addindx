import io
import os

# Bozuk XML onarımı ve maksimum hız için LXML kullanıyoruz
try:
    import lxml.etree as le
    LXML_AVAILABLE = True
except ImportError:
    import xml.etree.ElementTree as le 
    LXML_AVAILABLE = False

def strip_namespace(root):
    """XML etiketlerindeki isim alanlarını (namespace) en hızlı şekilde temizler."""
    for elem in root.iter():
        # LXML etiketleri string değil obje döndürebilir, güvenli kontrol
        tag = getattr(elem, 'tag', None)
        if tag and isinstance(tag, str) and '}' in tag:
            elem.tag = tag.split('}', 1)[1]
    return root

def get_val(element, tag_path):
    """Verilen XPath konumundaki metin değerini güvenle çeker."""
    if element is None: return ""
    try:
        found = element.find(tag_path)
        return found.text.strip() if found is not None and found.text else ""
    except Exception: 
        return ""

def get_float(element, tag_path):
    """Verilen XPath konumundaki sayısal değeri çeker, TR formatını baz alır."""
    val = get_val(element, tag_path)
    if not val: return 0.0
    try:
        if "," in val: 
            return float(val.replace('.', '').replace(',', '.'))
        return float(val)
    except Exception: 
        return 0.0

def parse_party_info(party_element):
    """Faturadaki alıcı veya satıcı (Party) iletişim detaylarını ayrıştırır."""
    info = {
        "VKN": "", "KURUM": "", "SAHIS": "",
        "IL": "", "ILCE": "", "ADRES_DETAY": "", 
        "TELEFON": "", "EPOSTA": ""
    }
    if party_element is None: return info
    
    # --- TEMEL KİMLİK BİLGİLERİ ---
    info["VKN"] = get_val(party_element, 'PartyIdentification/ID')
    kurum_adi = get_val(party_element, 'PartyName/Name')
    fname = get_val(party_element, 'Person/FirstName')
    lname = get_val(party_element, 'Person/FamilyName')
    sahis_adi = f"{fname} {lname}".strip()
    
    if kurum_adi: info["KURUM"] = kurum_adi
    if sahis_adi: info["SAHIS"] = sahis_adi
    
    if len(info["VKN"]) == 11 and not info["SAHIS"] and info["KURUM"]:
        info["SAHIS"] = info["KURUM"]
        info["KURUM"] = ""

    # --- İLETİŞİM BİLGİLERİ ---
    info["IL"] = get_val(party_element, './/CityName')
    info["ILCE"] = get_val(party_element, './/CitySubdivisionName')
    
    street = get_val(party_element, './/StreetName')
    bldg = get_val(party_element, './/BuildingNumber')
    room = get_val(party_element, './/Room')
    
    adres_parcalari = [s for s in [street, bldg, room] if s]
    info["ADRES_DETAY"] = " ".join(adres_parcalari)

    info["TELEFON"] = get_val(party_element, './/Telephone')
    info["EPOSTA"] = get_val(party_element, './/ElectronicMail')
        
    return info

def parse_single_invoice_content(content_bytes, filename="Bilinmeyen"):
    row_list = []
    try:
        # SİHİRLİ DOKUNUŞ: Bozulan XML'i "recover=True" ile hatasız onaran lxml motoru
        if LXML_AVAILABLE:
            parser = le.XMLParser(recover=True, encoding='utf-8')
            root = le.parse(io.BytesIO(content_bytes), parser).getroot()
        else:
            root = le.parse(io.BytesIO(content_bytes)).getroot()

        if root is None:
            return []

        root = strip_namespace(root)
        invoice = root if root.tag == 'Invoice' else root.find('.//Invoice')
        if invoice is None: invoice = root

        # 1. Genel Fatura Bilgileri
        senaryo = get_val(invoice, 'ProfileID')
        tip = get_val(invoice, 'InvoiceTypeCode')
        fatura_no = get_val(invoice, 'ID')
        tarih = get_val(invoice, 'IssueDate')
        uuid = get_val(invoice, 'UUID')
        pb = get_val(invoice, 'DocumentCurrencyCode')
        doviz_kuru = get_float(invoice, 'PricingExchangeRate/CalculationRate') or 1.0

        s_info = parse_party_info(invoice.find('.//AccountingSupplierParty/Party'))
        c_info = parse_party_info(invoice.find('.//AccountingCustomerParty/Party'))

        # 2. Fatura Alt Toplamları
        lmt = invoice.find('LegalMonetaryTotal')
        genel_matrah = get_float(lmt, 'LineExtensionAmount')
        genel_iskonto = get_float(lmt, 'AllowanceTotalAmount')
        genel_vergi_dahil = get_float(lmt, 'TaxInclusiveAmount')
        odenecek = get_float(lmt, 'PayableAmount')

        # 3. Vergi Toplamları (Fatura Geneli)
        top_taxes = {}
        for tt in invoice.findall('TaxTotal'):
            for sub in tt.findall('TaxSubtotal'):
                t_code = get_val(sub, 'TaxCategory/TaxScheme/TaxTypeCode')
                t_amt = get_float(sub, 'TaxAmount')
                top_taxes[t_code] = top_taxes.get(t_code, 0) + t_amt

        wht_elem = invoice.find('WithholdingTaxTotal')
        top_tevkifat = get_float(wht_elem, 'TaxAmount') if wht_elem is not None else 0.0
        top_kdv = top_taxes.get('0015', 0.0)
        top_otv = top_taxes.get('0007', 0.0)
        top_oiv = top_taxes.get('0011', 0.0)

        # 4. Kalem Döngüsü (Tam 50 Sütun)
        lines = invoice.findall('InvoiceLine')
        for line in lines:
            line_id = get_val(line, 'ID')
            mal_hizmet = get_val(line, 'Item/Name')
            qty_node = line.find('InvoicedQuantity')
            miktar = float(qty_node.text) if (qty_node is not None and qty_node.text) else 0.0
            birim = qty_node.get('unitCode', '') if qty_node is not None else ""
            
            fiyat = get_float(line, 'Price/PriceAmount')
            satir_matrah = get_float(line, 'LineExtensionAmount')

            # Kalem Vergi Analizi
            kdv_klm = 0.0; kdv_oran = 0.0; kdv_matrah = 0.0
            otv_klm = 0.0; otv_oran = 0.0; otv_matrah = 0.0
            
            for tt in line.findall('TaxTotal'):
                for sub in tt.findall('TaxSubtotal'):
                    t_code = get_val(sub, 'TaxCategory/TaxScheme/TaxTypeCode')
                    if t_code == '0015': # KDV
                        kdv_klm = get_float(sub, 'TaxAmount')
                        kdv_oran = get_float(sub, 'TaxCategory/Percent')
                        kdv_matrah = get_float(sub, 'TaxableAmount') or satir_matrah
                    elif t_code == '0007': # ÖTV
                        otv_klm = get_float(sub, 'TaxAmount')
                        otv_oran = get_float(sub, 'TaxCategory/Percent')
                        otv_matrah = get_float(sub, 'TaxableAmount') or satir_matrah

            tevkifat_kodu = get_val(line, './/WithholdingTaxTotal/TaxSubtotal/TaxCategory/TaxScheme/TaxTypeCode')

            # EXACT 50 SÜTUN EŞLEŞTİRMESİ
            row_data = {
                "TUR_FATURA": senaryo, "TIP_FATURA": tip, "NO_FATURA": fatura_no,
                "TARIH_FATURA": tarih, "FaturaUUID": uuid,
                # SATICI KİMLİK VE İLETİŞİM BİLGİLERİ
                "SATICI_VKN_TCKN": s_info["VKN"], "SATICI_KURUM": s_info["KURUM"], "SATICI_ŞAHIS": s_info["SAHIS"],
                "SATICI_IL": s_info["IL"], "SATICI_ILCE": s_info["ILCE"], "SATICI_ADRES": s_info["ADRES_DETAY"], 
                "SATICI_TELEFON": s_info["TELEFON"], "SATICI_EPOSTA": s_info["EPOSTA"],
                
                # ALICI KİMLİK BİLGİLERİ (Tekrarlayan satıcı bloğu buradan kaldırıldı)
                "ALICI_VKN_TCKN": c_info["VKN"], "ALICI_KURUM": c_info["KURUM"], "ALICI_ŞAHIS": c_info["SAHIS"],
                "MAL_HIZMET_CINSI": mal_hizmet, "PARA_KODU": pb, "DOVIZ_KURU": doviz_kuru,
                "FIYAT_BR": fiyat, "BR": birim, "MIKTAR": miktar, "TUTAR": satir_matrah,
                "MIKTAR_BEYAN": 0.0, "BR_BEYAN": "",
                "OTV_MATRAH_KLM": otv_matrah, "OTV_KLM": otv_klm,
                "KDV_MATRAH_KLM": kdv_matrah, "KDV_KLM": kdv_klm,
                "OTV_ORANI_KLM": otv_oran, "KDV_ORANI_KLM": kdv_oran,
                "MAL_HIZMET_TOP": genel_matrah, "TOP_KDV_OTV_HARIC_TUTAR": genel_matrah,
                "TOP_OTV_TUTAR": top_otv, "TOP_OTV_MATRAHI": genel_matrah,
                "TOP_KDV_TUTAR": top_kdv, "TOP_TEVKIFAT_TUTAR": top_tevkifat,
                "KalemNotUUID": "", "TOP_ÖİV_TUTAR": top_oiv, "TOP_ÖİV_MATRAHI": 0.0,
                "TOP_ELKHAVAGAZTÜKVER_TUTAR": 0.0, "TOP_ELKHAVAGAZTÜKVER_MATRAHI": 0.0,
                "TOP_503ÖİV_TUTAR": 0.0, "TOP_503ÖİV_MATRAHI": 0.0,
                "TOP_ELK_TUK_VER_TUTAR": 0.0, "TOP_ELK_TUK_VER_MATRAHI": 0.0,
                "TOP_TK_KULLANIM_TUTAR": 0.0, "TOP_TK_KULLANIM_MATRAHI": 0.0,
                "TOP_VERGI_TUTAR": top_kdv + top_otv + top_oiv,
                "TOP_VERGİLER_DAHIL_TUTAR": genel_vergi_dahil,
                "ISKONTO": genel_iskonto, "BINDIRIM": 0.0, "TOPLAM_TUTAR": odenecek,
                "KalemNo": line_id, "T_DEF_INDEX": tevkifat_kodu,
                
                # --- SİSTEM ZORUNLULUKLARI ---
                "ETTN": uuid, "DOSYA_YOLU": ""
            }
            row_list.append(row_data)
            
    except Exception as e:
        print(f"HATA ({filename}): Fatura satırları çözümlenemedi - {e}")

    return row_list