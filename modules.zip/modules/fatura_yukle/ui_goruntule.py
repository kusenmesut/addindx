import os
import io
import zipfile
import multiprocessing
import tkinter as tk
from tkinter import messagebox
import pandas as pd

# LXML ve Webview kontrolü
try:
    import lxml.etree as le
    import webview
    KUTUPHANELER_TAMAM = True
except ImportError:
    KUTUPHANELER_TAMAM = False

# --- SİHİRLİ KISIM: 1. GÖRSELDEKİ ORİJİNAL GİB FORMATININ BİREBİR REPLİKASI ---
STANDART_GIB_XSLT = """<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:n1="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
    xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
    xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
    xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">

    <xsl:output method="html" encoding="UTF-8" indent="yes"/>
    <xsl:decimal-format name="tr" decimal-separator="," grouping-separator="."/>

    <xsl:template match="/">
        <xsl:apply-templates select="//n1:Invoice"/>
    </xsl:template>

    <xsl:template match="n1:Invoice">
        <html>
            <head>
                <title>e-Fatura - Orijinal GİB Formatı</title>
                <style type="text/css">
                    body { font-family: 'Tahoma', "Times New Roman", Times, serif; font-size: 11px; color: #333; margin: 30px; }
                    table { border-collapse: collapse; width: 100%; }
                    td, th { border: 1px solid black; padding: 4px; font-size: 11px; }
                    .no-border, .no-border td { border: none; }
                    .header-title { font-size: 1.4em; font-weight: bold; text-align: center; font-family: Arial, sans-serif; margin-top:5px; display:block;}
                    .gib-logo { width: 95px; }
                    .info-table { width: 260px; float: right; border: 2px solid gray; }
                    .info-table td { border: 1px solid gray; padding: 3px; }
                    .totals-table { width: 38%; float: right; margin-top: 15px; border: 2px solid black; }
                    .totals-table td { border: 1px solid black; padding: 4px; }
                    .notes-box { border: 2px solid black; padding: 10px; margin-top: 20px; width: 100%; }
                    hr { height: 2px; color: #000; background-color: #000; border: none; }
                </style>
            </head>
            <body>
                <table class="no-border" width="100%">
                    <tr>
                        <td width="40%" valign="top">
                            <hr/>
                            <b><xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name"/></b><br/><br/>
                            <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName"/> / <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName"/><br/>
                            Tel: <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:Telephone"/><br/>
                            E-Posta: <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:Contact/cbc:ElectronicMail"/><br/>
                            Vergi Dairesi: <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme/cbc:Name"/><br/>
                            VKN/TCKN: <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID"/><br/>
                            <hr/>
                        </td>
                        <td width="20%" align="center" valign="middle">
                            <img src="gib_logo.png" class="gib-logo" alt="GİB Logo"/><br/>
                            <span class="header-title">e-FATURA</span>
                        </td>
                        <td width="40%" valign="top"></td>
                    </tr>
                    <tr>
                        <td valign="top">
                            <br/><hr/>
                            <b>SAYIN</b><br/>
                            <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name"/><br/>
                            <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:StreetName"/><br/>
                            <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName"/> / <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:CityName"/><br/>
                            E-Posta: <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:Contact/cbc:ElectronicMail"/><br/>
                            Vergi Dairesi: <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme/cbc:Name"/><br/>
                            VKN/TCKN: <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PartyIdentification/cbc:ID"/>
                            <br/><hr/>
                        </td>
                        <td colspan="2" valign="bottom">
                            <table class="info-table">
                                <tr><td><b>Özelleştirme No:</b></td><td><xsl:value-of select="cbc:CustomizationID"/></td></tr>
                                <tr><td><b>Senaryo:</b></td><td><xsl:value-of select="cbc:ProfileID"/></td></tr>
                                <tr><td><b>Fatura Tipi:</b></td><td><xsl:value-of select="cbc:InvoiceTypeCode"/></td></tr>
                                <tr><td><b>Fatura No:</b></td><td><xsl:value-of select="cbc:ID"/></td></tr>
                                <tr><td><b>Fatura Tarihi:</b></td><td><xsl:value-of select="cbc:IssueDate"/></td></tr>
                            </table>
                        </td>
                    </tr>
                </table>

                <br/>
                <b>ETTN:</b> <xsl:value-of select="cbc:UUID"/><br/><br/>

                <table border="1" style="border: 2px solid black;">
                    <tr style="background-color: #ffffff; font-weight: bold; text-align: center;">
                        <td width="4%">Sıra No</td>
                        <td width="23%">Mal Hizmet</td>
                        <td width="8%">Miktar</td>
                        <td width="8%">Birim Fiyat</td>
                        <td width="7%">İskonto Oranı</td>
                        <td width="8%">İskonto Tutarı</td>
                        <td width="7%">KDV Oranı</td>
                        <td width="10%">KDV Tutarı</td>
                        <td width="15%">Diğer Vergiler</td>
                        <td width="10%">Mal Hizmet Tutarı</td>
                    </tr>
                    <xsl:for-each select="cac:InvoiceLine">
                        <tr>
                            <td align="center"><xsl:value-of select="cbc:ID"/></td>
                            <td><xsl:value-of select="cac:Item/cbc:Name"/></td>
                            <td align="right"><xsl:value-of select="format-number(cbc:InvoicedQuantity, '#.##0,00', 'tr')"/> <xsl:text> </xsl:text><xsl:value-of select="cbc:InvoicedQuantity/@unitCode"/></td>
                            <td align="right"><xsl:value-of select="format-number(cac:Price/cbc:PriceAmount, '#.##0,00', 'tr')"/> TL</td>
                            
                            <td align="right">
                                <xsl:if test="cac:AllowanceCharge/cbc:MultiplierFactorNumeric">
                                    %<xsl:value-of select="format-number(cac:AllowanceCharge/cbc:MultiplierFactorNumeric * 100, '#.##', 'tr')"/>
                                </xsl:if>
                            </td>
                            <td align="right">
                                <xsl:if test="cac:AllowanceCharge/cbc:Amount">
                                    <xsl:value-of select="format-number(cac:AllowanceCharge/cbc:Amount, '#.##0,00', 'tr')"/> TL
                                </xsl:if>
                            </td>
                            
                            <td align="right">%<xsl:value-of select="format-number(cac:TaxTotal/cac:TaxSubtotal/cbc:Percent, '#.##', 'tr')"/></td>
                            <td align="right"><xsl:value-of select="format-number(cac:TaxTotal/cac:TaxSubtotal/cbc:TaxAmount, '#.##0,00', 'tr')"/> TL</td>
                            
                            <td align="right" style="font-size: 9px; color: gray;">
                                <xsl:for-each select="cac:WithholdingTaxTotal/cac:TaxSubtotal">
                                    KDV TEVKİFAT (%<xsl:value-of select="format-number(cbc:Percent, '#.##', 'tr')"/>)=<xsl:value-of select="format-number(cbc:TaxAmount, '#.##0,00', 'tr')"/> TL<br/>
                                </xsl:for-each>
                            </td>
                            
                            <td align="right"><xsl:value-of select="format-number(cbc:LineExtensionAmount, '#.##0,00', 'tr')"/> TL</td>
                        </tr>
                    </xsl:for-each>
                </table>

                <table class="totals-table">
                    <tr>
                        <td><b>Mal Hizmet Toplam Tutarı</b></td>
                        <td align="right"><xsl:value-of select="format-number(cac:LegalMonetaryTotal/cbc:LineExtensionAmount, '#.##0,00', 'tr')"/> TL</td>
                    </tr>
                    <tr>
                        <td><b>Toplam İskonto</b></td>
                        <td align="right">
                            <xsl:choose>
                                <xsl:when test="cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount">
                                    <xsl:value-of select="format-number(cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount, '#.##0,00', 'tr')"/> TL
                                </xsl:when>
                                <xsl:otherwise>0,00 TL</xsl:otherwise>
                            </xsl:choose>
                        </td>
                    </tr>
                    
                    <xsl:for-each select="cac:TaxTotal[1]/cac:TaxSubtotal">
                        <tr>
                            <td><b>Hesaplanan KDV(%<xsl:value-of select="format-number(cbc:Percent, '#.##', 'tr')"/>)</b></td>
                            <td align="right"><xsl:value-of select="format-number(cbc:TaxAmount, '#.##0,00', 'tr')"/> TL</td>
                        </tr>
                    </xsl:for-each>

                    <xsl:for-each select="cac:WithholdingTaxTotal/cac:TaxSubtotal">
                        <tr>
                            <td><b>Hesaplanan KDV Tevkifat(%<xsl:value-of select="format-number(cbc:Percent, '#.##', 'tr')"/>)</b></td>
                            <td align="right"><xsl:value-of select="format-number(cbc:TaxAmount, '#.##0,00', 'tr')"/> TL</td>
                        </tr>
                        <tr>
                            <td><b>Tevkifata Tabi İşlem Tutarı</b></td>
                            <td align="right"><xsl:value-of select="format-number(cbc:TaxableAmount, '#.##0,00', 'tr')"/> TL</td>
                        </tr>
                        <tr>
                            <td><b>Tevkifata Tabi İşlem Üzerinden Hes. KDV</b></td>
                            <td align="right"><xsl:value-of select="format-number(../../cac:TaxTotal[1]/cac:TaxSubtotal[1]/cbc:TaxAmount, '#.##0,00', 'tr')"/> TL</td>
                        </tr>
                    </xsl:for-each>

                    <tr>
                        <td><b>Vergiler Dahil Toplam Tutar</b></td>
                        <td align="right"><xsl:value-of select="format-number(cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount, '#.##0,00', 'tr')"/> TL</td>
                    </tr>
                    <tr>
                        <td><b>Ödenecek Tutar</b></td>
                        <td align="right"><xsl:value-of select="format-number(cac:LegalMonetaryTotal/cbc:PayableAmount, '#.##0,00', 'tr')"/> TL</td>
                    </tr>
                </table>

                <div style="clear: both;"></div>
                <div class="notes-box">
                    <xsl:for-each select="cbc:Note">
                        <b>Not: </b><xsl:value-of select="."/><br/>
                    </xsl:for-each>
                </div>
            </body>
        </html>
    </xsl:template>
</xsl:stylesheet>
"""

_XSLT_TRANSFORMER = None
if KUTUPHANELER_TAMAM:
    try:
        _xslt_root = le.XML(STANDART_GIB_XSLT.encode('utf-8'))
        _XSLT_TRANSFORMER = le.XSLT(_xslt_root)
    except Exception as e:
        print("XSLT Motoru Derleme Hatası:", e)

def gib_gorselini_baslat(pencere_basligi, html_dosya_yolu):
    webview.create_window(pencere_basligi, url=html_dosya_yolu, width=1100, height=800)
    webview.start()

class FaturaGoruntulePopup:
    def __init__(self, master, invoice_data):
        if not KUTUPHANELER_TAMAM:
            messagebox.showerror("Eksik Kütüphane", "Görüntüleme için 'lxml' ve 'pywebview' gereklidir.")
            return
        self.invoice_df = invoice_data
        self.orijinal_faturayi_ac()

    def orijinal_faturayi_ac(self):
        try:
            row = self.invoice_df.iloc[0]
            dosya_yolu = str(row.get('DOSYA_YOLU', ''))
            dosya_tipi = str(row.get('DOSYA_TIPI', '')).upper()
            zip_ici_ad = str(row.get('ZIP_ICI_AD', ''))
            
            if not os.path.exists(dosya_yolu):
                messagebox.showerror("Hata", "Orijinal dosya arşivde bulunamadı.")
                return

            xml_content = None
            if dosya_tipi == 'ZIP':
                
                # --- İÇ İÇE (NESTED) ZIP ARAMA ALGORİTMASI ---
                def search_in_zip(z_obj, target_name):
                    for info in z_obj.infolist():
                        if info.filename == target_name or info.filename.endswith(f"/{target_name}") or info.filename.endswith(f"\\{target_name}"):
                            return z_obj.read(info.filename)
                            
                    for info in z_obj.infolist():
                        if info.filename.lower().endswith('.zip'):
                            try:
                                nested_bytes = io.BytesIO(z_obj.read(info.filename))
                                with zipfile.ZipFile(nested_bytes, 'r') as nested_z:
                                    res = search_in_zip(nested_z, target_name)
                                    if res: return res
                            except: pass
                    return None

                with zipfile.ZipFile(dosya_yolu, 'r') as main_zip:
                    xml_content = search_in_zip(main_zip, zip_ici_ad)
                    
                    if not xml_content:
                        ettn = str(row.get('ETTN', '')).strip().lower()
                        if ettn:
                            xml_content = search_in_zip(main_zip, f"{ettn}.xml")
                            
            else:
                with open(dosya_yolu, 'rb') as f:
                    xml_content = f.read()

            if not xml_content:
                messagebox.showerror("Okuma Hatası", "XML faturası arşivin içinde bulunamadı. Arşiv hasarlı veya şifreli olabilir.")
                return

            # XSLT ile HTML Dönüşümü
            dom = le.parse(io.BytesIO(xml_content))
            html_icerik = str(_XSLT_TRANSFORMER(dom))

            proje_dizini = os.path.dirname(os.path.abspath(__file__))
            html_dosya_yolu = os.path.join(proje_dizini, "gecici_fatura_gorunumu.html")
            
            with open(html_dosya_yolu, "w", encoding="utf-8") as f:
                f.write(html_icerik)

            # Ekrana Bas
            fatura_no = str(row.get('NO_FATURA', 'GİB Fatura'))
            p = multiprocessing.Process(target=gib_gorselini_baslat, args=(f"GİB Denetim Ekranı - {fatura_no}", html_dosya_yolu))
            p.start()
            
        except Exception as e:
            messagebox.showerror("Görselleştirme Hatası", str(e))