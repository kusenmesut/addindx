import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import pandas as pd
import sys
from datetime import datetime

# --- MATPLOTLIB IMPORTLARI ---
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.ticker as mticker
import numpy as np

# --- PATH AYARI ---
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, '..', '..'))
if root_dir not in sys.path:
    sys.path.append(root_dir)

# --- İMPORTLAR ---
try:
    from config import CLR_BODY_BG, CLR_ACCENT, get_mukellefler_dir
except ImportError:
    def get_mukellefler_dir(): return "MUKELLEFLER"
    CLR_BODY_BG = "#f0f0f0"
    CLR_ACCENT = "#3498db"

# Engine'den DB okuma fonksiyonunu alıyoruz
try:
    from modules.fatura_yukle.engine import veritabanindan_fatura_oku
except ImportError:
    print("UYARI: engine.py modülü veya veritabanindan_fatura_oku fonksiyonu bulunamadı.")
    def veritabanindan_fatura_oku(vkn, yil): return pd.DataFrame()

# Görüntüleyici Modülü
try:
    from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
except ImportError:
    try:
        from ui_goruntule import FaturaGoruntulePopup
    except ImportError:
        FaturaGoruntulePopup = None

# --- RENK PALETİ ---
CLR_BG_MAIN = "#F4F6F9"
CLR_BG_SIDEBAR = "#FFFFFF"
CLR_TEXT_MAIN = "#2c3e50"
CLR_TEXT_SUB = "#7f8c8d"
CLR_BTN_PRIMARY = "#3498db"
CLR_BORDER = "#dcdde1"

class TumFaturalarFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BG_MAIN)
        self.master = master
        self.df_all_invoices = pd.DataFrame()
        self.df_filtered = pd.DataFrame()
        self.current_mukellef_info = None
        self.entry_vars = {} 
        self.stat_vars = {} 
        self.chart_canvases = {} 
        self.create_context_menu()
        
        self.setup_styles()
        self.setup_ui()
        self.after(100, self.auto_load_data)

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("Treeview", background="white", fieldbackground="white", foreground="#2c3e50", rowheight=30, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#ecf0f1", foreground="#2c3e50", relief="flat")
        style.map("Treeview", background=[('selected', '#3498db')])
        style.configure("TLabelframe", background=CLR_BG_SIDEBAR, bordercolor=CLR_BORDER)
        style.configure("TLabelframe.Label", background=CLR_BG_SIDEBAR, foreground=CLR_TEXT_MAIN, font=("Segoe UI", 9, "bold"))
        style.configure("TNotebook", background=CLR_BG_MAIN)
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=[15, 5])

    def setup_ui(self):
        # 1. SOL PANEL (FİLTRELER)
        self.sidebar = tk.Frame(self, bg=CLR_BG_SIDEBAR, width=280, padx=15, pady=15, bd=1, relief="solid")
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.pack_propagate(False)
        self.setup_sidebar()

        # 2. SAĞ PANEL (İÇERİK)
        self.main_area = tk.Frame(self, bg=CLR_BG_MAIN, padx=20, pady=20)
        self.main_area.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        self.setup_main_area()

    def create_context_menu(self):
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="📄 Muhasebe Fişini Bul (Yevmiye)", command=self.jump_to_accounting)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="👁️ Faturayı Görüntüle", command=self.open_invoice_viewer_btn)

    def show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)

    def jump_to_accounting(self):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0])['values']
        try:
            idx = self.COLUMNS.index("NO_FATURA")
            fatura_no = str(vals[idx]).strip()
        except (ValueError, IndexError):
            messagebox.showerror("Hata", "Fatura numarası okunamadı.")
            return

        root = self.winfo_toplevel()
        yevmiye_frame = self.find_frame_by_class_name(root, "YevmiyeAnalizFrame")
        
        if yevmiye_frame:
            yevmiye_frame.show_fis_popup_by_doc_no(fatura_no)
        else:
            try:
                from modules.yevmiye_analiz.ui import YevmiyeAnalizFrame
                temp_window = tk.Toplevel(root)
                temp_window.withdraw() 
                
                # --- ÇÖZÜM: Mükellef bilgilerini geçici pencereye aktar ---
                if hasattr(root, 'vkn'):
                    temp_window.vkn = root.vkn
                    temp_window.unvan = root.unvan
                    temp_window.yil = root.yil
                # ----------------------------------------------------------
                
                temp_yevmiye = YevmiyeAnalizFrame(temp_window)
                temp_yevmiye.show_fis_popup_by_doc_no(fatura_no)
            except ImportError:
                messagebox.showerror("Hata", "Yevmiye modülü yüklenemedi.")
            except Exception as e:
                messagebox.showerror("Hata", f"Yevmiye modülü başlatılamadı:\n{e}")

    def find_frame_by_class_name(self, parent, class_name):
        children = parent.winfo_children()
        for child in children:
            if child.__class__.__name__ == class_name: return child
        for child in children:
            res = self.find_frame_by_class_name(child, class_name)
            if res: return res
        return None
    
    def setup_sidebar(self):
        tk.Label(self.sidebar, text="Filtreler", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_MAIN, font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 20))
        self.create_sidebar_entry(self.sidebar, "Hızlı Arama", "genel_ara")

        frm_date = tk.LabelFrame(self.sidebar, text="Tarama Aralığı", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 9), bd=0)
        frm_date.pack(fill=tk.X, pady=10)
        
        f_d1 = tk.Frame(frm_date, bg=CLR_BG_SIDEBAR); f_d1.pack(fill=tk.X)
        tk.Label(f_d1, text="Başlangıç (Örn: 2022-01-01)", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 8)).pack(anchor="w")
        # HATANIN SEBEBİ BURASIYDI: Varsayılan 2023 tarihini sildik, artık sen yazmadıkça tarihi kısıtlamaz
        self.create_filter_entry(f_d1, "bas_tarih", "")

        f_d2 = tk.Frame(frm_date, bg=CLR_BG_SIDEBAR); f_d2.pack(fill=tk.X, pady=(5,0))
        tk.Label(f_d2, text="Bitiş", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 8)).pack(anchor="w")
        self.create_filter_entry(f_d2, "bit_tarih", "")

        frm_party = tk.LabelFrame(self.sidebar, text="Taraf Bilgisi", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 9), bd=0)
        frm_party.pack(fill=tk.X, pady=10)
        tk.Label(frm_party, text="Satıcı VKN/Ünvan", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 8)).pack(anchor="w")
        self.create_filter_entry(frm_party, "satici_ara")
        tk.Label(frm_party, text="Alıcı VKN/Ünvan", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 8)).pack(anchor="w", pady=(5,0))
        self.create_filter_entry(frm_party, "alici_ara")

        frm_amount = tk.LabelFrame(self.sidebar, text="Tutar", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 9), bd=0)
        frm_amount.pack(fill=tk.X, pady=10)
        f_a1 = tk.Frame(frm_amount, bg=CLR_BG_SIDEBAR); f_a1.pack(fill=tk.X)
        self.create_filter_entry(f_a1, "min_tutar", width=10, side=tk.LEFT, placeholder="Min")
        self.create_filter_entry(f_a1, "max_tutar", width=10, side=tk.RIGHT, placeholder="Max")

        btn_frame = tk.Frame(self.sidebar, bg=CLR_BG_SIDEBAR)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=20)

        tk.Button(btn_frame, text="Filtrele", bg=CLR_BTN_PRIMARY, fg="white", font=("Segoe UI", 10, "bold"), bd=0, pady=8, command=self.apply_filters, cursor="hand2").pack(fill=tk.X, pady=5)
        tk.Button(btn_frame, text="Sıfırla", bg="#ecf0f1", fg=CLR_TEXT_MAIN, font=("Segoe UI", 10), bd=0, pady=8, command=self.reset_filters, cursor="hand2").pack(fill=tk.X)

    def setup_main_area(self):
        # ÜST BAŞLIK VE BUTONLAR
        header_frame = tk.Frame(self.main_area, bg=CLR_BG_MAIN)
        header_frame.pack(fill=tk.X, pady=(0, 15))
        tk.Label(header_frame, text="Fatura Denetim ve Analiz Paneli", font=("Segoe UI", 14, "bold"), bg=CLR_BG_MAIN, fg=CLR_TEXT_MAIN).pack(side=tk.LEFT)
        self.lbl_mukellef = tk.Label(header_frame, text="", font=("Segoe UI", 10, "italic"), bg=CLR_BG_MAIN, fg=CLR_TEXT_SUB)
        self.lbl_mukellef.pack(side=tk.LEFT, padx=10)

        btn_container = tk.Frame(header_frame, bg=CLR_BG_MAIN)
        btn_container.pack(side=tk.RIGHT)
        
        self.create_header_btn(btn_container, "🗑️ Sil", "#e74c3c", self.delete_all_invoices)
        self.create_header_btn(btn_container, "📥 Yenile", "#3498db", self.load_invoice_data)
        self.create_header_btn(btn_container, "📊 Excel", "#27ae60", self.export_to_excel)
        self.create_header_btn(btn_container, "👁️ Görüntüle", "#8e44ad", self.open_invoice_viewer_btn)

        # SEKMELER (TABS) ALANI
        self.notebook = ttk.Notebook(self.main_area)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        self.tab_liste = tk.Frame(self.notebook, bg=CLR_BG_MAIN)
        self.tab_istatistik = tk.Frame(self.notebook, bg=CLR_BG_MAIN)

        self.notebook.add(self.tab_liste, text="📄 Fatura Listesi")
        self.notebook.add(self.tab_istatistik, text="📈 İstatistikler ve Analiz")

        # ================= TAB 1: LİSTE VE 4 TEMEL İSTATİSTİK =================
        stats_frame_main = tk.Frame(self.tab_liste, bg=CLR_BG_MAIN)
        stats_frame_main.pack(fill=tk.X, pady=(10, 15))
        
        self.create_stat_card(stats_frame_main, "Toplam Fatura", "adet_var", "📄")
        self.create_stat_card(stats_frame_main, "Toplam Tutar", "tutar_var", "₺")
        self.create_stat_card(stats_frame_main, "Ortalama Tutar", "ort_var", "📊")
        self.create_stat_card(stats_frame_main, "Benzersiz Cari", "cari_var", "👥")

        table_frame = tk.Frame(self.tab_liste, bg="white", bd=1, relief="solid")
        table_frame.pack(fill=tk.BOTH, expand=True)

        scroll_y = ttk.Scrollbar(table_frame, orient="vertical")
        scroll_x = ttk.Scrollbar(table_frame, orient="horizontal")

        # 50 SÜTUNLUK YAPI
        self.COLUMNS = [
            "TUR_FATURA", "TIP_FATURA", "NO_FATURA", "TARIH_FATURA", "FaturaUUID", 
            "SATICI_VKN_TCKN", "SATICI_KURUM", "SATICI_ŞAHIS", "ALICI_VKN_TCKN", 
            "ALICI_KURUM", "ALICI_ŞAHIS", "MAL_HIZMET_CINSI", "PARA_KODU", "DOVIZ_KURU", 
            "FIYAT_BR", "BR", "MIKTAR", "TUTAR", "MIKTAR_BEYAN", "BR_BEYAN", 
            "OTV_MATRAH_KLM", "OTV_KLM", "KDV_MATRAH_KLM", "KDV_KLM", "OTV_ORANI_KLM", 
            "KDV_ORANI_KLM", "MAL_HIZMET_TOP", "TOP_KDV_OTV_HARIC_TUTAR", "TOP_OTV_TUTAR", 
            "TOP_OTV_MATRAHI", "TOP_KDV_TUTAR", "TOP_TEVKIFAT_TUTAR", "KalemNotUUID", 
            "TOP_ÖİV_TUTAR", "TOP_ÖİV_MATRAHI", "TOP_ELKHAVAGAZTÜKVER_TUTAR", 
            "TOP_ELKHAVAGAZTÜKVER_MATRAHI", "TOP_503ÖİV_TUTAR", "TOP_503ÖİV_MATRAHI", 
            "TOP_ELK_TUK_VER_TUTAR", "TOP_ELK_TUK_VER_MATRAHI", "TOP_TK_KULLANIM_TUTAR", 
            "TOP_TK_KULLANIM_MATRAHI", "TOP_VERGI_TUTAR", "TOP_VERGİLER_DAHIL_TUTAR", 
            "ISKONTO", "BINDIRIM", "TOPLAM_TUTAR", "KalemNo", "T_DEF_INDEX", "ETTN", "DOSYA_YOLU"
        ]
        
        self.tree = ttk.Treeview(table_frame, columns=self.COLUMNS, show='headings', 
                                 yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set,
                                 selectmode="extended")
        
        scroll_y.config(command=self.tree.yview); scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        scroll_x.config(command=self.tree.xview); scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        self.tree.bind("<Double-1>", self.on_row_double_click)
        self.tree.bind("<Button-3>", self.show_context_menu)

        ozel_genislikler = {
            "NO_FATURA": 130, "TARIH_FATURA": 90, "SATICI_KURUM": 200, "ALICI_KURUM": 200, 
            "MAL_HIZMET_CINSI": 250, "TOPLAM_TUTAR": 110, "FaturaUUID": 150, "ETTN": 150
        }

        for col in self.COLUMNS:
            width_val = ozel_genislikler.get(col, 100)
            anchor_val = "e" if any(x in col for x in ["TUTAR", "MATRAH", "MIKTAR", "FIYAT", "KLM"]) else "w"
            self.tree.column(col, width=width_val, anchor=anchor_val)
            self.tree.heading(col, text=col.replace("_", " ").title(), anchor="w", 
                               command=lambda c=col: self.sort_treeview(c))

        # ================= TAB 2: DETAYLI 8 İSTATİSTİK VE GRAFİKLER =================
        stats_grid = tk.Frame(self.tab_istatistik, bg=CLR_BG_MAIN)
        stats_grid.pack(fill=tk.X, pady=15, padx=10)

        # Üst sıra (4 adet)
        row1 = tk.Frame(stats_grid, bg=CLR_BG_MAIN)
        row1.pack(fill=tk.X, pady=5)
        self.create_stat_card(row1, "Toplam KDV Tutarı", "kdv_tot_var", "💰")
        self.create_stat_card(row1, "Toplam ÖTV Tutarı", "otv_tot_var", "⛽")
        self.create_stat_card(row1, "Toplam Tevkifat", "tev_tot_var", "✂️")
        self.create_stat_card(row1, "Toplam İskonto", "isk_tot_var", "📉")

        # Alt sıra (4 adet)
        row2 = tk.Frame(stats_grid, bg=CLR_BG_MAIN)
        row2.pack(fill=tk.X, pady=5)
        self.create_stat_card(row2, "Tevkifatlı Fatura Sayısı", "tev_count_var", "🔢")
        self.create_stat_card(row2, "İskontolu Fatura Sayısı", "isk_count_var", "🔖")
        self.create_stat_card(row2, "En Yüksek Fatura Tutarı", "max_fat_var", "🏆")
        self.create_stat_card(row2, "En Çok İşlem Yapılan Cari", "top_cari_var", "⭐")

        # Grafikler
        self.analysis_frame = tk.Frame(self.tab_istatistik, bg=CLR_BG_MAIN, height=350)
        self.analysis_frame.pack(fill=tk.BOTH, expand=True, pady=10, padx=5)
        self.analysis_frame.pack_propagate(False)
        self.create_chart_container("chart_trend", "Aylık Tutar Trendi")
        self.create_chart_container("chart_kdv", "KDV Oran Dağılımı")
        self.create_chart_container("chart_top", "Top 5 Satıcı Kurum")

    # --- UI YARDIMCILARI ---
    def create_sidebar_entry(self, parent, label, var_key):
        tk.Label(parent, text=label, bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 9)).pack(anchor="w", pady=(5, 2))
        var = tk.StringVar()
        entry = tk.Entry(parent, textvariable=var, font=("Segoe UI", 10), bg="#f8f9fa", bd=1, relief="solid")
        entry.pack(fill=tk.X, ipady=3)
        self.entry_vars[var_key] = var

    def create_filter_entry(self, parent, var_key, default_val="", width=None, side=None, placeholder=""):
        var = tk.StringVar(value=default_val)
        entry = tk.Entry(parent, textvariable=var, font=("Segoe UI", 9), bg="#f8f9fa", bd=1, relief="solid")
        if width: entry.config(width=width)
        pack_opts = {'fill': tk.X, 'ipady': 3}
        if side: pack_opts.update({'side': side, 'expand': True, 'padx': 2})
        else: pack_opts.update({'fill': tk.X})
        entry.pack(**pack_opts)
        self.entry_vars[var_key] = var

    def create_header_btn(self, parent, text, bg, cmd):
        tk.Button(parent, text=text, bg=bg, fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=15, pady=5, cursor="hand2", command=cmd).pack(side=tk.LEFT, padx=5)

    def create_stat_card(self, parent, title, var_key, icon):
        card = tk.Frame(parent, bg="white", bd=1, relief="solid", padx=15, pady=10)
        card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        tk.Label(card, text=title, font=("Segoe UI", 9), fg=CLR_TEXT_SUB, bg="white").pack(anchor="w")
        content = tk.Frame(card, bg="white"); content.pack(fill=tk.X, pady=(5,0))
        var = tk.StringVar(value="-")
        tk.Label(content, textvariable=var, font=("Segoe UI", 12, "bold"), fg=CLR_TEXT_MAIN, bg="white").pack(side=tk.LEFT)
        tk.Label(content, text=icon, font=("Segoe UI", 14), fg=CLR_BTN_PRIMARY, bg="white").pack(side=tk.RIGHT)
        self.stat_vars[var_key] = var

    def create_chart_container(self, chart_key, title):
        frame = tk.Frame(self.analysis_frame, bg="white", bd=1, relief="solid", padx=5, pady=5)
        frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        tk.Label(frame, text=title, font=("Segoe UI", 9, "bold"), fg=CLR_TEXT_SUB, bg="white").pack(anchor="nw", pady=(0,5))
        canvas_frame = tk.Frame(frame, bg="white")
        canvas_frame.pack(fill=tk.BOTH, expand=True)
        self.chart_canvases[chart_key] = canvas_frame

    # --- GRAFİKLER ---
    def update_charts(self):
        if self.df_filtered.empty: return
        plt.rcParams.update({'font.size': 7, 'axes.titlesize': 8})
        
        # 1. Trend Grafiği
        container = self.chart_canvases["chart_trend"]
        for widget in container.winfo_children(): widget.destroy()
        if 'TARIH_FATURA' in self.df_filtered.columns and 'TOPLAM_TUTAR' in self.df_filtered.columns:
            try:
                df_t = self.df_filtered.copy()
                df_t['AY'] = pd.to_datetime(df_t['TARIH_FATURA'], errors='coerce').dt.to_period('M')
                trend_data = df_t.groupby('AY')['TOPLAM_TUTAR'].sum()
                fig = Figure(figsize=(3, 2.5), dpi=100)
                ax = fig.add_subplot(111)
                x_vals = [str(p) for p in trend_data.index]
                y_vals = trend_data.values
                x_nums = np.arange(len(x_vals))
                ax.plot(x_nums, y_vals, marker='o', color='#3498db', linewidth=2, markersize=5)
                ax.set_xticks(x_nums)
                ax.set_xticklabels(x_vals, rotation=45)
                ax.grid(True, linestyle='--', alpha=0.5)
                ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, p: f"{int(x/1000)}K"))
                canvas = FigureCanvasTkAgg(fig, master=container)
                canvas.draw()
                canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            except Exception as e: print(e)

        # 2. KDV Dağılımı
        container = self.chart_canvases["chart_kdv"]
        for widget in container.winfo_children(): widget.destroy()
        if 'KDV_ORANI_KLM' in self.df_filtered.columns and 'KDV_KLM' in self.df_filtered.columns:
            try:
                kdv_data = self.df_filtered.groupby('KDV_ORANI_KLM')['KDV_KLM'].sum()
                kdv_data = kdv_data[kdv_data > 0]
                if not kdv_data.empty:
                    fig = Figure(figsize=(3, 2.5), dpi=100)
                    ax = fig.add_subplot(111)
                    ax.pie(kdv_data, labels=[f"%{int(x)}" for x in kdv_data.index], autopct='%1.0f%%', 
                           colors=['#f1c40f', '#e67e22', '#e74c3c', '#9b59b6'], startangle=90, textprops={'fontsize': 7})
                    canvas = FigureCanvasTkAgg(fig, master=container)
                    canvas.draw()
                    canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            except Exception as e: print(e)

        # 3. Top Satıcılar
        container = self.chart_canvases["chart_top"]
        for widget in container.winfo_children(): widget.destroy()
        if 'SATICI_KURUM' in self.df_filtered.columns and 'TOPLAM_TUTAR' in self.df_filtered.columns:
            try:
                top = self.df_filtered.groupby('SATICI_KURUM')['TOPLAM_TUTAR'].sum().nlargest(5).sort_values()
                fig = Figure(figsize=(3, 2.5), dpi=100)
                ax = fig.add_subplot(111)
                bars = ax.barh([str(x)[:15] for x in top.index], top.values, color='#2ecc71')
                ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, p: f"{int(x/1000)}K"))
                canvas = FigureCanvasTkAgg(fig, master=container)
                canvas.draw()
                canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            except Exception as e: print(e)

    def auto_load_data(self):
        try:
            root = self.winfo_toplevel()
            if hasattr(root, 'vkn') and str(root.vkn) not in ["---", "0000000000"]:
                self.current_mukellef_info = {'vkn': root.vkn, 'unvan': root.unvan, 'yil': root.yil}
                self.lbl_mukellef.config(text=f"{root.unvan} | {root.yil}")
                self.load_invoice_data()
            else: self.lbl_mukellef.config(text="Aktif mükellef seçili değil")
        except: pass

    def load_invoice_data(self):
        if not self.current_mukellef_info: 
            messagebox.showwarning("Uyarı", "Lütfen önce Ana Ekrandan Mükellef Seçin.")
            return

        vkn = self.current_mukellef_info['vkn']
        yil = self.current_mukellef_info['yil']
        
        try:
            self.df_all_invoices = veritabanindan_fatura_oku(vkn, yil)
            
            if self.df_all_invoices.empty:
                for k in self.stat_vars.keys(): self.stat_vars[k].set("0")
                self.df_filtered = pd.DataFrame()
                self.refresh_treeview()
                return

            if 'TARIH_FATURA' in self.df_all_invoices.columns:
                self.df_all_invoices['TARIH_FATURA'] = pd.to_datetime(self.df_all_invoices['TARIH_FATURA'], errors='coerce')
            
            numeric_cols = ['TUTAR', 'TOPLAM_TUTAR', 'KDV_KLM', 'OTV_KLM', 'TOP_KDV_TUTAR', 'TOP_OTV_TUTAR', 'TOP_TEVKIFAT_TUTAR', 'ISKONTO']
            for col in numeric_cols:
                 if col in self.df_all_invoices.columns:
                     self.df_all_invoices[col] = pd.to_numeric(self.df_all_invoices[col], errors='coerce').fillna(0)

            self.df_filtered = self.df_all_invoices.copy()
            self.refresh_treeview()
            self.update_stats()
            self.update_charts()

        except Exception as e:
            messagebox.showerror("Veri Yükleme Hatası", str(e))

    def open_invoice_viewer_btn(self):
        self.on_row_double_click(None)

    def on_row_double_click(self, event):
        sel = self.tree.selection()
        if not sel: 
            if event is None: messagebox.showwarning("Seçim Yok", "Listeden bir fatura seçiniz.")
            return

        if FaturaGoruntulePopup is None:
            messagebox.showerror("Eksik Modül", "ui_goruntule.py modülü bulunamadı.")
            return

        vals = self.tree.item(sel[0])['values']
        
        try:
            idx_fat = self.COLUMNS.index("NO_FATURA")
            fatura_no = str(vals[idx_fat])
            
            df_invoice_rows = self.df_all_invoices[self.df_all_invoices['NO_FATURA'].astype(str) == fatura_no]

            if df_invoice_rows.empty:
                messagebox.showwarning("Veri Hatası", "Veritabanında bu faturaya ait detay bulunamadı.")
                return

            FaturaGoruntulePopup(self.master, df_invoice_rows)

        except Exception as e:
            messagebox.showerror("Hata", f"Görüntüleyici hatası: {e}")

    def refresh_treeview(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        if self.df_filtered.empty: return

        df_display = self.df_filtered
        if 'TARIH_FATURA' in self.df_filtered.columns:
            df_display = self.df_filtered.sort_values(by="TARIH_FATURA", ascending=False)

        for index, row in df_display.iterrows():
            row_values = []
            for col in self.COLUMNS:
                val = row.get(col, "")
                if col == "TARIH_FATURA" and pd.notnull(val) and val != "":
                    try: val = val.strftime("%d.%m.%Y")
                    except: pass
                elif isinstance(val, (float, int)) and col not in ["NO_FATURA", "ETTN", "SATICI_VKN_TCKN", "ALICI_VKN_TCKN"]:
                    try: val = f"{float(val):,.2f}"
                    except: pass
                row_values.append(val)
            self.tree.insert("", "end", values=tuple(row_values))

    def update_stats(self):
        if self.df_filtered.empty: 
            for k in self.stat_vars.keys(): self.stat_vars[k].set("0")
            return
            
        # Mükerrerleri atarak Fatura bazlı hesaplama
        unique = self.df_filtered.drop_duplicates(subset=["NO_FATURA"])
        
        # 1. TAB İSTATİSTİKLERİ (Temel)
        cnt = len(unique)
        tot = unique['TOPLAM_TUTAR'].sum() if 'TOPLAM_TUTAR' in unique.columns else 0
        avg = tot / cnt if cnt > 0 else 0
        parties = len(set(list(unique['SATICI_KURUM'].dropna().unique()) + list(unique['ALICI_KURUM'].dropna().unique())))
        
        self.stat_vars['adet_var'].set(f"{cnt}")
        self.stat_vars['tutar_var'].set(f"₺ {tot:,.2f}")
        self.stat_vars['ort_var'].set(f"₺ {avg:,.2f}")
        self.stat_vars['cari_var'].set(f"{parties}")

        # 2. TAB İSTATİSTİKLERİ (Detaylı Analiz 8 Adet)
        kdv_tot = unique['TOP_KDV_TUTAR'].sum() if 'TOP_KDV_TUTAR' in unique.columns else 0
        otv_tot = unique['TOP_OTV_TUTAR'].sum() if 'TOP_OTV_TUTAR' in unique.columns else 0
        tev_tot = unique['TOP_TEVKIFAT_TUTAR'].sum() if 'TOP_TEVKIFAT_TUTAR' in unique.columns else 0
        isk_tot = unique['ISKONTO'].sum() if 'ISKONTO' in unique.columns else 0
        
        tev_count = len(unique[unique['TOP_TEVKIFAT_TUTAR'] > 0]) if 'TOP_TEVKIFAT_TUTAR' in unique.columns else 0
        isk_count = len(unique[unique['ISKONTO'] > 0]) if 'ISKONTO' in unique.columns else 0
        max_fat = unique['TOPLAM_TUTAR'].max() if 'TOPLAM_TUTAR' in unique.columns else 0
        
        try:
            top_cari = unique.groupby('SATICI_KURUM')['TOPLAM_TUTAR'].sum().idxmax()
        except: top_cari = "-"

        self.stat_vars['kdv_tot_var'].set(f"₺ {kdv_tot:,.2f}")
        self.stat_vars['otv_tot_var'].set(f"₺ {otv_tot:,.2f}")
        self.stat_vars['tev_tot_var'].set(f"₺ {tev_tot:,.2f}")
        self.stat_vars['isk_tot_var'].set(f"₺ {isk_tot:,.2f}")
        self.stat_vars['tev_count_var'].set(f"{tev_count} Adet")
        self.stat_vars['isk_count_var'].set(f"{isk_count} Adet")
        self.stat_vars['max_fat_var'].set(f"₺ {max_fat:,.2f}")
        self.stat_vars['top_cari_var'].set(f"{str(top_cari)[:15]}")

    def setup_sidebar(self):
        tk.Label(self.sidebar, text="Filtreler", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_MAIN, font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 20))
        self.create_sidebar_entry(self.sidebar, "Hızlı Arama", "genel_ara")

        frm_date = tk.LabelFrame(self.sidebar, text="Tarama Aralığı", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 9), bd=0)
        frm_date.pack(fill=tk.X, pady=10)
        
        f_d1 = tk.Frame(frm_date, bg=CLR_BG_SIDEBAR); f_d1.pack(fill=tk.X)
        tk.Label(f_d1, text="Başlangıç (Örn: 2022-01-01)", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 8)).pack(anchor="w")
        # HATANIN SEBEBİ BURASIYDI: Varsayılan 2023 tarihini sildik, artık sen yazmadıkça tarihi kısıtlamaz
        self.create_filter_entry(f_d1, "bas_tarih", "")

        f_d2 = tk.Frame(frm_date, bg=CLR_BG_SIDEBAR); f_d2.pack(fill=tk.X, pady=(5,0))
        tk.Label(f_d2, text="Bitiş", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 8)).pack(anchor="w")
        self.create_filter_entry(f_d2, "bit_tarih", "")

        frm_party = tk.LabelFrame(self.sidebar, text="Taraf Bilgisi", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 9), bd=0)
        frm_party.pack(fill=tk.X, pady=10)
        tk.Label(frm_party, text="Satıcı VKN/Ünvan", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 8)).pack(anchor="w")
        self.create_filter_entry(frm_party, "satici_ara")
        tk.Label(frm_party, text="Alıcı VKN/Ünvan", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 8)).pack(anchor="w", pady=(5,0))
        self.create_filter_entry(frm_party, "alici_ara")

        frm_amount = tk.LabelFrame(self.sidebar, text="Tutar", bg=CLR_BG_SIDEBAR, fg=CLR_TEXT_SUB, font=("Segoe UI", 9), bd=0)
        frm_amount.pack(fill=tk.X, pady=10)
        f_a1 = tk.Frame(frm_amount, bg=CLR_BG_SIDEBAR); f_a1.pack(fill=tk.X)
        self.create_filter_entry(f_a1, "min_tutar", width=10, side=tk.LEFT, placeholder="Min")
        self.create_filter_entry(f_a1, "max_tutar", width=10, side=tk.RIGHT, placeholder="Max")

        btn_frame = tk.Frame(self.sidebar, bg=CLR_BG_SIDEBAR)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=20)

        tk.Button(btn_frame, text="Filtrele", bg=CLR_BTN_PRIMARY, fg="white", font=("Segoe UI", 10, "bold"), bd=0, pady=8, command=self.apply_filters, cursor="hand2").pack(fill=tk.X, pady=5)
        tk.Button(btn_frame, text="Sıfırla", bg="#ecf0f1", fg=CLR_TEXT_MAIN, font=("Segoe UI", 10), bd=0, pady=8, command=self.reset_filters, cursor="hand2").pack(fill=tk.X)


    def apply_filters(self):
        if self.df_all_invoices.empty: return
        df = self.df_all_invoices.copy()

        # Türkçe Karakter Uyumlu Hızlı Çevirici
        def to_tr_upper(series):
            return series.astype(str).str.replace('i', 'İ').str.replace('ı', 'I').str.upper()

        # 1. GENEL ARAMA (Dinamik ve Korumalı)
        txt = self.entry_vars['genel_ara'].get().strip()
        if txt:
            txt_upper = txt.replace('i', 'İ').replace('ı', 'I').upper()
            hedef_sutunlar = ['NO_FATURA', 'SATICI_KURUM', 'ALICI_KURUM', 'SATICI_VKN_TCKN', 'MAL_HIZMET_CINSI']
            mevcut_sutunlar = [col for col in hedef_sutunlar if col in df.columns]

            if mevcut_sutunlar:
                mask = False
                for col in mevcut_sutunlar:
                    mask = mask | to_tr_upper(df[col]).str.contains(txt_upper, regex=False, na=False)
                df = df[mask]

        # 2. SATICI ARAMA
        satici = self.entry_vars['satici_ara'].get().strip()
        if satici and 'SATICI_KURUM' in df.columns:
            satici_upper = satici.replace('i', 'İ').replace('ı', 'I').upper()
            df = df[to_tr_upper(df['SATICI_KURUM']).str.contains(satici_upper, regex=False, na=False)]

        # 3. ALICI ARAMA
        alici = self.entry_vars['alici_ara'].get().strip()
        if alici and 'ALICI_KURUM' in df.columns:
            alici_upper = alici.replace('i', 'İ').replace('ı', 'I').upper()
            df = df[to_tr_upper(df['ALICI_KURUM']).str.contains(alici_upper, regex=False, na=False)]

        # 4. TARİH FİLTRESİ
        bas_t = self.entry_vars['bas_tarih'].get().strip()
        bit_t = self.entry_vars['bit_tarih'].get().strip()
        if 'TARIH_FATURA' in df.columns and bas_t and bit_t:
            try:
                d1 = pd.to_datetime(bas_t)
                d2 = pd.to_datetime(bit_t)
                df = df[(df['TARIH_FATURA'] >= d1) & (df['TARIH_FATURA'] <= d2)]
            except: pass

        # 5. TUTAR FİLTRELERİ
        try:
            min_t_str = self.entry_vars['min_tutar'].get().strip()
            if min_t_str and 'TOPLAM_TUTAR' in df.columns:
                df = df[df['TOPLAM_TUTAR'] >= float(min_t_str)]
        except: pass

        try:
            max_t_str = self.entry_vars['max_tutar'].get().strip()
            if max_t_str and 'TOPLAM_TUTAR' in df.columns:
                df = df[df['TOPLAM_TUTAR'] <= float(max_t_str)]
        except: pass

        self.df_filtered = df
        self.refresh_treeview()
        self.update_stats()
        self.update_charts()

        if self.df_filtered.empty:
            messagebox.showinfo("Sonuç", "Arama kriterlerine uygun kayıt bulunamadı.")

    def reset_filters(self):
        for k, v in self.entry_vars.items():
            # Sıfırla butonuna basıldığında da tarihleri tamamen boşaltır
            v.set("")
        self.df_filtered = self.df_all_invoices.copy()
        self.refresh_treeview()
        self.update_stats()
        self.update_charts()
        
    def sort_treeview(self, col):
        if self.df_filtered.empty: return
        try:
            self.df_filtered = self.df_filtered.sort_values(by=col, ascending=True)
            self.refresh_treeview()
        except: pass

    def export_to_excel(self):
        if self.df_filtered.empty: return
        path = filedialog.asksaveasfilename(defaultextension=".xlsx")
        if path:
            try:
                self.df_filtered[self.COLUMNS].to_excel(path, index=False)
                messagebox.showinfo("Tamam", "Excel kaydedildi.")
            except Exception as e: messagebox.showerror("Hata", str(e))

    def delete_all_invoices(self):
        if not self.current_mukellef_info: return
        if not messagebox.askyesno("Dikkat", "Veritabanı silinecek! Onaylıyor musunuz?"): return
        vkn = self.current_mukellef_info['vkn']; unvan = self.current_mukellef_info['unvan']
        yil = self.current_mukellef_info['yil']
        base_dir = get_mukellefler_dir()
        t_dir = os.path.join(base_dir, f"{unvan}-{vkn}")
        if not os.path.exists(t_dir): t_dir = os.path.join(base_dir, f"{unvan.replace(' ', '_')}-{vkn}")
        db = os.path.join(t_dir, str(yil), f"fatura_data_{yil}.db")
        if os.path.exists(db):
            try:
                os.remove(db)
                self.df_all_invoices = pd.DataFrame()
                self.df_filtered = pd.DataFrame()
                self.refresh_treeview()
                self.update_stats()
                self.update_charts()
                messagebox.showinfo("Başarılı", "Silindi.")
            except Exception as e: messagebox.showerror("Hata", str(e))