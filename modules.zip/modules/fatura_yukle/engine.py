import os
import zipfile
import io
import pandas as pd
import sqlite3
from config import get_mukellefler_dir
# Proje mimarisine uygun session yönetimi
from utils.session_db import get_last_session 
from modules.fatura_yukle.parser import parse_single_invoice_content

def process_zip_recursive(zip_ref, result_list, source_path):
    """
    ZIP içindeki dosyaları tarar ve XML faturaları bulur.
    source_path: ZIP dosyasının bilgisayardaki tam yolu.
    """
    for file_info in zip_ref.infolist():
        filename = file_info.filename
        lower_name = filename.lower()
        
        # XML Dosyası ise
        if lower_name.endswith('.xml'):
            try:
                xml_content = zip_ref.read(filename)
                rows = parse_single_invoice_content(xml_content, filename)
                if rows:
                    for row in rows:
                        row['DOSYA_YOLU'] = source_path
                        row['DOSYA_TIPI'] = 'ZIP'
                        row['ZIP_ICI_AD'] = filename
                    result_list.extend(rows)
            except Exception as e:
                print(f"XML ZIP içi hata ({filename}): {e}")
                
        # İç içe ZIP ise
        elif lower_name.endswith('.zip'):
            try:
                nested_data = io.BytesIO(zip_ref.read(filename))
                with zipfile.ZipFile(nested_data) as nested_zip:
                    process_zip_recursive(nested_zip, result_list, source_path)
            except Exception as e:
                print(f"Nested ZIP hata ({filename}): {e}")


def toplu_fatura_iptal_et(ettn_listesi, vkn=None, yil=None):
    """
    Verilen ETTN listesini 'IPTAL_ETTN_LISTESI' tablosuna kaydeder ve 
    eğer FATURALAR tablosunda bu ETTN'ler varsa TIP_FATURA alanını günceller.
    """
    if vkn is None or yil is None:
        session = get_last_session()
        if not session:
            raise ValueError("Aktif oturum veya parametre bulunamadı.")
        vkn = session.get('vkn')
        yil = session.get('yil')

    if not ettn_listesi:
        return 0

    try:
        db_path = get_target_db_path(vkn, yil)
    except Exception as e:
        raise e
        
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 1. KARA LİSTE TABLOSUNU OLUŞTUR (Yoksa)
        cursor.execute('''CREATE TABLE IF NOT EXISTS IPTAL_ETTN_LISTESI (
                            ETTN TEXT PRIMARY KEY
                          )''')
                          
        # 2. ETTN'LERİ KARA LİSTEYE EKLE (Zaten varsa IGNORE ile atla)
        for ettn in ettn_listesi:
            cursor.execute("INSERT OR IGNORE INTO IPTAL_ETTN_LISTESI (ETTN) VALUES (?)", (ettn,))
        
        # 3. EĞER FATURALAR TABLOSU VARSA MEVCUT KAYITLARI GÜNCELLE
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='FATURALAR'")
        if cursor.fetchone():
            placeholders = ','.join('?' for _ in ettn_listesi)
            query = f"UPDATE FATURALAR SET TIP_FATURA = 'IPTAL' WHERE ETTN IN ({placeholders})"
            cursor.execute(query, ettn_listesi)
            guncellenen_kayit_sayisi = cursor.rowcount
        else:
            guncellenen_kayit_sayisi = 0
            
        conn.commit()
        return guncellenen_kayit_sayisi
        
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()


def toplu_fatura_oku(dosya_yolu):
    """
    Verilen dosya yolundaki (XML veya ZIP) faturaları okur ve liste döner.
    """
    tum_satirlar = []
    
    if not os.path.exists(dosya_yolu):
        print("Dosya yolu bulunamadı.")
        return []

    tam_yol = os.path.abspath(dosya_yolu)

    try:
        if dosya_yolu.lower().endswith('.xml'):
            with open(dosya_yolu, 'rb') as f:
                rows = parse_single_invoice_content(f.read(), os.path.basename(dosya_yolu))
                if rows:
                    for row in rows:
                        row['DOSYA_YOLU'] = tam_yol
                        row['DOSYA_TIPI'] = 'XML'
                        row['ZIP_ICI_AD'] = ''
                    tum_satirlar.extend(rows)
                
        elif dosya_yolu.lower().endswith('.zip'):
            with zipfile.ZipFile(dosya_yolu, 'r') as z:
                process_zip_recursive(z, tum_satirlar, tam_yol)
                
    except Exception as e:
        print(f"Toplu Okuma Hatası: {e}")
        
    return tum_satirlar

def get_target_db_path(vkn, yil):
    """
    MİMARİ KURAL: Klasör adını tahmin etme, VKN ile biten klasörü bul.
    """
    base_dir = get_mukellefler_dir()
    target_folder = None
    
    # 1. Ana dizini tara ve sonu -VKN ile biten klasörü bul
    if os.path.exists(base_dir):
        for f in os.listdir(base_dir):
            full_path = os.path.join(base_dir, f)
            if os.path.isdir(full_path) and f.endswith(f"-{vkn}"):
                target_folder = full_path
                break
    
    # Klasör yoksa hata fırlat (Çünkü önce mükellef oluşturulmalı)
    if not target_folder:
        raise FileNotFoundError(f"Sistemde VKN: {vkn} ile biten bir mükellef klasörü bulunamadı.")

    # 2. Yıl Klasörü Kontrolü
    yil_dir = os.path.join(target_folder, str(yil))
    os.makedirs(yil_dir, exist_ok=True)
    
    # 3. DB Yolu
    db_path = os.path.join(yil_dir, f"fatura_data_{yil}.db")
    return db_path


def faturayi_veritabanina_kaydet(df, vkn=None, yil=None):
    """
    DataFrame'i ilgili mükellefin YIL klasöründeki SQLite veritabanına kaydeder.
    Veritabanında önceden kayıtlı ETTN değerlerini kontrol ederek mükerrer kaydı engeller, 
    sadece yeni faturaları mevcut tablonun üzerine ekler (append).
    """
    # Parametreler boşsa Session'dan al
    if vkn is None or yil is None:
        session = get_last_session()
        if not session:
            raise ValueError("Aktif oturum veya parametre bulunamadı.")
        vkn = session.get('vkn')
        yil = session.get('yil')

    if df.empty: return 0, 0, ""
    
    # Mimariye uygun DB yolunu al
    try:
        db_path = get_target_db_path(vkn, yil)
    except Exception as e:
        raise e

    table_name = "FATURALAR"
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Tablo var mı?
        cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")
        table_exists = cursor.fetchone()
        
        existing_ettns = set()
        
        if table_exists:
            # Sütun kontrolü ve dinamik ekleme
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [info[1] for info in cursor.fetchall()]
            
            required_cols = [
                'DOSYA_YOLU', 'DOSYA_TIPI', 'ZIP_ICI_AD',
                'SATICI_IL', 'SATICI_ILCE', 'SATICI_ADRES', 'SATICI_TELEFON', 'SATICI_EPOSTA'
            ]
            for col in required_cols:
                if col not in columns:
                    cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {col} TEXT")
            
            # 1- DATABASE'İ KONTROL ET: Mevcut ETTN'leri getir (Hızlı arama için Set yapısı)
            cursor.execute(f"SELECT DISTINCT ETTN FROM {table_name} WHERE ETTN IS NOT NULL")
            existing_ettns = {row[0] for row in cursor.fetchall() if row[0]}
        
        if 'ETTN' not in df.columns:
            raise ValueError("Veri setinde ETTN sütunu eksik! ETTN olmadan mükerrer kontrolü yapılamaz.")
            
        initial_count = len(df)
        
        # MÜKERRER OLANLARI KAYDETME: Dataframe içinden db'de var olan ETTN'leri çıkartıyoruz
        df_new = df[~df['ETTN'].isin(existing_ettns)].copy()
        
        # Sütun güvenliği
        guvence_sutunlari = ['SATICI_IL', 'SATICI_ILCE', 'SATICI_ADRES', 'SATICI_TELEFON', 'SATICI_EPOSTA']
        for col in guvence_sutunlari:
            if col not in df_new.columns:
                df_new[col] = ""

        new_count = len(df_new)
        skipped_count = initial_count - new_count
        # --- YENİ MANTIK: KARA LİSTE (İPTAL) KONTROLÜ ---
        if new_count > 0:
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='IPTAL_ETTN_LISTESI'")
            if cursor.fetchone():
                # İptal havuzundaki tüm ETTN'leri çek
                cursor.execute("SELECT ETTN FROM IPTAL_ETTN_LISTESI")
                iptal_havuzu = {row[0] for row in cursor.fetchall() if row[0]}
                
                if iptal_havuzu:
                    # Yeni eklenecek veri setinde (df_new) ETTN'si iptal havuzunda olanların TIP_FATURA'sını ez
                    df_new.loc[df_new['ETTN'].isin(iptal_havuzu), 'TIP_FATURA'] = 'IPTAL'
        # ------------------------------------------------

        
        # 2- FARKLI VERİLER: Mevcut database'e ek (append) olarak kaydet ve devam et
        if new_count > 0:
            df_new.to_sql(table_name, conn, if_exists='append', index=False)
            
        return new_count, skipped_count, db_path

    except Exception as e:
        raise e
    finally:
        conn.close()


        # --- YENİ EKLENEN FONKSİYON ---
def veritabanindan_fatura_oku(vkn=None, yil=None):
    """
    Belirtilen VKN ve Yıl için SQLite veritabanındaki kayıtlı faturaları okur.
    Parametreler verilmezse aktif session'dan alır.
    Geriye DataFrame döner.
    """
    # Parametreler boşsa Session'dan al
    if vkn is None or yil is None:
        session = get_last_session()
        if not session:
            print("Aktif oturum veya parametre bulunamadı.")
            return pd.DataFrame() # Boş DataFrame dön
        vkn = session.get('vkn')
        yil = session.get('yil')

    try:
        # DB yolunu bul
        db_path = get_target_db_path(vkn, yil)
        
        if not os.path.exists(db_path):
            print(f"Veritabanı dosyası bulunamadı: {db_path}")
            return pd.DataFrame()

        # Veritabanına bağlan ve oku
        conn = sqlite3.connect(db_path)
        query = "SELECT * FROM FATURALAR"
        df = pd.read_sql(query, conn)
        conn.close()
        
        return df

    except Exception as e:
        print(f"Veritabanından okuma hatası: {e}")
        return pd.DataFrame()