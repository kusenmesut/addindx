<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:n1="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
    xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
    xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
    xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">

    <xsl:output method="html" encoding="UTF-8" indent="yes"/>

    <xsl:template match="/n1:Invoice">
        <html>
            <head>
                <title>e-Fatura - GİB Standart Formatı</title>
                <style type="text/css">
                    body { font-family: 'Tahoma', "Times New Roman", Times, serif; font-size: 11px; color: #333; background-color: #FFF; margin: 30px; }
                    table { border-collapse: collapse; width: 100%; }
                    td, th { border: 1px solid black; padding: 4px; font-size: 11px; }
                    .no-border, .no-border td { border: none; }
                    .header-title { font-size: 1.4em; font-weight: bold; text-align: center; font-family: Arial, sans-serif; margin-top:5px; display:block;}
                    .gib-logo { width: 95px; }
                    .info-table { width: 260px; float: right; border: 2px solid gray; }
                    .info-table td { border: 1px solid gray; padding: 3px; }
                    .totals-table { width: 35%; float: right; margin-top: 15px; border: 2px solid black; }
                    .totals-table td { border: 1px solid black; padding: 4px; }
                    .notes-box { border: 2px solid black; padding: 10px; margin-top: 20px; width: 100%; }
                    hr { border: 1px solid black; }
                </style>
            </head>
            <body>
                <table class="no-border" width="100%">
                    <tr>
                        <td width="40%" valign="top">
                            <hr/>
                            <b><xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyName/cbc:Name"/></b><br/><br/>
                            <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName"/> / <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cbc:CityName"/><br/>
                            Vergi Dairesi: <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme/cbc:Name"/><br/>
                            VKN/TCKN: <xsl:value-of select="cac:AccountingSupplierParty/cac:Party/cac:PartyIdentification/cbc:ID"/><br/>
                            <hr/>
                        </td>
                        <td width="20%" align="center" valign="middle">
                            <img src="gib_logo.png" class="gib-logo" alt="GİB Logo"/><br/>
                            <span class="header-title">e-FATURA</span>
                        </td>
                        <td width="40%" valign="top"></td>
                    </tr>
                    <tr>
                        <td valign="top">
                            <br/><hr/>
                            <b>SAYIN</b><br/>
                            <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PartyName/cbc:Name"/><br/>
                            <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:StreetName"/><br/>
                            <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:CitySubdivisionName"/> / <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cbc:CityName"/><br/>
                            Vergi Dairesi: <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme/cbc:Name"/><br/>
                            VKN/TCKN: <xsl:value-of select="cac:AccountingCustomerParty/cac:Party/cac:PartyIdentification/cbc:ID"/>
                            <br/><hr/>
                        </td>
                        <td colspan="2" valign="bottom">
                            <table class="info-table">
                                <tr><td><b>Özelleştirme No:</b></td><td><xsl:value-of select="cbc:CustomizationID"/></td></tr>
                                <tr><td><b>Senaryo:</b></td><td><xsl:value-of select="cbc:ProfileID"/></td></tr>
                                <tr><td><b>Fatura Tipi:</b></td><td><xsl:value-of select="cbc:InvoiceTypeCode"/></td></tr>
                                <tr><td><b>Fatura No:</b></td><td><xsl:value-of select="cbc:ID"/></td></tr>
                                <tr><td><b>Fatura Tarihi:</b></td><td><xsl:value-of select="cbc:IssueDate"/></td></tr>
                            </table>
                        </td>
                    </tr>
                </table>

                <br/>
                <b>ETTN:</b> <xsl:value-of select="cbc:UUID"/><br/><br/>

                <table border="1" style="border: 2px solid black;">
                    <tr style="background-color: #ffffff; font-weight: bold; text-align: center;">
                        <td width="4%">Sıra No</td>
                        <td width="25%">Mal Hizmet</td>
                        <td width="8%">Miktar</td>
                        <td width="8%">Birim Fiyat</td>
                        <td width="8%">İskonto Oranı</td>
                        <td width="8%">İskonto Tutarı</td>
                        <td width="7%">KDV Oranı</td>
                        <td width="9%">KDV Tutarı</td>
                        <td width="13%">Diğer Vergiler</td>
                        <td width="10%">Mal Hizmet Tutarı</td>
                    </tr>
                    <xsl:for-each select="cac:InvoiceLine">
                        <tr>
                            <td align="center"><xsl:value-of select="cbc:ID"/></td>
                            <td><xsl:value-of select="cac:Item/cbc:Name"/></td>
                            <td align="right"><xsl:value-of select="cbc:InvoicedQuantity"/> <xsl:value-of select="cbc:InvoicedQuantity/@unitCode"/></td>
                            <td align="right"><xsl:value-of select="cac:Price/cbc:PriceAmount"/> TL</td>
                            <td align="right"></td>
                            <td align="right"></td>
                            <td align="right">%<xsl:value-of select="cac:TaxTotal/cac:TaxSubtotal/cbc:Percent"/></td>
                            <td align="right"><xsl:value-of select="cac:TaxTotal/cac:TaxSubtotal/cbc:TaxAmount"/> TL</td>
                            <td align="right" style="font-size: 9px; color: gray;">
                                <xsl:for-each select="cac:WithholdingTaxTotal/cac:TaxSubtotal">
                                    TEVKİFAT (%<xsl:value-of select="cbc:Percent"/>) = <xsl:value-of select="cbc:TaxAmount"/> TL<br/>
                                </xsl:for-each>
                            </td>
                            <td align="right"><xsl:value-of select="cbc:LineExtensionAmount"/> TL</td>
                        </tr>
                    </xsl:for-each>
                </table>

                <table class="totals-table">
                    <tr><td width="60%"><b>Mal Hizmet Toplam Tutarı</b></td><td align="right" width="40%"><xsl:value-of select="cac:LegalMonetaryTotal/cbc:LineExtensionAmount"/> TL</td></tr>
                    <tr><td><b>Toplam İskonto</b></td><td align="right"><xsl:value-of select="cac:LegalMonetaryTotal/cbc:AllowanceTotalAmount"/> TL</td></tr>
                    
                    <xsl:for-each select="cac:TaxTotal[1]/cac:TaxSubtotal">
                        <tr><td><b>Hesaplanan KDV (%<xsl:value-of select="cbc:Percent"/>)</b></td><td align="right"><xsl:value-of select="cbc:TaxAmount"/> TL</td></tr>
                    </xsl:for-each>

                    <xsl:if test="cac:WithholdingTaxTotal">
                        <tr><td><b>Hesaplanan KDV Tevkifat</b></td><td align="right"><xsl:value-of select="cac:WithholdingTaxTotal/cbc:TaxAmount"/> TL</td></tr>
                    </xsl:if>

                    <tr><td><b>Vergiler Dahil Toplam Tutar</b></td><td align="right"><xsl:value-of select="cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount"/> TL</td></tr>
                    <tr><td><b>Ödenecek Tutar</b></td><td align="right"><xsl:value-of select="cac:LegalMonetaryTotal/cbc:PayableAmount"/> TL</td></tr>
                </table>

                <div style="clear: both;"></div>

                <div class="notes-box">
                    <xsl:for-each select="cbc:Note">
                        <b>Not: </b><xsl:value-of select="."/><br/>
                    </xsl:for-each>
                </div>
            </body>
        </html>
    </xsl:template>
</xsl:stylesheet>