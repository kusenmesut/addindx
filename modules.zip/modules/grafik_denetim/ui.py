import tkinter as tk
from tkinter import ttk, messagebox
import sys
import os

# Matplotlib
try:
    import matplotlib
    matplotlib.use("TkAgg")
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
    from matplotlib.figure import Figure
    import matplotlib.dates as mdates
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False
    
try:
    from .engine import ChartEngine
except ImportError:
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from engine import ChartEngine

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
from config import CLR_BODY_BG, CLR_ACCENT

# NoteManager
try:
    from modules.not_yonetimi.ui import NoteManager
    HAS_NOTES = True
except ImportError:
    HAS_NOTES = False

# Colors
CLR_BG = "#ecf0f1"
CLR_SIDEBAR = "white"
CLR_BORC = "red"      # Kırmızı
CLR_ALACAK = "green"  # Yeşil
CLR_BAKIYE = "black"  # Siyah
CLR_FIS_HEADER = "#0F3057"

class SelectedAccountsPanel(tk.Frame):
    # Sağ tarafta seçilen hesapları ve modlarını gösteren panel
    def __init__(self, master, command=None, **kwargs):
        super().__init__(master, **kwargs)
        self.command = command 
        self.items = {} 
        
        tk.Label(self, text="SEÇİLEN HESAPLAR & MODLARI", bg="#34495e", fg="white", font=("Arial", 9, "bold")).pack(fill="x")
        
        self.canvas = tk.Canvas(self, bg="white", height=100, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg="white")
        
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

    def add_account(self, code, name):
        if code in self.items: return
        row = tk.Frame(self.scrollable_frame, bg="white")
        row.pack(fill="x", padx=5, pady=2)
        var_visible = tk.BooleanVar(value=True)
        chk = tk.Checkbutton(row, text=f"{code}", variable=var_visible, bg="white", font=("Arial", 9, "bold"), command=self.command)
        chk.pack(side="left")
        lbl = tk.Label(row, text=f"- {name[:15]}..", bg="white", font=("Arial", 8), fg="gray")
        lbl.pack(side="left")
        cmb = ttk.Combobox(row, values=["BAKİYE", "BORÇ", "ALACAK", "TÜMÜ"], state="readonly", width=8, font=("Arial", 8))
        cmb.set("BAKİYE")
        cmb.pack(side="right", padx=2)
        cmb.bind("<<ComboboxSelected>>", lambda e: self.command())
        self.items[code] = {"frame": row, "var": var_visible, "combo": cmb}
        self.command()

    def remove_account(self, code):
        if code in self.items:
            self.items[code]["frame"].destroy()
            del self.items[code]
            self.command()

    def get_active_configs(self):
        configs = []
        for code, data in self.items.items():
            if data["var"].get(): configs.append((code, data["combo"].get()))
        return configs
        
    def clear(self):
        for code in list(self.items.keys()): self.remove_account(code)

class ScrollableCheckBoxList(tk.Frame):
    # Sol taraftaki ana hesap listesi
    def __init__(self, master, on_check=None, on_uncheck=None, **kwargs):
        super().__init__(master, **kwargs)
        self.on_check = on_check
        self.on_uncheck = on_uncheck
        self.vars = {} 
        self.canvas = tk.Canvas(self, bg="white", highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg="white")
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
    def add_item(self, code, name):
        var = tk.BooleanVar()
        def callback():
            if var.get(): self.on_check(code, name)
            else: self.on_uncheck(code)
        chk = tk.Checkbutton(self.scrollable_frame, text=f"{code} - {name}", variable=var, bg="white", anchor="w", command=callback)
        chk.pack(fill="x", padx=5, pady=2)
        self.vars[code] = var

    def set_checked(self, code, state=True):
        if code in self.vars:
            current = self.vars[code].get()
            if current != state:
                self.vars[code].set(state)
                # İsim engine'den alınmalı ama burada basitçe tetikliyoruz
                if state: self.on_check(code, "Hesap") 
                else: self.on_uncheck(code)

    def clear(self):
        for w in self.scrollable_frame.winfo_children(): w.destroy()
        self.vars.clear()

class ChartAuditFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BG)
        self.engine = ChartEngine()
        self.canvas = None
        if not HAS_MATPLOTLIB:
            tk.Label(self, text="Matplotlib kütüphanesi eksik!", fg="red").pack(expand=True)
            return
        self.setup_ui()
        self.load_account_list()

    def setup_ui(self):
        paned = tk.PanedWindow(self, orient=tk.HORIZONTAL, sashwidth=4, bg="#bdc3c7")
        paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # LEFT PANEL
        left_frame = tk.Frame(paned, bg=CLR_SIDEBAR, width=350)
        paned.add(left_frame)
        tk.Label(left_frame, text="HESAP LİSTESİ", bg="#34495e", fg="white", font=("Arial", 10, "bold"), pady=8).pack(fill=tk.X)
        self.ent_search = tk.Entry(left_frame, bg="#ecf0f1")
        self.ent_search.pack(fill=tk.X, padx=5, pady=5)
        self.ent_search.bind("<KeyRelease>", self.filter_list)
        self.chk_list = ScrollableCheckBoxList(left_frame, on_check=self.add_to_chart, on_uncheck=self.remove_from_chart, bg="white")
        self.chk_list.pack(fill=tk.BOTH, expand=True)

        # RIGHT PANEL
        right_frame = tk.Frame(paned, bg="white")
        paned.add(right_frame)
        ctrl_frame = tk.Frame(right_frame, bg="white", height=45)
        ctrl_frame.pack(fill=tk.X, padx=10, pady=5)
        tk.Label(ctrl_frame, text="Zaman:", bg="white", font=("Arial", 9, "bold")).pack(side=tk.LEFT, padx=5)
        self.cmb_period = ttk.Combobox(ctrl_frame, values=["GÜNLÜK", "AYLIK", "3 AYLIK", "YILLIK"], state="readonly", width=10)
        self.cmb_period.pack(side=tk.LEFT, padx=5)
        self.cmb_period.set("GÜNLÜK")
        self.cmb_period.bind("<<ComboboxSelected>>", lambda e: self.draw_chart())
        tk.Label(ctrl_frame, text="ℹ️ Tıklayarak fiş detayını gör.", bg="white", fg="gray").pack(side=tk.RIGHT, padx=10)
        self.selected_panel = SelectedAccountsPanel(right_frame, command=self.draw_chart, bg="white", height=120)
        self.selected_panel.pack(fill=tk.X, padx=10, pady=5)
        self.graph_container = tk.Frame(right_frame, bg="white")
        self.graph_container.pack(fill=tk.BOTH, expand=True)

    def load_account_list(self):
        self.all_accounts = []
        self.chk_list.clear()
        for code, name in self.engine.accounts.items():
            self.all_accounts.append((code, name))
            self.chk_list.add_item(code, name)

    def filter_list(self, event):
        search = self.ent_search.get().lower()
        self.chk_list.clear()
        for code, name in self.all_accounts:
            if search in f"{code} {name}".lower():
                self.chk_list.add_item(code, name)
    
    def add_to_chart(self, code, name):
        if name == "Hesap": name = self.engine.accounts.get(code, "Bilinmiyor")
        self.selected_panel.add_account(code, name)
        
    def remove_from_chart(self, code):
        self.selected_panel.remove_account(code)

    # --- DIŞARIDAN TETİKLENEN NAVİGASYON ---
    def select_account(self, account_code):
        # Mizan'dan gelen istek üzerine hesabı seçer ve çizer
        self.selected_panel.clear()
        if account_code in self.chk_list.vars:
            self.chk_list.vars[account_code].set(True)
            name = self.engine.accounts.get(account_code, "Bilinmiyor")
            self.add_to_chart(account_code, name)
        else:
            messagebox.showwarning("Uyarı", f"{account_code} nolu hesap grafik listesinde bulunamadı.")

    def draw_chart(self):
        selected_items = self.selected_panel.get_active_configs()
        period = self.cmb_period.get()
        for w in self.graph_container.winfo_children(): w.destroy()
        if not selected_items:
            tk.Label(self.graph_container, text="Lütfen soldan en az bir hesap seçiniz.", bg="white", fg="gray").pack(expand=True)
            return
        codes_only = [c[0] for c in selected_items]
        data = self.engine.get_multi_account_data(codes_only, period)
        if not data: return
        fig = Figure(figsize=(8, 5), dpi=100)
        ax = fig.add_subplot(111)
        self.scatter_points = []
        for code, mode in selected_items:
            if code not in data: continue
            d = data[code]; x_vals = d['x']; lbl_pre = f"{code}"
            if mode in ["BORÇ", "TÜMÜ"] and d['borc']:
                ax.plot(x_vals, d['borc'], linestyle='--', color=CLR_BORC, alpha=0.6, label=f"{lbl_pre} Borç")
                mask = [abs(v) > 0.01 for v in d['borc']]
                if any(mask):
                    x_sc = [x_vals[i] for i, v in enumerate(mask) if v]
                    y_sc = [d['borc'][i] for i, v in enumerate(mask) if v]
                    ind_sc = [i for i, v in enumerate(mask) if v]
                    sc = ax.scatter(x_sc, y_sc, color=CLR_BORC, s=20, picker=5)
                    self.scatter_points.append({'sc': sc, 'data': d, 'type': 'Borç', 'key': 'borc', 'indices': ind_sc})
            if mode in ["ALACAK", "TÜMÜ"] and d['alacak']:
                ax.plot(x_vals, d['alacak'], linestyle=':', color=CLR_ALACAK, alpha=0.6, label=f"{lbl_pre} Alacak")
                mask = [abs(v) > 0.01 for v in d['alacak']]
                if any(mask):
                    x_sc = [x_vals[i] for i, v in enumerate(mask) if v]
                    y_sc = [d['alacak'][i] for i, v in enumerate(mask) if v]
                    ind_sc = [i for i, v in enumerate(mask) if v]
                    sc = ax.scatter(x_sc, y_sc, color=CLR_ALACAK, s=20, marker='s', picker=5)
                    self.scatter_points.append({'sc': sc, 'data': d, 'type': 'Alacak', 'key': 'alacak', 'indices': ind_sc})
            if mode in ["BAKİYE", "TÜMÜ"] and d['balance']:
                ax.plot(x_vals, d['balance'], linestyle='-', color=CLR_BAKIYE, linewidth=1.5, label=f"{lbl_pre} Bakiye")
                sc = ax.scatter(x_vals, d['balance'], color=CLR_BAKIYE, s=15, picker=5)
                all_inds = list(range(len(x_vals)))
                self.scatter_points.append({'sc': sc, 'data': d, 'type': 'Bakiye', 'key': 'balance', 'indices': all_inds})
        if ax.get_legend_handles_labels()[0]: ax.legend()
        ax.grid(True, linestyle='--', alpha=0.5)
        if period == "GÜNLÜK": ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
        fig.autofmt_xdate()
        canvas = FigureCanvasTkAgg(fig, master=self.graph_container)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        toolbar = NavigationToolbar2Tk(canvas, self.graph_container)
        toolbar.update()
        self.annot = ax.annotate("", xy=(0,0), xytext=(20,20), textcoords="offset points", bbox=dict(boxstyle="round", fc="w", alpha=0.9), arrowprops=dict(arrowstyle="->"))
        self.annot.set_visible(False)
        def hover(event):
            vis = self.annot.get_visible()
            if event.inaxes == ax:
                for item in reversed(self.scatter_points):
                    cont, ind = item['sc'].contains(event)
                    if cont:
                        sc_idx = ind["ind"][0]
                        orig_idx = item['indices'][sc_idx]
                        d = item['data']; yev = d['yev'][orig_idx]; desc = str(d['desc'][orig_idx]); amt = d[item['key']][orig_idx]
                        self.annot.xy = item['sc'].get_offsets()[sc_idx]
                        self.annot.set_text(f"Fiş: {yev}\n{item['type']}: {amt:,.2f}\n{desc[:30]}...")
                        self.annot.set_visible(True); canvas.draw_idle(); return
            if vis: self.annot.set_visible(False); canvas.draw_idle()
        def click(event):
            if event.inaxes == ax:
                for item in reversed(self.scatter_points):
                    cont, ind = item['sc'].contains(event)
                    if cont:
                        sc_idx = ind["ind"][0]; orig_idx = item['indices'][sc_idx]; fis_no = item['data']['yev'][orig_idx]
                        self.open_fis_detail(fis_no); break
        canvas.mpl_connect("motion_notify_event", hover)
        canvas.mpl_connect("button_press_event", click)

    def open_fis_detail(self, fis_no):
        items = self.engine.get_fis_details(fis_no)
        if not items: return
        popup = tk.Toplevel(self); popup.title(f"Fiş Detayı - No: {fis_no}"); popup.geometry("1000x500")
        head = tk.Frame(popup, bg=CLR_FIS_HEADER, height=60); head.pack(fill=tk.X)
        tk.Label(head, text=f"FİŞ NO: {fis_no}", bg=CLR_FIS_HEADER, fg="white", font=("Arial", 16, "bold")).pack(side=tk.LEFT, padx=20, pady=15)
        cols = ("Ref", "Kod", "Ad", "Aciklama", "Borc", "Alacak")
        tree = ttk.Treeview(popup, columns=cols, show="headings")
        tree.column("Ref", width=0, stretch=False); tree.heading("Ref", text="")
        tree.heading("Kod", text="Hesap Kodu"); tree.column("Kod", width=100)
        tree.heading("Ad", text="Hesap Adı"); tree.column("Ad", width=200)
        tree.heading("Aciklama", text="Açıklama"); tree.column("Aciklama", width=300)
        tree.heading("Borc", text="Borç"); tree.column("Borc", width=100, anchor="e")
        tree.heading("Alacak", text="Alacak"); tree.column("Alacak", width=100, anchor="e")
        tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        for it in items:
            desc = f"{it.get('Fiş Açıklama','')} {it.get('Detay Açıklama','')}"
            b = float(it.get('Borç', 0)); a = float(it.get('Alacak', 0))
            vals = (fis_no, it.get('Hesap Kodu'), it.get('Hesap Adı'), desc, f"{b:,.2f}", f"{a:,.2f}")
            tree.insert("", "end", values=vals)
        if HAS_NOTES:
            popup_notes = NoteManager(tree, "YEVMİYE", popup, indices={'ref':0, 'hk':1, 'ha':2, 'borc':4, 'alacak':5})
            popup_notes.color_rows()
