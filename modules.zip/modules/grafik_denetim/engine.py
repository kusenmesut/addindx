import os
import pandas as pd
import sys
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
from config import get_mukellefler_dir, get_base_dir
from utils.session_db import get_last_session

class ChartEngine:
    def __init__(self):
        self.df = pd.DataFrame()
        self.accounts = {}
        self.status_msg = "Hazır"
        self.load_data()

    def get_active_file_path(self):
        session = get_last_session()
        if not session: return None, "Oturum Yok", None
        vkn = session.get("vkn")
        year = session.get("year", session.get("yil"))
        if not vkn or str(vkn) == "---": return None, "Mükellef Seçilmedi", None
        base_dir = get_mukellefler_dir()
        target_folder = None
        for f in os.listdir(base_dir):
            if str(f).strip().endswith(f"-{str(vkn).strip()}"):
                target_folder = os.path.join(base_dir, f)
                break
        if not target_folder: return None, "Klasör Bulunamadı", None
        target_file = os.path.join(target_folder, str(year), f"{str(year)}_FULL.parquet")
        return target_file, "Veri Yüklendi", year

    def load_data(self):
        target_file, msg, year = self.get_active_file_path()
        self.status_msg = msg
        if not target_file or not os.path.exists(target_file):
            self.status_msg = "Veri Yok"
            return

        try:
            self.df = pd.read_parquet(target_file)
            col_map = {"KayitTarihi": "Tarih", "YevmiyeNo": "Yevmiye No", "HesapKodu": "Hesap Kodu", "HesapAdi": "Hesap Adı", "FisAciklamasi": "Fiş Açıklama", "DetayAciklama": "Detay Açıklama", "Borc": "Borç", "Alacak": "Alacak"}
            self.df.rename(columns=col_map, inplace=True)
            for col in ["Borç", "Alacak", "Yevmiye No"]:
                if col in self.df.columns:
                    self.df[col] = pd.to_numeric(self.df[col], errors='coerce').fillna(0)
            if 'Tarih' in self.df.columns:
                self.df['Tarih_Obj'] = pd.to_datetime(self.df['Tarih'], errors='coerce')
            
            if not self.df.empty:
                acc_df = self.df[['Hesap Kodu', 'Hesap Adı']].drop_duplicates().sort_values('Hesap Kodu')
                self.accounts = dict(zip(acc_df['Hesap Kodu'], acc_df['Hesap Adı']))
        except Exception as e:
            self.status_msg = f"Hata: {str(e)}"
            self.df = pd.DataFrame()

    def get_multi_account_data(self, account_codes, period="GÜNLÜK"):
        if self.df.empty or not account_codes: return {}
        series_data = {}
        
        for code in account_codes:
            sub_df = self.df[self.df['Hesap Kodu'] == str(code)].copy()
            if sub_df.empty: continue
            
            if period == "AYLIK": sub_df['GroupKey'] = sub_df['Tarih_Obj'].dt.to_period('M')
            elif period == "3 AYLIK": sub_df['GroupKey'] = sub_df['Tarih_Obj'].dt.to_period('Q')
            elif period == "YILLIK": sub_df['GroupKey'] = sub_df['Tarih_Obj'].dt.to_period('Y')
            else: sub_df['GroupKey'] = sub_df['Tarih_Obj']

            if period == "GÜNLÜK":
                sub_df.sort_values(by=['Tarih_Obj', 'Yevmiye No'], inplace=True)
                grouped = sub_df
                x_vals = grouped['Tarih_Obj'].tolist()
            else:
                grouped = sub_df.groupby('GroupKey').agg({'Borç': 'sum', 'Alacak': 'sum', 'Yevmiye No': 'max', 'Detay Açıklama': 'last'}).reset_index()
                if period == "3 AYLIK" or period == "YILLIK" or period == "AYLIK": x_vals = grouped['GroupKey'].dt.start_time.tolist()
                else: x_vals = grouped['GroupKey'].tolist()

            yev_vals = grouped['Yevmiye No'].tolist()
            desc_vals = (grouped['Detay Açıklama'].fillna('')).tolist()
            borc_y = grouped['Borç'].tolist()
            alacak_y = grouped['Alacak'].tolist()
            
            grouped['Net'] = grouped['Borç'] - grouped['Alacak']
            grouped['Balance'] = grouped['Net'].cumsum()
            bal_y = grouped['Balance'].tolist()

            series_data[code] = {
                "name": self.accounts.get(code, "Bilinmiyor"),
                "x": x_vals, "borc": borc_y, "alacak": alacak_y, "balance": bal_y,
                "yev": yev_vals, "desc": desc_vals, "period": period
            }
        return series_data

    def get_fis_details(self, fis_no):
        if self.df.empty: return []
        s_fis = str(fis_no).split('.')[0].strip()
        mask = self.df['Yevmiye No'].astype(str).str.split('.').str[0] == s_fis
        rows = self.df[mask]
        return rows.to_dict('records')
