import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
import json
import threading
import time
import zipfile
import io
import tempfile
import shutil
import socket  # Mevcut importların yanına ekleyiniz
import datetime
import base64
# Resim işleme için
from PIL import Image as PilImage
import sys
# Üst klasörden modül çağırmak için yol ekliyoruz
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(current_dir))
if parent_dir not in sys.path:
    sys.path.append(parent_dir)
# ... diğer importlar ...
from users import CloudLicenseManager

# Senin Profil Motorunu Çağırıyoruz
try:
    from modules.kullanici_profil.engine import ProfilEngine
except ImportError:
    ProfilEngine = None

# --- MEVCUT IMPORTLARIN ALTINA EKLEYİN ---
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Frame, KeepTogether, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
# --- MEVCUT IMPORTLARIN ALTINA EKLEYİN ---
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml
# PageBreak eklendi ^
import html # Metin temizliği için
# --- MODÜL IMPORTLARI ---
from .engine import AuditEngine 
from users import CloudLicenseManager
import sqlite3
import sys




def check_internet_connection(host="1.1.1.1", port=443, timeout=5):
    """
    Güvenilir Cloudflare sunucusuna (HTTPS portu üzerinden) bağlanarak
    internet kontrolü yapar. Kurumsal ağlarda engellenme riski en düşük yöntemdir.
    """
    try:
        # with bloğu, işlem bitince bağlantıyı güvenle kapatır
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((host, port))
        return True
    except Exception as e:
        # print(f"İnternet kontrol hatası: {e}") # İstersen hatayı görmek için bu satırı açabilirsin
        return False
# Proje dizin yapısına göre config ve utils erişimi
try:
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))
    from config import get_mukellefler_dir
    from utils.session_db import get_last_session
except ImportError:
    pass

# Fatura Görüntüleyici Modülü
try:
    from modules.fatura_yukle.ui_goruntule import FaturaGoruntulePopup
except ImportError:
    FaturaGoruntulePopup = None
try:
    from modules.mali_tablolar.ui import FinancialReportEngine
except ImportError:
    FinancialReportEngine = None



# --- GLOBAL DEĞİŞKENLER ---
CURRENT_USER_TOKEN = None
CURRENT_COMPANY_NAME = ""
CURRENT_USER_CREDITS = 0
CREDIT_LABEL_LIST = []  # Tüm kredi etiketlerini (Main + Denetim) burada tutacağız

def set_user_session(token, company, credits=0, *args):
    """
    Kullanıcı oturum bilgilerini ve kredisini kaydeder.
    """
    global CURRENT_USER_TOKEN, CURRENT_COMPANY_NAME, CURRENT_USER_CREDITS
    CURRENT_USER_TOKEN = token
    CURRENT_COMPANY_NAME = company
    try:
        CURRENT_USER_CREDITS = int(credits)
    except:
        CURRENT_USER_CREDITS = 0

# --- İLERLEME PENCERESİ ---
class ProgressPopup(tk.Toplevel):
    def __init__(self, parent, on_cancel=None):
        super().__init__(parent)
        self.on_cancel = on_cancel
        self.configure(bg="white")
        self.overrideredirect(True) 
        w, h = 500, 200
        ws = self.winfo_screenwidth(); hs = self.winfo_screenheight()
        x = (ws/2) - (w/2); y = (hs/2) - (h/2)
        self.geometry(f'{w}x{h}+{int(x)}+{int(y)}')
        
        main_frame = tk.Frame(self, bg="white", bd=1, relief="solid")
        main_frame.pack(fill="both", expand=True)

        self.lbl_percent = tk.Label(main_frame, text="0%", bg="white", fg="#57606f", font=("Segoe UI Light", 48))
        self.lbl_percent.pack(pady=(20, 5))

        self.style = ttk.Style()
        self.style.theme_use('clam')
        try: self.style.configure("Clean.Horizontal.TProgressbar", troughcolor='white', background='#55efc4', borderwidth=0, thickness=8) 
        except: pass
        
        self.progress = ttk.Progressbar(main_frame, orient="horizontal", length=420, mode="determinate", style="Clean.Horizontal.TProgressbar")
        self.progress.pack(pady=5)

        self.lbl_status = tk.Label(main_frame, text="Yükleniyor...", bg="white", fg="#a4b0be", font=("Segoe UI", 9))
        self.lbl_status.pack(pady=(5, 10))

        self.btn_cancel = tk.Button(main_frame, text="İPTAL", bg="white", fg="#ff6b6b", font=("Segoe UI", 8, "bold"), bd=0, cursor="hand2", command=self.cancel_process)
        self.btn_cancel.place(relx=0.95, rely=0.95, anchor="se")
        self.grab_set()

    def cancel_process(self):
        if self.on_cancel:
            self.lbl_status.config(text="İptal ediliyor...", fg="#ff6b6b")
            self.on_cancel()

    def update_bar(self, current, total, task_name):
        if total == 0: return
        perc = (current / total) * 100
        self.progress['value'] = perc
        self.lbl_percent.config(text=f"{int(perc)}%")
        self.lbl_status.config(text=f"Analiz: {task_name}")
        self.update_idletasks()
    
    def close(self):
        self.grab_release()
        self.destroy()
class GroupSelectionPopup(tk.Toplevel):
    """
    Kullanıcının hangi senaryo gruarını çalıştıracağını seçtiği pencere.
    """
    def __init__(self, parent, available_groups, initial_selection="TÜMÜ"):
        super().__init__(parent)
        self.title("Denetim Kapsamını Seçin")
        self.geometry("450x500")
        self.configure(bg="white")
        self.result = None # Seçilen gruplar buraya dönecek
        
        # Ekran ortalama
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f'+{x}+{y}')
        
        # Başlık
        tk.Label(self, text="Çalıştırılacak Senaryo Gruarını Seçin", bg="white", fg="#2c3e50", 
                 font=("Segoe UI", 12, "bold")).pack(pady=10)
        
        tk.Label(self, text="", bg="#fff3cd", fg="#856404", 
                 font=("Segoe UI", 9), padx=10, pady=5).pack(fill="x", padx=20)

        # Liste Alanı (Scrollable)
        frame_list = tk.Frame(self, bg="white", bd=1, relief="solid")
        frame_list.pack(fill="both", expand=True, padx=20, pady=10)
        
        canvas = tk.Canvas(frame_list, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(frame_list, orient="vertical", command=canvas.yview)
        self.scrollable_frame = tk.Frame(canvas, bg="white")
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Checkboxlar
        self.check_vars = {}
        
        # "TÜMÜ" seçildiyse hepsini işaretle, değilse sadece geleni işaretle
        select_all = (initial_selection == "TÜMÜ")
        
        for grp in available_groups:
            var = tk.BooleanVar(value=select_all or (grp == initial_selection))
            self.check_vars[grp] = var
            cb = tk.Checkbutton(self.scrollable_frame, text=grp, variable=var, bg="white", 
                                font=("Segoe UI", 10), anchor="w")
            cb.pack(fill="x", padx=10, pady=2)

        # Alt Butonlar
        btn_frame = tk.Frame(self, bg="white")
        btn_frame.pack(fill="x", padx=20, pady=10)
        
        tk.Button(btn_frame, text="Tümünü Seç", command=self.select_all, bg="#ecf0f1", bd=0, padx=10).pack(side="left")
        tk.Button(btn_frame, text="Temizle", command=self.deselect_all, bg="#ecf0f1", bd=0, padx=10).pack(side="left", padx=5)
        
        tk.Button(btn_frame, text="DENETİMİ BAŞLAT", command=self.confirm, 
                  bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), bd=0, padx=20, pady=5).pack(side="right")

    def select_all(self):
        for var in self.check_vars.values(): var.set(True)

    def deselect_all(self):
        for var in self.check_vars.values(): var.set(False)
        
    def confirm(self):
        selected = [grp for grp, var in self.check_vars.items() if var.get()]
        if not selected:
            messagebox.showwarning("Uyarı", "Lütfen en az bir grup seçiniz.")
            return
        self.result = selected
        self.destroy()
# =========================================================
# ANA FRAME (DenetimFrame)
# =========================================================

class DenetimFrame(tk.Frame):
    def __init__(self, parent, controller=None):
        super().__init__(parent)
        self.controller = controller
        
        # HATA DÜZELTİLDİ: Fonksiyon artık sınıf içinde tanımlı.
        self.setup_status_bar()

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)

        # 1. RİSK DENETİMİ (Bulut)
        self.audit_tab = AuditPanelTab(self.notebook)
        self.notebook.add(self.audit_tab, text="🔍 RİSK DENETİMİ")

    


    def setup_status_bar(self):
        """
        Üst bilgi barını ve kredi göstergesini oluşturur.
        """
        info_frame = tk.Frame(self, bg="#ecf0f1", height=35)
        info_frame.pack(fill="x", side="top"); info_frame.pack_propagate(False)
        
        tk.Label(info_frame, text="⚡ DENETİM PANELİ", bg="#ecf0f1", fg="#041b33", font=("Segoe UI", 10, "bold")).pack(side="left", padx=10, pady=5)
        
        global CURRENT_USER_TOKEN, CURRENT_USER_CREDITS, CREDIT_LABEL_LIST 
        
        status_text = "🟢 BULUT BAĞLANTISI AKTİF" if CURRENT_USER_TOKEN else "🔴 BAĞLANTI YOK (Offline)"
        status_color = "#27ae60" if CURRENT_USER_TOKEN else "#c0392b"
        tk.Label(info_frame, text=status_text, bg="#ecf0f1", fg=status_color, font=("Segoe UI", 9, "bold")).pack(side="right", padx=10, pady=5)

        #if CURRENT_USER_TOKEN:
        #    lbl = tk.Label(info_frame, text=f"💰 Kredi: {CURRENT_USER_CREDITS}", bg="#ecf0f1", fg="#e67e22", font=("Segoe UI", 9, "bold"))
        #    lbl.pack(side="right", padx=15, pady=5)
        #    
            # Etiketi listeye ekle (Global güncelleme için)
        #    if lbl not in CREDIT_LABEL_LIST:
        #       CREDIT_LABEL_LIST.append(lbl)

# =========================================================
# RİSK DENETİM PANELİ
# =========================================================

class AuditPanelTab(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.engine = AuditEngine()
        self.current_results = []
        self.displayed_df = None
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.colors = {"purple": "#c53e15", "red": "#306109", "blue": "#3742fa", "green": "#2ed573", "bg_gray": "#f1f2f6", "text_dark": "#2f3542", "header_bg": "#dfe4ea", "orange": "#ffa502"}
        self.last_net_check_time = 0  # <--- Bunu __init__ içine ekleyin
        self.abort_reason = None      # <--- İptal sebebini takip etmek için bunu da ekleyin
        self.configure_styles()
        self.setup_ui()
        self.setup_context_menu()
        self.after(1500, self.load_groups_from_cloud)
    
# --- KREDİ LOGLAMA (YENİ EKLENEN METOT) ---
    # --- KREDİ LOGLAMA (DÜZELTİLDİ: Web'den Gelen Tutarı İşler) ---
    def log_credit_usage_to_history(self, group_name, amount):
        """
        Analiz tamamlandığında, hesaplanan gerçek düşüm miktarını kaydeder.
        """
        if ProfilEngine and amount > 0:
            try:
                engine = ProfilEngine()
                # Sunucudan hesaplanan gerçek tutarı ("amount") veritabanına yaz
                engine.kredi_islem_kaydet(f"Denetim: {group_name}", amount)
            except Exception as e:
                print(f"Kredi Log Hatası: {e}")
    # -------------------------------------------------------------
    # -------------------------------------------
# -------------------------------------------------------------------------
    # --- KAPAK SAYFASI İÇİN YARDIMCI FONKSİYONLAR ---
    # -------------------------------------------------------------------------

    def get_analysis_period_info(self):
        """
        Kullanıcının talimatı üzerine:
        1. Aktif VKN ve Yılı session'dan çeker.
        2. Klasör yapısını tarayarak (UNVAN-VKN) hedef klasörü bulur.
        3. {YIL}_FULL.parquet dosyasını okuyup MIN ve MAX tarihleri bulur.
        """
        try:
            # a) Importlar ve Session
            from config import get_mukellefler_dir
            from utils.session_db import get_last_session
            
            session = get_last_session()
            vkn = session.get('vkn')
            yil = session.get('yil')
            
            if not vkn or not yil:
                return f"01/01/{datetime.datetime.now().year} - 31/12/{datetime.datetime.now().year}"

            # b) Fiziksel Klasörü Bulma
            base_dir = get_mukellefler_dir()
            target_folder = None
            
            if os.path.exists(base_dir):
                for f in os.listdir(base_dir):
                    # Klasör adı: "Firma Adi - 1234567890" formatında olabilir
                    # Sonu VKN ile biten klasörü buluyoruz
                    if f.endswith(str(vkn)):
                        target_folder = os.path.join(base_dir, f)
                        break
            
            if not target_folder:
                return f"01/01/{yil} - 31/12/{yil}"

            # c) Dosya Yolu
            parquet_path = os.path.join(target_folder, str(yil), f"{yil}_FULL.parquet")
            
            # d) Tarih Okuma (Pandas ile sadece tarih sütunu)
            if os.path.exists(parquet_path):
                # Sadece 'KayitTarihi' sütununu okuyarak performansı koruyoruz
                try:
                    df_dates = pd.read_parquet(parquet_path, columns=["KayitTarihi"])
                    if not df_dates.empty:
                        min_date = pd.to_datetime(df_dates["KayitTarihi"]).min()
                        max_date = pd.to_datetime(df_dates["KayitTarihi"]).max()
                        return f"{min_date.strftime('%d/%m/%Y')} - {max_date.strftime('%d/%m/%Y')}"
                except:
                    pass # Kolon ismi farklıysa veya dosya bozuksa varsayılana dön
            
            # Dosya yoksa veya okunamadıysa standart yıl aralığı
            return f"01/01/{yil} - 31/12/{yil}"

        except Exception as e:
            print(f"Dönem hesaplama hatası: {e}")
            return f"01/01/{datetime.datetime.now().year} - 31/12/{datetime.datetime.now().year}"

    def get_user_profile_data(self):
        """
        modules/kullanici_profil/profile.db veritabanından 
        Ünvan ve Logo (Base64) bilgisini çeker.
        """
        profile_data = {"unvan": "Mükellef / Firma Ünvanı", "logo_bytes": None}
        
        try:
            # DB Yolu: modules/kullanici_profil/profile.db
            # __file__ -> modules/denetim_analiz/ui.py
            # Hedef -> modules/kullanici_profil/profile.db
            base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(base_path, "kullanici_profil", "profile.db")
            
            if os.path.exists(db_path):
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                # Tablo adı genellikle 'profil' veya 'settings' olur, kullanıcı koduna göre tahmin ediyoruz
                # Kullanıcı kodunda tablo oluşturma yok ama engine.py referansı var.
                # Genelde standart isim 'profiles' veya 'settings'dir. 
                # Hata almamak için try-except içinde basit sorgu deniyoruz.
                try:
                    cursor.execute("SELECT unvan, logo_data FROM profil_settings LIMIT 1") # Tablo adı tahmini
                    row = cursor.fetchone()
                    if row:
                        if row[0]: profile_data["unvan"] = row[0]
                        if row[1]: 
                            # Base64'ten Bytes'a çevir
                            profile_data["logo_bytes"] = base64.b64decode(row[1])
                except:
                    # Alternatif tablo ismi denemesi (Eğer tablo ismi farklıysa burayı güncelleyebiliriz)
                    pass
                conn.close()
                
        except Exception as e:
            print(f"Profil veri hatası: {e}")
            
        return profile_data
    # -------------------------------------------------------------------------
    # --- GÜNCELLENMİŞ YARDIMCI FONKSİYONLAR (LOGO, ÜNVAN, MÜKELLEF) ---
    # -------------------------------------------------------------------------

    # -------------------------------------------------------------------------
    # --- KAPAK VE VERİ ÇEKME MOTORLARI ---
    # -------------------------------------------------------------------------
    
    def get_audit_info(self):
        """
        1. Tarih Aralığı: {YIL}_FULL.parquet dosyasından MIN-MAX tarihleri okur.
        2. Mükellef Ünvanı: Klasör adını tarar (UNVAN-VKN) ve Ünvan kısmını ayıklar.
        """
        info = {
            "period": f"01/01/{datetime.datetime.now().year} - 31/12/{datetime.datetime.now().year}",
            "target_unvan": "Bilinmeyen Mükellef"
        }
        
        try:
            # a) Session'dan VKN ve YIL al
            from config import get_mukellefler_dir
            from utils.session_db import get_last_session
            
            session = get_last_session()
            vkn = session.get('vkn')
            yil = session.get('yil')
            
            if not vkn or not yil: return info

            # b) Fiziksel Klasörü ve Ünvanı Bulma
            base_dir = get_mukellefler_dir()
            target_folder = None
            
            if os.path.exists(base_dir):
                for f in os.listdir(base_dir):
                    # KURAL: Klasör adı VKN ile bitmeli (Örn: "TEKMAN METAL-1234567890")
                    if f.endswith(f"-{vkn}"):
                        target_folder = os.path.join(base_dir, f)
                        
                        # --- KRİTİK: Klasör adından Ünvanı Ayıkla ---
                        # "FIRMA ADI-VKN" formatında sondaki tireden öncesini alıyoruz.
                        if "-" in f:
                            info["target_unvan"] = f.rsplit('-', 1)[0].strip()
                        else:
                            info["target_unvan"] = f # Tire yoksa klasör adını olduğu gibi al
                        break
            
            if not target_folder: return info

            # c) Tarih Aralığı ({YIL}_FULL.parquet)
            parquet_path = os.path.join(target_folder, str(yil), f"{yil}_FULL.parquet")
            
            if os.path.exists(parquet_path):
                try:
                    df_dates = pd.read_parquet(parquet_path, columns=["KayitTarihi"])
                    if not df_dates.empty:
                        min_date = pd.to_datetime(df_dates["KayitTarihi"]).min()
                        max_date = pd.to_datetime(df_dates["KayitTarihi"]).max()
                        info["period"] = f"{min_date.strftime('%d/%m/%Y')} - {max_date.strftime('%d/%m/%Y')}"
                except:
                    pass # Hata olursa varsayılan tarih kalır

        except Exception as e:
            print(f"Denetim bilgisi hatası: {e}")
            
        return info

    # -------------------------------------------------------------------------
    # --- GÜNCELLENMİŞ VERİ MOTORLARI (PROFIL ENGINE ENTEGRASYONU) ---
    # -------------------------------------------------------------------------

    def get_user_profile_data(self):
        """
        Doğrudan ProfilEngine'i kullanarak veriyi çeker.
        Böylece Profil ekranında kaydettiğin verinin aynısı gelir (Postgres + Local DB).
        """
        profile_data = {"auditor_unvan": "DENETİM / YMM OFİSİ", "logo_bytes": None}
        
        if ProfilEngine:
            try:
                # Profil motorunu başlat ve veriyi iste
                engine = ProfilEngine()
                data = engine.bilgileri_getir()
                
                if data:
                    # 1. Ünvanı Al (Postgres'ten geliyor)
                    if data.get("unvan"):
                        profile_data["auditor_unvan"] = str(data["unvan"]).upper()
                    
                    # 2. Logoyu Al (Local SQLite'tan geliyor - Base64)
                    if data.get("logo_data"):
                        try:
                            profile_data["logo_bytes"] = base64.b64decode(data["logo_data"])
                        except:
                            pass
            except Exception as e:
                print(f"ProfilEngine Hatası: {e}")
        
        return profile_data

    def get_audit_info(self):
        """
        1. Mükellef Adı: Klasör isminden (UNVAN-VKN) otomatik ayrıştırılır.
        2. Tarih Aralığı: Parquet dosyasından okunur.
        """
        info = {
            "period": f"01/01/{datetime.datetime.now().year} - 31/12/{datetime.datetime.now().year}",
            "target_unvan": "Bilinmeyen Mükellef"
        }
        
        try:
            # a) Session'dan VKN ve YIL al
            from config import get_mukellefler_dir
            from utils.session_db import get_last_session
            
            session = get_last_session()
            vkn = session.get('vkn')
            yil = session.get('yil')
            
            if not vkn: return info

            # b) Fiziksel Klasörü Bul (Senin verdiğin kurala göre)
            base_dir = get_mukellefler_dir()
            target_folder = None
            found_folder_name = ""
            
            if os.path.exists(base_dir):
                for f in os.listdir(base_dir):
                    # KURAL: Klasör adı VKN ile bitmeli
                    if f.endswith(f"-{vkn}"):
                        target_folder = os.path.join(base_dir, f)
                        found_folder_name = f
                        break
            
            # c) Mükellef Ünvanını Klasör Adından Çek
            if found_folder_name:
                # "FIRMA ADI-VKN" -> Sondaki tireden öncesini al
                if "-" in found_folder_name:
                    info["target_unvan"] = found_folder_name.rsplit('-', 1)[0].strip()
                else:
                    info["target_unvan"] = found_folder_name
            
            if not target_folder: return info

            # d) Tarih Aralığı ({YIL}_FULL.parquet)
            parquet_path = os.path.join(target_folder, str(yil), f"{yil}_FULL.parquet")
            
            if os.path.exists(parquet_path):
                try:
                    df_dates = pd.read_parquet(parquet_path, columns=["KayitTarihi"])
                    if not df_dates.empty:
                        min_date = pd.to_datetime(df_dates["KayitTarihi"]).min()
                        max_date = pd.to_datetime(df_dates["KayitTarihi"]).max()
                        info["period"] = f"{min_date.strftime('%d/%m/%Y')} - {max_date.strftime('%d/%m/%Y')}"
                except:
                    pass

        except Exception as e:
            print(f"Denetim bilgisi hatası: {e}")
            
        return info
    
    def _get_treeview_column_config(self):
        """
        Treeview'da o an tanımlı olan dinamik sütun yapısını ve başlıkları getirir.
        Dönüş: (col_keys, col_headers)
        """
        # Treeview'da tanımlı sütun ID'leri (Örn: 'FATURA_NO', 'TARIH')
        # 'No' sütunu UI indeksidir, veride olmadığı için hariç tutuyoruz.
        tree_cols = list(self.data_tree["columns"])
        
        valid_keys = []
        headers = []
        
        for col_id in tree_cols:
            if col_id == "No": continue # Sıra numarası sütununu atla
            
            # Sütun başlığını (Örn: "Fatura No") al
            heading = self.data_tree.heading(col_id, "text")
            
            valid_keys.append(col_id)
            headers.append(heading)
            
        return valid_keys, headers
    def configure_styles(self):
        # Satır yüksekliğini artırıyoruz (Resimdeki ferahlık için)
        self.style.configure("Treeview", 
                             rowheight=40, 
                             font=('Segoe UI', 10), 
                             background="white", 
                             fieldbackground="white", 
                             borderwidth=0)
        
        # Başlıkları daha belirgin ve koyu yapıyoruz
        self.style.configure("Treeview.Heading", 
                             font=('Segoe UI', 10, 'bold'), 
                             background="#f8f9fa", 
                             foreground="#2f3542", 
                             relief="flat")
        
        # Seçili satır rengini daha yumuşak bir mavi yapıyoruz
        self.style.map("Treeview", 
                       background=[('selected', '#e1f5fe')], 
                       foreground=[('selected', '#0288d1')])
        
    def show_invoice_document(self):
        """
        Seçili satırdaki Fatura No'yu alır, veritabanından bulur ve E-Fatura Görüntüleyiciyi açar.
        """
        # Modül yüklü mü kontrol et
        if FaturaGoruntulePopup is None:
            messagebox.showerror("Hata", "Fatura görüntüleme modülü (ui_goruntule) bulunamadı.")
            return

        sel = self.data_tree.selection()
        if not sel: return
        
        # Seçili satırın değerlerini al
        vals = self.data_tree.item(sel[0])['values']
        
        # Tablodaki sütun başlıklarını al ('No', 'FATURA_NO', 'TARIH'...)
        # Treeview'da sütun sırası değişebileceği için indeksi dinamik buluyoruz.
        col_ids = self.data_tree["columns"]
        
        try:
            # Hem 'FATURA_NO' hem de 'Fatura Numarası' isimlerini kontrol et
            if "Fatura Numarası" in col_ids:
                fatura_idx = col_ids.index("Fatura Numarası")
            elif "FATURA_NO" in col_ids:
                fatura_idx = col_ids.index("FATURA_NO")
            else:
                # İkisi de yoksa hata fırlat
                raise ValueError("Sütun bulunamadı")
            
            fatura_no = str(vals[fatura_idx]).strip()
            
        except ValueError:
            messagebox.showerror("Hata", "Bu tabloda fatura numarası sütunu bulunamadı.")
            return

        # Fatura No geçerli mi?
        if not fatura_no or fatura_no in ["-", "", "None", "nan", "."]:
            messagebox.showwarning("Uyarı", "Geçerli bir Fatura Numarası seçilemedi.")
            return

        # --- VERİTABANINDAN ÇEK ---
        df_invoice = self.fetch_invoice_from_db(fatura_no)

        if df_invoice is not None and not df_invoice.empty:
            try:
                # Görüntüleyiciyi Popup Olarak Aç
                target_master = self.winfo_toplevel() # Ana pencereyi bul
                FaturaGoruntulePopup(target_master, df_invoice)
            except Exception as e:
                messagebox.showerror("Hata", f"Görüntüleyici açılırken hata oluştu:\n{e}")
        else:
            messagebox.showinfo("Bilgi", f"'{fatura_no}' numaralı fatura arşivde/veritabanında bulunamadı.")
# --- YENİ EKLENEN DOSYA/BELGE FONKSİYONLARI ---

    def find_and_extract_xml(self, zip_path, target_filename, dest_dir):
        """ZIP içinden (recursive) XML dosyasını bulup çıkarır."""
        def search_in_zip(current_zip, target_name):
            # 1. Mevcut ZIP içinde ara
            for name in current_zip.namelist():
                # Türkçe karakter sorununa karşı basit bir encoding kontrolü veya direkt isim eşleşmesi
                if os.path.basename(name) == target_name:
                    return current_zip.read(name)
            
            # 2. İç içe ZIP'lere bak
            for name in current_zip.namelist():
                if name.lower().endswith('.zip'):
                    try:
                        nested_data = io.BytesIO(current_zip.read(name))
                        with zipfile.ZipFile(nested_data) as nested_z:
                            result = search_in_zip(nested_z, target_name)
                            if result: return result
                    except: continue
            return None

        try:
            with zipfile.ZipFile(zip_path, 'r') as z:
                content = search_in_zip(z, target_filename)
                if content:
                    target_path = os.path.join(dest_dir, target_filename)
                    with open(target_path, 'wb') as f:
                        f.write(content)
                    return target_path
        except Exception as e:
            print(f"ZIP Hatası: {e}")
        return None

    def get_invoice_file_info(self, fatura_no):
        """Veritabanından sadece dosya yolu ve adını çeker."""
        try:
            session = get_last_session()
            if not session or not session.get('vkn'): return None
            
            vkn = session.get('vkn')
            yil = session.get('yil')
            # Unvan session'da yoksa bile klasör araması yapacağız
            
            base_dir = get_mukellefler_dir()
            target_folder = None
            
            # Klasör bulma
            if os.path.exists(base_dir):
                for f in os.listdir(base_dir):
                    if f.endswith(f"-{vkn}") and os.path.isdir(os.path.join(base_dir, f)):
                        target_folder = os.path.join(base_dir, f)
                        break
            
            if not target_folder: return None

            db_path = os.path.join(target_folder, str(yil), f"fatura_data_{yil}.db")
            if not os.path.exists(db_path): return None

            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row 
            cursor = conn.cursor()
            
            # Gerekli dosya bilgilerini çek
            cursor.execute("SELECT DOSYA_YOLU, DOSYA, ZIP_ICI_AD FROM FATURALAR WHERE FATURA_NO = ?", (fatura_no,))
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return dict(row)
            return None

        except Exception as e:
            print(f"DB Hatası (Dosya Bilgisi): {e}")
            return None

    def show_invoice_document_file(self):
        """
        Sağ Tık Menüsü İçin:
        Seçili satırdaki Belge/Fatura No ile fiziksel dosyayı (XML/PDF) bulur ve görüntüler.
        """
        if FaturaGoruntulePopup is None:
            messagebox.showerror("Hata", "Fatura görüntüleme modülü (ui_goruntule) yüklenemedi.")
            return

        sel = self.data_tree.selection()
        if not sel: return
        
        vals = self.data_tree.item(sel[0])['values']
        
        # Sütunlarda 'FATURA_NO' veya 'BelgeNo'yu dinamik bulalım
        col_ids = self.data_tree["columns"]
        target_col = None
        
        if "FATURA_NO" in col_ids: target_col = "FATURA_NO"
        elif "BelgeNo" in col_ids: target_col = "BelgeNo"
        elif "Belge No" in col_ids: target_col = "Belge No"
        
        if not target_col:
            messagebox.showerror("Hata", "Bu tabloda Fatura No veya Belge No sütunu bulunamadı.")
            return
            
        try:
            fatura_idx = col_ids.index(target_col)
            belge_no = str(vals[fatura_idx]).strip()
        except ValueError:
            return

        if not belge_no or belge_no in ["-", "", "None", "0", "nan"]:
            messagebox.showwarning("Uyarı", "Geçerli bir Belge Numarası yok.")
            return

        # 1. Dosya Bilgilerini Çek
        file_info = self.get_invoice_file_info(belge_no)

        if not file_info:
            # Dosya bulunamazsa eski yöntemi (DB'den DataFrame gösterme) dene
            self.show_invoice_document() 
            return

        source_path = file_info.get('DOSYA_YOLU')
        dosya_adi = file_info.get('ZIP_ICI_AD') 
        if not dosya_adi: dosya_adi = file_info.get('DOSYA')

        if not source_path or not os.path.exists(source_path):
            messagebox.showwarning("Hata", f"Dosya diskte bulunamadı:\n{source_path}")
            return

        final_path = source_path
        
        # 2. ZIP İşlemleri
        if source_path.lower().endswith('.zip'):
            if not dosya_adi:
                messagebox.showerror("Hata", "Dosya ZIP formatında ama içindeki XML adı veritabanında yok.")
                return
                
            temp_dir = tempfile.gettempdir()
            extracted_path = self.find_and_extract_xml(source_path, dosya_adi, temp_dir)
            
            if extracted_path:
                final_path = extracted_path
            else:
                messagebox.showerror("Hata", f"ZIP içinde dosya bulunamadı:\n{dosya_adi}")
                return

        # 3. Görüntüleyiciyi Aç
        try:
            target_master = self.winfo_toplevel()
            FaturaGoruntulePopup(target_master, final_path)
        except Exception as e:
            messagebox.showerror("Hata", f"Görüntüleyici açılırken hata: {e}")




    def fetch_invoice_from_db(self, fatura_no):
        """
        Aktif mükellefin veritabanına bağlanır ve fatura detaylarını çeker.
        """
        try:
            # 1. Oturum Bilgilerini Al (Hangi mükellef, Hangi yıl?)
            session = get_last_session()
            if not session or not session.get('vkn'): 
                return None
            
            vkn = session.get('vkn')
            yil = session.get('yil')
            
            # 2. Veritabanı Yolunu Bul
            base_dir = get_mukellefler_dir() # config.py'den gelir
            target_folder = None
            
            # VKN ile klasör eşleştirme
            if os.path.exists(base_dir):
                for f in os.listdir(base_dir):
                    # Klasör adı genelde "UNVAN-VKN" formatındadır, sonu VKN ile biteni bul
                    if f.endswith(f"-{vkn}") and os.path.isdir(os.path.join(base_dir, f)):
                        target_folder = os.path.join(base_dir, f)
                        break
            
            if not target_folder: return None

            # DB Dosyası: .../MUKELLEF/2023/fatura_data_2023.db
            db_path = os.path.join(target_folder, str(yil), f"fatura_data_{yil}.db")
            
            if not os.path.exists(db_path): return None

            # 3. Bağlan ve Sorgula
            conn = sqlite3.connect(db_path)
            # Fatura Numarasına göre tüm satırları (kalemleri) çek
            query = "SELECT * FROM FATURALAR WHERE FATURA_NO = ?"
            df = pd.read_sql(query, conn, params=(fatura_no,))
            conn.close()
            
            return df

        except Exception as e:
            print(f"DB Hatası (fetch_invoice): {e}")
            return None
        
    def setup_ui(self):
        self.paned = tk.PanedWindow(self, orient=tk.HORIZONTAL, sashwidth=4, bg=self.colors['header_bg'])
        self.paned.pack(fill="both", expand=True)
        
        # --- SOL PANEL ---
        left_frame = tk.Frame(self.paned, width=320, bg="white")
        self.paned.add(left_frame)
        self.header_label = tk.Label(left_frame, text="  DENETİM LİSTESİ", bg="#800020", fg="white", height=2, font=("Segoe UI", 11, "bold"), anchor="w")
        self.header_label.pack(fill="x")
        
        tree_container_left = tk.Frame(left_frame, bg="white")
        tree_container_left.pack(fill="both", expand=True)
        self.result_tree = ttk.Treeview(tree_container_left, columns=("id"), show="tree", displaycolumns=(), selectmode="browse")
        
        vsb_left = ttk.Scrollbar(tree_container_left, orient="vertical", command=self.result_tree.yview)
        hsb_left = ttk.Scrollbar(tree_container_left, orient="horizontal", command=self.result_tree.xview)
        self.result_tree.configure(yscrollcommand=vsb_left.set, xscrollcommand=hsb_left.set)
        self.result_tree.grid(row=0, column=0, sticky="nsew")
        vsb_left.grid(row=0, column=1, sticky="ns")
        hsb_left.grid(row=1, column=0, sticky="ew")
        tree_container_left.grid_rowconfigure(0, weight=1); tree_container_left.grid_columnconfigure(0, weight=1)
        self.result_tree.bind("<<TreeviewSelect>>", self.on_result_select)
        
        tk.Label(left_frame, text="  GEÇMİŞ RAPORLAR", bg=self.colors['header_bg'], fg=self.colors['text_dark'], font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x")
        self.history_list = tk.Listbox(left_frame, height=6, bd=0, bg="#f8f9fa", font=("Segoe UI", 9))
        self.history_list.pack(fill="x", padx=2, pady=2)
        self.history_list.bind("<Double-1>", self.load_historical_report)

        # --- SAĞ PANEL ---
        self.right_frame = tk.Frame(self.paned, bg="white")
        self.paned.add(self.right_frame)
        
        stats_frame = tk.Frame(self.right_frame, bg="white")
        stats_frame.pack(fill="x", padx=15, pady=15)
        
        self.var_total = tk.StringVar(value="0")
        self.var_risk_count = tk.StringVar(value="0")
        self.var_risk_title = tk.StringVar(value="Risk Seçilmedi")

        self.create_card(stats_frame, self.colors['purple'], "Toplam Risk", self.var_total, "🛡️", 0)
        p_card = tk.Frame(stats_frame, bg=self.colors['red'], height=90)
        p_card.pack_propagate(False); p_card.grid(row=0, column=1, sticky="ew", padx=5)
        tk.Label(p_card, text="📄", bg=self.colors['red'], fg="white", font=("Segoe UI", 28)).pack(side="left", padx=10)
        p_txt = tk.Frame(p_card, bg=self.colors['red']); p_txt.pack(side="right", padx=10, fill="y", expand=True)
        tk.Label(p_txt, textvariable=self.var_risk_count, bg=self.colors['red'], fg="white", font=("Segoe UI", 22, "bold")).pack(anchor="e", pady=(5,0))
        tk.Label(p_txt, textvariable=self.var_risk_title, bg=self.colors['red'], fg="white", font=("Segoe UI", 8), wraplength=150, justify="right").pack(anchor="e")
        stats_frame.columnconfigure(0, weight=1); stats_frame.columnconfigure(1, weight=2)

        # --- TOOLBAR (AÇILIR MENÜLÜ YAPI) ---
        toolbar = tk.Frame(self.right_frame, bg="white")
        toolbar.pack(fill="x", padx=20, pady=(5, 10))
        
        # Sol Başlık
        tk.Label(toolbar, text="Risk Detay Tablosu", font=("Segoe UI", 12, "bold"), bg="white", fg=self.colors['text_dark']).pack(side="left")
        
        # --- AÇILIR MENÜ BUTONU (DROPDOWN) ---
        mb_actions = tk.Menubutton(toolbar, text="⬇ Dışa Aktar / İşlemler  ▼", bg="#34495e", fg="white", 
                                   font=("Segoe UI", 9, "bold"), relief="flat", padx=15, pady=5, cursor="hand2")
        mb_actions.pack(side="right", padx=5)
        
        action_menu = tk.Menu(mb_actions, tearoff=0, bg="white", fg="#2c3e50", font=("Segoe UI", 10))
        mb_actions.config(menu=action_menu)
        
        # --- SEÇENEKLER ---
        
        # Excel
        action_menu.add_command(label="📥  Kayıtları Excel'e Aktar", command=self.export_to_excel)
        action_menu.add_separator() 
        
        # PDF Seçenekleri
        action_menu.add_command(label="📄  PDF İndir (Seçili Risk)", command=self.export_to_pdf)
        action_menu.add_command(label="📑  PDF İndir (Tüm Grup)", command=self.export_group_to_pdf)
        
        action_menu.add_separator()
        
        # WORD Seçenekleri (YENİ)
        action_menu.add_command(label="📝  Word İndir (Seçili Risk)", command=self.export_to_word)
        action_menu.add_command(label="📚  Word İndir (Tüm Grup)", command=self.export_group_to_word)

        self.right_split = tk.PanedWindow(self.right_frame, orient=tk.VERTICAL, sashwidth=4, bg=self.colors['header_bg'])
        self.right_split.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        
        table_container_right = tk.Frame(self.right_split, bg="white")
        self.right_split.add(table_container_right, height=350)
        self.data_tree = ttk.Treeview(table_container_right, style="Treeview", selectmode="extended")
        ysb_right = ttk.Scrollbar(table_container_right, orient="vertical", command=self.data_tree.yview)
        xsb_right = ttk.Scrollbar(table_container_right, orient="horizontal", command=self.data_tree.xview)
        self.data_tree.configure(yscrollcommand=ysb_right.set, xscrollcommand=xsb_right.set)
        self.data_tree.grid(row=0, column=0, sticky="nsew")
        ysb_right.grid(row=0, column=1, sticky="ns")
        xsb_right.grid(row=1, column=0, sticky="ew")
        table_container_right.grid_rowconfigure(0, weight=1); table_container_right.grid_columnconfigure(0, weight=1)

        # ... (setup_ui fonksiyonunun üst kısımları aynı kalacak) ...
        
        # --- DETAY ALANI (PROFESYONEL RAPOR GÖRÜNÜMÜ) ---
        detail_frame = tk.Frame(self.right_split, bg="white")
        self.right_split.add(detail_frame)
        
        # Header
        header_det = tk.Frame(detail_frame, bg="#9c88ff", height=25)
        header_det.pack(fill="x")
        tk.Label(header_det, text="🔍 Otomatik Sonuç ve Çözüm Önerisi", bg="#9c88ff", fg="white", font=("Segoe UI", 9, "bold"), padx=10).pack(side="left")

        # Text Container
        txt_container = tk.Frame(detail_frame, bg="white")
        txt_container.pack(fill="both", expand=True)
        
        # Scrollbars
        v_scroll = ttk.Scrollbar(txt_container, orient="vertical")
        h_scroll = ttk.Scrollbar(txt_container, orient="horizontal")
        
        # TEXT WIDGET (Önemli: Font burada tanımlanmalı)
        self.detail_text = tk.Text(txt_container, bg="white", font=("Segoe UI", 10), bd=0, padx=20, pady=20, wrap="none")
        
        # Scrollbar Bağlantıları
        self.detail_text.config(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)
        v_scroll.config(command=self.detail_text.yview)
        h_scroll.config(command=self.detail_text.xview)
        
        self.detail_text.grid(row=0, column=0, sticky="nsew")
        v_scroll.grid(row=0, column=1, sticky="ns")
        h_scroll.grid(row=1, column=0, sticky="ew")
        
        txt_container.grid_rowconfigure(0, weight=1)
        txt_container.grid_columnconfigure(0, weight=1)

        # --- STİL TANIMLAMALARI (TAGS) ---
        
        # 1. Ana Rapor Başlığı (Ortalı, Büyük)
        self.detail_text.tag_configure("main_header", font=("Segoe UI", 16, "bold"), foreground="#2c3e50", justify="center", spacing3=20)
        
        # 2. Bölüm Başlıkları (Mavi, Kalın - Örn: "1. Tespit İsmi")
        self.detail_text.tag_configure("section_header", font=("Segoe UI", 11, "bold"), foreground="#2980b9", spacing1=15, spacing3=5)
        
        # 3. İçerik Kutusu (Hafif girintili, Siyah yazı)
        self.detail_text.tag_configure("content", font=("Segoe UI", 10), foreground="#34495e", lmargin1=10, lmargin2=10, spacing1=2)
        
        # 4. TABLO BAŞLIĞI (Kırmızı Arka Plan, Beyaz Yazı) -> Resimdeki gibi
        self.detail_text.tag_configure("table_header_row", font=("Segoe UI", 10, "bold"), background="#c0392b", foreground="white", lmargin1=10, lmargin2=10, spacing1=5, spacing3=5)
        
        # 5. TABLO SATIRLARI (Gri ve Beyaz Arka Plan)
        self.detail_text.tag_configure("table_row_odd", font=("Segoe UI", 10), background="#ecf0f1", foreground="black", lmargin1=10, lmargin2=10, spacing1=3, spacing3=3)
        self.detail_text.tag_configure("table_row_even", font=("Segoe UI", 10), background="white", foreground="black", lmargin1=10, lmargin2=10, spacing1=3, spacing3=3)
        
        # 6. Mavi Kutu (Tespit İsmi vb. için vurgu)
        self.detail_text.tag_configure("blue_box", background="#eaf2f8", foreground="#2c3e50", font=("Segoe UI", 10, "bold"), lmargin1=10, lmargin2=10, rmargin=10, spacing1=5, spacing3=5, relief="solid", borderwidth=1)

        # Footer (Aynen korundu)
        footer = tk.Frame(self.right_frame, bg="white")
        footer.pack(fill="x", padx=20, pady=5)
        tk.Button(footer, text="RAPORU SİL", bg="white", fg=self.colors['red'], bd=1, relief="solid", font=("Segoe UI", 9, "bold"), padx=15, pady=5, command=self.delete_selected_report).pack(side="left", padx=5)
        tk.Label(footer, text="Senaryo Grubu:", bg="white", font=("Segoe UI", 9, "bold")).pack(side="left", padx=(20, 5))
        self.cb_group_run = ttk.Combobox(footer, state="readonly", font=("Segoe UI", 9), width=25)
        self.cb_group_run.pack(side="left", padx=5)
        self.cb_group_run['values'] = [] 
        tk.Button(footer, text="🔄", command=self.load_groups_from_cloud, width=3).pack(side="left", padx=2)
        tk.Button(footer, text="🚀 BULUT DENETİMİ BAŞLAT", bg="#2980b9", fg="white", relief="flat", font=("Segoe UI", 9, "bold"), padx=15, pady=6, command=self.run_audit).pack(side="left", padx=5)
        # ... (setup_ui içindeki mevcut kodların devamı)

        # --- EXCEL TARZI KOPYALAMA İÇİN KLAVYE KISAYOLU ---
        self.data_tree.bind("<Control-c>", lambda e: self.copy_multiline_selection())
        self.data_tree.bind("<Control-c>", lambda e: self.copy_multiline_selection())
                
        self.refresh_history()

    def create_card(self, parent, bg, title, count_var, icon, col):
        # --- GÜNCELLEME: Yükseklik 40px (Minimal) ---
        card = tk.Frame(parent, bg=bg, height=40)
        card.pack_propagate(False)
        card.grid(row=0, column=col, sticky="ew", padx=2)
        
        # İçerik Yan Yana (Side=Left)
        # 1. Simge
        tk.Label(card, text=icon, bg=bg, fg="white", font=("Segoe UI", 12)).pack(side="left", padx=(10, 5))
        # 2. Sayı (Kalın)
        tk.Label(card, textvariable=count_var, bg=bg, fg="white", font=("Segoe UI", 14, "bold")).pack(side="left")
        # 3. Başlık (Normal)
        tk.Label(card, text=f" {title}", bg=bg, fg="white", font=("Segoe UI", 10)).pack(side="left", padx=5)
        
        return card

    # ui.py dosyası içindeki `load_groups_from_cloud` fonksiyonunu bulup BÖYLE DEĞİŞTİRİN:

    def load_groups_from_cloud(self):
        if not CURRENT_USER_TOKEN: return
        def _fetch():
            try:
                response = CloudLicenseManager.get_menu(CURRENT_USER_TOKEN)
                if not response: return
                
                # --- HATA DÜZELTMESİ: Dict / List Güvenliği ---
                scenarios = response.get("scenarios", []) if isinstance(response, dict) else response
                
                groups = set()
                for s in scenarios:
                    if isinstance(s, dict): # Ekstra tip güvenliği
                        grp = s.get('group_name')
                        if grp: groups.add(grp)
                
                sorted_groups = sorted(list(groups))
                
                final_list = ["TÜMÜ"] + sorted_groups
                self.available_groups_cache = sorted_groups 
                
                self.after(0, lambda: self.cb_group_run.config(values=final_list))
                if final_list:
                    self.after(0, lambda: self.cb_group_run.current(0))
            except Exception as e:
                print(f"Grup yükleme hatası: {e}")
        threading.Thread(target=_fetch, daemon=True).start()

    def setup_context_menu(self):
        """
        Sağ paneldeki tablo için sağ tık menüsünü ve 
        yönlendirme fonksiyonlarını tanımlar.
        """
        # --- SOL PANEL MENÜSÜ ---
        self.tree_menu = tk.Menu(self, tearoff=0)
        self.tree_menu.add_command(label="📂 Hepsini Aç", command=self.expand_all_groups)
        self.tree_menu.add_command(label="📁 Hepsini Kapat", command=self.collapse_all_groups)
        
        self.result_tree.bind("<Button-3>", self.on_tree_right_click)

        # --- SAĞ PANEL (RİSK DETAY) MENÜSÜ ---
        self.data_tree_menu = tk.Menu(self, tearoff=0, font=("Segoe UI", 10))
        
        # --- YENİ EKLENEN KISIM: HÜCRE KOPYALAMA ---
        self.data_tree_menu.add_command(label="📋 Hücreyi Kopyala", 
                                        command=self.copy_cell_content)
        self.data_tree_menu.add_separator()
        # -------------------------------------------

        self.data_tree_menu.add_command(label="📄 Yevmiye Fiş Detayını Göster", 
                                        command=self.show_fis_detail_context)
        self.data_tree_menu.add_command(label="👁️ Faturayı/Belgeyi Görüntüle", 
                                        command=self.show_invoice_document_context)
        
        # Sağ tık bağlaması (Windows/Linux için Button-3, Mac için Button-2)
        self.data_tree.bind("<Button-3>", self.on_data_right_click)
        if self.tk.call('tk', 'windowingsystem') == 'aqua': 
            self.data_tree.bind("<Button-2>", self.on_data_right_click)

    # =========================================================
    # --- EXCEL TARZI AKILLI KOPYALAMA SİSTEMİ ---
    # =========================================================

    def on_data_right_click(self, event):
        """
        Sağ tıklandığında:
        1. Tıklanan HÜCREYİ (Satır + Sütun) algılar.
        2. Menüyü o anki hücre değerine göre günceller.
        3. Çoklu seçim varsa korur.
        """
        # 1. Tıklanan Satırı Bul
        row_id = self.data_tree.identify_row(event.y)
        if not row_id: return 

        # 2. Seçim Mantığı (Mevcut seçimi bozma, yeni satırsa ekle)
        current_selection = self.data_tree.selection()
        if row_id not in current_selection:
            self.data_tree.selection_set(row_id)

        # 3. Tıklanan Sütunu ve Hücre Değerini Bul
        col_id = self.data_tree.identify_column(event.x) # Örn: '#2'
        self.clicked_cell_value = ""
        
        try:
            # Sütun ID'sini index'e çevir (#1 -> 0, #2 -> 1...)
            # Not: 'displaycolumns' kullanılmadığı varsayılarak values sırası baz alınır.
            col_index = int(col_id.replace('#', '')) - 1
            
            vals = self.data_tree.item(row_id)['values']
            if 0 <= col_index < len(vals):
                self.clicked_cell_value = str(vals[col_index])
        except Exception as e:
            print(f"Hücre verisi alma hatası: {e}")

        # --- MENÜYÜ DİNAMİK OLARAK YENİLE ---
        self.data_tree_menu.delete(0, tk.END) # Eski menüyü temizle

        # A. HÜCRE KOPYALAMA SEÇENEĞİ
        # Değer çok uzunsa kısaltarak göster (Örn: "Kopyala: 'Fatura No...'")
        display_val = self.clicked_cell_value
        if len(display_val) > 20: display_val = display_val[:17] + "..."
        
        self.data_tree_menu.add_command(
            label=f"📋 Hücreyi Kopyala: '{display_val}'", 
            command=self.copy_single_cell
        )

        # B. ÇOKLU SEÇİM KOPYALAMA SEÇENEĞİ
        sel_count = len(self.data_tree.selection())
        if sel_count > 1:
            self.data_tree_menu.add_command(
                label=f"📑 Seçili Satırları Kopyala ({sel_count} Kayıt)", 
                command=self.copy_multiline_selection
            )

        self.data_tree_menu.add_separator()
        
        # C. STANDART İŞLEMLER
        self.data_tree_menu.add_command(label="📄 Yevmiye Fiş Detayını Göster", command=self.show_fis_detail_context)
        self.data_tree_menu.add_command(label="👁️ Faturayı/Belgeyi Görüntüle", command=self.show_invoice_document_context)

        # Menüyü Aç
        try:
            self.data_tree_menu.post(event.x_root, event.y_root)
        finally:
            self.data_tree_menu.grab_release()

    def copy_single_cell(self):
        """Sadece sağ tıklanan hücrenin içeriğini panoya kopyalar."""
        if hasattr(self, 'clicked_cell_value') and self.clicked_cell_value:
            self.clipboard_clear()
            self.clipboard_append(self.clicked_cell_value)
            self.update() # Panoda kalıcı olması için update şart

    def copy_multiline_selection(self):
        """
        Seçili satırların tamamını EXCEL FORMATINDA (Tab-delimited) kopyalar.
        Böylece Excel'e yapıştırınca sütunlar otomatik ayrışır.
        """
        selection = self.data_tree.selection()
        if not selection: return

        result_text = ""
        # İsteğe bağlı: Başlıkları da eklemek istersen şu satırı açabilirsin:
        # headers = [self.data_tree.heading(c)['text'] for c in self.data_tree['columns']]
        # result_text += "\t".join(headers) + "\n"

        for item in selection:
            vals = self.data_tree.item(item)['values']
            # Değerleri stringe çevir ve aralarına TAB (\t) koy
            # Excel TAB karakterini sütun ayracı olarak görür.
            row_str = "\t".join([str(v) for v in vals])
            result_text += row_str + "\n"

        self.clipboard_clear()
        self.clipboard_append(result_text)
        self.update()

    def copy_cell_content(self):
        """Sağ tıklanan hücrenin içeriğini panoya kopyalar."""
        if hasattr(self, 'clicked_cell_value') and self.clicked_cell_value:
            self.clipboard_clear()
            self.clipboard_append(self.clicked_cell_value)
            self.update() # Panoda kalıcı olması için update şart
            
            # İsteğe bağlı: Kullanıcıya küçük bir bildirim (Status bar varsa oraya da yazılabilir)
            # messagebox.showinfo("Bilgi", "Kopyalandı") -> Bu çok rahatsız edici olur, kullanma.
        else:
            messagebox.showwarning("Uyarı", "Kopyalanacak veri seçilemedi.")


    def on_tree_right_click(self, event):
        try: self.tree_menu.post(event.x_root, event.y_root)
        except: pass
    def expand_all_groups(self):
        def open_recursive(item):
            self.result_tree.item(item, open=True)
            for child in self.result_tree.get_children(item): open_recursive(child)
        for child in self.result_tree.get_children(""): open_recursive(child)
    def collapse_all_groups(self):
        def close_recursive(item):
            self.result_tree.item(item, open=False)
            for child in self.result_tree.get_children(item): close_recursive(child)
        for child in self.result_tree.get_children(""): close_recursive(child)
    def on_right_click(self, event):
        item = self.data_tree.identify_row(event.y)
        if item:
            if item not in self.data_tree.selection(): self.data_tree.selection_set(item)
            try: self.context_menu.post(event.x_root, event.y_root)
            except: pass
    def on_double_click_row(self, event):
        """
        AKILLI ÇİFT TIKLAMA MANTIĞI:
        1. Öncelik: YevmiyeNo varsa -> Muhasebe Fiş Detayını açar.
        2. İkinci Öncelik: BelgeNo varsa -> Fatura Görüntüleyiciyi açar.
        """
        sel = self.data_tree.selection()
        if not sel: return
        
        # Seçili satırdaki verileri ve sütun başlıklarını al
        vals = self.data_tree.item(sel[0])['values']
        if not vals: return
        col_ids = list(self.data_tree["columns"])
        
        # Verileri sütun isimleriyle eşleştir (Dictionary yapısı)
        row_data = dict(zip(col_ids, vals))
        
        # --- 1. YEVMİYE NO KONTROLÜ (ÖNCELİKLİ) ---
        yev_no = row_data.get("YevmiyeNo") or row_data.get("Yevmiye No")
        
        if yev_no and str(yev_no).strip() not in ["-", "", "0", "None", "nan"]:
            # Temizlik: Virgülleri kaldır (binlik ayracı gelmiş olabilir)
            yev_no_clean = str(yev_no).strip().replace(',', '')
            self.open_fis_detail_popup(yev_no_clean)
            return

        # --- 2. BELGE / FATURA NO KONTROLÜ ---
        belge_no = (row_data.get("FATURA_NO") or 
                    row_data.get("BelgeNo") or 
                    row_data.get("Belge No") or 
                    row_data.get("Fatura Numarası"))

        if belge_no and str(belge_no).strip() not in ["-", "", "None", "nan", "."]:
            if FaturaGoruntulePopup:
                self.show_invoice_document_file()
            else:
                messagebox.showerror("Hata", "Fatura görüntüleme modülü yüklenemedi.")
        else:
            messagebox.showinfo("Bilgi", "Seçili satırda geçerli bir Yevmiye Fişi veya Fatura numarası bulunamadı.")



    def get_selected_yevmiye_no(self):
        sel = self.data_tree.selection()
        if not sel: return None
        vals = self.data_tree.item(sel[0])['values']
        try: return str(vals[1]).replace(',', '') 
        except: return None
    def show_fis_detail_context(self):
        """Seçili satırdaki Yevmiye No üzerinden fiş detayını açar."""
        sel = self.data_tree.selection()
        if not sel: return
        
        vals = self.data_tree.item(sel[0])['values']
        col_ids = self.data_tree["columns"]
        
        try:
            # Sütun ismini dinamik bul (YevmiyeNo veya Yevmiye No)
            idx = col_ids.index("YevmiyeNo") if "YevmiyeNo" in col_ids else col_ids.index("Yevmiye No")
            yev_no = str(vals[idx]).strip().replace(',', '')
            
            if yev_no and yev_no not in ["-", "", "0"]:
                self.open_fis_detail_popup(yev_no) # Mevcut popup fonksiyonunu çağırır
            else:
                messagebox.showwarning("Uyarı", "Geçerli bir Yevmiye Numarası bulunamadı.")
        except ValueError:
            messagebox.showerror("Hata", "Bu tabloda Yevmiye No sütunu bulunamadı.")

    def show_invoice_document_context(self):
        """
        Risk detay tablosundan seçilen Fatura No'yu kullanarak 
        fatura görüntüleyiciyi tetikler.
        """
        if FaturaGoruntulePopup is None:
            messagebox.showerror("Hata", "Fatura görüntüleme modülü bulunamadı.")
            return

        sel = self.data_tree.selection()
        if not sel: return
        
        vals = self.data_tree.item(sel[0])['values']
        col_ids = self.data_tree["columns"]
        
        # 1. Adım: Fatura No Sütununu Tespit Et
        target_col = next((c for c in col_ids if c in ["FATURA_NO", "BelgeNo", "Belge No"]), None)
        if not target_col:
            messagebox.showerror("Hata", "Tabloda Fatura No sütunu bulunamadı.")
            return

        try:
            idx = col_ids.index(target_col)
            belge_no = str(vals[idx]).strip()
            
            if not belge_no or belge_no in ["-", "None", "nan"]:
                messagebox.showwarning("Uyarı", "Geçerli bir belge numarası bulunamadı.")
                return

            # 2. Adım: Fatura No ile Veritabanından Tüm Satırları Çek
            # fetch_invoice_from_db fonksiyonu ui.py içinde tanımlı olmalıdır.
            df_invoice = self.fetch_invoice_from_db(belge_no)

            if df_invoice is not None and not df_invoice.empty:
                # 3. Adım: DataFrame'i Görüntüleyiciye Gönder
                target_master = self.winfo_toplevel() 
                FaturaGoruntulePopup(target_master, df_invoice)
            else:
                messagebox.showinfo("Bilgi", f"'{belge_no}' numaralı faturanın detayları arşivde bulunamadı.")

        except Exception as e:
            messagebox.showerror("Hata", f"Görüntüleme sırasında bir hata oluştu: {e}")


    def open_fis_detail_popup(self, fis_no):
        # 1- BİRDEN FAZLA PENCERE AÇILMASINI ENGELLEME
        if hasattr(self, '_fis_popup') and self._fis_popup.winfo_exists():
            self._fis_popup.destroy()

        items = self.engine.get_fis_details(fis_no)
        if not items:
            messagebox.showinfo("Bilgi", "Fiş detayı bulunamadı.")
            return

        popup = tk.Toplevel(self)
        self._fis_popup = popup # Pencere referansını sınıfa kaydet
        
        popup.title(f"Fiş İnceleme - No: {fis_no}")
        popup.geometry("1200x650")
        popup.configure(bg="white")
        
        # --- TASARIM RENKLERİ ---
        HEADER_BG = "#0b2b40"
        TEXT_WHITE = "white"
        
        # 1. BAŞLIK ALANI
        date_str = str(items[0].get('KayitTarihi', '-')) if items else "-"
        
        header_frame = tk.Frame(popup, bg=HEADER_BG, height=60)
        header_frame.pack(fill="x")
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text=f"FİŞ NO: {fis_no}", bg=HEADER_BG, fg=TEXT_WHITE, 
                 font=("Segoe UI", 16, "bold")).pack(side="left", padx=20)
        
        tk.Label(header_frame, text=f"TARİH: {date_str}", bg=HEADER_BG, fg=TEXT_WHITE, 
                 font=("Segoe UI", 14, "bold")).pack(side="right", padx=20)

        # --- ARAÇ ÇUBUĞU (EXCEL VE KOPYALAMA BİLGİSİ) ---
        toolbar_frame = tk.Frame(popup, bg="#ecf0f1", height=40)
        toolbar_frame.pack(fill="x")
        toolbar_frame.pack_propagate(False)

        def _export_excel():
            if not items: return
            try:
                # Veriyi DataFrame'e çevir ve Excel olarak kaydet
                df_exp = pd.DataFrame(items)
                
                # Sütun isimlerini Türkçeleştir (Görünen isimler gibi)
                col_map = {
                    'HesapKodu': 'Hesap Kodu', 'HesapAdi': 'Hesap Adı', 'BelgeNo': 'Belge No',
                    'FisAciklamasi': 'Fiş Açıklama', 'DetayAciklama': 'Detay Açıklama',
                    'Borc': 'Borç', 'Alacak': 'Alacak'
                }
                # Sadece mevcut sütunları al ve yeniden adlandır
                existing_keys = [k for k in col_map.keys() if k in df_exp.columns]
                df_exp = df_exp[existing_keys].rename(columns=col_map)
                
                path = filedialog.asksaveasfilename(
                    parent=popup,
                    defaultextension=".xlsx", 
                    filetypes=[("Excel Dosyası", "*.xlsx")],
                    title=f"Fiş_{fis_no}_Detay"
                )
                if path:
                    df_exp.to_excel(path, index=False)
                    messagebox.showinfo("Başarılı", "Excel dosyası başarıyla kaydedildi.", parent=popup)
            except Exception as e:
                messagebox.showerror("Hata", str(e), parent=popup)

        # Excel İndir Butonu
        tk.Button(toolbar_frame, text="📥 Excel İndir", bg="#27ae60", fg="white", 
                  font=("Segoe UI", 9, "bold"), relief="flat", padx=10, 
                  command=_export_excel).pack(side="right", padx=10, pady=5)

        tk.Label(toolbar_frame, text="💡 İpucu: Satırları kopyalamak için tabloya sağ tıklayınız.", 
                 bg="#ecf0f1", fg="#7f8c8d", font=("Segoe UI", 8)).pack(side="left", padx=20)

        # 2. İKİ YÖNLÜ SCROLL İÇEREN TABLO ALANI
        cols = ("HesapKodu", "HesapAdı", "BelgeNo", "FisAciklama", "DetayAciklama", "Borc", "Alacak")
        
        tree_frame = tk.Frame(popup, bg="white")
        tree_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        style = ttk.Style()
        style.configure("FisDetay.Treeview", rowheight=25, font=('Segoe UI', 9))
        style.configure("FisDetay.Treeview.Heading", font=('Segoe UI', 9, 'bold'))
        
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", style="FisDetay.Treeview", selectmode="extended")
        
        ysb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        xsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        
        tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        # Sütun Ayarları
        tree.heading("HesapKodu", text="Hesap Kodu");      tree.column("HesapKodu", width=100, anchor="w")
        tree.heading("HesapAdı", text="Hesap Adı");        tree.column("HesapAdı", width=200, anchor="w")
        tree.heading("BelgeNo", text="Belge No");          tree.column("BelgeNo", width=100, anchor="w")
        tree.heading("FisAciklama", text="Fiş Açıklama");  tree.column("FisAciklama", width=200, anchor="w")
        tree.heading("DetayAciklama", text="Detay Açıklama"); tree.column("DetayAciklama", width=200, anchor="w")
        tree.heading("Borc", text="Borç");                 tree.column("Borc", width=120, anchor="e")
        tree.heading("Alacak", text="Alacak");             tree.column("Alacak", width=120, anchor="e")

        tree.tag_configure('odd', background='#f1f8ff')
        tree.tag_configure('even', background='white')

        # --- SAĞ TIK MENÜSÜ (KOPYALAMA) ---
        context_menu = tk.Menu(tree, tearoff=0)
        
        def _copy_selection():
            selection = tree.selection()
            if not selection: return
            res = ""
            for item in selection:
                vals = tree.item(item)['values']
                res += "\t".join([str(v) for v in vals]) + "\n"
            popup.clipboard_clear()
            popup.clipboard_append(res)
            
        def _copy_all():
            res = ""
            # Başlıklar
            headers = [tree.heading(c)['text'] for c in cols]
            res += "\t".join(headers) + "\n"
            # Veriler
            for child in tree.get_children():
                vals = tree.item(child)['values']
                res += "\t".join([str(v) for v in vals]) + "\n"
            popup.clipboard_clear()
            popup.clipboard_append(res)

        context_menu.add_command(label="Seçili Satırları Kopyala", command=_copy_selection)
        context_menu.add_command(label="Tüm Tabloyu Kopyala", command=_copy_all)

        def _on_right_click(event):
            try: context_menu.post(event.x_root, event.y_root)
            except: pass
            
        tree.bind("<Button-3>", _on_right_click)
        if popup.tk.call('tk', 'windowingsystem') == 'aqua': tree.bind("<Button-2>", _on_right_click)

        # 3. VERİ DOLDURMA
        total_borc = 0.0
        total_alacak = 0.0
        
        for i, it in enumerate(items):
            try: b = float(it.get('Borc', 0))
            except: b = 0.0
            try: a = float(it.get('Alacak', 0))
            except: a = 0.0
            
            total_borc += b
            total_alacak += a
            
            fmt_borc = f"{b:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
            fmt_alacak = f"{a:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
            
            vals = (
                it.get('HesapKodu', ''), 
                it.get('HesapAdi', ''), 
                it.get('BelgeNo', ''), 
                it.get('FisAciklamasi', ''), 
                it.get('DetayAciklama', ''), 
                fmt_borc, 
                fmt_alacak
            )
            
            tag = 'odd' if i % 2 == 0 else 'even'
            tree.insert("", "end", values=vals, tags=(tag,))
            
        # 4. ALT BİLGİ (TOPLAMLAR)
        footer_frame = tk.Frame(popup, bg="white", height=50)
        footer_frame.pack(fill="x", side="bottom")
        tk.Frame(footer_frame, bg="#bdc3c7", height=1).pack(fill="x", side="top")
        
        diff = abs(total_borc - total_alacak)
        is_balanced = diff < 0.01
        
        status_text = "✅ FİŞ DENGEDE" if is_balanced else "❌ DENGESİZ"
        status_bg = "#27ae60" if is_balanced else "#c0392b"
        
        t_borc_fmt = f"{total_borc:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        t_alacak_fmt = f"{total_alacak:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        
        lbl_borc = tk.Label(footer_frame, text=f"TOPLAM BORÇ: {t_borc_fmt}", fg="#c0392b", bg="white", font=("Segoe UI", 11, "bold"))
        lbl_borc.pack(side="left", padx=20, pady=15)
        
        lbl_alacak = tk.Label(footer_frame, text=f"TOPLAM ALACAK: {t_alacak_fmt}", fg="#27ae60", bg="white", font=("Segoe UI", 11, "bold"))
        lbl_alacak.pack(side="left", padx=20, pady=15)
        
        lbl_status = tk.Label(footer_frame, text=status_text, fg="white", bg=status_bg, font=("Segoe UI", 10, "bold"), padx=10, pady=5)
        lbl_status.pack(side="right", padx=20, pady=10)
    
    def export_to_excel(self):
        if self.displayed_df is None or self.displayed_df.empty:
            messagebox.showwarning("Uyarı", "Dışa aktarılacak veri bulunamadı.")
            return

        try:
            # 1. Dinamik Sütunları Al
            col_keys, col_headers = self._get_treeview_column_config()
            
            # 2. DataFrame'i bu sütunlara göre filtrele ve sırala
            # (Veri setinde olup ekranda olmayan sütunlar elenir)
            available_cols = [c for c in col_keys if c in self.displayed_df.columns]
            
            export_df = self.displayed_df[available_cols].copy()
            
            # 3. Sütun Başlıklarını Türkçeleştir (Treeview başlıklarını kullan)
            # col_keys ve available_cols eşleşmesini sağla
            rename_map = {}
            for i, key in enumerate(col_keys):
                if key in available_cols:
                    rename_map[key] = col_headers[i]
            
            export_df.rename(columns=rename_map, inplace=True)
            
            # 4. Kaydet
            path = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel Dosyası", "*.xlsx")],
                title="Dinamik_Rapor"
            )
            
            if path:
                export_df.to_excel(path, index=False)
                messagebox.showinfo("Başarılı", "Excel dosyası, ekrandaki görünümle kaydedildi.")
                
        except Exception as e:
            messagebox.showerror("Hata", f"Excel oluşturma hatası: {e}")

    def export_to_pdf(self):
        """
        Seçili riskin PDF raporunu oluşturur.
        Yasal Uyarı 1. sayfada (başlığın hemen altında) yer alır.
        """
        sel = self.result_tree.selection()
        if not sel:
            messagebox.showwarning("Uyarı", "Lütfen önce listeden bir risk seçiniz.")
            return

        val = self.result_tree.item(sel[0])['values']
        if not val:
            messagebox.showwarning("Uyarı", "Seçtiğiniz öğe bir 'Grup Başlığı'.\nLütfen grubun içini açarak altındaki Risk maddelerinden birini seçiniz.")
            return
        idx = val[0]
        data = self.current_results[idx]
        scen = data['scenario']
        df = data['data']

        path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF Dosyası", "*.pdf")],
            title="Risk_Raporu"
        )
        if not path: return

        try:
            # --- Font Ayarları ---
            try:
                pdfmetrics.registerFont(TTFont('Arial', 'arial.ttf'))
                pdfmetrics.registerFont(TTFont('Arial-Bold', 'arialbd.ttf'))
                font_normal = 'Arial'
                font_bold = 'Arial-Bold'
            except:
                font_normal = 'Helvetica'
                font_bold = 'Helvetica-Bold'

            doc = SimpleDocTemplate(path, pagesize=landscape(A4), 
                                    rightMargin=20, leftMargin=20, topMargin=30, bottomMargin=30)
            elements = []
            styles = getSampleStyleSheet()
            
            # --- Stil Tanımları ---
            style_main = ParagraphStyle('M', parent=styles['Heading1'], fontName=font_bold, fontSize=16, textColor=colors.HexColor("#2c3e50"), alignment=1, spaceAfter=20)
            style_sub = ParagraphStyle('S', parent=styles['Normal'], fontName=font_bold, fontSize=11, textColor=colors.HexColor("#c0392b"), alignment=1)
            style_cell = ParagraphStyle('C', parent=styles['Normal'], fontName=font_normal, fontSize=7, leading=8, textColor=colors.black)
            style_cell_h = ParagraphStyle('CH', parent=styles['Normal'], fontName=font_bold, fontSize=7, leading=8, textColor=colors.white)
            style_card_title = ParagraphStyle('CT', parent=styles['Normal'], fontName=font_bold, fontSize=10, textColor=colors.HexColor("#7f8c8d"))
            style_card_body = ParagraphStyle('CB', parent=styles['Normal'], fontName=font_bold, fontSize=10, textColor=colors.HexColor("#2d3436"), leading=12)

            # FOOTER YARDIMCI FONKSİYONU
            def add_pdf_footer(canvas, doc):
                canvas.saveState()
                try: canvas.setFont('Arial', 7)
                except: canvas.setFont('Helvetica', 7)
                canvas.setFillColor(colors.HexColor("#7f8c8d"))
                line1 = "Bu rapor, e-denetimPRO tarafından tamamen bilgi ve karar destek amacıyla otomatik üretilmiş olup; yasal bir dayanak, bağımsız denetim veya mali müşavirlik görüşü niteliği taşımaz."
                line2 = "Nihai mali ve hukuki sorumluluk, bulguları yorumlayıp onaylayan ruhsatlı meslek mensuplarına aittir; e-denetimPRO raporun kullanımından doğacak zararlardan sorumlu tutulamaz."
                canvas.drawCentredString(doc.pagesize[0]/2.0, 20, line1)
                canvas.drawCentredString(doc.pagesize[0]/2.0, 10, line2)
                canvas.restoreState()

            # --- Başlık (Sayfa 1) ---
            elements.append(Paragraph("RİSK ANALİZ RAPORU", style_main))
            elements.append(Paragraph(f"Senaryo: {scen.get('risk_title', '-')}", style_sub))
            elements.append(Spacer(1, 15))
            
            # NOT: BURADAKİ PAGEBREAK KALDIRILDI, DOĞRUDAN YASAL UYARIYA GEÇİYORUZ

            # ========================================================
            # YASAL UYARI VE SORUMLULUK REDDİ BEYANI (Sayfa 1'in devamı)
            # ========================================================
            style_disc_title = ParagraphStyle('DiscTitle', parent=styles['Heading2'], fontName=font_bold, fontSize=14, textColor=colors.HexColor("#c0392b"), alignment=1, spaceAfter=15)
            style_disc_body = ParagraphStyle('DiscBody', parent=styles['Normal'], fontName=font_normal, fontSize=9, textColor=colors.HexColor("#2d3436"), leading=12, alignment=4) 
            
            elements.append(Paragraph("YASAL UYARI", style_disc_title))
            
            disclaimer_texts = [
                "1. Bilgi Amaçlı Kullanım: Bu rapor, e-denetimPRO yazılımı tarafından kullanıcıların sağladığı finansal verilerin algoritmik yöntemlerle işlenmesi sonucunda otomatik olarak üretilmiştir. Raporda yer alan tüm analiz, hesaplama, anomali tespitleri ve bulgular tamamen bilgi amaçlıdır ve bir karar destek aracı (decision-support tool) olarak sunulmaktadır.",
                "2. Profesyonel Tavsiye Değildir: Bu rapordaki hiçbir içerik; bağımsız denetim raporu, mali müşavirlik görüşü, vergi danışmanlığı, hukuki tavsiye veya herhangi bir bağlayıcı mesleki karar niteliği taşımamaktadır. Yazılım, yasal yetkiye sahip bir meslek mensubunun (YMM, SMMM, Bağımsız Denetçi) mesleki yargı, yorum ve denetim sürecinin yerine geçemez.",
                "3. Veri Doğruluğu ve Bağımlılığı: Uygulamanın ürettiği sonuçların doğruluğu, bütünüyle kullanıcı tarafından sisteme aktarılan ham verilerin (mizan, muavin, fatura dökümleri vb.) kalitesine, eksiksiz olmasına ve doğruluğuna bağlıdır. Sisteme girilen hatalı, eksik, manipüle edilmiş veya güncel olmayan verilerden kaynaklanabilecek yanlış analiz veya sonuçlardan [e-denetimPRO/e-denetim.com] hiçbir koşulda sorumlu tutulamaz.",
                "4. Sorumluluğun Sınırlandırılması: Bu rapor, resmi kurumlara (Gelir İdaresi Başkanlığı, Kamu Gözetimi Kurumu, SPK vb.) yapılacak bildirimlerde, beyannamelerde veya hukuki ihtilaflarda tek başına geçerli bir belge veya yasal dayanak olarak kullanılamaz. Rapordaki verilere dayanılarak alınacak ticari, finansal, vergisel ve hukuki kararların tüm riski münhasıran kullanıcıya aittir. Bu raporun kullanımından veya yorumlanmasından doğabilecek doğrudan, dolaylı, özel veya tesadüfi hiçbir maddi/manevi zarardan, kar kaybından veya cezai yaptırımdan [e-denetimPRO/e-denetim.com] ve geliştiricileri sorumlu değildir.",
                "5. Nihai İnceleme Uyarısı: Raporda sunulan verilerin ve tespitlerin, resmi işlemlere konu edilmeden önce mutlaka yetkili kurumlar ve ruhsatlı meslek mensupları (YMM/SMMM/Bağımsız Denetçi) tarafından incelenmesi, yorumlanması ve onaylanması tavsiye edilir. Raporun oluşturulması ve indirilmesi, kullanıcının bu şartları okuduğu, anladığı ve peşinen kabul ettiği anlamına gelir."
            ]
            
            for text in disclaimer_texts:
                elements.append(Paragraph(text, style_disc_body))
                elements.append(Spacer(1, 6))
                
            elements.append(PageBreak()) # Yasal uyarı BİTTİKTEN sonra sayfa atla
            # ========================================================

            # --- 1. VERİ TABLOSU ---
            current_tree_keys, current_tree_headers = self._get_treeview_column_config()
            if self.displayed_df is not None and not self.displayed_df.empty:
                final_keys = [k for k in current_tree_keys if k in df.columns]
                final_headers = [current_tree_headers[i] for i, k in enumerate(current_tree_keys) if k in df.columns]
            else:
                final_keys = list(df.columns)
                final_headers = list(df.columns)

            header_row = [Paragraph(str(h), style_cell_h) for h in final_headers]
            table_data = [header_row]
            
            for row in df.head(20).to_dict('records'):
                row_data = []
                for key in final_keys:
                    val = row.get(key, '')
                    if isinstance(val, (int, float)) and any(x in str(key).upper() for x in ["TUTAR", "BORC", "ALACAK", "BAKIYE"]):
                        val_str = f"{val:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
                    elif ("Tarih" in str(key) or "TARIH" in str(key)) and isinstance(val, pd.Timestamp):
                        val_str = val.strftime('%d.%m.%Y')
                    else:
                        val_str = str(val)
                    row_data.append(Paragraph(val_str, style_cell))
                table_data.append(row_data)

            col_count = len(final_keys)
            if col_count > 0:
                t = Table(table_data, colWidths=[780/col_count]*col_count)
                t.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#c0392b")),
                    ('GRID', (0,0), (-1,-1), 0.5, colors.lightgrey),
                    ('VALIGN', (0,0), (-1,-1), 'TOP'),
                    ('PADDING', (0,0), (-1,-1), 2),
                ]))
                elements.append(t)
                elements.append(Paragraph("• Tablo ilk 20 kaydı göstermektedir.", style_cell))
                elements.append(Spacer(1, 20))

            # --- 2. RENKLİ KARTLAR ---
            def add_styled_card(title, content, color_hex, icon):
                safe_content = html.escape(str(content)).replace('\n', '<br/>')
                content_list = [Paragraph(f"{icon} {title.upper()}", style_card_title), Paragraph(safe_content, style_card_body)]
                card_data = [['', content_list]] 
                t_card = Table(card_data, colWidths=[8, 772])
                t_card.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (0,0), colors.HexColor(color_hex)), 
                    ('BACKGROUND', (1,0), (1,0), colors.white),               
                    ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor("#dcdde1")), 
                    ('VALIGN', (0,0), (-1,-1), 'TOP'),
                    ('LEFTPADDING', (1,0), (1,0), 10), 
                    ('TOPPADDING', (0,0), (-1,-1), 8),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 8),
                ]))
                elements.append(t_card)
                elements.append(Spacer(1, 10)) 

            add_styled_card("Tespit Edilen Risk", scen.get('risk_title', 'Tanımsız'), "#c0392b", "🚨") 
            msg = scen.get('risk_message') or scen.get('message', 'Açıklama yok.')
            add_styled_card("Analiz Detayı", msg, "#2980b9", "📝") 
            
            val1 = len(df)
            val2 = len(df['YevmiyeNo'].unique()) if 'YevmiyeNo' in df.columns else "N/A"
            stats_text = f"Toplam Kayıt: {val1} | Etkilenen Belge Sayısı: {val2}"
            add_styled_card("Özet Veri", stats_text, "#f1c40f", "📊") 
            
            reason = scen.get('risk_reason', 'Belirtilmemiş')
            add_styled_card("Risk Nedeni", reason, "#e67e22", "❓") 
            
            legis = scen.get('legislation', 'Standart Prosedür')
            add_styled_card("Mevzuat Dayanağı", legis, "#8e44ad", "⚖️") 
            
            sol = scen.get('solution_suggestion') or scen.get('solution', 'Öneri yok.')
            add_styled_card("Denetçi Çözüm Önerisi", sol, "#27ae60", "💡") 

            doc.build(elements, onFirstPage=add_pdf_footer, onLaterPages=add_pdf_footer)
            
            messagebox.showinfo("Başarılı", f"PDF Raporu oluşturuldu:\n{path}")
            try: os.startfile(path)
            except: pass

        except Exception as e:
            messagebox.showerror("Hata", f"PDF hatası: {e}")

    def export_group_to_pdf(self):
        """
        TAM SÜRÜM (EKSİKSİZ):
        1. Kapak Sayfası: Logo > Denetçi Ünvanı > Mükellef Adı > Tarihler
        2. Türkçe Karakter: Windows fontlarını (Arial) otomatik yükler.
        3. İçerik: Tüm tablolar ve renkli analiz kartları eksiksiz basılır.
        """
        # 1. VERİ KONTROLÜ
        if not hasattr(self, 'current_results') or not self.current_results:
            messagebox.showwarning("Uyarı", "Dışa aktarılacak analiz sonucu bulunamadı.")
            return

        # 2. VERİLERİ SIRALA (Grup Adı -> Risk Başlığı)
        sorted_data = sorted(
            self.current_results, 
            key=lambda x: (x['scenario'].get('group_name', 'Genel'), x['scenario']['risk_title'])
        )

        path = filedialog.asksaveasfilename(
            defaultextension=".pdf", 
            filetypes=[("PDF Dosyası", "*.pdf")],
            title="Kurumsal_Denetim_Raporu"
        )
        if not path: return

        try:
            # --- PROFİL VE DENETİM BİLGİLERİNİ ÇEK ---
            # (Yardımcı fonksiyonların ui.py içinde tanımlı olduğundan emin olun)
            prof_data = self.get_user_profile_data() 
            audit_info = self.get_audit_info()
            
            period_str = audit_info["period"]
            target_company = audit_info["target_unvan"]
            auditor_title = prof_data["auditor_unvan"]
            report_date = datetime.datetime.now().strftime("%d/%m/%Y")
            
            # --- FONT AYARLARI (TÜRKÇE KARAKTER İÇİN) ---
            font_normal = 'Helvetica'
            font_bold = 'Helvetica-Bold'
            try:
                # Windows Arial Fontlarını Yüklemeye Çalış
                font_path_arial = os.path.join(os.environ['WINDIR'], 'Fonts', 'arial.ttf')
                font_path_arial_bd = os.path.join(os.environ['WINDIR'], 'Fonts', 'arialbd.ttf')
                
                if os.path.exists(font_path_arial) and os.path.exists(font_path_arial_bd):
                    pdfmetrics.registerFont(TTFont('Arial', font_path_arial))
                    pdfmetrics.registerFont(TTFont('Arial-Bold', font_path_arial_bd))
                    font_normal = 'Arial'
                    font_bold = 'Arial-Bold'
            except:
                print("Arial fontu yüklenemedi, varsayılan font kullanılıyor.")

            # --- DOKÜMAN AYARLARI ---
            doc = SimpleDocTemplate(path, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
            elements = []
            styles = getSampleStyleSheet()

            # --- STİL TANIMLARI ---
            # Kapak Stilleri
            style_auditor = ParagraphStyle('Auditor', parent=styles['Normal'], fontName=font_bold, fontSize=14, textColor=colors.HexColor("#34495e"), alignment=1, spaceBefore=5)
            style_target = ParagraphStyle('Target', parent=styles['Normal'], fontName=font_bold, fontSize=20, textColor=colors.HexColor("#003366"), alignment=1, leading=24)
            style_rep_type = ParagraphStyle('RepType', parent=styles['Normal'], fontName=font_normal, fontSize=16, textColor=colors.HexColor("#7f8c8d"), alignment=1)
            style_cover_info = ParagraphStyle('CoverInfo', parent=styles['Normal'], fontName=font_bold, fontSize=12, textColor=colors.black, alignment=1)

            # İçerik Stilleri
            style_main = ParagraphStyle('MainTitle', parent=styles['Heading1'], fontName=font_bold, fontSize=14, textColor=colors.HexColor("#2980b9"), alignment=1, spaceAfter=5)
            style_group = ParagraphStyle('GroupTitle', parent=styles['Heading2'], fontName=font_bold, fontSize=12, textColor=colors.HexColor("#2c3e50"), alignment=1, spaceBefore=10, spaceAfter=10)
            style_sub = ParagraphStyle('SubTitle', parent=styles['Normal'], fontName=font_bold, fontSize=10, textColor=colors.HexColor("#c0392b"), spaceAfter=5)
            
            style_cell = ParagraphStyle('Cell', parent=styles['Normal'], fontName=font_normal, fontSize=7, leading=8, textColor=colors.black)
            style_cell_h = ParagraphStyle('CellH', parent=styles['Normal'], fontName=font_bold, fontSize=7, leading=8, textColor=colors.white)
            style_note = ParagraphStyle('Note', parent=styles['Normal'], fontName=font_normal, fontSize=8, textColor=colors.grey)
            
            style_card_title = ParagraphStyle('CardTitle', parent=styles['Normal'], fontName=font_bold, fontSize=9, textColor=colors.HexColor("#7f8c8d"))
            style_card_body = ParagraphStyle('CardBody', parent=styles['Normal'], fontName=font_bold, fontSize=9, textColor=colors.HexColor("#2d3436"), leading=11)

            # =========================================================
            # 1. KAPAK SAYFASI
            # =========================================================
            
            # A. LOGO (Varsa)
            if prof_data["logo_bytes"]:
                try:
                    from reportlab.platypus import Image as RLImage
                    img_io = io.BytesIO(prof_data["logo_bytes"])
                    # Logoyu orantılı boyutlandır
                    img = RLImage(img_io, width=180, height=130, kind='proportional')
                    img.hAlign = 'CENTER'
                    elements.append(img)
                except: pass
            
            elements.append(Spacer(1, 15))

            # B. DENETÇİ FİRMA ÜNVANI (Logonun Altında)
            elements.append(Paragraph(auditor_title, style_auditor))
            
            elements.append(Spacer(1, 60))

            # C. İNCELENEN MÜKELLEF ADI
            elements.append(Paragraph(target_company, style_target))
            
            elements.append(Spacer(1, 30))

            # D. RAPOR TÜRÜ
            elements.append(Paragraph("e-Denetim Raporu", style_rep_type))
            
            elements.append(Spacer(1, 80))

            # E. TARİH BİLGİLERİ
            elements.append(Paragraph(f"Analiz Dönemi : {period_str}", style_cover_info))
            elements.append(Spacer(1, 10))
            elements.append(Paragraph(f"Rapor Tarihi : {report_date}", style_cover_info))
            
            # Kapak bitti, içeriğe geç
            elements.append(PageBreak()) 
            
            
            # === YASAL UYARI VE SORUMLULUK REDDİ BEYANI (SAYFA 2) ===
            style_disc_title = ParagraphStyle('DiscTitle', parent=styles['Heading2'], fontName=font_bold, fontSize=14, textColor=colors.HexColor("#c0392b"), alignment=1, spaceAfter=15)
            style_disc_body = ParagraphStyle('DiscBody', parent=styles['Normal'], fontName=font_normal, fontSize=10, textColor=colors.HexColor("#2d3436"), leading=14, alignment=4) # alignment=4 (Justify)
            
            elements.append(Paragraph("YASAL UYARI", style_disc_title))
            
            disclaimer_texts = [
                "1. Bilgi Amaçlı Kullanım: Bu rapor, e-denetimPRO yazılımı tarafından kullanıcıların sağladığı finansal verilerin algoritmik yöntemlerle işlenmesi sonucunda otomatik olarak üretilmiştir. Raporda yer alan tüm analiz, hesaplama, anomali tespitleri ve bulgular tamamen bilgi amaçlıdır ve bir karar destek aracı (decision-support tool) olarak sunulmaktadır.",
                "2. Profesyonel Tavsiye Değildir: Bu rapordaki hiçbir içerik; bağımsız denetim raporu, mali müşavirlik görüşü, vergi danışmanlığı, hukuki tavsiye veya herhangi bir bağlayıcı mesleki karar niteliği taşımamaktadır. Yazılım, yasal yetkiye sahip bir meslek mensubunun (YMM, SMMM, Bağımsız Denetçi) mesleki yargı, yorum ve denetim sürecinin yerine geçemez.",
                "3. Veri Doğruluğu ve Bağımlılığı: Uygulamanın ürettiği sonuçların doğruluğu, bütünüyle kullanıcı tarafından sisteme aktarılan ham verilerin (mizan, muavin, fatura dökümleri vb.) kalitesine, eksiksiz olmasına ve doğruluğuna bağlıdır. Sisteme girilen hatalı, eksik, manipüle edilmiş veya güncel olmayan verilerden kaynaklanabilecek yanlış analiz veya sonuçlardan [e-denetimPRO/e-denetim.com] hiçbir koşulda sorumlu tutulamaz.",
                "4. Sorumluluğun Sınırlandırılması: Bu rapor, resmi kurumlara (Gelir İdaresi Başkanlığı, Kamu Gözetimi Kurumu, SPK vb.) yapılacak bildirimlerde, beyannamelerde veya hukuki ihtilaflarda tek başına geçerli bir belge veya yasal dayanak olarak kullanılamaz. Rapordaki verilere dayanılarak alınacak ticari, finansal, vergisel ve hukuki kararların tüm riski münhasıran kullanıcıya aittir. Bu raporun kullanımından veya yorumlanmasından doğabilecek doğrudan, dolaylı, özel veya tesadüfi hiçbir maddi/manevi zarardan, kar kaybından veya cezai yaptırımdan [e-denetimPRO/e-denetim.com] ve geliştiricileri sorumlu değildir.",
                "5. Nihai İnceleme Uyarısı: Raporda sunulan verilerin ve tespitlerin, resmi işlemlere konu edilmeden önce mutlaka yetkili kurumlar ve ruhsatlı meslek mensupları (YMM/SMMM/Bağımsız Denetçi) tarafından incelenmesi, yorumlanması ve onaylanması tavsiye edilir. Raporun oluşturulması ve indirilmesi, kullanıcının bu şartları okuduğu, anladığı ve peşinen kabul ettiği anlamına gelir."
            ]
            
            for text in disclaimer_texts:
                elements.append(Paragraph(text, style_disc_body))
                elements.append(Spacer(1, 10))
                
            elements.append(PageBreak()) # Yasal uyarı sonrası sayfa sonu
            # ========================================================
            # =========================================================
            # 2. İÇERİK DÖNGÜSÜ (TAM KOD)
            # =========================================================
            
            total_risks = len(sorted_data)
            # --- FOOTER YARDIMCI FONKSİYONU ---
            def add_pdf_footer(canvas, doc):
                canvas.saveState()
                try: canvas.setFont('Arial', 7)
                except: canvas.setFont('Helvetica', 7)
                canvas.setFillColor(colors.HexColor("#7f8c8d"))
                line1 = "Bu rapor, e-denetimPRO tarafından tamamen bilgi ve karar destek amacıyla otomatik üretilmiş olup; yasal bir dayanak, bağımsız denetim veya mali müşavirlik görüşü niteliği taşımaz."
                line2 = "Nihai mali ve hukuki sorumluluk, bulguları yorumlayıp onaylayan ruhsatlı meslek mensuplarına aittir; e-denetimPRO raporun kullanımından doğacak zararlardan sorumlu tutulamaz."
                canvas.drawCentredString(doc.pagesize[0]/2.0, 20, line1)
                canvas.drawCentredString(doc.pagesize[0]/2.0, 10, line2)
                canvas.restoreState()
            # --- KART YARDIMCI FONKSİYONU ---
            def add_styled_card(title, content, color_hex, icon):
                # HTML karakterlerini temizle ve satır sonlarını <br/> yap
                safe_content = html.escape(str(content)).replace('\n', '<br/>')
                
                content_list = [
                    Paragraph(f"{icon} {title.upper()}", style_card_title),
                    Paragraph(safe_content, style_card_body)
                ]
                
                # Tablo Yapısı: [İnce Renkli Şerit (8px)] [İçerik]
                # A4 Genişlik ~595pt. Marginler 60pt. Kullanılabilir: ~535pt.
                t_card = Table([['', content_list]], colWidths=[8, 520])
                t_card.setStyle(TableStyle([
                    ('BACKGROUND', (0,0), (0,0), colors.HexColor(color_hex)), # Sol Şerit
                    ('BACKGROUND', (1,0), (1,0), colors.white),               # İçerik BG
                    ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor("#dcdde1")), # Çerçeve
                    ('VALIGN', (0,0), (-1,-1), 'TOP'),
                    ('LEFTPADDING', (1,0), (1,0), 10),
                    ('TOPPADDING', (0,0), (-1,-1), 6),
                    ('BOTTOMPADDING', (0,0), (-1,-1), 6),
                ]))
                elements.append(t_card)
                elements.append(Spacer(1, 6))

            # --- DÖNGÜ BAŞLANGICI ---
            for i, data in enumerate(sorted_data):
                scen = data['scenario']
                df = data['data']
                group_name = scen.get('group_name', 'GENEL')
                risk_title = scen.get('risk_title', 'Tanımsız Risk')

                # 2.1. Başlıklar
                elements.append(Paragraph(f"RİSK DETAY RAPORU ({i+1}/{total_risks})", style_main))
                elements.append(Paragraph(f"📂 GRUP: {group_name}", style_group))
                elements.append(Paragraph(f"Senaryo: {risk_title}", style_sub))

                # 2.2. Veri Tablosu
                # Gereksiz sütunları çıkar
                final_cols = [c for c in df.columns if c not in ['index', 'level_0', 'ID']]
                
                if final_cols:
                    # Başlık Satırı
                    header_row = [Paragraph(str(c).replace("_", " ").title(), style_cell_h) for c in final_cols]
                    table_data = [header_row]
                    
                    # Veri Satırları (İlk 15 Kayıt)
                    for row in df.head(15).to_dict('records'):
                        r_data = []
                        for c in final_cols:
                            val = row.get(c, '')
                            # Sayı ve Tarih Formatlama
                            if isinstance(val, (int, float)) and any(x in str(c).upper() for x in ["TUTAR", "BORC", "ALACAK", "BAKIYE"]):
                                val = f"{val:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
                            elif ("Tarih" in str(c)) and isinstance(val, pd.Timestamp):
                                val = val.strftime('%d.%m.%Y')
                            r_data.append(Paragraph(str(val), style_cell))
                        table_data.append(r_data)
                    
                    # Tablo Genişlik Ayarı
                    col_w = 530 / len(final_cols) if final_cols else 530
                    if col_w < 30: col_w = 30 # Minimum genişlik
                    
                    t = Table(table_data, colWidths=[col_w] * len(final_cols))
                    t.setStyle(TableStyle([
                        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#c0392b")), # Başlık Kırmızı
                        ('GRID', (0,0), (-1,-1), 0.5, colors.lightgrey),
                        ('VALIGN', (0,0), (-1,-1), 'TOP'),
                        ('LEFTPADDING', (0,0), (-1,-1), 2),
                        ('RIGHTPADDING', (0,0), (-1,-1), 2)
                    ]))
                    elements.append(t)
                    elements.append(Spacer(1, 5))
                    elements.append(Paragraph(f"• Tablo ilk {len(table_data)-1} kaydı göstermektedir. (Toplam Kayıt: {len(df)})", style_note))

                elements.append(Spacer(1, 15))
                
                # 2.3. Renkli Bilgi Kartları
                # A) Tespit (Kırmızı)
                add_styled_card("Tespit Edilen Risk", risk_title, "#c0392b", "🚨")
                
                # B) Analiz Detayı (Mavi)
                msg = scen.get('risk_message') or scen.get('message', 'Açıklama yok.')
                add_styled_card("Analiz Detayı", msg, "#2980b9", "📝")
                
                # C) İstatistik (Sarı)
                stats_text = f"Toplam Riskli Kayıt: {len(df)}"
                if 'YevmiyeNo' in df.columns:
                    stats_text += f" | Etkilenen Fiş Sayısı: {len(df['YevmiyeNo'].unique())}"
                add_styled_card("Özet İstatistikler", stats_text, "#f1c40f", "📊")
                
                # D) Neden (Turuncu)
                reason = scen.get('risk_reason', 'Belirtilmemiş')
                add_styled_card("Risk Nedeni", reason, "#e67e22", "❓")
                
                # E) Mevzuat (Mor)
                legis = scen.get('legislation', 'Standart Prosedür')
                add_styled_card("Mevzuat Dayanağı", legis, "#8e44ad", "⚖️")
                
                # F) Çözüm Önerisi (Yeşil)
                sol = scen.get('solution_suggestion') or scen.get('solution', 'Öneri yok.')
                add_styled_card("Denetçi Çözüm Önerisi", sol, "#27ae60", "💡")

                # Son sayfa değilse PageBreak ekle
                if i < total_risks - 1:
                    elements.append(PageBreak())

            # 3. PDF OLUŞTUR VE KAYDET
            doc.build(elements, onFirstPage=add_pdf_footer, onLaterPages=add_pdf_footer)
            messagebox.showinfo("Başarılı", f"Rapor Başarıyla Oluşturuldu:\n{path}")
            try: os.startfile(path)
            except: pass

        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Hata", f"PDF Oluşturma Hatası: {str(e)}")
    # =========================================================================
    def _clean_text_for_word(self, text):
        """
        Word dokümanını bozabilecek geçersiz karakterleri (ASCII kontrol karakterleri vb.) temizler.
        """
        if text is None: return ""
        text = str(text)
        # İzin verilen karakterler: 32 (boşluk) ve üzeri, ayrıca tab, yeni satır.
        return "".join(ch for ch in text if (ord(ch) >= 32) or ch in "\n\r\t")


    def _add_word_report_content(self, doc, data, index_info=""):
        """Word İçerik Oluşturucu - UI Tasarımına Sadık Kalınarak"""
        scen = data['scenario']
        df = data['data']
        
        # --- DİNAMİK SÜTUN BELİRLEME ---
        final_cols = list(df.columns)
        exclude = ['index', 'level_0', 'ID', 'Unnamed: 0']
        final_cols = [c for c in final_cols if c not in exclude]

        risk_title = self._clean_text_for_word(scen.get('risk_title', 'Tanımsız Risk'))
        
        # 1. RİSK BAŞLIĞI
        doc.add_paragraph("") 
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"RİSK RAPORU {index_info}")
        run.bold = True; run.font.size = Pt(16); run.font.color.rgb = RGBColor(44, 62, 80) # Koyu Lacivert
        
        p2 = doc.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run2 = p2.add_run(f"Senaryo: {risk_title}")
        run2.bold = True; run2.font.size = Pt(12); run2.font.color.rgb = RGBColor(192, 57, 43) # Kırmızı

        # --- TABLO ---
        if final_cols:
            table = doc.add_table(rows=1, cols=len(final_cols))
            table.style = 'Table Grid'
            
            # Header
            hdr_cells = table.rows[0].cells
            for i, col in enumerate(final_cols):
                hdr_cells[i].text = self._clean_text_for_word(str(col).replace("_", " ").title())
                # Başlık Arkaplanı: Kırmızı (#c0392b -> C0392B)
                try:
                    shading_elm = parse_xml(r'<w:shd {} w:fill="C0392B"/>'.format(nsdecls('w')))
                    hdr_cells[i]._tc.get_or_add_tcPr().append(shading_elm)
                except: pass
                
                for par in hdr_cells[i].paragraphs:
                    par.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for r in par.runs: 
                        r.font.bold = True; r.font.size = Pt(7); r.font.color.rgb = RGBColor(255, 255, 255)

            # Veri (İlk 20)
            for row in df.head(20).to_dict('records'):
                row_cells = table.add_row().cells
                for i, col in enumerate(final_cols):
                    val = row.get(col, '')
                    if isinstance(val, (int, float)) and any(x in str(col).upper() for x in ["TUTAR", "BORC", "ALACAK"]):
                        val = f"{val:,.2f}"
                    row_cells[i].text = self._clean_text_for_word(str(val))
                    for par in row_cells[i].paragraphs:
                        for r in par.runs: r.font.size = Pt(7)

        doc.add_paragraph("")
        
        # --- UI KARTLARINI SİMÜLE EDEN FONKSİYON ---
        def add_styled_card_word(title, content, color_hex, icon):
            # 2 Sütunlu Tablo: Sol sütun renkli şerit, Sağ sütun içerik
            tbl = doc.add_table(rows=1, cols=2)
            tbl.style = 'Table Grid' # İsterseniz kenarlığı kaldırabilirsiniz (None)
            tbl.autofit = False 
            tbl.allow_autofit = False
            
            # 1. Sol Sütun (Renkli Şerit)
            cell_color = tbl.cell(0, 0)
            cell_color.width = Cm(0.3) # Çok ince şerit
            
            # Hex kodunu (Örn: #c0392b) temizle -> C0392B
            clean_hex = color_hex.replace("#", "").upper()
            try:
                shading_elm = parse_xml(r'<w:shd {} w:fill="{}"/>'.format(nsdecls('w'), clean_hex))
                cell_color._tc.get_or_add_tcPr().append(shading_elm)
            except: pass
            
            # 2. Sağ Sütun (İçerik)
            cell_content = tbl.cell(0, 1)
            cell_content.width = Cm(25) # Geniş alan
            
            p = cell_content.paragraphs[0]
            # Başlık
            r1 = p.add_run(f"{icon} {title.upper()}\n")
            r1.bold = True
            r1.font.size = Pt(9)
            r1.font.color.rgb = RGBColor(127, 140, 141) # Gri ton (#7f8c8d)
            
            # İçerik
            r2 = p.add_run(self._clean_text_for_word(str(content)))
            r2.bold = True
            r2.font.size = Pt(10)
            r2.font.color.rgb = RGBColor(45, 52, 54) # Koyu Gri (#2d3436)
            
            doc.add_paragraph("") # Kartlar arası boşluk

        # --- UI KARTLARI ---
        
        # 1. Tespit (Kırmızı)
        add_styled_card_word("Tespit Edilen Risk", scen.get('risk_title', 'Tanımsız'), "#c0392b", "🚨")
        
        # 2. Analiz (Mavi)
        msg = scen.get('risk_message') or scen.get('message', 'Açıklama yok.')
        add_styled_card_word("Analiz Detayı", msg, "#2980b9", "📝")
        
        # 3. İstatistik (Sarı)
        stats_text = f"Toplam Kayıt: {len(df)}"
        if 'YevmiyeNo' in df.columns:
            stats_text += f" | Etkilenen Fiş: {len(df['YevmiyeNo'].unique())}"
        add_styled_card_word("Özet Veri", stats_text, "#f1c40f", "📊")
        
        # 4. Neden (Turuncu)
        reason = scen.get('risk_reason', 'Belirtilmemiş')
        add_styled_card_word("Risk Nedeni", reason, "#e67e22", "❓")
        
        # 5. Mevzuat (Mor)
        legis = scen.get('legislation', 'Standart Prosedür')
        add_styled_card_word("Mevzuat Dayanağı", legis, "#8e44ad", "⚖️")
        
        # 6. Çözüm (Yeşil)
        sol = scen.get('solution_suggestion') or scen.get('solution', 'Öneri yok.')
        add_styled_card_word("Denetçi Çözüm Önerisi", sol, "#27ae60", "💡")

    def export_to_word(self):
        """
        Tek bir riski Word'e aktarır. 
        Yasal Uyarı sayfanın en üstünde (ilk sayfada) yer alır.
        """
        sel = self.result_tree.selection()
        if not sel:
            messagebox.showwarning("Uyarı", "Lütfen bir risk seçiniz.")
            return

        val = self.result_tree.item(sel[0])['values']
        if not val: 
            messagebox.showwarning("Uyarı", "Lütfen bir grup değil, risk maddesi seçiniz.")
            return
        
        idx = int(val[0])
        data = self.current_results[idx]

        path = filedialog.asksaveasfilename(defaultextension=".docx", filetypes=[("Word Dosyası", "*.docx")], title="Rapor_Word")
        if not path: return

        try:
            doc = Document()
            # Yatay Sayfa Ayarı
            section = doc.sections[0]
            section.orientation = WD_ORIENT.LANDSCAPE
            new_width, new_height = section.page_height, section.page_width
            section.page_width = new_width
            section.page_height = new_height
            section.left_margin = Cm(1.5)
            section.right_margin = Cm(1.5)

            # ========================================================
            # 1. ÖNCE YASAL UYARI VE SORUMLULUK REDDİ BEYANI 
            # (Sayfanın en üstüne basılır)
            # ========================================================
            p_disc_title = doc.add_paragraph()
            p_disc_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r_disc_title = p_disc_title.add_run("YASAL UYARI")
            r_disc_title.bold = True
            r_disc_title.font.size = Pt(12) # Çok yer kaplamaması için biraz küçülttük
            r_disc_title.font.color.rgb = RGBColor(192, 57, 43)

            disclaimer_texts = [
                "1. Bilgi Amaçlı Kullanım: Bu rapor, e-denetimPRO yazılımı tarafından kullanıcıların sağladığı finansal verilerin algoritmik yöntemlerle işlenmesi sonucunda otomatik olarak üretilmiştir. Raporda yer alan tüm analiz, hesaplama, anomali tespitleri ve bulgular tamamen bilgi amaçlıdır ve bir karar destek aracı (decision-support tool) olarak sunulmaktadır.",
                "2. Profesyonel Tavsiye Değildir: Bu rapordaki hiçbir içerik; bağımsız denetim raporu, mali müşavirlik görüşü, vergi danışmanlığı, hukuki tavsiye veya herhangi bir bağlayıcı mesleki karar niteliği taşımamaktadır. Yazılım, yasal yetkiye sahip bir meslek mensubunun (YMM, SMMM, Bağımsız Denetçi) mesleki yargı, yorum ve denetim sürecinin yerine geçemez.",
                "3. Veri Doğruluğu ve Bağımlılığı: Uygulamanın ürettiği sonuçların doğruluğu, bütünüyle kullanıcı tarafından sisteme aktarılan ham verilerin (mizan, muavin, fatura dökümleri vb.) kalitesine, eksiksiz olmasına ve doğruluğuna bağlıdır. Sisteme girilen hatalı, eksik, manipüle edilmiş veya güncel olmayan verilerden kaynaklanabilecek yanlış analiz veya sonuçlardan [e-denetimPRO/e-denetim.com] hiçbir koşulda sorumlu tutulamaz.",
                "4. Sorumluluğun Sınırlandırılması: Bu rapor, resmi kurumlara (Gelir İdaresi Başkanlığı, Kamu Gözetimi Kurumu, SPK vb.) yapılacak bildirimlerde, beyannamelerde veya hukuki ihtilaflarda tek başına geçerli bir belge veya yasal dayanak olarak kullanılamaz. Rapordaki verilere dayanılarak alınacak ticari, finansal, vergisel ve hukuki kararların tüm riski münhasıran kullanıcıya aittir. Bu raporun kullanımından veya yorumlanmasından doğabilecek doğrudan, dolaylı, özel veya tesadüfi hiçbir maddi/manevi zarardan, kar kaybından veya cezai yaptırımdan [e-denetimPRO/e-denetim.com] ve geliştiricileri sorumlu değildir.",
                "5. Nihai İnceleme Uyarısı: Raporda sunulan verilerin ve tespitlerin, resmi işlemlere konu edilmeden önce mutlaka yetkili kurumlar ve ruhsatlı meslek mensupları (YMM/SMMM/Bağımsız Denetçi) tarafından incelenmesi, yorumlanması ve onaylanması tavsiye edilir. Raporun oluşturulması ve indirilmesi, kullanıcının bu şartları okuduğu, anladığı ve peşinen kabul ettiği anlamına gelir."
            ]

            for text in disclaimer_texts:
                p_disc = doc.add_paragraph()
                p_disc.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                r_disc = p_disc.add_run(text)
                r_disc.font.size = Pt(8) # İlk sayfada tabloya da yer kalması için 8 punto yapıldı
                r_disc.font.color.rgb = RGBColor(45, 52, 54)

            # Araya ince bir boşluk atalım
            doc.add_paragraph("")
            # ========================================================

            # ========================================================
            # 2. SONRA ASIL RAPOR İÇERİĞİ EKLENİR (Tablo, Kartlar vs.)
            # ========================================================
            self._add_word_report_content(doc, data)
            
            # ========================================================
            # 3. FOOTER (ALT BİLGİ) EKLENMESİ
            # ========================================================
            for sec in doc.sections:
                footer = sec.footer
                p_foot = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
                p_foot.text = "Bu rapor, e-denetimPRO tarafından tamamen bilgi ve karar destek amacıyla otomatik üretilmiş olup; yasal bir dayanak, bağımsız denetim veya mali müşavirlik görüşü niteliği taşımaz.\nNihai mali ve hukuki sorumluluk, bulguları yorumlayıp onaylayan ruhsatlı meslek mensuplarına aittir; e-denetimPRO raporun kullanımından doğacak zararlardan sorumlu tutulamaz."
                p_foot.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in p_foot.runs:
                    run.font.size = Pt(7)
                    run.font.color.rgb = RGBColor(127, 140, 141)
            
            doc.save(path)
            messagebox.showinfo("Başarılı", f"Word dosyası kaydedildi:\n{path}")
            try: os.startfile(path)
            except: pass
            
        except Exception as e:
            messagebox.showerror("Hata", f"Word hatası: {e}")

    def export_group_to_word(self):
        """
        TAM SÜRÜM: Word Raporu
        - Kapak Sayfası (Dikey): Logo, Denetçi, Mükellef, Tarih
        - İçerik Sayfaları (Yatay): Tablolar ve Kartlar
        - Hata Düzeltmesi: get_audit_info entegrasyonu sağlandı.
        """
        # 1. VERİ KONTROLÜ
        if not hasattr(self, 'current_results') or not self.current_results:
            messagebox.showwarning("Uyarı", "Dışa aktarılacak analiz sonucu bulunamadı.")
            return

        # 2. SIRALAMA (Grup Adı -> Risk Başlığı)
        sorted_data = sorted(
            self.current_results, 
            key=lambda x: (x['scenario'].get('group_name', 'Genel'), x['scenario']['risk_title'])
        )

        path = filedialog.asksaveasfilename(
            defaultextension=".docx", 
            filetypes=[("Word Dosyası", "*.docx")], 
            title="Kurumsal_Denetim_Raporu"
        )
        if not path: return

        try:
            # --- VERİLERİ ÇEK (Doğru Fonksiyon İsimleri ile) ---
            prof_data = self.get_user_profile_data() # Logo ve Denetçi
            audit_info = self.get_audit_info()       # Mükellef ve Tarih
            
            period_str = audit_info["period"]
            target_company = audit_info["target_unvan"]
            auditor_title = prof_data["auditor_unvan"]
            report_date = datetime.datetime.now().strftime("%d/%m/%Y")

            doc = Document()
            
            # =========================================================
            # 1. KAPAK SAYFASI (DİKEY FORMAT)
            # =========================================================
            
            # A. LOGO (Ortalanmış)
            if prof_data["logo_bytes"]:
                try:
                    img_io = io.BytesIO(prof_data["logo_bytes"])
                    p_logo = doc.add_paragraph()
                    p_logo.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    r_logo = p_logo.add_run()
                    # Logoyu Word için uygun boyuta getir (5 cm genişlik)
                    r_logo.add_picture(img_io, width=Cm(5))
                except Exception as e:
                    print(f"Logo ekleme hatası: {e}")

            doc.add_paragraph("") # Boşluk

            # B. DENETÇİ FİRMA ÜNVANI (Gri, Orta Boy)
            p_aud = doc.add_paragraph()
            p_aud.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r_aud = p_aud.add_run(auditor_title)
            r_aud.bold = True
            r_aud.font.size = Pt(14)
            r_aud.font.color.rgb = RGBColor(80, 80, 80) # Koyu Gri

            # Sayfa Ortasına İtmek İçin Boşluklar
            for _ in range(4): doc.add_paragraph("")

            # C. İNCELENEN MÜKELLEF (Büyük, Lacivert)
            p_tgt = doc.add_paragraph()
            p_tgt.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r_tgt = p_tgt.add_run(target_company)
            r_tgt.bold = True
            r_tgt.font.size = Pt(22)
            r_tgt.font.color.rgb = RGBColor(0, 51, 102) # Lacivert

            doc.add_paragraph("")

            # D. RAPOR TÜRÜ
            p_type = doc.add_paragraph()
            p_type.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r_type = p_type.add_run("e-Denetim Raporu")
            r_type.italic = True
            r_type.font.size = Pt(16)
            r_type.font.color.rgb = RGBColor(100, 100, 100) # Gri

            # Sayfa Altına İtmek İçin Boşluklar
            for _ in range(6): doc.add_paragraph("")

            # E. TARİHLER
            p_date = doc.add_paragraph()
            p_date.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # Dönem
            r_d1 = p_date.add_run(f"Analiz Dönemi : {period_str}\n")
            r_d1.bold = True
            r_d1.font.size = Pt(12)
            
            # Rapor Tarihi
            r_d2 = p_date.add_run(f"\nRapor Tarihi : {report_date}")
            r_d2.bold = True
            r_d2.font.size = Pt(12)

            # Kapak Bitti -> Sayfa Sonu
            doc.add_page_break()
            
            
            # === YASAL UYARI VE SORUMLULUK REDDİ BEYANI (SAYFA 2 - DİKEY) ===
            p_disc_title = doc.add_paragraph()
            p_disc_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r_disc_title = p_disc_title.add_run("YASAL UYARI")
            r_disc_title.bold = True
            r_disc_title.font.size = Pt(14)
            r_disc_title.font.color.rgb = RGBColor(192, 57, 43)
            doc.add_paragraph("")

            disclaimer_texts = [
                "1. Bilgi Amaçlı Kullanım: Bu rapor, e-denetimPRO yazılımı tarafından kullanıcıların sağladığı finansal verilerin algoritmik yöntemlerle işlenmesi sonucunda otomatik olarak üretilmiştir. Raporda yer alan tüm analiz, hesaplama, anomali tespitleri ve bulgular tamamen bilgi amaçlıdır ve bir karar destek aracı (decision-support tool) olarak sunulmaktadır.",
                "2. Profesyonel Tavsiye Değildir: Bu rapordaki hiçbir içerik; bağımsız denetim raporu, mali müşavirlik görüşü, vergi danışmanlığı, hukuki tavsiye veya herhangi bir bağlayıcı mesleki karar niteliği taşımamaktadır. Yazılım, yasal yetkiye sahip bir meslek mensubunun (YMM, SMMM, Bağımsız Denetçi) mesleki yargı, yorum ve denetim sürecinin yerine geçemez.",
                "3. Veri Doğruluğu ve Bağımlılığı: Uygulamanın ürettiği sonuçların doğruluğu, bütünüyle kullanıcı tarafından sisteme aktarılan ham verilerin (mizan, muavin, fatura dökümleri vb.) kalitesine, eksiksiz olmasına ve doğruluğuna bağlıdır. Sisteme girilen hatalı, eksik, manipüle edilmiş veya güncel olmayan verilerden kaynaklanabilecek yanlış analiz veya sonuçlardan [e-denetimPRO/e-denetim.com] hiçbir koşulda sorumlu tutulamaz.",
                "4. Sorumluluğun Sınırlandırılması: Bu rapor, resmi kurumlara (Gelir İdaresi Başkanlığı, Kamu Gözetimi Kurumu, SPK vb.) yapılacak bildirimlerde, beyannamelerde veya hukuki ihtilaflarda tek başına geçerli bir belge veya yasal dayanak olarak kullanılamaz. Rapordaki verilere dayanılarak alınacak ticari, finansal, vergisel ve hukuki kararların tüm riski münhasıran kullanıcıya aittir. Bu raporun kullanımından veya yorumlanmasından doğabilecek doğrudan, dolaylı, özel veya tesadüfi hiçbir maddi/manevi zarardan, kar kaybından veya cezai yaptırımdan [e-denetimPRO/e-denetim.com] ve geliştiricileri sorumlu değildir.",
                "5. Nihai İnceleme Uyarısı: Raporda sunulan verilerin ve tespitlerin, resmi işlemlere konu edilmeden önce mutlaka yetkili kurumlar ve ruhsatlı meslek mensupları (YMM/SMMM/Bağımsız Denetçi) tarafından incelenmesi, yorumlanması ve onaylanması tavsiye edilir. Raporun oluşturulması ve indirilmesi, kullanıcının bu şartları okuduğu, anladığı ve peşinen kabul ettiği anlamına gelir."
            ]

            for text in disclaimer_texts:
                p_disc = doc.add_paragraph()
                p_disc.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                r_disc = p_disc.add_run(text)
                r_disc.font.size = Pt(10)
                r_disc.font.color.rgb = RGBColor(45, 52, 54)
                doc.add_paragraph("")

            doc.add_page_break() # Yasal Uyarıdan Sonra Tekrar Sayfa Atla
            # ========================================================
            # =========================================================
            # 2. İÇERİK SAYFALARI (YATAY FORMAT)
            # =========================================================
            
            # Word'de bölüm (section) ekleyerek yönü yatay (landscape) yapıyoruz
            section = doc.add_section()
            section.orientation = WD_ORIENT.LANDSCAPE
            
            # Sayfa boyutlarını ters çevir (A4 Dikey -> A4 Yatay)
            new_width, new_height = section.page_height, section.page_width
            section.page_width = new_width
            section.page_height = new_height
            
            # Kenar Boşlukları
            section.left_margin = Cm(1.5)
            section.right_margin = Cm(1.5)

            total = len(sorted_data)
            
            # --- DÖNGÜ: Tüm Riskleri Yazdır ---
            for i, data in enumerate(sorted_data):
                grp_name = data['scenario'].get('group_name', 'GENEL')
                
                # Sayfa Başlığı Bilgisi: (1/50) - KASA GRUBU
                index_info = f"({i+1}/{total}) - {grp_name}"
                
                # İçerik Oluşturucu (Mevcut yardımcı fonksiyonunuzu çağırır)
                # Bu fonksiyon tabloları ve kartları oluşturur
                self._add_word_report_content(doc, data, index_info=index_info)
                
                # Son risk hariç her riskten sonra sayfa sonu ekle
                if i < total - 1:
                    doc.add_page_break()
            # --- WORD FOOTER (ALT BİLGİ) AYARLARI ---
            for sec in doc.sections:
                footer = sec.footer
                # Eğer footer paragrafı yoksa oluştur
                p_foot = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
                p_foot.text = "Bu rapor, e-denetimPRO tarafından tamamen bilgi ve karar destek amacıyla otomatik üretilmiş olup; yasal bir dayanak, bağımsız denetim veya mali müşavirlik görüşü niteliği taşımaz.\nNihai mali ve hukuki sorumluluk, bulguları yorumlayıp onaylayan ruhsatlı meslek mensuplarına aittir; e-denetimPRO raporun kullanımından doğacak zararlardan sorumlu tutulamaz."
                p_foot.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in p_foot.runs:
                    run.font.size = Pt(7)
                    run.font.color.rgb = RGBColor(127, 140, 141) # Gri
            # ----------------------------------------
            # 3. KAYDET VE AÇ
            doc.save(path)
            messagebox.showinfo("Başarılı", f"Word Raporu Başarıyla Oluşturuldu:\n{path}")
            try: os.startfile(path)
            except: pass
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Hata", f"Word Oluşturma Hatası: {str(e)}")


    def run_audit(self):
        # 1. Ön Kontroller
        if not check_internet_connection():
            messagebox.showerror("Bağlantı Hatası", "İnternet bağlantısı algılanamadı.")
            return

        if not CURRENT_USER_TOKEN: 
            messagebox.showerror("Hata", "Token Yok\nLütfen Launcher ile giriş yapın.")
            return
            
        # 2. Grup Listesi Kontrolü
        if not hasattr(self, 'available_groups_cache') or not self.available_groups_cache:
            messagebox.showinfo("Bilgi", "Grup listesi yükleniyor, lütfen bekleyip tekrar deneyin.")
            self.load_groups_from_cloud()
            return

        # 3. POPUP SEÇİM PENCERESİ
        # Combobox'taki mevcut seçimi varsayılan olarak gönder
        current_selection = self.cb_group_run.get()
        
        popup = GroupSelectionPopup(self, self.available_groups_cache, initial_selection=current_selection)
        self.wait_window(popup) # Pencere kapanana kadar bekle
        
        # 4. Seçim Yapıldıysa Başlat
        if popup.result:
            selected_groups = popup.result # Liste döner: ['KASA', 'BANKA'...]
            
            self.stop_event = threading.Event()
            self.progress_win = ProgressPopup(self, on_cancel=self.stop_audit)
            self.progress_win.update()
            
            # Listeyi thread'e gönderiyoruz
            t = threading.Thread(target=lambda: self.audit_thread_task(selected_groups))
            t.start()


    def stop_audit(self): 
        if self.stop_event: self.stop_event.set()
    def audit_thread_task(self, selected_groups_list):
        """
        Seçilen grupları sırayla işler.
        AKILLI WEB SENKRONİZASYONU:
        İşlem öncesi ve sonrası sunucu bakiyesi kontrol edilerek,
        düşülen gerçek miktar (fark) geçmişe kaydedilir.
        """
        total_results = []
        try:
            self.abort_reason = None
            self.last_net_check_time = time.time()
            
            if self.progress_win: 
                self.after(0, lambda: self.progress_win.lbl_status.config(text="Veriler Hazırlanıyor..."))
            
            self.engine.load_data()
            if self.stop_event.is_set(): return

            # --- GRUP DÖNGÜSÜ ---
            for index, group_name in enumerate(selected_groups_list):
                if self.stop_event.is_set(): break
                
                msg = f"Grup İşleniyor ({index+1}/{len(selected_groups_list)}): {group_name}"
                if self.progress_win: 
                    self.after(0, lambda m=msg: self.progress_win.lbl_status.config(text=m))

                if not check_internet_connection():
                    self.abort_reason = "connection_lost"
                    self.stop_event.set()
                    break

                # 1. BAŞLANGIÇ BAKİYESİNİ AL (WEB)
                bal_before = CloudLicenseManager.get_wallet_balance(CURRENT_USER_TOKEN)

                # =======================================================
                # YENİ: MOTOR ÇALIŞMADAN ÖNCE KREDİ / ERİŞİM KONTROLÜ
                # Motorun "sıfır risk buldum" diyerek bizi kandırmasını önler.
                # =======================================================
                pkg_check = CloudLicenseManager.fetch_group_package(CURRENT_USER_TOKEN, group_name)
                if isinstance(pkg_check, dict) and pkg_check.get("success") is False:
                    self.abort_reason = "insufficient_funds"
                    self.stop_event.set()
                    
                    err_msg = pkg_check.get("message", "Yetersiz Kredi veya Sunucu Hatası")
                    
                    # Anında hatayı göster ve döngüyü kır
                    self.after(0, lambda m=err_msg: self.finish_audit_error(f"⚠️ İŞLEM DURDURULDU\n\n{m}"))
                    break
                # =======================================================

                # 2. ANALİZİ ÇALIŞTIR 
                # (Bu fonksiyon çalışırken sunucu krediyi düşüyor)
                group_results = self.engine.run_scenarios(
                    CURRENT_USER_TOKEN, 
                    self.update_progress_from_thread, 
                    group_filter=group_name, 
                    stop_event=self.stop_event
                )
                
                # 3. İŞLEM BAŞARILIYSA MALİYETİ HESAPLA VE KAYDET
                if group_results is not None:
                    try:
                        # Bitiş Bakiyesini Al (WEB)
                        bal_after = CloudLicenseManager.get_wallet_balance(CURRENT_USER_TOKEN)
                        
                        # Farkı Hesapla (Gerçek Web Maliyeti)
                        real_cost = bal_before - bal_after
                        
                        # Eğer sunucu kredi kestiyse bunu geçmişe işle
                        if real_cost > 0:
                            self.log_credit_usage_to_history(group_name, real_cost)
                        
                        # Sağ üstteki bakiyeyi güncelle
                        refresh_ui_credits_global()
                            
                    except Exception as e:
                        print(f"Loglama hatası: {e}")

                    total_results.extend(group_results)
                
                time.sleep(0.5)

            # --- BİTİŞ İŞLEMLERİ ---
            if self.stop_event.is_set():
                if self.abort_reason == "connection_lost":
                    self.after(0, lambda: self.finish_audit_error("⚠️ BAĞLANTI KOPTU\nİşlem sırasında internet kesildi.\nTamamlanan grupların sonuçları kaydedildi."))
                    if total_results:
                        ver = self.engine.save_report(total_results)
                        self.after(0, lambda: self.finish_audit(total_results, f"{ver} (Kısmi)"))
                
                elif self.abort_reason == "insufficient_funds":
                    # Hata mesajını zaten yukarıda döngü kırılırken gösterdik.
                    # Ekstra bir uyarı daha çıkartmamak için burayı sessizce pas geçiyoruz.
                    pass
                
                else:
                    self.after(0, lambda: self.finish_audit(None, "İşlem İptal Edildi"))
                    
            elif not total_results: 
                self.after(0, lambda: self.finish_audit(None, "Seçilen gruplarda risk bulunamadı veya işlem başarısız."))
            else:
                ver = self.engine.save_report(total_results)
                self.after(0, lambda: self.finish_audit(total_results, ver))
                
        except Exception as e: 
            import traceback; traceback.print_exc()
            self.after(0, lambda: self.finish_audit_error(str(e)))

            
    def update_progress_from_thread(self, c, t, task):
        # 1. Her çağrıda UI barını güncelle (Mevcut kod)
        if self.progress_win: 
            self.after(0, lambda: self.progress_win.update_bar(c, t, task))
            
        # 2. İNTERNET KONTROLÜ (Sürekli Denetim)
        # Sistemi yormamak için her 5 saniyede bir kontrol yapıyoruz.
        import time
        current_time = time.time()
        
        if current_time - self.last_net_check_time > 5:  # 5 saniye geçtiyse
            self.last_net_check_time = current_time
            
            if not check_internet_connection(timeout=3): # Hızlı timeout (1.5 sn)
                # İnternet koptu! İşlemi durdur.
                self.abort_reason = "connection_lost" # Sebebi kaydet
                self.stop_event.set() # Engine döngüsünü kır
                print("⚠️ İnternet koptu, işlem durduruluyor...")
    
    def finish_audit(self, res, msg):
        # KREDİ GÜNCELLEME LİSTESİ ÇAĞIRILIYOR
        refresh_ui_credits_global()
        
        if self.progress_win: self.progress_win.close()
        if not res: messagebox.showinfo("Bilgi", msg); return
        self.refresh_history(); self.display_results(res); self.header_label.config(text=f"  SONUÇLAR [{msg}]"); messagebox.showinfo("Bitti", msg)
    
    def finish_audit_error(self, msg):
        if self.progress_win: self.progress_win.close()
        messagebox.showerror("Hata", msg)
    def refresh_history(self):
        self.history_list.delete(0, tk.END)
        try:
            hist = self.engine.get_report_history()
            for _, r in hist.iterrows(): self.history_list.insert(tk.END, f"{r['version_name']} ({r['total_risks']} Risk)")
        except: pass
    def load_historical_report(self, e):
        s = self.history_list.curselection()
        if not s: return
        
        # Listeden seçilen metni al: "STOKLAR - 16.01 14:30 (5 Risk)"
        full_text = self.history_list.get(s[0])
        
        # Sondaki " (X Risk)" ibaresini ayırarak gerçek versiyon adını bul
        # rsplit kullanarak sondan ilk boşluk+parantez ikilisini buluyoruz
        if " (" in full_text:
            ver = full_text.rsplit(" (", 1)[0]
        else:
            ver = full_text # Format farklıysa olduğu gibi al
            
        res = self.engine.fetch_report_results(ver)
        if res: 
            self.display_results(res)
        else:
            # Eğer veri gelmezse kullanıcıyı uyar (Hata ayıklama için)
            from tkinter import messagebox
            messagebox.showinfo("Bilgi", "Seçilen rapora ait veri okunamadı.")
    def delete_selected_report(self):
        s = self.history_list.curselection()
        if not s: return
        
        full_text = self.history_list.get(s[0])
        
        # İsmi doğru ayrıştır
        if " (" in full_text:
            ver = full_text.rsplit(" (", 1)[0]
        else:
            ver = full_text
            
        if messagebox.askyesno("Sil", f"'{ver}' başlıklı rapor silinsin mi?"):
            if self.engine.delete_report_version(ver): 
                self.refresh_history()
                # Silindikten sonra ekrandaki tabloyu da temizle
                self.result_tree.delete(*self.result_tree.get_children())
                self.var_total.set("0")
    def display_results(self, results):
        self.current_results = results
        self.result_tree.delete(*self.result_tree.get_children())
        self.var_total.set(str(len(results)))

        # Sıralama: Önce Ana Grup, Sonra Risk Başlığına göre
        results.sort(key=lambda x: (x['scenario'].get('group_name', '') or '', x['scenario']['risk_title']))

        # --- Stil Tanımları ---
        self.result_tree.tag_configure('group', font=('Segoe UI', 10, 'bold'), background='#dfe6e9', foreground='#2d3436')
        self.result_tree.tag_configure('subgroup', font=('Segoe UI', 9, 'bold'), background='#f1f2f6', foreground='#636e72')
        self.result_tree.tag_configure('risk_high', foreground='#c0392b')

        main_groups = {}  
        sub_groups = {}   

        for idx, item in enumerate(results):
            # 1. ADIM: Ana Grup (Senaryo Grubu, örn: KASA GRUBU)
            grp_name = item['scenario'].get('group_name', 'Genel')
            if not grp_name: grp_name = 'Genel'

            if grp_name not in main_groups:
                main_groups[grp_name] = self.result_tree.insert(
                    "", "end", text=f" 📂 {grp_name}", open=False, tags=('group',)
                )
            parent_node_id = main_groups[grp_name]

            # 2. ADIM: Alt Grup ve Başlık Temizliği
            full_title = item['scenario']['risk_title']
            
            # Tire (-) işaretine göre başlığı ikiye bölüyoruz
            if "-" in full_title:
                # Tireden öncesi alt grup adı (Örn: 100 KASA)
                sub_grp_name = full_title.split("-", 1)[0].strip()
                # Tireden sonrası ise riskin sadeleştirilmiş adı
                clean_title = full_title.split("-", 1)[1].strip()
            else:
                sub_grp_name = "Diğer"
                clean_title = full_title

            sub_key = (parent_node_id, sub_grp_name)
            
            if sub_key not in sub_groups:
                sub_groups[sub_key] = self.result_tree.insert(
                    parent_node_id, "end", text=f" 🔹 {sub_grp_name}", open=False, tags=('subgroup',)
                )
            sub_node_id = sub_groups[sub_key]

            # 3. ADIM: Temizlenmiş Risk Maddesini Ekleme
            # Artık full_title yerine, gereksiz önekten kurtulmuş clean_title kullanıyoruz
            display_text = f" 🟠 {clean_title} ({len(item['data'])})"

            self.result_tree.insert(
                sub_node_id, "end", text=display_text, values=(idx,), tags=('risk_high',)
            )
    
    def sort_tree_column(self, col, reverse):
        """
        Treeview sütununu tıklandığında sıralar.
        Türkçe para birimi formatını (1.234,56) sayıya çevirerek doğru sıralama yapar.
        """
        # Verileri [(değer, item_id), ...] formatında al
        l = [(self.data_tree.set(k, col), k) for k in self.data_tree.get_children('')]
        
        # Sıralama Anahtarı (Sayı mı Metin mi?)
        def sort_key(t):
            val, _ = t
            # Boş değerleri en sona at
            if not val: return -999999999999 if reverse else 999999999999
            
            try:
                # 1. Sayısal Dönüşüm Denemesi (Türkçe format: 1.234,56 -> 1234.56)
                clean_val = val.replace('.', '').replace(',', '.')
                return float(clean_val)
            except ValueError:
                # 2. Metinsel Sıralama (Küçük harfe çevir ki A ile a karışmasın)
                return str(val).lower()

        try:
            l.sort(key=sort_key, reverse=reverse)
        except Exception as e:
            print(f"Sıralama hatası: {e}")
            l.sort(reverse=reverse) # Fallback: Düz string sıralaması

        # Öğeleri yeni sıraya göre taşı
        for index, (val, k) in enumerate(l):
            self.data_tree.move(k, '', index)

        # Bir sonraki tıklama için yönü tersine çevir
        self.data_tree.heading(col, command=lambda: self.sort_tree_column(col, not reverse))

        
    def on_result_select(self, event):
        sel = self.result_tree.selection()
        if not sel: return
        
        val = self.result_tree.item(sel[0])['values']
        if not val: return 
        
        idx = int(val[0])
        data = self.current_results[idx]
        scen = data['scenario']
        
        df = data['data'].copy()
        
        # =========================================================
        # --- TEKİLLEŞTİRME MANTIĞI (DEDUPLICATION) ---
        # =========================================================
        # Eğer veri setinde YevmiyeNo varsa, aynı yevmiyeye ait alt satırları temizle.
        # Her yevmiye numarası tabloda sadece 1 kez (tekil) görünür.
        if "YevmiyeNo" in df.columns:
            df = df.drop_duplicates(subset=["YevmiyeNo"]).copy()
        elif "Yevmiye No" in df.columns:
            df = df.drop_duplicates(subset=["Yevmiye No"]).copy()
            
        self.displayed_df = df
        
        # Risk sayısını tekilleştirilmiş satır sayısına göre güncelle
        self.var_risk_count.set(str(len(df))) 
        self.var_risk_title.set(scen['risk_title'])
        
        self.data_tree.delete(*self.data_tree.get_children())
        
        # =========================================================
        # --- 1. SÜTUN GÖSTERİM MANTIĞI ---
        # =========================================================
        source_type = scen.get('source_type', '')
        
        if not source_type:
            if 'FATURA_NO' in df.columns and 'YevmiyeNo' in df.columns: 
                source_type = 'FATURA_YEVMIYE'
            elif 'FATURA_NO' in df.columns: 
                source_type = 'FATURA'
            elif 'YevmiyeNo' in df.columns: 
                source_type = 'YEVMIYE'
            else:
                source_type = 'DIGER'

        std_efatura_cols = ["FATURA_NO", "TARIH", "SAAT", "ALICI", "ALICI_VKN", "MAL_HIZMET", "SATICI", "SATICI_VKN", "ODENECEK_TUTAR", "KDV_TUTAR", "PB", "SENARYO", "NOTLAR"]
        std_yevmiye_cols = ["YevmiyeNo", "KayitTarihi", "HesapKodu", "HesapAdi", "MuavinKodu", "MuavinAdi", "BelgeNo", "FisAciklamasi", "DetayAciklama", "Borc", "Alacak", "Bakiye"]

        display_cols = []
        
        if source_type == 'FATURA' and all(c in df.columns for c in ["FATURA_NO", "ODENECEK_TUTAR"]):
            display_cols = [c for c in std_efatura_cols if c in df.columns]
        elif source_type == 'YEVMIYE' and all(c in df.columns for c in ["YevmiyeNo", "Borc"]):
            display_cols = [c for c in std_yevmiye_cols if c in df.columns]
        else:
            ignore_cols = ["index", "level_0", "Unnamed: 0", "ID"]
            display_cols = [c for c in df.columns if c not in ignore_cols]

        # ---------------------------------------------------------
        # --- YENİ EKLENEN KISIM: İSTENMEYEN SÜTUNLARI GİZLEME ---
        # ---------------------------------------------------------
        hide_keywords = ["UNVAN", "VKN", "KAYNAK DOSYA", "KAYNAK_DOSYA", "DOSYA", "DOSYA_ADI"]
        display_cols = [c for c in display_cols if str(c).upper() not in hide_keywords]


        # =========================================================
        # --- 2. GÖRÜNÜM AYARLARI (ORTALAMA & GENİŞLİK) ---
        # =========================================================
        self.data_tree["columns"] = ["No"] + display_cols
        self.data_tree["show"] = "headings" # Açılır-kapanır ağaç yapısını İPTAL ettik, düz tablo.
        
        self.data_tree.column("No", width=40, anchor="center") 
        self.data_tree.heading("No", text="No")

        for col in display_cols:
            str_col = str(col).upper()
            width = 100
            if any(x in str_col for x in ["ACIKLAMA", "HIZMET", "ALICI", "SATICI", "MATRAH", "TOPLAM", "HESAP"]): width = 130
            elif any(x in str_col for x in ["TARIH", "VKN", "SAAT", "NO", "KOD", "DONEM"]): width = 90
            
            self.data_tree.column(col, width=width, anchor="center")
            
            header_text = str(col).replace("_", " ").title()
            if str_col == "ALICI_VKN": header_text = "Alıcı VKN"
            elif str_col == "FATURA_NO": header_text = "Fatura No"
            elif str_col == "ODENECEK_TUTAR": header_text = "Ödenecek Tutar"
            
            self.data_tree.heading(col, text=header_text, command=lambda _col=col: self.sort_tree_column(_col, False))

        # =========================================================
        # --- 3. VERİ DOLDURMA ---
        # =========================================================
        self.data_tree.tag_configure('evenrow', background="#fafafa")
        self.data_tree.tag_configure('oddrow', background="white")
        
        money_keywords = ["TUTAR", "FARK", "BORC", "ALACAK", "BAKIYE", "MATRAH", "TOPLAM", "HESAP", "KDV", "ODENECEK"]

        row_counter = 1
        for _, row in df.iterrows():
            vals = [row_counter]
            row_tags = ['evenrow'] if row_counter % 2 == 0 else ['oddrow']
            
            for c in display_cols:
                val = row.get(c, '')
                str_col = str(c).upper()
                
                if isinstance(val, (int, float)):
                    is_code_col = any(x in str_col for x in ["NO", "VKN", "TCKN", "YIL", "AY", "ID", "KOD"])
                    is_money_col = any(k in str_col for k in money_keywords)
                    
                    if "KODU" in str_col or "VERGINO" in str_col:
                        vals.append(str(val))
                    elif is_money_col:
                        formatted = f"{val:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
                        vals.append(formatted)
                    elif not is_code_col and val != 0: 
                        formatted = f"{val:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
                        vals.append(formatted)
                    else:
                        vals.append(str(val))
                elif ("Tarih" in str(c) or "TARIH" in str_col) and hasattr(val, 'strftime'):
                    vals.append(val.strftime('%d.%m.%Y'))
                else:
                    vals.append(str(val))
                    
            self.data_tree.insert("", "end", values=vals, tags=tuple(row_tags))
            row_counter += 1
            
        # Alt kısmı ve istatistikleri güncelle (Tekilleştirilmiş DataFrame gönderiliyor)
        self.update_detail_text(scen, df, data.get('cc_matches', []))

    def update_detail_text(self, scen, df, cc_matches=[]):
        """
        Detay alanını modernize edilmiş yüksek kontrastlı kartlarla doldurur.
        Metinler iki yana yaslanmış formatta (justify) ve kopyalama hatası giderilmiştir.
        """
        for widget in self.report_inner_frame.winfo_children():
            widget.destroy()

        self.report_inner_frame.config(padx=20, pady=20, bg="#f5f6fa")
        self.card_registry = []

        # --- KOPYALAMA MENÜSÜ YÖNETİMİ ---
        if hasattr(self, 'copy_menu'):
            try: self.copy_menu.destroy()
            except: pass
            
        self.copy_menu = tk.Menu(self, tearoff=0, bg="white", fg="#2c3e50")
        self.copy_text_buffer = ""
        
        def _perform_copy():
            if self.copy_text_buffer:
                self.clipboard_clear()
                self.clipboard_append(self.copy_text_buffer)
                self.update()

        self.copy_menu.add_command(label="📋 Metni Kopyala", command=_perform_copy)

        def _show_context_menu(event, text):
            self.copy_text_buffer = text
            try:
                self.copy_menu.tk_popup(event.x_root, event.y_root)
            finally:
                self.copy_menu.grab_release()

        def _select_card(clicked_frame, child_widgets):
            for card in self.card_registry:
                try:
                    card["frame"].config(bg="white")
                    for child in card["children"]: child.config(bg="white")
                except: pass
            clicked_frame.config(bg="#f8f9fa")
            for child in child_widgets: child.config(bg="#f8f9fa")

        # --- MODERN KART OLUŞTURUCU (Justify ve Düzeltilmiş Bağlamalar) ---
        def create_audit_card(parent, title, content, color="#c0392b", icon="🔍"):
            shadow = tk.Frame(parent, bg="#dcdde1", padx=1, pady=1)
            shadow.pack(fill="x", pady=6)
            
            card_frame = tk.Frame(shadow, bg="white", bd=0)
            card_frame.pack(fill="both", expand=True)

            side_bar = tk.Frame(card_frame, bg=color, width=5)
            side_bar.pack(side="left", fill="y")

            inner = tk.Frame(card_frame, bg="white", padx=15, pady=10)
            inner.pack(side="left", fill="both", expand=True)

            lbl_title = tk.Label(inner, text=f"{icon} {title.upper()}", font=("Segoe UI", 9, "bold"), 
                                 bg="white", fg="#7f8c8d", anchor="w")
            lbl_title.pack(fill="x")

            # --- GÜNCELLEME: İKİ YANA YASTA (JUSTIFY FORMATI) ---
            lbl_body = tk.Label(inner, text=content, font=("Segoe UI", 10, "bold"), 
                                bg="white", fg="#2d3436", 
                                justify="left", anchor="nw", # Justify simülasyonu
                                wraplength=620) # Metin genişliği sabitleme
            lbl_body.pack(fill="x", pady=(5, 0))

            all_w = [card_frame, inner, lbl_title, lbl_body]
            
            # Bağlamaları her alt widget için ayrı ayrı (Closure korumalı) tanımlıyoruz
            for w in all_w:
                w.bind("<MouseWheel>", self._on_mousewheel)
                w.bind("<Button-1>", lambda e, f=card_frame, c=all_w: _select_card(f, c))
                # Kritik: t=content ifadesi metnin o kart için sabitlenmesini sağlar
                w.bind("<Button-3>", lambda e, t=content: _show_context_menu(e, t))
                if self.tk.call('tk', 'windowingsystem') == 'aqua':
                    w.bind("<Button-2>", lambda e, t=content: _show_context_menu(e, t))

            self.card_registry.append({"frame": card_frame, "children": all_w})

        # ==================== İÇERİK OLUŞTURMA ====================

        # 1. RİSK BAŞLIĞI
        create_audit_card(self.report_inner_frame, "Tespit Edilen Risk", 
                          scen.get('risk_title', 'Tanımsız'), color="#c0392b", icon="🚨")

        # 2. AÇIKLAMA
        msg = scen.get('risk_message') or scen.get('message', 'Açıklama yok.')
        create_audit_card(self.report_inner_frame, "Analiz Detayı", msg, color="#2980b9", icon="📝")

        # 3. İSTATİSTİKLER
        val1 = len(df)
        val2 = len(df['YevmiyeNo'].unique()) if 'YevmiyeNo' in df.columns else "N/A"
        stats_text = f"Toplam Kayıt: {val1} | Etkilenen Fiş: {val2}"
        create_audit_card(self.report_inner_frame, "Özet Veri", stats_text, color="#f1c40f", icon="📊")

        # 4. NEDEN / MEVZUAT
        reason = scen.get('risk_reason', 'Belirtilmemiş')
        create_audit_card(self.report_inner_frame, "Risk Nedeni", reason, color="#e67e22", icon="❓")
        
        legis = scen.get('legislation', 'Standart Prosedür')
        create_audit_card(self.report_inner_frame, "Mevzuat Dayanağı", legis, color="#8e44ad", icon="⚖️")

        # 5. ÇÖZÜM ÖNERİSİ
        sol = scen.get('solution_suggestion') or scen.get('solution', 'Öneri yok.')
        create_audit_card(self.report_inner_frame, "Denetçi Çözüm Önerisi", sol, color="#27ae60", icon="💡")

        # Kaydırma alanını ve görünümü yenile
        self.report_inner_frame.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def setup_ui(self):
        # =========================================================
        # 1. EN ÜST ORTA ALAN (Açılır Kutu ve Buton Burada)
        # =========================================================
        top_action_frame = tk.Frame(self, bg="white")
        top_action_frame.pack(fill="x", side="top", pady=(10, 10))
        
        center_wrapper = tk.Frame(top_action_frame, bg="white")
        center_wrapper.pack(anchor="center")
        
        tk.Label(center_wrapper, text="Senaryo Grubu:", bg="white", font=("Segoe UI", 9, "bold")).pack(side="left", padx=(5, 5))
        
        # İŞTE HATA VEREN WIDGET BURADA TANIMLANIYOR:
        self.cb_group_run = ttk.Combobox(center_wrapper, state="readonly", font=("Segoe UI", 9), width=25)
        self.cb_group_run.pack(side="left", padx=5)
        self.cb_group_run['values'] = [] 
        
        tk.Button(center_wrapper, text="🔄", command=self.load_groups_from_cloud, width=3).pack(side="left", padx=2)
        tk.Button(center_wrapper, text="🚀 BULUT DENETİMİ BAŞLAT", bg="#2980b9", fg="white", relief="flat", font=("Segoe UI", 9, "bold"), padx=15, pady=6, command=self.run_audit).pack(side="left", padx=5)
        # =========================================================

        # 2. MEVCUT PANEL KODLARI BURADAN DEVAM EDİYOR
        self.paned = tk.PanedWindow(self, orient=tk.HORIZONTAL, sashwidth=4, bg=self.colors['header_bg'])
        self.paned.pack(fill="both", expand=True)
        
        # ... Sol Panel, Sağ Panel vs. kodların aynen kalacak ...
        
        # --- SOL PANEL ---
        left_frame = tk.Frame(self.paned, width=320, bg="white")
        self.paned.add(left_frame)
        self.header_label = tk.Label(left_frame, text="  DENETİM LİSTESİ", bg="#800020", fg="white", height=2, font=("Segoe UI", 11, "bold"), anchor="w")
        self.header_label.pack(fill="x")
        
        tree_container_left = tk.Frame(left_frame, bg="white")
        tree_container_left.pack(fill="both", expand=True)
        self.result_tree = ttk.Treeview(tree_container_left, columns=("id"), show="tree", displaycolumns=(), selectmode="browse")
        
        vsb_left = ttk.Scrollbar(tree_container_left, orient="vertical", command=self.result_tree.yview)
        hsb_left = ttk.Scrollbar(tree_container_left, orient="horizontal", command=self.result_tree.xview)
        self.result_tree.configure(yscrollcommand=vsb_left.set, xscrollcommand=hsb_left.set)
        self.result_tree.grid(row=0, column=0, sticky="nsew")
        vsb_left.grid(row=0, column=1, sticky="ns")
        hsb_left.grid(row=1, column=0, sticky="ew")
        tree_container_left.grid_rowconfigure(0, weight=1); tree_container_left.grid_columnconfigure(0, weight=1)
        self.result_tree.bind("<<TreeviewSelect>>", self.on_result_select)
        
        tk.Label(left_frame, text="  GEÇMİŞ RAPORLAR", bg=self.colors['header_bg'], fg=self.colors['text_dark'], font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x")
        self.history_list = tk.Listbox(left_frame, height=6, bd=0, bg="#f8f9fa", font=("Segoe UI", 9))
        self.history_list.pack(fill="x", padx=2, pady=2)
        self.history_list.bind("<Double-1>", self.load_historical_report)

        # --- SAĞ PANEL ---
        self.right_frame = tk.Frame(self.paned, bg="white")
        self.paned.add(self.right_frame)
        
        stats_frame = tk.Frame(self.right_frame, bg="white")
        stats_frame.pack(fill="x", padx=10, pady=5)
        
        self.var_total = tk.StringVar(value="0")
        self.var_risk_count = tk.StringVar(value="0")
        self.var_risk_title = tk.StringVar(value="Risk Seçilmedi")

        self.create_card(stats_frame, self.colors['purple'], "Toplam Risk", self.var_total, "🛡️", 0)
        
        p_card = tk.Frame(stats_frame, bg=self.colors['red'], height=40)
        p_card.pack_propagate(False)
        p_card.grid(row=0, column=1, sticky="ew", padx=2)
        
        tk.Label(p_card, text="📄", bg=self.colors['red'], fg="white", font=("Segoe UI", 12)).pack(side="left", padx=(10, 5))
        tk.Label(p_card, textvariable=self.var_risk_count, bg=self.colors['red'], fg="white", font=("Segoe UI", 14, "bold")).pack(side="left")
        tk.Label(p_card, textvariable=self.var_risk_title, bg=self.colors['red'], fg="white", font=("Segoe UI", 10)).pack(side="left", padx=5)
        
        stats_frame.columnconfigure(0, weight=1); stats_frame.columnconfigure(1, weight=2)

        # --- TOOLBAR (AÇILIR MENÜLÜ YAPI) ---
        toolbar = tk.Frame(self.right_frame, bg="white")
        toolbar.pack(fill="x", padx=20, pady=(5, 10))
        
        # Sol Başlık
        tk.Label(toolbar, text="Risk Detay Tablosu", font=("Segoe UI", 12, "bold"), bg="white", fg=self.colors['text_dark']).pack(side="left")
        
        # --- AÇILIR MENÜ BUTONU (DROPDOWN) ---
        mb_actions = tk.Menubutton(toolbar, text="⬇ Dışa Aktar / İşlemler  ▼", bg="#34495e", fg="white", 
                                   font=("Segoe UI", 9, "bold"), relief="flat", padx=15, pady=5, cursor="hand2")
        mb_actions.pack(side="right", padx=5)
        
        action_menu = tk.Menu(mb_actions, tearoff=0, bg="white", fg="#2c3e50", font=("Segoe UI", 10))
        mb_actions.config(menu=action_menu)
        
        # --- SEÇENEKLER ---
        
        # Excel
        action_menu.add_command(label="📥  Kayıtları Excel'e Aktar", command=self.export_to_excel)
        action_menu.add_separator() 
        
        # PDF Seçenekleri
        action_menu.add_command(label="📄  PDF İndir (Seçili Risk)", command=self.export_to_pdf)
        action_menu.add_command(label="📑  PDF İndir (Tüm Grup)", command=self.export_group_to_pdf)
        
        action_menu.add_separator()
        
        # WORD Seçenekleri (YENİ)
        action_menu.add_command(label="📝  Word İndir (Seçili Risk)", command=self.export_to_word)
        action_menu.add_command(label="📚  Word İndir (Tüm Grup)", command=self.export_group_to_word)


        self.right_split = tk.PanedWindow(self.right_frame, orient=tk.VERTICAL, sashwidth=4, bg=self.colors['header_bg'])
        self.right_split.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        
        table_container_right = tk.Frame(self.right_split, bg="white")
        self.right_split.add(table_container_right, height=350)
        self.data_tree = ttk.Treeview(table_container_right, style="Treeview", selectmode="extended")
        self.data_tree.bind("<Double-1>", self.on_double_click_row)
        ysb_right = ttk.Scrollbar(table_container_right, orient="vertical", command=self.data_tree.yview)
        xsb_right = ttk.Scrollbar(table_container_right, orient="horizontal", command=self.data_tree.xview)
        self.data_tree.configure(yscrollcommand=ysb_right.set, xscrollcommand=xsb_right.set)
        self.data_tree.grid(row=0, column=0, sticky="nsew")
        ysb_right.grid(row=0, column=1, sticky="ns")
        xsb_right.grid(row=1, column=0, sticky="ew")
        table_container_right.grid_rowconfigure(0, weight=1); table_container_right.grid_columnconfigure(0, weight=1)

# ... (setup_ui üst kısımları aynı) ...

        # =========================================================================
        # --- YENİ DETAY ALANI (PDF VIEWER - ORTALANMIŞ SAYFA) ---
        # =========================================================================
        detail_container = tk.Frame(self.right_split, bg="white")
        self.right_split.add(detail_container)
        
        # Başlık
        header_det = tk.Frame(detail_container, bg="#9c88ff", height=30)
        header_det.pack(fill="x")
        tk.Label(header_det, text="🔍 Otomatik Sonuç ve Çözüm Önerisi", bg="#9c88ff", fg="white", font=("Segoe UI", 10, "bold"), padx=10).pack(side="left")

        # PDF VIEWER ARKA PLANI (Koyu Gri/Mavi)
        VIEWER_BG = "#d1d8e0" 

        # Scrollable Canvas
        self.canvas = tk.Canvas(detail_container, bg=VIEWER_BG, highlightthickness=0)
        self.v_scroll = ttk.Scrollbar(detail_container, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.v_scroll.set)

        self.v_scroll.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        # Rapor Kağıdı (Beyaz Sayfa)
        self.report_inner_frame = tk.Frame(self.canvas, bg="white", bd=1, relief="solid")
        
        # Canvas içine pencere olarak ekle (Anchor='n' ile yukarıdan ortalayacağız)
        self.canvas_window = self.canvas.create_window((0, 0), window=self.report_inner_frame, anchor="n")

        # Scroll ve Resize Ayarları
        self.report_inner_frame.bind("<Configure>", self._on_frame_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        
        self.bind_mouse_scroll(self.canvas)
        self.bind_mouse_scroll(self.report_inner_frame)
        # =========================================================================

        footer = tk.Frame(self.right_frame, bg="white")
        footer.pack(fill="x", padx=20, pady=5)
        
        tk.Button(footer, text="RAPORU SİL", bg="white", fg=self.colors['red'], bd=1, relief="solid", font=("Segoe UI", 9, "bold"), padx=15, pady=5, command=self.delete_selected_report).pack(side="left", padx=5)
       
        self.refresh_history()

    # --- Scroll ve Sayfa Ortalama Yardımcıları ---
    def _on_frame_configure(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
    
    def _on_canvas_configure(self, event):
        # Sayfayı Ortala
        canvas_width = event.width
        # Kağıt genişliği: Maksimum 850px (A4 hissi), eğer ekran küçükse kenarlardan 30px boşluk
        page_width = min(canvas_width - 30, 850)
        if page_width < 100: page_width = 100
        
        self.canvas.itemconfig(self.canvas_window, width=page_width)
        # Tam ortaya (x = width/2) ve yukarıdan 20px aşağıya
        self.canvas.coords(self.canvas_window, canvas_width // 2, 20)

    def bind_mouse_scroll(self, widget):
        widget.bind("<MouseWheel>", self._on_mousewheel)
        widget.bind("<Button-4>", self._on_mousewheel)
        widget.bind("<Button-5>", self._on_mousewheel)

    def _on_mousewheel(self, event):
        if self.canvas.winfo_exists():
            if event.delta: self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            elif event.num == 5: self.canvas.yview_scroll(1, "units")
            elif event.num == 4: self.canvas.yview_scroll(-1, "units")

def _clean_text_for_word(self, text):
        """
        Word dokümanını bozabilecek geçersiz karakterleri (ASCII kontrol karakterleri vb.) temizler.
        """
        if text is None: return ""
        text = str(text)
        # İzin verilen karakterler: 32 (boşluk) ve üzeri, ayrıca tab, yeni satır.
        return "".join(ch for ch in text if (ord(ch) >= 32) or ch in "\n\r\t")



def refresh_ui_credits_global():
    """
    Kredi bilgisini listedeki TÜM etiketlerde günceller.
    """
    if not CURRENT_USER_TOKEN: return

    def _task():
        try:
            # Yeni bakiyeyi çek
            from users import CloudLicenseManager
            bal = CloudLicenseManager.get_wallet_balance(CURRENT_USER_TOKEN)
            
            global CURRENT_USER_CREDITS
            CURRENT_USER_CREDITS = bal
            
            # LİSTEDEKİ TÜM ETİKETLERİ GÜNCELLE
            for widget in CREDIT_LABEL_LIST:
                try:
                    if widget.winfo_exists():
                        widget.config(text=f"💰 Kredi: {bal}")
                except:
                    pass
                    
        except Exception as e:
            print(f"Kredi güncelleme hatası: {e}")

    threading.Thread(target=_task, daemon=True).start()