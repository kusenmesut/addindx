# engine.py
import os
import sqlite3
import pandas as pd
import numpy as np
import json
import traceback
from io import StringIO
from datetime import datetime
from config import get_mukellefler_dir
from utils.session_db import get_last_session

# YENİ EKLENEN IMPORT
from users import CloudLicenseManager 

class AuditEngine:
    def __init__(self):
        self.session = get_last_session()
        self.vkn = self.session.get('vkn')
        self.yil = self.session.get('yil')
        self.target_folder = self._find_target_folder()
        
        self.df_journal = None 
        self.df_invoices = None # YENİ: Fatura verisi için değişken   
        self.client_db_path = None
        
        if self.target_folder:
            self.client_db_path = os.path.join(self.target_folder, f"audit_results_{self.yil}.db")
            self._init_client_result_db()

# --- YENİ EKLENEN FONKSİYON ---
    def _load_invoice_data(self):
        """
        Fatura veritabanı varsa yükler ve cache'ler.
        Yoksa None döner.
        """
        if self.df_invoices is not None:
            return self.df_invoices

        if not self.target_folder or not self.yil:
            return None

        # İstenilen Path Yapısı: MUKELLEF_KLASORU / YIL / fatura_data_YIL.db
        db_path = os.path.join(self.target_folder, str(self.yil), f"fatura_data_{self.yil}.db")

        if not os.path.exists(db_path):
            return None

        try:
            conn = sqlite3.connect(db_path)
            # Tüm faturaları DataFrame'e çekiyoruz
            self.df_invoices = pd.read_sql("SELECT * FROM FATURALAR", conn)
            conn.close()
            return self.df_invoices
        except Exception as e:
            print(f"Fatura DB okuma hatası: {e}")
            return None
        
    def load_data(self):
        if not self.target_folder or not self.yil:
            raise FileNotFoundError("Aktif mükellef veya yıl seçili değil.")

        parquet_path = os.path.join(self.target_folder, str(self.yil), f"{self.yil}_FULL.parquet")
        if not os.path.exists(parquet_path):
            raise FileNotFoundError(f"Veri dosyası bulunamadı: {parquet_path}")

        try:
            self.df_journal = pd.read_parquet(parquet_path, engine='pyarrow') 
        except:
            self.df_journal = pd.read_parquet(parquet_path)
            
        self.df_journal['Borc'] = self.df_journal['Borc'].fillna(0)
        self.df_journal['Alacak'] = self.df_journal['Alacak'].fillna(0)
        self.df_journal['Bakiye'] = self.df_journal['Borc'] - self.df_journal['Alacak']
        
        if 'YevmiyeNo' in self.df_journal.columns:
            self.df_journal['YevmiyeNo'] = pd.to_numeric(self.df_journal['YevmiyeNo'], errors='coerce').fillna(0)

    def _get_filtered_journal(self):
        # 1. WİFİ GİBİ DÜŞÜN: Veri zaten filtrelenmişse, direkt hafızadaki hazır veriyi ver! (Saniyeler kazandırır)
        if hasattr(self, 'df_filtered_journal_cache') and self.df_filtered_journal_cache is not None:
            return self.df_filtered_journal_cache

        if self.df_journal is None or self.df_journal.empty:
            return pd.DataFrame()
        
        df = self.df_journal.copy()

        # Metin bazlı aramalar
        desc_combined = (df.get('FisAciklamasi', pd.Series()).fillna('').astype(str) + ' ' + 
                         df.get('DetayAciklama', pd.Series()).fillna('').astype(str)).str.lower()
        
        hesap_kodu = df.get('HesapKodu', pd.Series()).fillna('').astype(str)
        kayit_tarihi = df.get('KayitTarihi', pd.Series()).fillna('').astype(str)

        excl_yevmiyeler = set()

        if 1 in df['YevmiyeNo'].values:
            excl_yevmiyeler.add(1)

        kelime_mask = desc_combined.str.contains('yansıt|yansit|kapanış|kapanis|açılı|acili|devir', na=False)
        kelime_yevmiyeler = df.loc[kelime_mask, 'YevmiyeNo'].unique()
        excl_yevmiyeler.update(kelime_yevmiyeler)

        yansitma_hesaplari = ('711', '721', '731', '741', '751', '761', '771', '781')
        yansitma_mask = hesap_kodu.str.startswith(yansitma_hesaplari, na=False)
        yansitma_hesap_yevmiyeler = df.loc[yansitma_mask, 'YevmiyeNo'].unique()
        excl_yevmiyeler.update(yansitma_hesap_yevmiyeler)

        mask_3112 = kayit_tarihi.str.contains('31.12', na=False)
        if mask_3112.any():
            son_yevmiye_3112 = df.loc[mask_3112, 'YevmiyeNo'].max()
            if pd.notna(son_yevmiye_3112):
                excl_yevmiyeler.add(son_yevmiye_3112)

        df_clean = df[~df['YevmiyeNo'].isin(list(excl_yevmiyeler))]
        
        # 2. HAZIRLANMIŞ VERİYİ HAFIZAYA KAYDET (Bir sonraki senaryo anında çeksin)
        self.df_filtered_journal_cache = df_clean 
        
        return df_clean

    def run_scenarios(self, user_token, progress_callback=None, group_filter=None, stop_event=None):
        if self.df_journal is None: self.load_data()
        
        results = []
        is_cancelled = False # İptal durumunu takip et
        
        # --- DURUM 1: GRUP ÇALIŞTIRMA (TOPLU) ---
        if group_filter and group_filter != "TÜMÜ":
            print(f"Mod: Grup Hazırlanıyor ({group_filter})...")
            
            # 1. Kodları Al (Para henüz düşmedi)
            response = CloudLicenseManager.fetch_group_package(user_token, group_filter)
            if not response.get("success"):
                print(f"Grup Hatası: {response.get('message')}")
                return []
            
            scenarios = response.get("scenarios", [])
            total = len(scenarios)
            
            # 2. Çalıştır
            for i, scen in enumerate(scenarios):
                # KULLANICI İPTAL ETTİ Mİ?
                if stop_event and stop_event.is_set(): 
                    is_cancelled = True
                    print("!!! Kullanıcı Tarafından İptal Edildi - Kredi Düşülmeyecek !!!")
                    break
                
                if progress_callback: progress_callback(i + 1, total, scen['risk_title'])
                
                # Seçili Grup İsmini Senaryoya İşle
                scen['group_name'] = group_filter 
                
                code_payload = scen.get('code_payload', '')
                if code_payload:
                    self._execute_single_scenario(scen, code_payload, results)
            
            # 3. İŞLEM TAMAMLANDIYSA PARAYI KES (Confirmation)
            if not is_cancelled:
                print("Grup Başarıyla Tamamlandı -> Kredi Düşülüyor...")
                CloudLicenseManager.confirm_transaction(user_token, group_filter, 'group')

        # --- DURUM 2: TÜMÜ (MENÜ BAZLI TEK TEK) ---
        else:
            print("Mod: Tümünü Çalıştırma")
            menu_data = CloudLicenseManager.get_menu(user_token)
            
            # HATA DÜZELTMESİ: Dict / List Güvenliği
            scenarios = menu_data.get("scenarios", []) if isinstance(menu_data, dict) else menu_data
            if not scenarios: 
                print("Uyarı: Senaryo listesi boş geldi.")
                return []
                
            total = len(scenarios)
            
            # Bu modda her senaryo için ayrı ayrı onay verilir 
            
            for i, scen in enumerate(scenarios):
                if stop_event and stop_event.is_set(): 
                    print("İptal Edildi.")
                    break
                
                if progress_callback: progress_callback(i + 1, total, scen.get('risk_title', 'Bilinmeyen Risk'))

                # Kodu Çek (Para düşmez)
                api_res = CloudLicenseManager.fetch_code_payload(user_token, scen['id'])
                if not api_res.get("success"): continue
                
                # --- Grup Adı Kontrolü ---
                if 'group_name' not in scen or not scen['group_name']:
                    scen['group_name'] = "Genel"
                # -------------------------

                # Çalıştır
                self._execute_single_scenario(scen, api_res["code"], results)
                
                # Başarılı çalıştıysa ONAYLA ve PARAYI KES (Tekli)
                CloudLicenseManager.confirm_transaction(user_token, scen['id'], 'single')

        return results

    def _execute_single_scenario(self, scen, code_payload, results_list):
        """
        Kod çalıştırma mantığı - FİLTRELİ VERİ KULLANIMI İLE GÜNCELLENDİ
        """
        detected_df = pd.DataFrame()
        try:
            source_type = scen.get('source_type', 'YEVMIYE') 
            
            # --- 1. ÇALIŞMA ORTAMI (SCOPE) HAZIRLIĞI ---
            execution_scope = {
                'pd': pd, 
                'np': np, 
                'result_df': pd.DataFrame(),
                'vkn': self.vkn,
                'datetime': datetime 
            }

            # --- 2. VERİ YÜKLEME ---
            if source_type == 'FATURA_YEVMIYE':
                df_inv = self._load_invoice_data()
                if df_inv is None or df_inv.empty: return 
                
                if self.df_journal is None: self.load_data()
                
                execution_scope['df'] = df_inv         
                # KRİTİK DÜZELTME: Ham veri yerine filtrelenmiş veriyi scope'a ekliyoruz
                execution_scope['df_journal'] = self._get_filtered_journal() 
                
            elif source_type == 'FATURA':
                target_df = self._load_invoice_data()
                if target_df is None or target_df.empty: return
                execution_scope['df'] = target_df
                
            else: # Varsayılan: YEVMIYE
                if self.df_journal is None: self.load_data()
                # KRİTİK DÜZELTME: Ham veri yerine filtrelenmiş veriyi scope'a ekliyoruz
                execution_scope['df'] = self._get_filtered_journal()

            # --- 3. KOD TEMİZLİĞİ ---
            code_payload = code_payload.strip()
            if (code_payload.startswith('"') and code_payload.endswith('"')) or \
               (code_payload.startswith("'") and code_payload.endswith("'")):
                code_payload = code_payload[1:-1]
            
            code_payload = code_payload.replace('\\n', ' ').replace('\n', ' ').replace('\\r', '')
            code_body = code_payload.replace("@PYTHON", "", 1).strip()
            
            # --- 4. KODU ÇALIŞTIRMA ---
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                exec(code_body, execution_scope)
            
            # Sonucu al
            detected_df = execution_scope.get('result_df', pd.DataFrame())

        except Exception as e:
            print(f"Senaryo Hatası ({scen.get('risk_title', 'Bilinmeyen')}): {e}")
            pass

        # --- 5. SONUÇ KAYDI ---
        cc_matches = []
        rule = scen.get('cross_check') or scen.get('cross_check_rule')
        
        if not detected_df.empty and rule:
             cc_matches = self._run_cross_check(rule)
             scen['cross_check'] = rule 

        if not detected_df.empty or scen.get('is_pinned', False):
            if 'group_name' not in scen: scen['group_name'] = 'Genel'
            
            results_list.append({
                'scenario': scen,
                'data': detected_df,
                'cc_matches': cc_matches
            })

    def _run_cross_check(self, logic_str):
        try:
            parts = logic_str.split(';')
            if len(parts) < 2: return []
            target, check = parts[0].strip(), parts[1].strip()
            check_list = tuple(check.split('-')) # startswith için tuple olmalı
            
            if 'HesapKodu' not in self.df_journal.columns: return []
            
            # 1. Adım: Hedef hesabı içeren Yevmiye Numaralarını bul
            target_mask = self.df_journal['HesapKodu'].astype(str).str.startswith(target)
            target_yevmiyes = self.df_journal.loc[target_mask, 'YevmiyeNo'].unique()
            
            if len(target_yevmiyes) == 0: return []

            # 2. Adım: Sadece bu yevmiyeleri içeren veriyi al
            relevant = self.df_journal[self.df_journal['YevmiyeNo'].isin(target_yevmiyes)]
            
            # 3. Adım: Döngü KULLANMADAN, içinde check_list hesapları geçenleri bul
            match_mask = relevant['HesapKodu'].astype(str).str.startswith(check_list)
            
            # Eşleşen Yevmiye Numaralarını al, temizle ve listeye çevir
            matches = relevant.loc[match_mask, 'YevmiyeNo'].dropna().unique()
            return [str(int(float(m))) for m in matches]
            
        except Exception as e:
            print(f"Cross Check Hatası: {e}")
            return []

    def _init_client_result_db(self):
        conn = sqlite3.connect(self.client_db_path)
        cursor = conn.cursor()
        
        # 1. Raporlar Tablosu (Ana Başlıklar)
        cursor.execute("CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY AUTOINCREMENT, version_name TEXT, created_at DATETIME, total_risks INTEGER)")
        
        # 2. Rapor Detayları Tablosu
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS report_details (
                id INTEGER PRIMARY KEY AUTOINCREMENT, 
                report_id INTEGER, 
                scenario_id INTEGER, 
                group_name TEXT,       -- YENİ SÜTUN
                sub_group_name TEXT,   -- YENİ SÜTUN
                risk_tanimi TEXT, 
                tespit_mesaji TEXT, 
                mevzuat TEXT, 
                risk_nedeni TEXT, 
                cozum TEXT, 
                detected_data TEXT, 
                cc_matches TEXT, 
                FOREIGN KEY(report_id) REFERENCES reports(id)
            )
        """)
        
        # --- MIGRATION (Eski DB uyumluluğu için) ---
        # Eğer tablo önceden oluşmuşsa ve yeni sütunlar yoksa ekle:
        try:
            cursor.execute("SELECT group_name FROM report_details LIMIT 1")
        except sqlite3.OperationalError:
            # Sütun yoksa ekle
            try:
                cursor.execute("ALTER TABLE report_details ADD COLUMN group_name TEXT")
                cursor.execute("ALTER TABLE report_details ADD COLUMN sub_group_name TEXT")
            except: pass

        conn.commit()
        conn.close()

    def save_report(self, results):
        """
        Analiz sonuçlarını veritabanına kaydeder.
        Eksik sütun varsa otomatik ekler (Migration).
        """
        if not results: 
            print("Kaydedilecek sonuç yok.")
            return None
        
        # --- 1. DİNAMİK BAŞLIK OLUŞTURMA ---
        from datetime import datetime
        
        found_groups = set()
        for item in results:
            g = item['scenario'].get('group_name')
            if g and g != "Genel":
                found_groups.add(g)
        
        time_str = datetime.now().strftime('%d.%m %H:%M')
        
        if len(found_groups) == 1:
            group_title = list(found_groups)[0]
            version_name = f"{group_title} - {time_str}"
        elif len(found_groups) > 1:
            version_name = f"Karma Rapor - {time_str}"
        else:
            version_name = f"Genel Rapor - {time_str}"

        # --- 2. VERİTABANI BAĞLANTISI VE ONARIM ---
        conn = sqlite3.connect(self.client_db_path)
        cursor = conn.cursor()
        
        try:
            # Tablo yoksa oluştur (Garanti olsun)
            cursor.execute("CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY AUTOINCREMENT, version_name TEXT, created_at DATETIME, total_risks INTEGER)")
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS report_details (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, 
                    report_id INTEGER, 
                    scenario_id INTEGER, 
                    risk_tanimi TEXT, 
                    tespit_mesaji TEXT, 
                    mevzuat TEXT, 
                    risk_nedeni TEXT, 
                    cozum TEXT, 
                    detected_data TEXT, 
                    cc_matches TEXT, 
                    FOREIGN KEY(report_id) REFERENCES reports(id)
                )
            """)
            
            # --- KRİTİK BÖLÜM: Sütun Kontrolü ve Ekleme ---
            try:
                cursor.execute("SELECT group_name FROM report_details LIMIT 1")
            except sqlite3.OperationalError:
                print("Veritabanı güncelleniyor: Sütunlar ekleniyor...")
                cursor.execute("ALTER TABLE report_details ADD COLUMN group_name TEXT")
                cursor.execute("ALTER TABLE report_details ADD COLUMN sub_group_name TEXT")
                conn.commit() 
            # ---------------------------------------------

            # --- 3. KAYIT İŞLEMİ ---
            cursor.execute("INSERT INTO reports (version_name, created_at, total_risks) VALUES (?, ?, ?)", 
                           (version_name, datetime.now(), len(results)))
            report_id = cursor.lastrowid
            
            for item in results:
                s = item['scenario']
                df = item['data']
                
                # --- KRİTİK DÜZELTME: Veri Sterilizasyonu ---
                safe_df = df.copy()
                
                for col in safe_df.select_dtypes(include=['object', 'category']).columns:
                    safe_df[col] = safe_df[col].astype(str)
                
                safe_df = safe_df.reset_index(drop=True)
                
                json_data = safe_df.to_json(orient='split', date_format='iso')
                # ---------------------------------------------
                
                cc_json = json.dumps(item.get('cc_matches', []))
                
                msg = s.get('risk_message') or s.get('message') or ''
                sol = s.get('solution_suggestion') or s.get('solution') or ''
                risk_title = s.get('risk_title', '')
                group_name = s.get('group_name', 'Genel')
                
                if "-" in risk_title:
                    sub_group = risk_title.split("-")[0].strip()
                else:
                    sub_group = group_name

                cursor.execute("""
                    INSERT INTO report_details 
                    (report_id, scenario_id, group_name, sub_group_name, risk_tanimi, tespit_mesaji, mevzuat, risk_nedeni, cozum, detected_data, cc_matches) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (report_id, s.get('id'), group_name, sub_group, risk_title, msg, s.get('legislation'), s.get('risk_reason'), sol, json_data, cc_json))
                
            conn.commit()
            print(f"Başarıyla kaydedildi: {version_name}")
            return version_name
            
        except Exception as e:
            conn.rollback()
            print(f"KAYIT HATASI: {e}") 
            traceback.print_exc() 
            return None
        finally:
            conn.close()

    def fetch_report_results(self, version_name):
        """
        Seçilen versiyona ait rapor detaylarını veritabanından okur.
        Grup isminin 'Genel'e dönüşmesini engelleyen düzeltme içerir.
        """
        if not self.client_db_path or not os.path.exists(self.client_db_path):
            return []

        conn = sqlite3.connect(self.client_db_path)
        conn.row_factory = sqlite3.Row  
        cursor = conn.cursor()
        
        try:
            cursor.execute("SELECT id FROM reports WHERE version_name = ?", (version_name,))
            res = cursor.fetchone()
            
            if not res: 
                return []
            
            report_id = res['id']
            
            df_details = pd.read_sql(f"SELECT * FROM report_details WHERE report_id={report_id}", conn)
            
            results = []
            for _, row in df_details.iterrows():
                try: 
                    if row['detected_data']:
                        data_df = pd.read_json(StringIO(row['detected_data']), orient='split')
                    else:
                        data_df = pd.DataFrame()
                except: 
                    data_df = pd.DataFrame()
                
                cc_matches = []
                try:
                    if row.get('cc_matches'):
                        cc_matches = json.loads(row['cc_matches'])
                except: pass
                
                g_name = "Genel"
                
                if 'group_name' in row:
                    val = row['group_name']
                    if pd.notna(val) and str(val).strip() != "":
                        g_name = str(val)

                results.append({
                    'scenario': {
                        'risk_title': row.get('risk_tanimi'), 
                        'group_name': g_name,  
                        'risk_message': row.get('tespit_mesaji'), 
                        'message': row.get('tespit_mesaji'), 
                        'legislation': row.get('mevzuat'), 
                        'risk_reason': row.get('risk_nedeni'), 
                        'solution_suggestion': row.get('cozum'),
                        'solution': row.get('cozum')
                    }, 
                    'data': data_df, 
                    'cc_matches': cc_matches
                })
                
            return results
            
        except Exception as e:
            print(f"Rapor okuma hatası: {e}")
            return []
        finally:
            conn.close()
        
    def get_report_history(self):
        """
        Kayıtlı rapor versiyonlarını listeler.
        Hata oluşursa boş DataFrame döner, böylece UI bozulmaz.
        """
        if not self.client_db_path or not os.path.exists(self.client_db_path):
            return pd.DataFrame()

        conn = sqlite3.connect(self.client_db_path)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='reports'")
            if not cursor.fetchone():
                return pd.DataFrame()

            df = pd.read_sql("SELECT * FROM reports ORDER BY id DESC", conn)
            return df
        except Exception as e:
            print(f"Geçmiş yükleme hatası: {e}")
            return pd.DataFrame()
        finally:
            conn.close()

    def delete_report_version(self, version_name):
        conn = sqlite3.connect(self.client_db_path); cursor = conn.cursor()
        try:
            cursor.execute("SELECT id FROM reports WHERE version_name=?", (version_name,))
            rid = cursor.fetchone()[0]
            cursor.execute("DELETE FROM report_details WHERE report_id=?", (rid,))
            cursor.execute("DELETE FROM reports WHERE id=?", (rid,))
            conn.commit(); return True
        except: return False
        finally: conn.close()
        
    def _find_target_folder(self):
        if not self.vkn: return None
        base = get_mukellefler_dir()
        for f in os.listdir(base):
            if f.endswith(f"-{self.vkn}"): return os.path.join(base, f)
        return None
        
    def get_fis_details(self, yevmiye_no):
        if self.df_journal is None: self.load_data()
        try:
            target = int(float(str(yevmiye_no).replace(',', '')))
            return self.df_journal[self.df_journal['YevmiyeNo'].astype(int) == target].fillna('').to_dict('records')
        except: return []