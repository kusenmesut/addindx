# modules/degiskenler_tablosu/ui.py
import tkinter as tk
from tkinter import ttk, messagebox

from modules.degiskenler_tablosu.engine import VariablesEngine


class DegiskenlerTablosuFrame(tk.Frame):
    def __init__(self, parent, controller=None):
        super().__init__(parent)
        self.controller = controller
        self.engine = VariablesEngine()

        self.vars_data = []
        self.selected_label = None

        # --- RENK PALETİ (Modern Web Tarzı) ---
        self.colors = {
            "bg_main": "#F4F6F9",
            "bg_card": "#FFFFFF",
            "primary": "#0D6EFD",
            "primary_hover": "#0B5ED7",
            "text_dark": "#343A40",
            "text_muted": "#6C757D",
            "border": "#DEE2E6",
            "success": "#198754",
            "danger": "#DC3545",
        }

        self.configure(bg=self.colors["bg_main"])
        self.setup_styles()
        self.setup_ui()
        self.refresh_table()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("Main.TFrame", background=self.colors["bg_main"])
        style.configure("Card.TFrame", background=self.colors["bg_card"])

        style.configure("Header.TFrame", background=self.colors["primary"])
        style.configure(
            "Header.TLabel",
            background=self.colors["primary"],
            foreground="white",
            font=("Segoe UI", 11, "bold"),
        )

        style.configure(
            "FieldLabel.TLabel",
            background=self.colors["bg_card"],
            foreground=self.colors["text_muted"],
            font=("Segoe UI", 8),
        )

        style.configure(
            "Modern.TEntry",
            fieldbackground="white",
            bordercolor=self.colors["border"],
            lightcolor=self.colors["border"],
            darkcolor=self.colors["border"],
            padding=5,
        )

        style.configure(
            "Primary.TButton",
            background=self.colors["primary"],
            foreground="white",
            borderwidth=0,
            font=("Segoe UI", 9, "bold"),
            padding=(12, 6),
        )
        style.map("Primary.TButton", background=[("active", self.colors["primary_hover"])])

        style.configure(
            "Secondary.TButton",
            background="white",
            foreground=self.colors["text_dark"],
            bordercolor=self.colors["border"],
            borderwidth=1,
            padding=(10, 6),
        )

        style.configure(
            "Treeview",
            background="white",
            fieldbackground="white",
            foreground=self.colors["text_dark"],
            rowheight=35,
            font=("Segoe UI", 9),
            borderwidth=0,
        )
        style.configure(
            "Treeview.Heading",
            background="#F8F9FA",
            foreground=self.colors["text_dark"],
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padding=10,
        )
        style.map(
            "Treeview",
            background=[("selected", "#E7F1FF")],
            foreground=[("selected", self.colors["primary"])],
        )

    def setup_ui(self):
        # 1) HEADER
        header = ttk.Frame(self, style="Header.TFrame", height=45)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)

        ttk.Label(header, text="☰", style="Header.TLabel", font=("Segoe UI", 14)).pack(
            side="left", padx=(15, 10)
        )
        ttk.Label(header, text="Değişkenler", style="Header.TLabel").pack(side="left")

        # 2) CONTENT
        content_area = ttk.Frame(self, style="Main.TFrame")
        content_area.pack(fill="both", expand=True, padx=20, pady=20)

        # --- FORM KARTI ---
        form_card = self._create_card(content_area, title="Değişken Bilgileri")
        form_card.pack(fill="x", pady=(0, 20))

        form_grid = ttk.Frame(form_card, style="Card.TFrame")
        form_grid.pack(fill="x", padx=15, pady=10)

        # SADE FORM: label, value(float), description
        self.label_var = tk.StringVar()
        self.value_var = tk.StringVar()
        self.desc_var = tk.StringVar()

        self.ent_label = self._create_modern_input(
            form_grid, "Değişken Adı *", self.label_var, 0, 0, width=40
        )
        self.ent_value = self._create_modern_input(
            form_grid, "Deger *", self.value_var, 0, 1, width=20
        )
        self._create_modern_input(
            form_grid,
            "Açıklama / Notlar",
            self.desc_var,
            1,
            0,
            colspan=2,
            width=72,
        )

        # Değer girişini sayısal filtre (yazarken)
        vcmd = (self.register(self._validate_numeric_typing), "%P")
        self.ent_value.configure(validate="key", validatecommand=vcmd)

        # Action bar
        action_bar = ttk.Frame(form_card, style="Card.TFrame")
        action_bar.pack(fill="x", padx=15, pady=(0, 15))

        self.status_lbl = tk.Label(
            action_bar, text="", bg="white", fg=self.colors["success"], font=("Segoe UI", 9, "bold")
        )
        self.status_lbl.pack(side="left")

        self.btn_save = ttk.Button(
            action_bar, text="Ekle", style="Primary.TButton", command=self.upsert_from_form
        )
        self.btn_save.pack(side="right", padx=(5, 0))

        ttk.Button(
            action_bar, text="Yeni / Temizle", style="Secondary.TButton", command=self.clear_form
        ).pack(side="right")

        # --- TABLO KARTI ---
        border_frame = tk.Frame(content_area, bg=self.colors["border"], padx=1, pady=1)
        border_frame.pack(fill="both", expand=True)

        inner_table_frame = ttk.Frame(border_frame, style="Card.TFrame")
        inner_table_frame.pack(fill="both", expand=True)

        # Toolbar
        toolbar = ttk.Frame(inner_table_frame, style="Card.TFrame")
        toolbar.pack(fill="x", padx=15, pady=15)

        ttk.Label(
            toolbar, text="İşlemler:", background="white", foreground=self.colors["text_dark"]
        ).pack(side="left", padx=(0, 5))

        self.bulk_action_var = tk.StringVar()
        ttk.Combobox(
            toolbar,
            textvariable=self.bulk_action_var,
            values=["Seçilenleri Sil"],
            width=15,
            state="readonly",
        ).pack(side="left")

        apply_btn = tk.Button(
            toolbar,
            text="Uygula",
            bg=self.colors["primary"],
            fg="white",
            relief="flat",
            padx=10,
            command=self.apply_bulk_action,
        )
        apply_btn.pack(side="left", padx=5)

        ttk.Button(
            toolbar, text="Yenile", style="Secondary.TButton", command=self.refresh_table
        ).pack(side="right")

        # Treeview
        cols = ("label", "value", "description")
        self.tree = ttk.Treeview(
            inner_table_frame, columns=cols, show="headings", height=10, selectmode="browse"
        )

        vsb = ttk.Scrollbar(inner_table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        self.tree.heading("label", text="Değişken")
        self.tree.heading("value", text="Değer")
        self.tree.heading("description", text="Açıklama")

        self.tree.column("label", width=260, anchor="w")
        self.tree.column("value", width=140, anchor="e")
        self.tree.column("description", width=420, anchor="w")

        self.tree.pack(side="left", fill="both", expand=True, padx=(1, 0), pady=(0, 1))
        vsb.pack(side="right", fill="y", pady=(0, 1))

        self.tree.bind("<<TreeviewSelect>>", self.on_select)

    def _create_card(self, parent, title):
        border = tk.Frame(parent, bg=self.colors["border"], padx=1, pady=1)
        card = ttk.Frame(border, style="Card.TFrame")
        card.pack(fill="both", expand=True)

        title_lbl = ttk.Label(
            card,
            text=title,
            font=("Segoe UI", 10, "bold"),
            foreground=self.colors["primary"],
            background="white",
        )
        title_lbl.pack(anchor="w", padx=15, pady=(15, 5))

        sep = ttk.Separator(card, orient="horizontal")
        sep.pack(fill="x", padx=15, pady=(0, 5))
        return border

    def _create_modern_input(self, parent, label_text, var, row, col, width=20, colspan=1):
        f = ttk.Frame(parent, style="Card.TFrame")
        f.grid(row=row, column=col, padx=10, pady=10, sticky="w", columnspan=colspan)

        ttk.Label(f, text=label_text, style="FieldLabel.TLabel").pack(anchor="w")

        ent = ttk.Entry(f, textvariable=var, width=width, style="Modern.TEntry")
        ent.pack(anchor="w", pady=(2, 0), ipady=3)
        return ent

    # ---------- Numeric helpers ----------
    def _validate_numeric_typing(self, proposed: str) -> bool:
        """
        Kullanıcı yazarken izin ver:
          - boş
          - 12
          - 12.3
          - 12,3 (sonradan float'a çevireceğiz)
          - -12.3
        """
        if proposed == "" or proposed == "-" or proposed == "." or proposed == ",":
            return True
        proposed = proposed.replace(",", ".")
        try:
            float(proposed)
            return True
        except Exception:
            return False

    def _cast_value_float(self, raw: str) -> float:
        raw = (raw or "").strip()
        if raw == "":
            return 0.0
        raw = raw.replace(",", ".")
        return float(raw)

    # ---------- Logic ----------
    def refresh_table(self):
        self.tree.delete(*self.tree.get_children())
        self.status_lbl.config(text="")

        try:
            self.vars_data = self.engine.load()
        except Exception as e:
            self.status_lbl.config(text=f"Hata: {e}", fg=self.colors["danger"])
            return

        for v in self.vars_data:
            self.tree.insert(
                "",
                "end",
                values=(
                    v.get("label", ""),
                    v.get("value", 0.0),
                    v.get("description", ""),
                ),
            )

    def on_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return

        val = self.tree.item(sel[0], "values")
        self.selected_label = val[0]

        self.label_var.set(val[0])
        self.value_var.set(str(val[1]))
        self.desc_var.set(val[2])

        self.btn_save.config(text="Güncelle")

    def clear_form(self):
        self.selected_label = None
        self.label_var.set("")
        self.value_var.set("")
        self.desc_var.set("")
        self.tree.selection_remove(self.tree.selection())
        self.btn_save.config(text="Ekle")
        self.status_lbl.config(text="")

        try:
            self.ent_label.focus_set()
        except Exception:
            pass

    def upsert_from_form(self):
        label = self.label_var.get().strip()
        if not label:
            messagebox.showwarning("Uyarı", "Değişken adı zorunludur.")
            return

        try:
            value = self._cast_value_float(self.value_var.get())
        except Exception:
            messagebox.showerror("Hata", "Değer sayısal olmalıdır.")
            return

        item = {
            "label": label,
            "value": value,
            "description": self.desc_var.get().strip(),
        }

        try:
            self.engine.upsert(item)
            self.refresh_table()
            self.status_lbl.config(text=f"✓ '{label}' kaydedildi.", fg=self.colors["success"])
            self.clear_form()
        except Exception as e:
            messagebox.showerror("Hata", str(e))

    def apply_bulk_action(self):
        if self.bulk_action_var.get() != "Seçilenleri Sil":
            messagebox.showinfo("Bilgi", "Bir işlem seçiniz.")
            return

        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Bilgi", "Önce bir kayıt seçin.")
            return

        label = self.tree.item(sel[0], "values")[0]
        if not messagebox.askyesno("Sil", f"'{label}' silinsin mi?"):
            return

        try:
            self.engine.delete(label)
            self.refresh_table()
            self.clear_form()
            self.status_lbl.config(text="✓ Kayıt silindi.", fg=self.colors["success"])
        except Exception as e:
            messagebox.showerror("Hata", str(e))
