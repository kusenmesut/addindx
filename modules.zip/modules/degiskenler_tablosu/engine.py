# modules/degiskenler_tablosu/engine.py
import os
import json
from datetime import datetime

from config import get_mukellefler_dir
from utils.session_db import get_last_session


class VariablesEngine:
    """
    Mükellef bazlı değişkenleri (kasa min tutar, faiz oranı vb.)
    MUKELLEFLER/<UNVAN-VKN>/degiskenler.json içinde saklar.

    Yeni model:
      - label (benzersiz)  -> Değişken adı
      - value (float)      -> Sayısal değer
      - description        -> Not/Açıklama
    """

    DEFAULT_VARIABLES = [
        {
            "label": "KasaMinimum",
            "value": 10000.0,
            "description": "KasaMinimum",
        },
        {
            "label": "FaizOrani",
            "value": 0.48,
            "description": "FaizOrani",
        },
    ]

    def __init__(self):
        self.session = get_last_session() or {}
        self.vkn = self.session.get("vkn")
        self.yil = self.session.get("yil")

    def _resolve_target_folder(self) -> str:
        """
        Klasör adları UNVAN-VKN formatında olduğu için listdir ile sonu -VKN biteni bulur.
        """
        if not self.vkn:
            raise ValueError("Aktif VKN bulunamadı (session_db).")

        base_dir = get_mukellefler_dir()
        target_folder = None
        for f in os.listdir(base_dir):
            if f.endswith(f"-{self.vkn}"):
                target_folder = os.path.join(base_dir, f)
                break

        if not target_folder:
            raise FileNotFoundError(f"Mükellef klasörü bulunamadı. VKN: {self.vkn}")

        return target_folder

    def _variables_path(self) -> str:
        folder = self._resolve_target_folder()
        return os.path.join(folder, "degiskenler.json")

    def load(self) -> list[dict]:
        """
        Değişkenleri dosyadan yükler. Dosya yoksa default seti oluşturur ve kaydeder.
        Eski format (liste veya key/type içeren) gelirse normalize eder.
        """
        path = self._variables_path()

        if not os.path.exists(path):
            data = self._with_meta(self.DEFAULT_VARIABLES)
            self._write_raw(data)
            return data["variables"]

        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)

        # Eski format: doğrudan liste ise
        if isinstance(raw, list):
            normalized = self._normalize_list(raw)
            data = self._with_meta(normalized)
            self._write_raw(data)
            return data["variables"]

        # Yeni format: {"meta":..., "variables":[...]}
        variables = raw.get("variables", [])
        normalized = self._normalize_list(variables)

        # normalize sonucu farklıysa dosyayı güncelle
        if normalized != variables:
            data = self._with_meta(normalized)
            self._write_raw(data)
            return data["variables"]

        return variables

    def save(self, variables: list[dict]) -> None:
        """
        UI'dan gelen tabloyu kaydeder (normalize ederek).
        """
        normalized = self._normalize_list(variables)
        data = self._with_meta(normalized)
        self._write_raw(data)

    def upsert(self, var_item: dict) -> None:
        """
        Tek bir değişken ekle/güncelle.
        Benzersiz anahtar: label
        """
        variables = self.load()

        label = (var_item.get("label") or "").strip()
        if not label:
            raise ValueError("Değişken adı (label) boş olamaz.")

        # value her zaman float olmalı
        value = var_item.get("value", 0.0)
        try:
            value = float(value)
        except Exception:
            raise ValueError("Değer (value) sayısal olmalıdır.")

        item = {
            "label": label,
            "value": value,
            "description": (var_item.get("description") or "").strip(),
        }

        found = False
        for i, v in enumerate(variables):
            if (v.get("label") or "").strip() == label:
                variables[i] = item
                found = True
                break

        if not found:
            variables.append(item)

        self.save(variables)

    def delete(self, label: str) -> None:
        variables = self.load()
        label = (label or "").strip()
        variables = [v for v in variables if (v.get("label") or "").strip() != label]
        self.save(variables)

    def get_value(self, label: str, default=0.0) -> float:
        """
        Analiz modülleri engine tarafında buradan okur.
        """
        label = (label or "").strip()
        for v in self.load():
            if (v.get("label") or "").strip() == label:
                try:
                    return float(v.get("value", default))
                except Exception:
                    return float(default)
        return float(default)

    # ----------------- Helpers -----------------

    def _normalize_list(self, items: list[dict]) -> list[dict]:
        """
        Eski kayıtları yeni modele çevirir.
        Eski: {"key","label","type","value","description"} -> Yeni: {"label","value","description"}
        """
        normalized = []
        seen = set()

        for it in items or []:
            if not isinstance(it, dict):
                continue

            # label yoksa key'i label olarak kullan
            label = (it.get("label") or it.get("key") or "").strip()
            if not label:
                continue

            # value her zaman float
            raw_val = it.get("value", 0.0)
            try:
                value = float(str(raw_val).strip().replace(",", "."))
            except Exception:
                value = 0.0

            desc = (it.get("description") or "").strip()

            # label benzersiz kalsın
            if label in seen:
                continue
            seen.add(label)

            normalized.append({"label": label, "value": value, "description": desc})

        # hiç yoksa defaultları döşe
        if not normalized:
            normalized = [dict(x) for x in self.DEFAULT_VARIABLES]

        return normalized

    def _with_meta(self, variables: list[dict]) -> dict:
        return {
            "meta": {
                "vkn": self.vkn,
                "yil": self.yil,
                "updated_at": datetime.now().isoformat(timespec="seconds"),
                "schema": "variables_v2_label_value_desc",
            },
            "variables": variables,
        }

    def _write_raw(self, data: dict) -> None:
        path = self._variables_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
