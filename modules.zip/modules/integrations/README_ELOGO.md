# eLogo fatura indirme bağlantısı

Bu entegrasyon, kullanıcının Microsoft Edge üzerinde manuel olarak açtığı eLogo oturumunu kullanır. Portal parolası/OTP otomatik doldurulmaz ve Entegratör Yönetimi veritabanına kaydedilmez. Kısa ömürlü portal AccessToken yalnızca indirme işi süresince bellekte tutulur.

## Klasör konumu

Bu klasör ana uygulamadaki `modules/` dizininin altında bulunmalıdır:

```text
modules/
  entegrator_yonetimi/
  integrations/
    invoice_import.py
    connectors/
      transport.py
      runtime.py
      providers/
        base.py
        elogo.py
```

Projeyi ana dizininden çalıştırın. Entegrasyon kullanıcıya özel ayrı bir uygulama başlatmaz; Entegratör Yönetimi sekmesindeki **Faturaları İndir** penceresinden başlatılır.

## İlk kurulum

1. Entegratör Yönetimi'nde aktif VKN için yeni hesap ekleyin ve sağlayıcıyı `eLogo` seçin.
2. Portal/Scraping etkin olmalıdır. eLogo portal kullanıcı adı/parolası bu uygulamada saklanmaz.
3. Mali Dönem sekmesinde `Portal / Scraping` ve saklama yöntemini seçin. `RAM + Klasör` için mevcut, yazılabilir bir klasör seçin.
4. Hesabı kaydedin ve listeden eLogo hesabını seçin.
5. **Faturaları İndir** düğmesine basın. Edge, VKN'ye özel kalıcı profil ile açılır. eLogo girişini, OTP/CAPTCHA varsa bunları kendiniz tamamlayın. İndirme bitene kadar Edge penceresini kapatmayın.

Varsayılan portal adresi kullanıcının doğruladığı canlı adres `https://efatura-d.elogo.com.tr/Account/LoginPage` olarak ayarlanmıştır. Gateway adresi, kullanıcı tarafından verilen rehberdeki `https://efatura-apigateway.elogo.com.tr` adresidir. Gateway ile gerçek portal Origin eşleşmesi gerçek Edge oturumunda doğrulanmalıdır.

## Desteklenen dört kanal

- Gelen e-Fatura
- Giden e-Fatura
- Giden e-Arşiv
- Gelen e-Arşiv (eLogo rehberindeki GİB İVD listesi üzerinden)

e-Fatura ve giden e-Arşiv tarih aralıkları aylık parçalar halinde; gelen e-Arşiv en fazla 7 günlük parçalar halinde sorgulanır. Sayfa boyutu 250'dir. XML indirmeleri sıralı yapılır. Bir belgenin indirilmesi başarısız olursa sonraki belgeye devam edilir.

## İçe aktarma

İndirilen Base64 UBL XML içerikleri mevcut `modules.fatura_yukle.parser.parse_single_invoice_content()` işlevine verilir. Yeni bir XML parser oluşturulmaz. Ayrıştırılan satırlar mevcut `faturayi_veritabanina_kaydet()` motoruna gönderilir ve aktif VKN/mali yıl fatura veritabanına kaydedilir. ETTN eşleşmesi ve XML içindeki satıcı/alıcı VKN'si kontrol edilir.

Entegratör durumları (`IPTAL`, `RED`, `ITIRAZ` vb.) `ENTEGRATOR_DURUMU`, `ENTEGRATOR_DURUM_ACIKLAMA`, `ENTEGRATOR_DURUM_DETAY` ve `HESABA_DAHIL` alanlarıyla kaydedilir. **Önemli:** Bu değişiklik durumları kayda taşır; mevcut bütün rapor ve analiz sorgularının `HESABA_DAHIL=1` filtresini kullanması bu paketin kapsamına henüz dahil değildir. İptal/red belgelerinin tüm rapor toplamlarından dışlanması için rapor sorgularında merkezi filtre ayrıca uygulanmalıdır.

## Kullanıcı durdurma ve hata yönetimi

- İndirme sırasında **Durdur** seçilirse o ana kadar tamamlanan XML belgeleri korunur ve mevcut parser'a aktarılır.
- Listeleme aşamasında durdurulursa liste tamamlanmadan indirme başlamaz.
- Her fatura için indirme ve parser hataları ayrı sayılır; tek bir belgenin hatası diğer belgeleri durdurmaz.
- Gelen e-Arşiv için ilk büyük indirme sonrasında eLogo portalındaki kontör bakiyesinin kontrol edilmesi önerilir.

## Güvenlik ve sınırlamalar

- Sadece Edge DevTools loopback adresi (`127.0.0.1`) kullanılır. DevTools dış ağa açılmaz.
- Giriş kullanıcı tarafından yapılır. Şifre, OTP, cookie, token ve HTTP yanıt gövdeleri loglanmaz.
- Yalnızca listeleme ve XML okuma/indirme uç noktaları kullanılır. Toplu e-posta indirme ve PostBox `GetDocument` / `GetDocumentDone` çağrıları kullanılmaz.
- Bu bağlantı, kullanıcının sağladığı ve çalışan olduğunu belirttiği eLogo portal rehberindeki belgelenmemiş portal gateway uç noktalarına dayanır. eLogo bu uç noktaları değiştirebilir; portal güncellemelerinden sonra kısa tarih aralığıyla yeniden doğrulayın.
- Bu geliştirme ortamında canlı eLogo hesabı/Edge oturumu bulunmadığı için gerçek portal testi yapılamadı. Oturum, CORS/Origin, gerçek yanıt şeması ve kontör davranışı kullanıcı bilgisayarında kısa testle doğrulanmalıdır.

## Teknik notlar

- eLogo indirme sağlayıcısı resmi PostBox SOAP bağlantısı değildir. Rehberdeki portal oturumundan alınan kısa ömürlü anahtarla kullanılan eLogo portal gateway uç noktalarına dayanır.
- eLogo için Playwright kullanılmaz. Microsoft Edge `--remote-debugging-port=0` ile başlatılır; `DevToolsActivePort` dosyasındaki port okunur ve CDP WebSocket bağlantısı yalnız loopback üzerinden kurulur. HTTP çağrıları uygulamanın `requests` tabanlı `HttpConnector` katmanından yapılır.
- Edge profili VKN bazında kalıcıdır: `%LOCALAPPDATA%\eDenetimPRO\eLogoProfiles\<VKN>`. Aynı VKN profili açık bulunursa mevcut oturuma bağlanılır. İş tamamlanınca rehberdeki gibi Edge kapatılır; profil klasörü silinmez.
- AccessToken yalnız provider nesnesinin belleğinde tutulur; 401 yanıtında portal içi token yenileme çağrısı yapılır ve salt-okunur istek bir kez tekrarlanır.
- Portal kullanıcısı/şifresi uygulama veritabanında saklanmaz. Giriş, OTP ve CAPTCHA etkileşimi kullanıcıya aittir.
- eLogo portal gateway uç noktaları belgelenmemiştir ve sağlayıcı tarafından değiştirilebilir. Bu nedenle ilk deneme 1–3 günlük dar bir dönemle yapılmalıdır. Portalın canlı Origin/Gateway uyumu ve gerçek yanıt alanları Windows bilgisayarında doğrulanmalıdır.
- e-Fatura için liste satırlarının çoğunluk VKN'si aktif mükellefle uyuşmazsa işlem güvenlik amacıyla durdurulur. İlk sürümde otomatik yanlış-mükellef aktarımına izin verilmez.
- İptal/red/itiraz alanları fatura kaydına yazılır. `HESABA_DAHIL` alanı durum bilgisini taşır; mevcut rapor ve analiz sorgularının tümünde bu alanla süzme henüz bu pakette uygulanmamıştır.

## İlk canlı test önerisi

1. eLogo hesabı için Portal/Scraping ve aktif mali dönem ayarını kaydedin.
2. Sadece **Gelen e-Fatura** kanalını seçin.
3. 1–3 günlük fatura tarihi aralığı kullanın.
4. Edge'de doğru mükellefle manuel oturum açın ve pencereyi kapatmayın.
5. Yeni kayıt sayısını, mükerrer sayısını ve hata listesini kontrol edin.
6. Fatura ekranında birkaç ETTN, belge tarihi ve VKN alanını eLogo portalındaki kayıtlarla karşılaştırın.
7. Bu test tamamlanmadan dört kanalı birlikte veya uzun tarih aralığını çalıştırmayın.
