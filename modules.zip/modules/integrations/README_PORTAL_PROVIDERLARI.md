# Portal entegratörleri — eLogo, Sovos/Fitbulut, NetBT, Mikro, Zirve

Bu paket, yüklenen `PORTAL_FATURA_CEKME_REHBERI.md` içindeki portal akışlarını e-DenetimPRO'nun mevcut ConnectorRunner + RAM import + parser + FATURALAR DB zincirine bağlar.

## Desteklenen gerçek portal adaptörleri

| Entegratör | Portal giriş adresi | Gelen e-Fatura | Giden e-Fatura | Giden e-Arşiv | Gelen e-Arşiv |
|---|---|---:|---:|---:|---:|
| eLogo | `https://efatura-d.elogo.com.tr/Account/LoginPage` (hesapta kayıtlı portal URL'si esas alınır) | ✓ | ✓ | ✓ | ✓ |
| Sovos / Fitbulut | `https://cloud.fitbulut.com/kullanici/giris` | ✓ | ✓ | ✓ | — |
| NetBT | `https://netbt.efaturaservis.com/portalv3/Login.aspx` | ✓ | ✓ | ✓ | — |
| Mikro e-Portal | `https://eportal.mikrogrup.com/` | ✓ | ✓ | ✓ | — |
| Zirve E-Dönüşüm | `https://portal.zirvedonusum.com/accounting/login` | ✓* | — | — | — |

`Zirve E-Dönüşüm` için adaptör, kullanıcının yüklediği `inbound_efatura_v0001.draft.json` keşif dosyasına göre eklenmiştir. Yalnız gelen e-Fatura kanalı desteklenir. Listeleme endpoint ve JSON alanları gözlenmiştir; indirme endpointi de HTTP 200 / ZIP yanıtıyla gözlenmiş olsa da indirme sorgusunun `records` ve `type` değerleri keşif raporunda maskelendiğinden canlı ortamda tek belgeyle doğrulama bekler (*).

`Foriba`, `EDM`, `Uyumsoft`, `Digital Planet` ve `QNB eFinans` seçenekleri eski hesap ayarlarının korunması için yönetim ekranında listelenmeye devam eder. Yüklenen portal rehberi bu markalar için ayrı bir portal akışı tanımlamadığından bunlar için gerçek listeleme adaptörü iddia edilmez. Rehberde Sovos/Fitbulut anlatımı vardır; Foriba'nın aynı portalı kullandığı varsayılmamıştır.

## Oturum / güvenlik modeli

- Portal kullanıcı adı, parola, OTP, CAPTCHA veya Cloudflare doğrulaması otomatik doldurulmaz/aşılmaz. Kullanıcı Edge penceresinde kendisi oturum açar.
- Portal token/cookie/yanıt verileri loga veya `datanet/entegrator.db` içine yazılmaz; işlem belleğinde kullanılır. Zirve Bearer anahtarını Edge sayfasının localStorage/sessionStorage alanlarından yalnızca çalışma anında bulur ve aynı portalın `/accounting/api/user/me` okuma uç noktasıyla doğrular; token Python tarafına veya diske çıkarılmaz.
- Profil dizini VKN + portal ayrıdır: `%LOCALAPPDATA%\\eDenetimPRO\\PortalProfiles\\<provider>\\<VKN>`.
- DevTools yalnız loopback `127.0.0.1`/localhost üzerinde çalışır.
- Portal iş akışları salt-okunur listeleme ve XML indirmedir. `setRead`, arşivle, yanıt gönder, iptal etme veya PostBox `GetDocumentDone` çağrıları yapılmaz.
- İstekler sıralı ve aralıklı yürütülür; NetBT rapor sayfalarında XHR sakinleşmesi beklenir.

## Portal parametreleri


### Zirve E-Dönüşüm (keşif dosyasına dayalı adaptör)

- Kaynak kanıt: `connectors/providers/protocols/zirve/drafts/inbound_efatura_v0001.draft.json`. Kaynak dosya değiştirilmeden arşivlenir; uygulama tanımı `definitions/zirve.json` içindedir.
- Portal: `portal.zirvedonusum.com`; giriş Edge üzerinde kullanıcı tarafından yapılır. Giriş bilgileri ve token saklanmaz.
- Kimlik doğrulama: gözlenen `Bearer` şeması kullanılır. Token anahtarı adı kaynak JSON'da yer almadığından adaptör, yalnızca token/JWT/authorization benzeri localStorage/sessionStorage kayıtlarını bellekte tarar ve her çağrıdan önce `GET /accounting/api/user/me` ile doğrular. Token bulunamazsa istek durdurulur.
- Gelen e-Fatura listesi: `GET /accounting/api/inbox/getInboxes`; gözlenen sorgu alanları `year`, `month`, `page`, `size`, `isArchive` ve diğer filtre adlarıdır. Adaptör ay/yıl bazlı sayfalama yapar ve kullanıcının tarih aralığına uymayan satırları istemci tarafında eler. Sayfa indeksi sıfırdan başlatılır; bu Spring Pageable yanıtından çıkarılmış ve canlı ortamda yeniden kontrol edilmesi gereken bir varsayımdır.
- Liste satırları `recordId`, `documentUuid`, `documentId`, `sourceTitle`, `sourceId`, `documentIssueDate`, `invoiceTotal`, `taxInclusiveAmount`, `currencyCode` ve `invoiceTypeCode` alanlarından normalize edilir.
- XML indirme: gözlenen uç `POST /accounting/api/inbox/downloadSelected`; gözlenen query alanları `year`, `month`, `records`, `type`; örnek HTTP yanıtı `application/zip` ve 200'dür. Gizlilik temizliği nedeniyle kaynak raporda query değerleri yoktur. Bu nedenle ilk adaptör tek kayıt ve `type=XML` varsayımıyla deneme yapar. Portal bu çağrıyı reddederse entegratör başarılı gösterilmez; canlı trafik keşfiyle gerçek `records/type` değerleri alınmalıdır.
- İndirilen ZIP içindeki UBL XML, ETTN/fatura numarasıyla eşleştirilir. Tek belge eşleşmiyorsa içe aktarma durdurulur. Binary/ZIP XML parser dışında yeni bir ayrıştırıcı üretilmez.
- `cancelPortalStatus` alanı gözlenmiştir ancak kod anlamları kaynak dosyada yoktur. Bu nedenle adaptör bilinmeyen sayısal kodları iptal/ret saymaz; durum eşlemesi canlı kanıta kadar açık tutulur.
- Bu adaptör yalnız gelen e-Fatura içindir. Giden e-Fatura ve e-Arşiv kanalları tanımlı değildir.

### Sovos / Fitbulut

- Oturum anahtarı portal `localStorage.token` alanından alınır; `Authorization` başlığına doğrudan konur, `Bearer` eklenmez.
- İstekler `cloudapi.fitbulut.com/v1` uçlarına Edge sayfası içinden `fetch` ile gönderilir. Doğrudan HTTP istemcisinin 401 döndürmesi nedeniyle bu yöntem kullanılır.
- e-Fatura listesi `invoice/getInvoiceListByParameters`, `direction=inbound|outbound`, `dateType=issue`, `startDate`, `endDate`, `offset`, `limit=200`.
- Her e-Fatura sorgusunda `isArchived=0` ve `isArchived=1` ayrı çağrılır.
- Tarih aralığı en fazla 93 takvim günü olacak şekilde parçalanır; sayfalama `offset` ile yapılır.
- Giden e-Arşiv `archive/getInvoiceListByParameters` üzerinden listelenir.
- e-Fatura XML `invoice/getInvoiceDocumentByUUID`; giden e-Arşiv XML `archive/getInvoiceDocumentByUUID`; her indirme paketi en fazla 50 UUID içerir.
- `StatusCodeDesc` RED, `CancelStatusId`/`IsCancelled` iptal, `IsObjectioned` itiraz olarak işaretlenir.

### NetBT

- Portal eski ASP.NET + Ext.NET arayüzüdür. Adaptör raporları görünür Edge sayfasının gizli iframe'lerinde açar; portalın Ext grid/store ve kendi XML indirme işlevlerini kullanır.
- Raporlar: `InboundReport.aspx`, `OutboundReport.aspx`, `OutboundArchiveReport.aspx`.
- Tarih filtreleri `dfInvoiceDateStart` / `dfInvoiceDateEnd`; sayfalama store `loadPage` üzerinden yapılır. 1000'den fazla kayıt varsa tüm sayfalar gezilir.
- Gelen e-Fatura `btnBatchXmlDownload`, giden e-Fatura `Button1`, giden e-Arşiv `DownloadFile(0)` + `DownloadSavedFile` akışıyla indirilir.
- ZIP/form indirmeleri Edge içinde yakalanır; XML dış diske çıkarılmaz.
- Giden e-Arşiv XML'indeki fatura numarası seçilen satırla eşleştirilir. Uyuşmazlık halinde belge içe aktarılmaz.
- `MarkIsCancelled` / `CancelStatus` iptal; `AcceptStatusText` RED durumudur.

### Mikro e-Portal

- Giriş sonrası URL'den `/cp/<firma GUID>/` yolu alınır. Listeleme ve indirme çağrıları o firma yolu altında Edge sayfası içinden yapılır.
- Gelen e-Fatura `inbox/GetIncomingInvoiceList`, giden e-Fatura `outbox/GetSubmittedInvoiceList`, giden e-Arşiv `EArchive/GetEArchiveList`.
- Sayfa başına 500 kayıt; `pagination.totalPage` kadar sayfalanır.
- e-Arşiv sorgusunda rehberde özellikle belirtilen `state` ve `invoiceProfilesFilter` parametreleri gönderilmez; `eArchiveState=Hepsi` ve `status=All` kullanılır.
- XML ZIP indirmeleri 100 ID'lik paketlerle `DownloadXmlFilesZip` / `DownloadXmlFilesZipParallel` üzerinden yapılır.
- `CancelationDate` iptal; `ObjectionState.Code` itiraz; `State.Description` RED durumudur.

## Ortak RAM → mevcut DB aktarımı

1. ConnectorRunner portal listesini alır ve UBL XML içeriklerini RAM'de tutar (`force_ram=True`).
2. Her XML doğrudan mevcut `modules.fatura_yukle.parser.parse_single_invoice_content()` fonksiyonuna verilir.
3. Parser satırları mevcut `faturayi_veritabanina_kaydet()` işleviyle aktif VKN + mali yılın `FATURALAR` tablosuna yazılır. Yeni parser veya ayrı fatura DB'si oluşturulmaz.
4. ETTN, XML'in kendi UUID'siyle karşılaştırılır; gelen belgelerde alıcı VKN, gidenlerde satıcı VKN seçili mükellefle kontrol edilir.
5. `IPTAL` için mevcut `toplu_fatura_iptal_et()` çağrılır; `IPTAL_ETTN_LISTESI` ve `TIP_FATURA` üzerindeki ` - IPTAL` işareti oluşturulur.
6. `RED` ve `ITIRAZ` kayıtları `HESABA_DAHIL=0` olur. eLogo rehberinde `ITIRAZ_REDDEDILDI` için faturanın geçerli olduğu açıkça belirtildiğinden, bu durum `HESABA_DAHIL=1` kalır.
7. Daha sonraki sorguda durum değişirse ETTN satırının durum alanları güncellenir. `IPTAL` dışındaki güncel durumlarda eski iptal havuzu kaydı ve ` - IPTAL` soneki kaldırılır.

Durum sütunları: `ENTEGRATOR_DURUMU`, `ENTEGRATOR_DURUM_ACIKLAMA`, `ENTEGRATOR_DURUM_DETAY`, `HESABA_DAHIL`, `KAYNAK_ENTEGRATOR`, `KAYNAK_BELGE_KANALI`, `BELGE_AILESI`, `BELGE_YONU`.

**Raporlama notu:** Bu paket `HESABA_DAHIL` alanını doğru durumla günceller. Uygulamadaki her rapor/sorgu girişinin bu alanı merkezi olarak filtrelemesi ayrıca yapılmalıdır; bu pakette tüm rapor SQL'lerinin merkezi olarak değiştirilmiş olduğu iddia edilmez.

## Test kapsamı ve sınırlar

- Derleme, provider kayıt çözümleme, sahte Edge/CDP yanıtlarıyla listeleme/indirme, tarih parametreleri, sayfalama parametreleri, XML/ZIP çözme, ETTN eşleme ve DB durum geçişi testleri yapılmıştır. Zirve için ayrıca sahte Edge yanıtlarıyla alan adı eşleşmesi, bearer oturum doğrulama akışı, gelen e-Fatura listeleme, tek XML ZIP çıkarma ve kanal kısıtları test edilmiştir.
- Bu geliştirme ortamında gerçek Sovos, NetBT, Mikro ve Zirve kullanıcı hesabı/Edge oturumu bulunmadığından canlı portal oturumu ve canlı listeleme/indirme testi yapılmamıştır. Zirve indirme query değerleri kaynak taslaktan maskeli geldiği için canlı tek-belge testi özellikle zorunludur. Gerçek portal yanıt alanları/iframe grid yapısı portal tarafında değişmiş olabilir.
- İlk kullanıcı testi portal başına kısa 1–3 günlük tarih aralığı ve tek fatura türüyle yapılmalı; portalda görülen toplam kayıt sayısı ile test penceresindeki sayı karşılaştırılmalıdır.
- NetBT'nin rapor grid alanları rehberde tam listelenmediğinden adaptör beklenmeyen grid yapısında güvenli biçimde hata verir; yanlış XML'i DB'ye yazmamak için eşleşme kontrolü başarısızsa aktarım atlanır.
- Gelen e-Arşiv bu kaynak rehberde yalnız eLogo için tanımlıdır. Sovos, NetBT ve Mikro'da bu seçimler test penceresinde kapalıdır.

## Sürümlü entegratör tanım motoru

Portal ayarları artık yalnızca UI içinde sabit if/else kurallarıyla tanımlanmaz. `connectors/providers/definitions/*.json` altındaki sürümlü manifestler ortak kaynaktır. Her manifest şu bilgileri taşır:

- `provider_code`, `display_name`, `aliases`, `definition_version`
- `auth_methods`, `default_method`, portal giriş URL'si ve izinli hostlar
- desteklenen belge kanalları
- liste/indirme endpoint'leri, sayfa boyutu, tarih aralığı ve paket sınırları
- portalın listeleme sorgusu için varsayılan parametreleri
- durum alanlarının hangi iş anlamına geldiği
- API/portal alanlarının dinamik form şeması (`fields.api`, `fields.portal`)

`EntegratorEngine.list_provider_definitions()` ve `get_provider_definition()` bu katalogu okur. Kullanıcının eklediği tanımlar `datanet/entegrator.db` içindeki `integrator_provider_definitions` tablosuna kaydedilir. Dinamik hesap alanları, keşiften üretilen manifest üzerinden hazırlanır.

### Otomatik protokol keşfi

Entegratör Yönetimi ekranındaki **Otomatik Protokol Keşfi** akışı iki katmanlıdır:

1. Kullanıcı yalnızca HTTPS portal/API ana adresini girebilir; entegratör adı isteğe bağlıdır. `connectors/discovery.py`, alan adını yerleşik ve uygulama DB kataloğundaki entegratörlerle eşleştirir; bilinmeyen adları alan adından üretir. Ardından standart OpenAPI, Swagger ve WSDL tanım adreslerini salt-okunur GET istekleriyle kontrol eder. Bir tanım bulunursa API sunucuları, endpoint'ler, HTTP metotları, güvenlik şemaları, parametre adları, tarih ve sayfalama alanları, istek/yanıt içerik türleri ve OpenAPI şema referanslarından türetilen gövde alanlarının ad/tip envanteri çıkarılır. Yerleşik katalogdaki alan adları ve API gateway hostlarıyla eşleşme de otomatik yapılır; eşleşen entegratör tekrar oluşturulmaz.
2. Yayınlanmış API tanımı yoksa **Girişli Portal Trafiğinden Keşfet** seçeneği aynı ekrandan yönetici tarayıcı aracını açar. Kullanıcı portalda kendisi giriş yapar; fatura liste ekranı, tarih filtreleri, sayfalama ve örnek indirme akışlarını normal biçimde kullanır. Tarayıcı gözlemcisi aynı portal XHR/fetch isteklerinde query/body alan adlarını ve JSON yanıt alanlarının veri türlerini analiz eder. Authorization başlığının Bearer/Basic gibi şeması, API-key/CSRF başlık adları ve cookie oturumunun varlığı/isimleri yalnızca gösterge olarak çıkarılır; başlık, cookie, token veya form değerleri kaydedilmez. Gerçek alan değerleri, VKN/fatura içeriği, parola ve OTP protokol raporuna yazılmaz.
3. Beş yerel uzman kuralı DOM/listeme, iş akışı, indirme, oturum ve güvenlik kanıtlarını değerlendirir. Bulunan endpoint ve alan envanteri sürümlü protokol taslağına, oradan da katalog tanımına aktarılabilir.

Otomatik keşif, yalnızca internette bilinen doküman adreslerini aramakla sınırlı değildir; oturum açılmış portalın fiilen kullandığı isteklerden de protokol alanlarını öğrenir. Ancak kullanıcı portalda ilgili fatura ekranlarını/filtreleri/sayfalama ve indirme akışlarını gezdirmeden sistem her kanalın parametresini çıkaramaz. WebSocket kare içerikleri, binary RPC gövdeleri ve özel SSO imza akışları bu sürümde otomatik çözümlenmez. Dokümansız ve farklı bir kimlik doğrulama/işlem protokolü kullanan bir portalda ek insan doğrulaması gerekir.

**Önemli:** Keşfedilen tanım `implementation_available=false` ve çalıştırılamaz taslak olarak kaydedilir. Endpoint ve şema tespiti, o portalın fatura çekme adaptörünün tamamlandığı anlamına gelmez. Gerçek listeleme için `connectors/providers/<provider>.py` içinde protokole özgü adapter sınıfı, güvenlik/host kontrolleri, salt-okunur örnek çağrı ve belge eşlemesi testleri gerekir. Tanımı olup adaptörü olmayan EDM/Foriba/Uyumsoft/Digital Planet/QNB seçenekleri çalışır entegratör gibi gösterilmez. Yerleşik manifestler kullanıcı tanımlarıyla ezilemez.

Runtime, kaydedilmiş hesapla aynı `provider_code` ve `definition_version` tanımını birleştirerek adaptöre `provider_definition`, `provider_request_profile` ve `provider_status_mapping` olarak verir. Mevcut eLogo, Sovos, NetBT ve Mikro adaptörleri yerleşik parametre profillerini kullanmaya devam eder.
