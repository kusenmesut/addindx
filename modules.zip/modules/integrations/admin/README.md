# Yönetici Scrape Protokol Hazırlayıcı

Bu araç yalnızca yönetici/geliştirme ortamında çalıştırılır. Son kullanıcı menüsüne eklenmez.

## eLogo profili

Yönetici, `https://efatura-d.elogo.com.tr` adresinin gerçek/canlı portal olduğunu doğruladı. İlk açılış profili doğrudan Gelen e-Fatura listesine gider:

`https://efatura-d.elogo.com.tr/Invoice/EInvoiceIncomingList`

Host adındaki `-d` bölümü tek başına test ortamı göstergesi olarak yorumlanmaz.

## Çalıştırma

Proje kök dizininden iki yöntem de desteklenir:

```powershell
python -m modules.integrations.admin.scrape_preparer
```

veya

```powershell
python modules/integrations/admin/scrape_preparer.py
```

## Canlı tarayıcı -> hazırlayıcı veri akışı

Tarayıcı sayfası açıldığında aynı portal origin'indeki sayfa/frame'lere olay gözlemcisi kurulur. Gözlemci yalnızca güvenli yapısal metaveri gönderir; bir olay geldiğinde `BrowserWorker` kısa debounce sonrasında sayfanın DOM/parametre keşfini yeniden çalıştırır, beş uzmanı tekrar analiz eder ve güncel raporu UI olay kuyruğuna gönderir.

Dinlenen olaylar:

- DOM MutationObserver: yeni/silinen öğeler, metin ve izin verilen nitelik değişimleri.
- Filtre etkileşimleri: `input` / `change`; yalnızca alanın adı/kimliği/etiket tanımı, alan değeri değil.
- Kullanıcı tıklamaları: kontrol türü ve tanımlayıcı metaverisi; tıklanan satır/fatura verisi değil.
- Scroll durması: sanal liste ve lazy-load edilen satırları yakalamak için.
- SPA `pushState` / `replaceState`, `popstate`, `hashchange` ve `pageshow`.
- Frame/iframe navigasyonu, yeni sekme/pencere ve sayfa kapanması.
- Aynı portal hostundaki XHR/fetch yanıt ve başarısız istek metaverisi; URL query/hash temizlenir.
- Aynı portal hostundaki WebSocket açılış/kapanış ve yalnızca alınan frame sayısı; frame içeriği okunmaz.
- Yönetici tarayıcıda örnek belgeyi elle indirdiğinde gerçek Playwright download olayı.
- Kaçırılan olaylara karşı 9 saniyelik salt-okunur uzlaştırma taraması.

DOM/etkileşim sinyalleri yaklaşık 650 ms tarayıcı tarafı debounce, 850 ms worker debounce ve en az 1,35 saniye yeniden keşif aralığı ile birleştirilir. Çok hızlı değişiklikler tek keşifte birleştirilir. Periyodik uzlaştırma 9 saniyede bir yapılır; fark yoksa yeni rapor üretmez.

Her canlı değişiklikte önceki seçici doğrulaması geçersiz olur. UI'deki DOM öğe ağacı, beş uzman analizi, canlı durum etiketi ve işlem günlüğü güncellenir. Protokol tekrar `DRAFT` ve `executable=false` kalır.

## Gizlilik / kapsam

- Parola, OTP, input/textarea alanlarının güncel değerleri, cookie, token, localStorage/sessionStorage, kimlik doğrulama başlıkları ve request/response gövdeleri kaydedilmez. Parametre keşfi için select seçeneklerinin görünen etiketleri ve option değerleri alınabilir; kullanıcının seçimi yalnızca etiket olarak raporlanır.
- Üçüncü taraf origin'lerdeki iframe DOM'u incelenmez. Yalnızca profilin izin verilen portal hostu izlenir.
- Ağ izleme yalnızca URL'nin query/hash temizlenmiş yolu, metot, kaynak türü, HTTP durumu ve content-type gibi sınırlı metaveriyi kaydeder.
- Satır örnekleri varsayılan olarak kapalıdır. Açılırsa VKN/TCKN, e-posta, IBAN, telefon, ETTN ve yaygın fatura numarası biçimleri maskelenir; tutar veya diğer ticari bilgiler kalabileceğinden raporu kaydederken ayrıca onay istenir.
- Ekran görüntüsü kişisel/ticari veri içerebilir; kaydetmeden önce uyarı gösterilir.
- Motor portalda onay, iptal, gönderme, silme veya kaydetme gibi durum değiştirici işlemleri otomatikleştirmez.
- Kullanıcı portal girişini kendisi tamamlar; oturum profili yerel bilgisayarda kalır ve protokol paketine dahil edilmez.

## eLogo Gelen e-Fatura taslağı

`connectors/providers/protocols/elogo/drafts/inbound_efatura_v0003.draft.json`

CSS seçicileri, gerçek indirme kontrolü ve parser doğrulaması gözlenmeden taslak çalıştırılabilir hale gelmez.


## eLogo indirme altyapısı (yönetici protokol hazırlayıcıdan ayrı)

- `connectors/transport.py`: `EdgeDevToolsConnector` ile mükellef VKN'sine özel kalıcı Edge profili, 127.0.0.1 DevTools, manuel giriş bekleme ve RAM'de PortalRefreshToken alma.
- `connectors/providers/elogo.py`: Rehberdeki dört salt-okunur listeleme ve UBL XML indirme akışı.
- `connectors/runtime.py`: sıralı indirme, saklama ve belge bazlı hata raporlama.
- `invoice_import.py`: indirilen UBL içeriklerini mevcut parser ve fatura veritabanı kayıt fonksiyonuna aktarır.

eLogo portal parolası Entegratör Yönetimi veritabanına kaydedilmez. Kullanıcı Edge'de kendisi giriş yapar. Erişim tokenı yalnızca işlem belleğinde tutulur.
