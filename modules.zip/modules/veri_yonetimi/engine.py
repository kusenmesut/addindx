import os
import shutil
import sqlite3
from config import get_mukellefler_dir, get_base_dir

def get_db_path():
    """Ana dizindeki notes.db yolunu döndürür"""
    return os.path.join(get_base_dir(), "notes.db")

def agac_yapisini_getir():
    """
    MUKELLEFLER klasörünü tarar ve hiyerarşik veri döndürür.
    Çıktı Formatı: { 'Unvan-VKN': { '2024': ['01', '02'], '2023': ['12'] } }
    """
    root_dir = get_mukellefler_dir()
    data = {}
    
    if not os.path.exists(root_dir):
        return {}

    # Mükellef Klasörleri
    for muk_dir in os.listdir(root_dir):
        muk_path = os.path.join(root_dir, muk_dir)
        if os.path.isdir(muk_path) and "-" in muk_dir: # Basit validasyon
            data[muk_dir] = {}
            
            # Yıl Klasörleri
            for yil_dir in os.listdir(muk_path):
                yil_path = os.path.join(muk_path, yil_dir)
                if os.path.isdir(yil_path) and yil_dir.isdigit() and len(yil_dir) == 4:
                    data[muk_dir][yil_dir] = []
                    
                    # Ay Klasörleri
                    for ay_dir in os.listdir(yil_path):
                        ay_path = os.path.join(yil_path, ay_dir)
                        if os.path.isdir(ay_path) and ay_dir.isdigit() and len(ay_dir) == 2:
                            data[muk_dir][yil_dir].append(ay_dir)
                    
                    # Ayları sırala
                    data[muk_dir][yil_dir].sort()
    return data

def klasor_sil(yol):
    """Verilen yolu ve altındakileri kalıcı olarak siler."""
    try:
        if os.path.exists(yol):
            shutil.rmtree(yol)
            return True, "Klasör başarıyla silindi."
        return False, "Klasör bulunamadı."
    except Exception as e:
        return False, f"Silme hatası: {e}"

def notlari_sil_db(vkn):
    """
    Veritabanından (notes.db) belirtilen VKN'ye ait TÜM notları siler.
    """
    db_path = get_db_path()
    if not os.path.exists(db_path):
        return False, "Veritabanı bulunamadı."

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Kaç kayıt olduğunu öğren (Bilgi amaçlı)
        cursor.execute("SELECT count(*) FROM risk_notes WHERE vkn=?", (vkn,))
        count = cursor.fetchone()[0]
        
        if count > 0:
            cursor.execute("DELETE FROM risk_notes WHERE vkn=?", (vkn,))
            conn.commit()
            conn.close()
            return True, f"{count} adet not silindi."
        else:
            conn.close()
            return True, "Silinecek not bulunamadı."
            
    except Exception as e:
        return False, f"DB Hatası: {e}"