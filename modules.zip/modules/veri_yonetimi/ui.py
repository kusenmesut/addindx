import tkinter as tk
from tkinter import ttk, messagebox
import os
from config import CLR_BODY_BG, CLR_ACCENT, get_mukellefler_dir
from .engine import agac_yapisini_getir, klasor_sil, notlari_sil_db

class VeriYonetimiFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=CLR_BODY_BG)
        self.master = master
        self.secili_yol = None
        self.secili_tip = None # 'mukellef', 'yil', 'ay'
        self.secili_vkn = None
        self.secili_baslik = ""
        
        self.setup_ui()
        self.refresh_tree()

    def setup_ui(self):
        # --- BAŞLIK ---
        header = tk.Frame(self, bg=CLR_BODY_BG)
        header.pack(fill=tk.X, padx=20, pady=20)
        
        tk.Label(header, text="🗂️ MÜKELLEF VE DEFTER YÖNETİMİ", 
                 font=("Segoe UI", 16, "bold"), bg=CLR_BODY_BG, fg="#2d3436").pack(side=tk.LEFT)
        
        tk.Button(header, text="🔄 YENİLE", command=self.refresh_tree,
                  bg="#0984e3", fg="white", font=("Segoe UI", 9, "bold"), bd=0, padx=15, pady=5, cursor="hand2").pack(side=tk.RIGHT)

        # --- ANA GÖVDE (PANED WINDOW) ---
        paned = tk.PanedWindow(self, orient=tk.HORIZONTAL, bg=CLR_BODY_BG, sashwidth=4)
        paned.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 20))

        # SOL PANEL: TREEVIEW (AĞAÇ)
        left_frame = tk.Frame(paned, bg="white", bd=1, relief="solid")
        paned.add(left_frame, width=450)

        # Treeview Scrollbar
        scroll_y = ttk.Scrollbar(left_frame, orient="vertical")
        
        self.tree = ttk.Treeview(left_frame, selectmode="browse", show="tree", yscrollcommand=scroll_y.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scroll_y.config(command=self.tree.yview)
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        # SAĞ PANEL: DETAY VE İŞLEMLER
        right_frame = tk.Frame(paned, bg=CLR_BODY_BG, padx=20)
        paned.add(right_frame)

        # Bilgi Başlığı
        self.lbl_info_header = tk.Label(right_frame, text="Seçim Yapılmadı", 
                                        font=("Segoe UI", 14, "bold"), bg=CLR_BODY_BG, fg="#636e72")
        self.lbl_info_header.pack(anchor="w", pady=(20, 10))

        # Bilgi Kutusu
        self.info_box = tk.Label(right_frame, text="Lütfen soldaki listeden silmek istediğiniz Mükellef, Yıl veya Dönemi seçin.", 
                                 font=("Consolas", 10), bg="white", fg="#2d3436", justify="left", 
                                 anchor="nw", relief="solid", bd=1, padx=15, pady=15)
        self.info_box.pack(fill=tk.BOTH, expand=True, pady=(0, 20))

        # Butonlar Alanı
        btn_frame = tk.Frame(right_frame, bg=CLR_BODY_BG)
        btn_frame.pack(fill=tk.X, anchor="s")

        # TEK SİLME BUTONU
        self.btn_delete = tk.Button(btn_frame, text="🗑️ SEÇİLİ ÖĞEYİ SİL", 
                                    command=self.delete_action, state=tk.DISABLED,
                                    bg="#d63031", fg="white", font=("Segoe UI", 11, "bold"), 
                                    pady=15, bd=0, cursor="hand2")
        self.btn_delete.pack(fill=tk.X, pady=5)

    def refresh_tree(self):
        # Ağacı Temizle
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        data = agac_yapisini_getir()
        
        # İkonlar
        ICON_MUK = "👤 "
        ICON_YIL = "📅 "
        ICON_AY = "📂 "

        for muk_dir, yillar in data.items():
            # Mükellef Node
            muk_node = self.tree.insert("", "end", text=f"{ICON_MUK}{muk_dir}", values=("mukellef", muk_dir), open=False)
            
            for yil, aylar in yillar.items():
                # Yıl Node
                yil_node = self.tree.insert(muk_node, "end", text=f"{ICON_YIL}{yil}", values=("yil", yil))
                
                for ay in aylar:
                    # Ay Node
                    self.tree.insert(yil_node, "end", text=f"{ICON_AY}{ay}. Dönem", values=("ay", ay))

    def on_select(self, event):
        selected_id = self.tree.selection()
        if not selected_id: return

        item = self.tree.item(selected_id)
        text = item['text']
        
        # Değerleri String'e çevir (Hata düzeltmesi)
        tip = str(item['values'][0]) 
        val = str(item['values'][1]) 
        
        self.secili_tip = tip
        self.secili_baslik = text
        
        # Yol ve VKN Hesaplama
        full_path = ""
        vkn = ""
        
        try:
            if tip == "mukellef":
                full_path = os.path.join(get_mukellefler_dir(), val)
                vkn = val.split('-')[-1]
                
            elif tip == "yil":
                parent = self.tree.item(self.tree.parent(selected_id))
                muk_dir = str(parent['values'][1]) 
                full_path = os.path.join(get_mukellefler_dir(), muk_dir, val)
                vkn = muk_dir.split('-')[-1]
                
            elif tip == "ay":
                parent_yil = self.tree.item(self.tree.parent(selected_id))
                parent_muk = self.tree.item(self.tree.parent(self.tree.parent(selected_id)))
                
                muk_dir = str(parent_muk['values'][1])
                yil = str(parent_yil['values'][1])
                
                full_path = os.path.join(get_mukellefler_dir(), muk_dir, yil, val)
                vkn = muk_dir.split('-')[-1]
        except Exception as e:
            print(f"Yol oluşturma hatası: {e}")
            vkn = "???"
            full_path = "HATA"

        self.secili_yol = full_path
        self.secili_vkn = vkn
        
        self.update_info_panel(text, full_path, tip)

    def update_info_panel(self, title, path, tip):
        # Temiz başlık (İkonu kaldır)
        clean_title = title[2:] if len(title) > 2 else title
        self.lbl_info_header.config(text=clean_title)
        
        try:
            total_size = 0
            file_count = 0
            if os.path.exists(path):
                for dirpath, _, filenames in os.walk(path):
                    for f in filenames:
                        fp = os.path.join(dirpath, f)
                        total_size += os.path.getsize(fp)
                        file_count += 1
            
            size_mb = total_size / (1024 * 1024)
            
            # Dinamik Uyarı Metni ve Buton Yazısı
            if tip == "mukellef":
                risk_text = "⚠️ KRİTİK UYARI: Mükellef silinirse;\n1. Tüm dosya ve klasörleri silinir.\n2. Veritabanındaki TÜM NOTLARI silinir.\nBu işlem geri alınamaz!"
                self.btn_delete.config(text="🗑️ MÜKELLEFİ SİL (Dosyalar + Notlar)", bg="#c0392b")
            else:
                risk_text = f"ℹ️ {tip.upper()} silinirse sadece ilgili klasör ve içeriği silinir."
                self.btn_delete.config(text=f"🗑️ {clean_title} SİL", bg="#d63031")
            
            info_text = (
                f"SEÇİM: {clean_title}\n"
                f"KONUM: ...{path[-60:] if len(path)>60 else path}\n\n"
                f"📄 İÇERİK: {file_count} Dosya\n"
                f"💾 BOYUT: {size_mb:.2f} MB\n\n"
                f"{'-'*50}\n{risk_text}\n{'-'*50}"
            )
        except:
            info_text = "Bilgi alınamadı."

        self.info_box.config(text=info_text)
        self.btn_delete.config(state=tk.NORMAL)

    def delete_action(self):
        if not self.secili_yol: return
        
        # Onay Mesajı
        action_msg = "Klasör ve içeriği"
        if self.secili_tip == "mukellef":
            action_msg = "Mükellef kartı, TÜM dosyaları ve VERİTABANI NOTLARI"
            
        onay = messagebox.askyesno(
            "Silme İşlemi Onayı", 
            f"DİKKAT!\n\nSeçilen {self.secili_tip.upper()}: {self.secili_baslik}\n\n{action_msg} kalıcı olarak silinecektir.\n\nBu işlem geri alınamaz. Onaylıyor musunuz?",
            icon='warning'
        )
        
        if onay:
            # 1. Eğer Mükellef ise önce DB'den notları temizle
            db_sonuc = ""
            if self.secili_tip == "mukellef":
                success_db, msg_db = notlari_sil_db(self.secili_vkn)
                if success_db:
                    db_sonuc = f"\n- {msg_db}"
                else:
                    messagebox.showerror("Veritabanı Hatası", f"Notlar silinemedi: {msg_db}")
                    return # DB silinemezse klasörü silme, dur.

            # 2. Klasörü Sil
            success_folder, msg_folder = klasor_sil(self.secili_yol)
            
            if success_folder:
                final_msg = f"✅ İşlem Başarılı.\n- {msg_folder}{db_sonuc}"
                messagebox.showinfo("Tamamlandı", final_msg)
                
                # Arayüzü Temizle
                self.refresh_tree()
                self.info_box.config(text="Silme işlemi tamamlandı. Lütfen yeni bir seçim yapın.")
                self.lbl_info_header.config(text="")
                self.btn_delete.config(state=tk.DISABLED, text="🗑️ SEÇİLİ ÖĞEYİ SİL", bg="#d63031")
            else:
                messagebox.showerror("Hata", f"Klasör silinemedi: {msg_folder}")