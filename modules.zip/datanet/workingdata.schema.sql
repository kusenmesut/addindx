-- SQLite local mirror, adapted from the 18 user-supplied PostgreSQL declarations.

-- These business tables contain no user data at initialization.

CREATE TABLE IF NOT EXISTS work_requests (
  request_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  unit_id INTEGER,
  requester_user_id INTEGER NOT NULL,
  requester_name TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  request_type TEXT NOT NULL DEFAULT 'İş Talebi',
  priority TEXT NOT NULL DEFAULT 'Normal' CHECK (priority IN ('Düşük', 'Normal', 'Yüksek', 'Acil')),
  critical_requested INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Yeni' CHECK (status IN ('Yeni', 'Değerlendiriliyor', 'Kabul Edildi', 'Reddedildi', 'İptal Edildi', 'İş Emrine Dönüştürüldü')),
  work_order_id TEXT,
  decision_by_user_id INTEGER,
  decision_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (request_id)
);

CREATE TABLE IF NOT EXISTS work_orders (
  work_order_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  source_request_id TEXT,
  unit_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'Normal' CHECK (priority IN ('Düşük', 'Normal', 'Yüksek', 'Acil')),
  is_critical INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Atandı' CHECK (status IN ('Sevk Bekliyor', 'Atandı', 'Devam Ediyor', 'Tamamlandı', 'İptal Edildi', 'Silindi', 'Kontrol Bekliyor', 'Düzeltme İstendi', 'Yönetici Onayı', 'Beklemede', 'Reddedildi')),
  approval_status TEXT NOT NULL DEFAULT 'Şef Kontrolü Gerekli',
  requested_by_user_id INTEGER NOT NULL,
  created_by_user_id INTEGER NOT NULL,
  created_by_name TEXT NOT NULL DEFAULT '',
  assigned_by_user_id INTEGER NOT NULL,
  assignee_user_id INTEGER,
  assignee_name TEXT NOT NULL DEFAULT '',
  due_at TEXT,
  submitted_for_review_at TEXT,
  chief_approved_by_user_id INTEGER,
  chief_approved_at TEXT,
  manager_approved_by_user_id INTEGER,
  manager_approved_at TEXT,
  completed_at TEXT,
  status_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (work_order_id)
);

CREATE TABLE IF NOT EXISTS work_order_participants (
  team_id INTEGER NOT NULL,
  work_order_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  participant_role TEXT NOT NULL DEFAULT 'Katılımcı',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (team_id, work_order_id, user_id)
);

CREATE TABLE IF NOT EXISTS work_order_approvals (
  approval_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  work_order_id TEXT NOT NULL,
  approver_user_id INTEGER NOT NULL,
  approver_name TEXT NOT NULL DEFAULT '',
  approval_step TEXT NOT NULL CHECK (approval_step IN ('Şef', 'Yönetici')),
  decision TEXT NOT NULL CHECK (decision IN ('Onaylandı', 'Düzeltme İstendi', 'Reddedildi')),
  note TEXT NOT NULL DEFAULT '',
  decided_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (approval_id)
);

CREATE TABLE IF NOT EXISTS work_order_comments (
  comment_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  work_order_id TEXT NOT NULL,
  author_user_id INTEGER NOT NULL,
  author_name TEXT NOT NULL DEFAULT '',
  comment_type TEXT NOT NULL DEFAULT 'NOT' CHECK (comment_type IN ('NOT', 'TALIMAT', 'SONUC')),
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (comment_id)
);

CREATE TABLE IF NOT EXISTS work_order_events (
  id INTEGER NOT NULL,
  event_id TEXT NOT NULL UNIQUE,
  team_id INTEGER NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  actor_user_id INTEGER NOT NULL,
  actor_name TEXT NOT NULL DEFAULT '',
  event_type TEXT NOT NULL,
  old_status TEXT NOT NULL DEFAULT '',
  new_status TEXT NOT NULL DEFAULT '',
  details TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS work_attachments (
  attachment_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  work_order_id TEXT NOT NULL,
  drive_file_id TEXT NOT NULL,
  drive_url TEXT NOT NULL DEFAULT '',
  file_name TEXT NOT NULL,
  mime_type TEXT NOT NULL DEFAULT 'application/octet-stream',
  uploaded_by_user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (attachment_id)
);

CREATE TABLE IF NOT EXISTS app_notifications (
  notification_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  recipient_user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  entity_type TEXT NOT NULL DEFAULT '',
  entity_id TEXT NOT NULL DEFAULT '',
  priority TEXT NOT NULL DEFAULT 'Normal',
  dedupe_key TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at TEXT,
  PRIMARY KEY (notification_id)
);

CREATE TABLE IF NOT EXISTS notification_outbox (
  outbox_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  recipient_user_id INTEGER NOT NULL,
  recipient_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  entity_type TEXT NOT NULL DEFAULT '',
  entity_id TEXT NOT NULL DEFAULT '',
  dedupe_key TEXT NOT NULL UNIQUE,
  send_after TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status TEXT NOT NULL DEFAULT 'Bekliyor',
  attempt_count INTEGER NOT NULL DEFAULT 0,
  last_error TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sent_at TEXT,
  PRIMARY KEY (outbox_id)
);

CREATE TABLE IF NOT EXISTS knowledge_articles (
  article_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  visibility TEXT NOT NULL DEFAULT 'TEAM' CHECK (visibility IN ('TEAM', 'ORG')),
  status TEXT NOT NULL DEFAULT 'Aday' CHECK (status IN ('Aday', 'Taslak', 'Onay Bekliyor', 'Yayında', 'Reddedildi', 'Silindi')),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Genel',
  source_work_order_id TEXT,
  created_by_user_id INTEGER NOT NULL,
  created_by_name TEXT NOT NULL DEFAULT '',
  reviewed_by_user_id INTEGER,
  reviewed_by_name TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (article_id)
);

CREATE TABLE IF NOT EXISTS knowledge_versions (
  version_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  article_id TEXT NOT NULL,
  version_no INTEGER NOT NULL DEFAULT 1,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  status TEXT NOT NULL,
  changed_by_user_id INTEGER NOT NULL,
  changed_by_name TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (version_id)
);

CREATE TABLE IF NOT EXISTS knowledge_article_messages (
  message_id TEXT NOT NULL,
  article_id TEXT NOT NULL,
  team_id INTEGER NOT NULL,
  source_work_order_id TEXT,
  entry_kind TEXT NOT NULL CHECK (entry_kind IN ('COMMENT', 'EVENT')),
  source_entry_id TEXT NOT NULL DEFAULT '',
  author_user_id INTEGER,
  author_name TEXT NOT NULL DEFAULT 'Kullanıcı',
  comment_type TEXT NOT NULL DEFAULT 'NOT',
  body TEXT NOT NULL DEFAULT '',
  event_type TEXT,
  old_status TEXT,
  new_status TEXT,
  details TEXT NOT NULL DEFAULT '{}',
  source_created_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (message_id),
  FOREIGN KEY (article_id) REFERENCES knowledge_articles(article_id)
);

CREATE TABLE IF NOT EXISTS work_chat_messages (
  message_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  sender_user_id INTEGER NOT NULL,
  sender_name TEXT NOT NULL DEFAULT '',
  sender_role TEXT NOT NULL DEFAULT 'Kullanıcı',
  recipient_type TEXT NOT NULL CHECK (recipient_type IN ('role', 'user')),
  recipient_role TEXT CHECK (recipient_role IS NULL OR recipient_role IN ('Yönetici','Şef','Kullanıcı')),
  recipient_unit_id INTEGER,
  recipient_user_id INTEGER,
  message_text TEXT NOT NULL CHECK (length(message_text) BETWEEN 1 AND 4000),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  attachment_name TEXT,
  attachment_mime TEXT,
  attachment_data_base64 TEXT,
  PRIMARY KEY (message_id)
);

CREATE TABLE IF NOT EXISTS work_chat_groups (
  group_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  group_name TEXT NOT NULL CHECK (length(group_name) BETWEEN 1 AND 100),
  description TEXT NOT NULL DEFAULT '',
  created_by INTEGER NOT NULL,
  created_by_name TEXT NOT NULL DEFAULT '',
  created_by_role TEXT NOT NULL DEFAULT 'Kullanıcı',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (group_id)
);

CREATE TABLE IF NOT EXISTS work_chat_group_members (
  membership_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  group_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  added_by INTEGER NOT NULL,
  added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (membership_id),
  FOREIGN KEY (group_id) REFERENCES work_chat_groups(group_id)
);

CREATE TABLE IF NOT EXISTS work_chat_group_messages (
  message_id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-a' || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
  team_id INTEGER NOT NULL,
  group_id TEXT NOT NULL,
  sender_user_id INTEGER NOT NULL,
  sender_name TEXT NOT NULL DEFAULT '',
  sender_role TEXT NOT NULL DEFAULT 'Kullanıcı',
  message_text TEXT NOT NULL CHECK (length(message_text) BETWEEN 1 AND 4000),
  attachment_name TEXT,
  attachment_mime TEXT,
  attachment_data_base64 TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (message_id),
  FOREIGN KEY (group_id) REFERENCES work_chat_groups(group_id)
);

CREATE TABLE IF NOT EXISTS work_chat_message_reads (
  team_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  message_type TEXT NOT NULL CHECK (message_type IN ('direct', 'group')),
  message_id TEXT NOT NULL,
  read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (team_id, user_id, message_type, message_id)
);

CREATE TABLE IF NOT EXISTS work_chat_read_receipt_migration_state (
  migration_key TEXT NOT NULL,
  applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (migration_key)
);

CREATE TABLE IF NOT EXISTS local_sync_outbox (
          operation_id TEXT PRIMARY KEY NOT NULL,
          team_id INTEGER NOT NULL,
          owner_user_id INTEGER NOT NULL,
          endpoint TEXT NOT NULL,
          payload_json TEXT NOT NULL,
          operation_kind TEXT NOT NULL,
          idempotency_key TEXT NOT NULL UNIQUE,
          status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','inflight','applied','conflict','failed')),
          attempt_count INTEGER NOT NULL DEFAULT 0,
          retry_after TEXT,
          error_message TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

CREATE TABLE IF NOT EXISTS local_sync_cursors (
          team_id INTEGER NOT NULL,
          table_name TEXT NOT NULL,
          last_cursor TEXT,
          last_sync_at TEXT,
          PRIMARY KEY (team_id, table_name)
        );

CREATE TABLE IF NOT EXISTS local_sync_conflicts (
          conflict_id TEXT PRIMARY KEY NOT NULL,
          team_id INTEGER NOT NULL,
          table_name TEXT NOT NULL,
          record_id TEXT NOT NULL,
          local_json TEXT NOT NULL,
          server_json TEXT NOT NULL,
          reason TEXT NOT NULL,
          resolution TEXT,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          resolved_at TEXT
        );

CREATE INDEX IF NOT EXISTS idx_work_requests_team ON work_requests(team_id);

CREATE INDEX IF NOT EXISTS idx_work_requests_team_created ON work_requests(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_work_requests_team_updated ON work_requests(team_id, updated_at);

CREATE INDEX IF NOT EXISTS idx_work_orders_team ON work_orders(team_id);

CREATE INDEX IF NOT EXISTS idx_work_orders_team_created ON work_orders(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_work_orders_team_updated ON work_orders(team_id, updated_at);

CREATE INDEX IF NOT EXISTS idx_work_order_participants_team ON work_order_participants(team_id);

CREATE INDEX IF NOT EXISTS idx_work_order_participants_team_created ON work_order_participants(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_work_order_approvals_team ON work_order_approvals(team_id);

CREATE INDEX IF NOT EXISTS idx_work_order_comments_team ON work_order_comments(team_id);

CREATE INDEX IF NOT EXISTS idx_work_order_comments_team_created ON work_order_comments(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_work_order_events_team ON work_order_events(team_id);

CREATE INDEX IF NOT EXISTS idx_work_order_events_team_created ON work_order_events(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_work_attachments_team ON work_attachments(team_id);

CREATE INDEX IF NOT EXISTS idx_work_attachments_team_created ON work_attachments(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_app_notifications_team ON app_notifications(team_id);

CREATE INDEX IF NOT EXISTS idx_app_notifications_team_created ON app_notifications(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_notification_outbox_team ON notification_outbox(team_id);

CREATE INDEX IF NOT EXISTS idx_notification_outbox_team_created ON notification_outbox(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_knowledge_articles_team ON knowledge_articles(team_id);

CREATE INDEX IF NOT EXISTS idx_knowledge_articles_team_created ON knowledge_articles(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_knowledge_articles_team_updated ON knowledge_articles(team_id, updated_at);

CREATE INDEX IF NOT EXISTS idx_knowledge_article_messages_team ON knowledge_article_messages(team_id);

CREATE INDEX IF NOT EXISTS idx_knowledge_article_messages_team_created ON knowledge_article_messages(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_work_chat_messages_team ON work_chat_messages(team_id);

CREATE INDEX IF NOT EXISTS idx_work_chat_messages_team_created ON work_chat_messages(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_work_chat_groups_team ON work_chat_groups(team_id);

CREATE INDEX IF NOT EXISTS idx_work_chat_groups_team_created ON work_chat_groups(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_work_chat_groups_team_updated ON work_chat_groups(team_id, updated_at);

CREATE INDEX IF NOT EXISTS idx_work_chat_group_members_team ON work_chat_group_members(team_id);

CREATE INDEX IF NOT EXISTS idx_work_chat_group_messages_team ON work_chat_group_messages(team_id);

CREATE INDEX IF NOT EXISTS idx_work_chat_group_messages_team_created ON work_chat_group_messages(team_id, created_at);

CREATE INDEX IF NOT EXISTS idx_work_chat_message_reads_team ON work_chat_message_reads(team_id);

CREATE INDEX IF NOT EXISTS idx_local_sync_outbox_status ON local_sync_outbox(status, retry_after, created_at);

CREATE INDEX IF NOT EXISTS idx_local_sync_outbox_owner ON local_sync_outbox(owner_user_id, team_id);


-- Client-side caches and durable change journal used by LocalWorkDB.
-- These tables are local-only and contain no server credentials.
CREATE TABLE IF NOT EXISTS local_auth_cache (
  session_hash TEXT PRIMARY KEY NOT NULL,
  owner_user_id INTEGER NOT NULL,
  response_json TEXT NOT NULL,
  verified_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS local_api_cache (
  owner_user_id INTEGER NOT NULL,
  team_id INTEGER NOT NULL,
  cache_key TEXT NOT NULL,
  endpoint TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  response_json TEXT NOT NULL,
  response_hash TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (owner_user_id, team_id, cache_key)
);
CREATE TABLE IF NOT EXISTS local_sync_changes (
  change_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  owner_user_id INTEGER NOT NULL,
  table_name TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  operation_id TEXT NOT NULL,
  row_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  applied_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_local_api_cache_endpoint
  ON local_api_cache(owner_user_id, team_id, endpoint);
CREATE INDEX IF NOT EXISTS idx_local_sync_changes_operation
  ON local_sync_changes(operation_id, applied_at);

-- Restored local mirror tables required by LocalWorkDB (missing in uploaded schema).

CREATE TABLE IF NOT EXISTS team_taxpayers (
  taxpayer_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  vkn TEXT NOT NULL,
  unvan TEXT NOT NULL DEFAULT '',
  created_by_user_id INTEGER,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(team_id, vkn)
);

CREATE TABLE IF NOT EXISTS taxpayer_files (
  taxpayer_file_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  taxpayer_id TEXT NOT NULL,
  fiscal_year TEXT NOT NULL DEFAULT '',
  file_kind TEXT NOT NULL DEFAULT 'Arşiv Dosyası',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(team_id, taxpayer_id, fiscal_year, file_kind)
);

CREATE TABLE IF NOT EXISTS taxpayer_file_versions (
  file_version_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  taxpayer_file_id TEXT NOT NULL,
  version_key TEXT NOT NULL,
  file_name TEXT NOT NULL DEFAULT '',
  version_label TEXT NOT NULL DEFAULT '',
  source_ref TEXT NOT NULL DEFAULT '',
  created_by_user_id INTEGER,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(team_id, taxpayer_file_id, version_key)
);

CREATE TABLE IF NOT EXISTS work_order_taxpayer_files (
  link_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  work_order_id TEXT NOT NULL,
  taxpayer_file_id TEXT NOT NULL,
  file_version_id TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(team_id, work_order_id)
);

CREATE TABLE IF NOT EXISTS work_checklist_templates (
  template_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Yayında',
  version_no INTEGER NOT NULL DEFAULT 1,
  created_by_user_id INTEGER NOT NULL,
  created_by_name TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS work_checklist_template_items (
  template_item_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  template_id TEXT NOT NULL,
  sequence_no INTEGER NOT NULL DEFAULT 0,
  stage_code TEXT NOT NULL DEFAULT 'Her Aşama',
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  input_type TEXT NOT NULL DEFAULT 'Uygunluk',
  is_required INTEGER NOT NULL DEFAULT 1,
  requires_explanation INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS work_order_checklists (
  checklist_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  work_order_id TEXT NOT NULL,
  template_id TEXT,
  template_version INTEGER NOT NULL DEFAULT 1,
  template_name TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Aktif',
  created_by_user_id INTEGER NOT NULL,
  created_by_name TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS work_order_checklist_items (
  item_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  checklist_id TEXT NOT NULL,
  work_order_id TEXT NOT NULL,
  template_item_id TEXT,
  sequence_no INTEGER NOT NULL DEFAULT 0,
  stage_code TEXT NOT NULL DEFAULT 'Her Aşama',
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  input_type TEXT NOT NULL DEFAULT 'Uygunluk',
  is_required INTEGER NOT NULL DEFAULT 1,
  requires_explanation INTEGER NOT NULL DEFAULT 0,
  result_code TEXT NOT NULL DEFAULT 'Bekliyor',
  explanation TEXT NOT NULL DEFAULT '',
  revision INTEGER NOT NULL DEFAULT 0,
  updated_by_user_id INTEGER,
  updated_by_name TEXT NOT NULL DEFAULT '',
  updated_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS work_order_checklist_events (
  event_id TEXT PRIMARY KEY NOT NULL,
  team_id INTEGER NOT NULL,
  work_order_id TEXT NOT NULL,
  checklist_id TEXT NOT NULL,
  item_id TEXT NOT NULL,
  operation_id TEXT NOT NULL DEFAULT '',
  actor_user_id INTEGER NOT NULL,
  actor_name TEXT NOT NULL DEFAULT '',
  event_type TEXT NOT NULL,
  old_result TEXT NOT NULL DEFAULT '',
  new_result TEXT NOT NULL DEFAULT '',
  explanation TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Supporting indexes for restored tables.

CREATE INDEX IF NOT EXISTS idx_team_taxpayers_team_vkn ON team_taxpayers(team_id, vkn);
CREATE INDEX IF NOT EXISTS idx_taxpayer_files_team_year ON taxpayer_files(team_id, fiscal_year);
CREATE INDEX IF NOT EXISTS idx_work_order_taxpayer_files_order ON work_order_taxpayer_files(team_id, work_order_id);
CREATE INDEX IF NOT EXISTS idx_work_checklist_templates_team ON work_checklist_templates(team_id, status, updated_at);
CREATE INDEX IF NOT EXISTS idx_work_checklist_template_items_template ON work_checklist_template_items(team_id, template_id, sequence_no);
CREATE INDEX IF NOT EXISTS idx_work_order_checklists_order ON work_order_checklists(team_id, work_order_id, status);
CREATE INDEX IF NOT EXISTS idx_work_order_checklist_items_order ON work_order_checklist_items(team_id, work_order_id, checklist_id, sequence_no);
CREATE INDEX IF NOT EXISTS idx_work_order_checklist_events_order ON work_order_checklist_events(team_id, work_order_id, created_at);
